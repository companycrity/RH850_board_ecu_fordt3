#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordCanDtcInhb(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Ip_FordCanDtcInhb;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Ip_FordCanDtcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordEpsLifeCycMod(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Ip_FordEpsLifeCycMod;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Ip_FordEpsLifeCycMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordInvldMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Ip_FordInvldMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Ip_FordInvldMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordMfgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Ip_FordMfgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Ip_FordMfgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordMissMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Ip_FordMissMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Ip_FordMissMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordTrlrBackUpAssiEnad(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Ip_FordTrlrBackUpAssiEnad;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Ip_FordTrlrBackUpAssiEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldFaildThd(void)
{
    extern __PST__g__32 FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldMissThd(void)
{
    extern __PST__g__32 FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldPassdThd(void)
{
    extern __PST__g__32 FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdInvldSigFaildThd(void)
{
    extern __PST__g__32 FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdInvldSigFaildThd;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdInvldSigFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdInvldSigPassdThd(void)
{
    extern __PST__g__32 FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdInvldSigPassdThd;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdInvldSigPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdMissMsgFaildThd(void)
{
    extern __PST__g__32 FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdMissMsgFaildThd;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdMissMsgFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdMissMsgPassdThd(void)
{
    extern __PST__g__32 FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdMissMsgPassdThd;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdMissMsgPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_ClrDiagcFlgProxyPrev(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Pim_ClrDiagcFlgProxyPrev;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_ClrDiagcFlgProxyPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FirstTranVldFlg(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Pim_FirstTranVldFlg;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_FirstTranVldFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehIgnStsInvldSigFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg3B3BusHiSpd_Pim_FordVehIgnStsInvldSigFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_FordVehIgnStsInvldSigFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehIgnStsInvldSigPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg3B3BusHiSpd_Pim_FordVehIgnStsInvldSigPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_FordVehIgnStsInvldSigPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehIgnStsPrev(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Pim_FordVehIgnStsPrev;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_FordVehIgnStsPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehIgnStsVldPrev(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Pim_FordVehIgnStsVldPrev;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_FordVehIgnStsVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehLifeCycModPrev(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Pim_FordVehLifeCycModPrev;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_FordVehLifeCycModPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehMsg3B3Miss(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Pim_FordVehMsg3B3Miss;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_FordVehMsg3B3Miss = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehMsg3B3Rxd(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Pim_FordVehMsg3B3Rxd;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_FordVehMsg3B3Rxd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_IgnStsVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg3B3BusHiSpd_Pim_IgnStsVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_IgnStsVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_IgnStsVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg3B3BusHiSpd_Pim_IgnStsVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_IgnStsVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_IgnStsVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg3B3BusHiSpd_Pim_IgnStsVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_IgnStsVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_MissMsgFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg3B3BusHiSpd_Pim_MissMsgFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_MissMsgFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_MissMsgPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg3B3BusHiSpd_Pim_MissMsgPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Pim_MissMsgPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 FordMsg3B3BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 FordMsg3B3BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg3B3BusHiSpd_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 FordMsg3B3BusHiSpd_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        FordMsg3B3BusHiSpd_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FordMsg3B3BusHiSpd_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_ClrDiagcFlgProxy();
    
    /* init for variable FordMsg3B3BusHiSpd_Ip_FordCanDtcInhb */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordCanDtcInhb();
    
    /* init for variable FordMsg3B3BusHiSpd_Ip_FordEpsLifeCycMod */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordEpsLifeCycMod();
    
    /* init for variable FordMsg3B3BusHiSpd_Ip_FordInvldMsgDiagcInhb */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordInvldMsgDiagcInhb();
    
    /* init for variable FordMsg3B3BusHiSpd_Ip_FordMfgDiagcInhb */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordMfgDiagcInhb();
    
    /* init for variable FordMsg3B3BusHiSpd_Ip_FordMissMsgDiagcInhb */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordMissMsgDiagcInhb();
    
    /* init for variable FordMsg3B3BusHiSpd_Ip_FordTrlrBackUpAssiEnad */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Ip_FordTrlrBackUpAssiEnad();
    
    /* init for variable FordMsg3B3BusHiSpd_Op_FordVehIgnStsVld : useless (never read) */

    /* init for variable FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldFaildThd */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldFaildThd();
    
    /* init for variable FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldMissThd */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldMissThd();
    
    /* init for variable FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldPassdThd */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdIgnStsVldPassdThd();
    
    /* init for variable FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdInvldSigFaildThd */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdInvldSigFaildThd();
    
    /* init for variable FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdInvldSigPassdThd */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdInvldSigPassdThd();
    
    /* init for variable FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdMissMsgFaildThd */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdMissMsgFaildThd();
    
    /* init for variable FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdMissMsgPassdThd */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Cal_FordMsg3B3BusHiSpdMissMsgPassdThd();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_ClrDiagcFlgProxyPrev */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_ClrDiagcFlgProxyPrev();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_FirstTranVldFlg */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FirstTranVldFlg();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_FordVehIgnStsInvldSigFaildRefTi */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehIgnStsInvldSigFaildRefTi();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_FordVehIgnStsInvldSigPassdRefTi */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehIgnStsInvldSigPassdRefTi();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_FordVehIgnStsPrev */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehIgnStsPrev();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_FordVehIgnStsVldPrev */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehIgnStsVldPrev();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_FordVehLifeCycModPrev */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehLifeCycModPrev();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_FordVehMsg3B3Miss */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehMsg3B3Miss();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_FordVehMsg3B3Rxd */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_FordVehMsg3B3Rxd();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_IgnStsVldFaildRefTi */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_IgnStsVldFaildRefTi();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_IgnStsVldMissRefTi */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_IgnStsVldMissRefTi();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_IgnStsVldPassdRefTi */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_IgnStsVldPassdRefTi();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_MissMsgFaildRefTi */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_MissMsgFaildRefTi();
    
    /* init for variable FordMsg3B3BusHiSpd_Pim_MissMsgPassdRefTi */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Pim_MissMsgPassdRefTi();
    
    /* init for variable FordMsg3B3BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable FordMsg3B3BusHiSpd_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable FordMsg3B3BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable FordMsg3B3BusHiSpd_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable FordMsg3B3BusHiSpd_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable FordMsg3B3BusHiSpd_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable FordMsg3B3BusHiSpd_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable FordMsg3B3BusHiSpd_Srv_SetNtcSts_Return */
    _main_gen_init_sym_FordMsg3B3BusHiSpd_Srv_SetNtcSts_Return();
    
}
