#ifndef FLTINJ_H
#define FLTINJ_H

/* Fault Injection Command */
#define FLTINJ_CURRMEASCORRLN_CURRMEASIDPTSIG   (42U)
#define FLTINJENA STD_OFF

#endif
