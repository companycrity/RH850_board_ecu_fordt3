#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_CurrMeasCorrln_Ip_DiagcStsIvtr1Inactv(void)
{
    extern __PST__UINT8 CurrMeasCorrln_Ip_DiagcStsIvtr1Inactv;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Ip_DiagcStsIvtr1Inactv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Ip_MotCurrCorrdA(void)
{
    extern __PST__FLOAT32 CurrMeasCorrln_Ip_MotCurrCorrdA;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Ip_MotCurrCorrdA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Ip_MotCurrCorrdB(void)
{
    extern __PST__FLOAT32 CurrMeasCorrln_Ip_MotCurrCorrdB;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Ip_MotCurrCorrdB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Ip_MotCurrCorrdC(void)
{
    extern __PST__FLOAT32 CurrMeasCorrln_Ip_MotCurrCorrdC;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Ip_MotCurrCorrdC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Ip_MotCurrEolCalSt(void)
{
    extern __PST__UINT8 CurrMeasCorrln_Ip_MotCurrEolCalSt;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Ip_MotCurrEolCalSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Ip_MotCurrRollgCntr1(void)
{
    extern __PST__UINT8 CurrMeasCorrln_Ip_MotCurrRollgCntr1;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Ip_MotCurrRollgCntr1 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Ip_SysSt(void)
{
    extern __PST__UINT8 CurrMeasCorrln_Ip_SysSt;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Cal_CurrMeasCorrlnMaxErrCurr(void)
{
    extern __PST__g__25 CurrMeasCorrln_Cal_CurrMeasCorrlnMaxErrCurr;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Cal_CurrMeasCorrlnMaxErrCurr = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Cal_CurrMeasCorrlnMaxStallCntr(void)
{
    extern __PST__g__26 CurrMeasCorrln_Cal_CurrMeasCorrlnMaxStallCntr;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Cal_CurrMeasCorrlnMaxStallCntr = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Cal_CurrMeasCorrlnNtc0x04DFailStep(void)
{
    extern __PST__g__27 CurrMeasCorrln_Cal_CurrMeasCorrlnNtc0x04DFailStep;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Cal_CurrMeasCorrlnNtc0x04DFailStep = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Cal_CurrMeasCorrlnNtc0x04DPassStep(void)
{
    extern __PST__g__27 CurrMeasCorrln_Cal_CurrMeasCorrlnNtc0x04DPassStep;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Cal_CurrMeasCorrlnNtc0x04DPassStep = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Pim_LongTermCorrlnStsABC(void)
{
    extern __PST__UINT8 CurrMeasCorrln_Pim_LongTermCorrlnStsABC;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Pim_LongTermCorrlnStsABC = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Pim_Snsr0RollgCntPrev(void)
{
    extern __PST__UINT8 CurrMeasCorrln_Pim_Snsr0RollgCntPrev;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Pim_Snsr0RollgCntPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Pim_Snsr0StallCntPrev(void)
{
    extern __PST__UINT8 CurrMeasCorrln_Pim_Snsr0StallCntPrev;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Pim_Snsr0StallCntPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 CurrMeasCorrln_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 CurrMeasCorrln_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeasCorrln_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 CurrMeasCorrln_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        CurrMeasCorrln_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable CurrMeasCorrln_Ip_DiagcStsIvtr1Inactv */
    _main_gen_init_sym_CurrMeasCorrln_Ip_DiagcStsIvtr1Inactv();
    
    /* init for variable CurrMeasCorrln_Ip_MotCurrCorrdA */
    _main_gen_init_sym_CurrMeasCorrln_Ip_MotCurrCorrdA();
    
    /* init for variable CurrMeasCorrln_Ip_MotCurrCorrdB */
    _main_gen_init_sym_CurrMeasCorrln_Ip_MotCurrCorrdB();
    
    /* init for variable CurrMeasCorrln_Ip_MotCurrCorrdC */
    _main_gen_init_sym_CurrMeasCorrln_Ip_MotCurrCorrdC();
    
    /* init for variable CurrMeasCorrln_Ip_MotCurrEolCalSt */
    _main_gen_init_sym_CurrMeasCorrln_Ip_MotCurrEolCalSt();
    
    /* init for variable CurrMeasCorrln_Ip_MotCurrRollgCntr1 */
    _main_gen_init_sym_CurrMeasCorrln_Ip_MotCurrRollgCntr1();
    
    /* init for variable CurrMeasCorrln_Ip_SysSt */
    _main_gen_init_sym_CurrMeasCorrln_Ip_SysSt();
    
    /* init for variable CurrMeasCorrln_Op_CurrMeasCorrlnSts : useless (never read) */

    /* init for variable CurrMeasCorrln_Op_CurrMeasIdptSig : useless (never read) */

    /* init for variable CurrMeasCorrln_Op_CurrMotSumABC : useless (never read) */

    /* init for variable CurrMeasCorrln_Cal_CurrMeasCorrlnMaxErrCurr */
    _main_gen_init_sym_CurrMeasCorrln_Cal_CurrMeasCorrlnMaxErrCurr();
    
    /* init for variable CurrMeasCorrln_Cal_CurrMeasCorrlnMaxStallCntr */
    _main_gen_init_sym_CurrMeasCorrln_Cal_CurrMeasCorrlnMaxStallCntr();
    
    /* init for variable CurrMeasCorrln_Cal_CurrMeasCorrlnNtc0x04DFailStep */
    _main_gen_init_sym_CurrMeasCorrln_Cal_CurrMeasCorrlnNtc0x04DFailStep();
    
    /* init for variable CurrMeasCorrln_Cal_CurrMeasCorrlnNtc0x04DPassStep */
    _main_gen_init_sym_CurrMeasCorrln_Cal_CurrMeasCorrlnNtc0x04DPassStep();
    
    /* init for variable CurrMeasCorrln_Pim_LongTermCorrlnStsABC */
    _main_gen_init_sym_CurrMeasCorrln_Pim_LongTermCorrlnStsABC();
    
    /* init for variable CurrMeasCorrln_Pim_Snsr0RollgCntPrev */
    _main_gen_init_sym_CurrMeasCorrln_Pim_Snsr0RollgCntPrev();
    
    /* init for variable CurrMeasCorrln_Pim_Snsr0StallCntPrev */
    _main_gen_init_sym_CurrMeasCorrln_Pim_Snsr0StallCntPrev();
    
    /* init for variable CurrMeasCorrln_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable CurrMeasCorrln_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_CurrMeasCorrln_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable CurrMeasCorrln_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_CurrMeasCorrln_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable CurrMeasCorrln_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable CurrMeasCorrln_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable CurrMeasCorrln_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable CurrMeasCorrln_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable CurrMeasCorrln_Srv_SetNtcSts_Return */
    _main_gen_init_sym_CurrMeasCorrln_Srv_SetNtcSts_Return();
    
}
