#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__110 _main_gen_init_g110(void);

extern union __PST__g__108 _main_gen_init_g108(void);

extern union __PST__g__84 _main_gen_init_g84(void);

extern struct __PST__g__77 _main_gen_init_g77(void);

extern union __PST__g__76 _main_gen_init_g76(void);

extern struct __PST__g__74 _main_gen_init_g74(void);

extern union __PST__g__72 _main_gen_init_g72(void);

extern union __PST__g__67 _main_gen_init_g67(void);

extern union __PST__g__63 _main_gen_init_g63(void);

extern union __PST__g__60 _main_gen_init_g60(void);

extern union __PST__g__57 _main_gen_init_g57(void);

extern union __PST__g__53 _main_gen_init_g53(void);

extern union __PST__g__48 _main_gen_init_g48(void);

extern union __PST__g__40 _main_gen_init_g40(void);

extern __PST__g__38 _main_gen_init_g38(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__36 _main_gen_init_g36(void);

extern __PST__g__35 _main_gen_init_g35(void);

extern __PST__SINT8 _main_gen_init_g2(void);

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__g__35 _main_gen_init_g35(void)
{
    __PST__g__35 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__36 _main_gen_init_g36(void)
{
    static struct __PST__g__36 x;
    /* struct/union type */
    x.OffsTrim = _main_gen_init_g10();
    x.OffsTrimPrfmdSts = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__40 _main_gen_init_g40(void)
{
    static union __PST__g__40 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__48 _main_gen_init_g48(void)
{
    static union __PST__g__48 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__53 _main_gen_init_g53(void)
{
    static union __PST__g__53 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__57 _main_gen_init_g57(void)
{
    static union __PST__g__57 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__60 _main_gen_init_g60(void)
{
    static union __PST__g__60 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__63 _main_gen_init_g63(void)
{
    static union __PST__g__63 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__67 _main_gen_init_g67(void)
{
    static union __PST__g__67 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__74 _main_gen_init_g74(void)
{
    static struct __PST__g__74 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FRS = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRS = bitf;
    }
    return x;
}

union __PST__g__72 _main_gen_init_g72(void)
{
    static union __PST__g__72 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g74();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__77 _main_gen_init_g77(void)
{
    static struct __PST__g__77 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRC = bitf;
    }
    return x;
}

union __PST__g__76 _main_gen_init_g76(void)
{
    static union __PST__g__76 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g77();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__84 _main_gen_init_g84(void)
{
    static union __PST__g__84 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__110 _main_gen_init_g110(void)
{
    static struct __PST__g__110 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FND = bitf;
    }
    return x;
}

union __PST__g__108 _main_gen_init_g108(void)
{
    static union __PST__g__108 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g110();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__38 _main_gen_init_g38(void)
{
    __PST__g__38 x;
    /* struct/union type */
    x.TSPC = _main_gen_init_g40();
    x._CC = _main_gen_init_g48();
    x.BRP = _main_gen_init_g53();
    x.IDE = _main_gen_init_g57();
    x.MDC = _main_gen_init_g60();
    x.SPCT = _main_gen_init_g63();
    x.MST = _main_gen_init_g67();
    x.CS = _main_gen_init_g72();
    x.CSC = _main_gen_init_g76();
    x.SRXD = _main_gen_init_g84();
    x.FRXD = _main_gen_init_g108();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_HwTq8Meas_Ip_HwTq8Polarity(void)
{
    extern __PST__SINT8 HwTq8Meas_Ip_HwTq8Polarity;
    
    /* initialization with random value */
    {
        HwTq8Meas_Ip_HwTq8Polarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Cal_HwTq8MeasHwTq8PrtclFltFailStep(void)
{
    extern __PST__g__35 HwTq8Meas_Cal_HwTq8MeasHwTq8PrtclFltFailStep;
    
    /* initialization with random value */
    {
        HwTq8Meas_Cal_HwTq8MeasHwTq8PrtclFltFailStep = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Cal_HwTq8MeasHwTq8PrtclFltPassStep(void)
{
    extern __PST__g__35 HwTq8Meas_Cal_HwTq8MeasHwTq8PrtclFltPassStep;
    
    /* initialization with random value */
    {
        HwTq8Meas_Cal_HwTq8MeasHwTq8PrtclFltPassStep = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_HwTq8Offs(void)
{
    extern struct __PST__g__36 HwTq8Meas_Pim_HwTq8Offs;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_HwTq8Offs = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_HwTq8ComStsErrCntr(void)
{
    extern __PST__UINT8 HwTq8Meas_Pim_HwTq8ComStsErrCntr;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_HwTq8ComStsErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_HwTq8IntSnsrErrCntr(void)
{
    extern __PST__UINT8 HwTq8Meas_Pim_HwTq8IntSnsrErrCntr;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_HwTq8IntSnsrErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_HwTq8MsgMissRxCnt(void)
{
    extern __PST__UINT32 HwTq8Meas_Pim_HwTq8MsgMissRxCnt;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_HwTq8MsgMissRxCnt = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_HwTq8PrevHwTq8(void)
{
    extern __PST__FLOAT32 HwTq8Meas_Pim_HwTq8PrevHwTq8;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_HwTq8PrevHwTq8 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_HwTq8PrevRollgCntr(void)
{
    extern __PST__UINT8 HwTq8Meas_Pim_HwTq8PrevRollgCntr;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_HwTq8PrevRollgCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_RackLimrCcwEot8(void)
{
    extern __PST__FLOAT32 HwTq8Meas_Pim_RackLimrCcwEot8;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_RackLimrCcwEot8 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_RackLimrCwEot8(void)
{
    extern __PST__FLOAT32 HwTq8Meas_Pim_RackLimrCwEot8;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_RackLimrCwEot8 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Avl(void)
{
    extern __PST__UINT8 HwTq8Meas_Pim_RackLimrEot8Avl;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_RackLimrEot8Avl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Data0(void)
{
    extern __PST__UINT8 HwTq8Meas_Pim_RackLimrEot8Data0;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_RackLimrEot8Data0 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Data1(void)
{
    extern __PST__UINT8 HwTq8Meas_Pim_RackLimrEot8Data1;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_RackLimrEot8Data1 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Data2(void)
{
    extern __PST__UINT8 HwTq8Meas_Pim_RackLimrEot8Data2;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_RackLimrEot8Data2 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Id2DataReadCmpl(void)
{
    extern __PST__UINT8 HwTq8Meas_Pim_RackLimrEot8Id2DataReadCmpl;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_RackLimrEot8Id2DataReadCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Id3DataReadCmpl(void)
{
    extern __PST__UINT8 HwTq8Meas_Pim_RackLimrEot8Id3DataReadCmpl;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_RackLimrEot8Id3DataReadCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Id4DataReadCmpl(void)
{
    extern __PST__UINT8 HwTq8Meas_Pim_RackLimrEot8Id4DataReadCmpl;
    
    /* initialization with random value */
    {
        HwTq8Meas_Pim_RackLimrEot8Id4DataReadCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RSENT4(void)
{
    extern __PST__g__38 RSENT4;
    
    /* initialization with random value */
    {
        RSENT4 = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Srv_CnvSnpshtData_u08_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 HwTq8Meas_Srv_CnvSnpshtData_u08_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        HwTq8Meas_Srv_CnvSnpshtData_u08_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 HwTq8Meas_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        HwTq8Meas_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 HwTq8Meas_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        HwTq8Meas_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 HwTq8Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        HwTq8Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 HwTq8Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        HwTq8Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Srv_HwTq8Offs_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 HwTq8Meas_Srv_HwTq8Offs_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        HwTq8Meas_Srv_HwTq8Offs_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Srv_IoHwAb_SetFctPrphlHwTq8_Return(void)
{
    extern __PST__UINT8 HwTq8Meas_Srv_IoHwAb_SetFctPrphlHwTq8_Return;
    
    /* initialization with random value */
    {
        HwTq8Meas_Srv_IoHwAb_SetFctPrphlHwTq8_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Srv_SetNtcStsAndSnpshtData_Return(void)
{
    extern __PST__UINT8 HwTq8Meas_Srv_SetNtcStsAndSnpshtData_Return;
    
    /* initialization with random value */
    {
        HwTq8Meas_Srv_SetNtcStsAndSnpshtData_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Cli_HwTq8ReadTrim_HwTqReadTrimData(void)
{
    extern __PST__FLOAT32 HwTq8Meas_Cli_HwTq8ReadTrim_HwTqReadTrimData;
    
    /* initialization with random value */
    {
        HwTq8Meas_Cli_HwTq8ReadTrim_HwTqReadTrimData = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Cli_HwTq8TrimPrfmdSts_HwTqOffsTrimPrfmdStsData(void)
{
    extern __PST__UINT8 HwTq8Meas_Cli_HwTq8TrimPrfmdSts_HwTqOffsTrimPrfmdStsData;
    
    /* initialization with random value */
    {
        HwTq8Meas_Cli_HwTq8TrimPrfmdSts_HwTqOffsTrimPrfmdStsData = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq8Meas_Cli_HwTq8WrTrim_HwTqWrOffsTrimData(void)
{
    extern __PST__FLOAT32 HwTq8Meas_Cli_HwTq8WrTrim_HwTqWrOffsTrimData;
    
    /* initialization with random value */
    {
        HwTq8Meas_Cli_HwTq8WrTrim_HwTqWrOffsTrimData = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable HwTq8Meas_Ip_HwTq8Polarity */
    _main_gen_init_sym_HwTq8Meas_Ip_HwTq8Polarity();
    
    /* init for variable HwTq8Meas_Op_HwTq8 : useless (never read) */

    /* init for variable HwTq8Meas_Op_HwTq8Qlfr : useless (never read) */

    /* init for variable HwTq8Meas_Op_HwTq8RollgCntr : useless (never read) */

    /* init for variable HwTq8Meas_Op_RackLimrCcwEotSig8 : useless (never read) */

    /* init for variable HwTq8Meas_Op_RackLimrCwEotSig8 : useless (never read) */

    /* init for variable HwTq8Meas_Op_RackLimrEotSig8Avl : useless (never read) */

    /* init for variable HwTq8Meas_Cal_HwTq8MeasHwTq8PrtclFltFailStep */
    _main_gen_init_sym_HwTq8Meas_Cal_HwTq8MeasHwTq8PrtclFltFailStep();
    
    /* init for variable HwTq8Meas_Cal_HwTq8MeasHwTq8PrtclFltPassStep */
    _main_gen_init_sym_HwTq8Meas_Cal_HwTq8MeasHwTq8PrtclFltPassStep();
    
    /* init for variable HwTq8Meas_Pim_HwTq8Offs */
    _main_gen_init_sym_HwTq8Meas_Pim_HwTq8Offs();
    
    /* init for variable HwTq8Meas_Pim_HwTq8ComStsErrCntr */
    _main_gen_init_sym_HwTq8Meas_Pim_HwTq8ComStsErrCntr();
    
    /* init for variable HwTq8Meas_Pim_HwTq8IntSnsrErrCntr */
    _main_gen_init_sym_HwTq8Meas_Pim_HwTq8IntSnsrErrCntr();
    
    /* init for variable HwTq8Meas_Pim_HwTq8MsgMissRxCnt */
    _main_gen_init_sym_HwTq8Meas_Pim_HwTq8MsgMissRxCnt();
    
    /* init for variable HwTq8Meas_Pim_HwTq8PrevHwTq8 */
    _main_gen_init_sym_HwTq8Meas_Pim_HwTq8PrevHwTq8();
    
    /* init for variable HwTq8Meas_Pim_HwTq8PrevRollgCntr */
    _main_gen_init_sym_HwTq8Meas_Pim_HwTq8PrevRollgCntr();
    
    /* init for variable HwTq8Meas_Pim_RackLimrCcwEot8 */
    _main_gen_init_sym_HwTq8Meas_Pim_RackLimrCcwEot8();
    
    /* init for variable HwTq8Meas_Pim_RackLimrCwEot8 */
    _main_gen_init_sym_HwTq8Meas_Pim_RackLimrCwEot8();
    
    /* init for variable HwTq8Meas_Pim_RackLimrEot8Avl */
    _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Avl();
    
    /* init for variable HwTq8Meas_Pim_RackLimrEot8Data0 */
    _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Data0();
    
    /* init for variable HwTq8Meas_Pim_RackLimrEot8Data1 */
    _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Data1();
    
    /* init for variable HwTq8Meas_Pim_RackLimrEot8Data2 */
    _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Data2();
    
    /* init for variable HwTq8Meas_Pim_RackLimrEot8Id2DataReadCmpl */
    _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Id2DataReadCmpl();
    
    /* init for variable HwTq8Meas_Pim_RackLimrEot8Id3DataReadCmpl */
    _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Id3DataReadCmpl();
    
    /* init for variable HwTq8Meas_Pim_RackLimrEot8Id4DataReadCmpl */
    _main_gen_init_sym_HwTq8Meas_Pim_RackLimrEot8Id4DataReadCmpl();
    
    /* init for variable RSENT4 */
    _main_gen_init_sym_RSENT4();
    
    /* init for variable HwTq8Meas_Srv_CnvSnpshtData_u08_SnpshtDataCnvd */
    _main_gen_init_sym_HwTq8Meas_Srv_CnvSnpshtData_u08_SnpshtDataCnvd();
    
    /* init for variable HwTq8Meas_Srv_CnvSnpshtData_u08_SnpshtData : useless (never read) */

    /* init for variable HwTq8Meas_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable HwTq8Meas_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_HwTq8Meas_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable HwTq8Meas_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_HwTq8Meas_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable HwTq8Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr */
    _main_gen_init_sym_HwTq8Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr();
    
    /* init for variable HwTq8Meas_Srv_GetTiSpan1MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable HwTq8Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan */
    _main_gen_init_sym_HwTq8Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan();
    
    /* init for variable HwTq8Meas_Srv_HwTq8Offs_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable HwTq8Meas_Srv_HwTq8Offs_SetRamBlockStatus_Return */
    _main_gen_init_sym_HwTq8Meas_Srv_HwTq8Offs_SetRamBlockStatus_Return();
    
    /* init for variable HwTq8Meas_Srv_IoHwAb_SetFctPrphlHwTq8_Return */
    _main_gen_init_sym_HwTq8Meas_Srv_IoHwAb_SetFctPrphlHwTq8_Return();
    
    /* init for variable HwTq8Meas_Srv_SetNtcStsAndSnpshtData_NtcNr : useless (never read) */

    /* init for variable HwTq8Meas_Srv_SetNtcStsAndSnpshtData_NtcStInfo : useless (never read) */

    /* init for variable HwTq8Meas_Srv_SetNtcStsAndSnpshtData_NtcSts : useless (never read) */

    /* init for variable HwTq8Meas_Srv_SetNtcStsAndSnpshtData_DebStep : useless (never read) */

    /* init for variable HwTq8Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData0 : useless (never read) */

    /* init for variable HwTq8Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData1 : useless (never read) */

    /* init for variable HwTq8Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData2 : useless (never read) */

    /* init for variable HwTq8Meas_Srv_SetNtcStsAndSnpshtData_Return */
    _main_gen_init_sym_HwTq8Meas_Srv_SetNtcStsAndSnpshtData_Return();
    
    /* init for variable HwTq8Meas_Cli_HwTq8ReadTrim_HwTqReadTrimData */
    _main_gen_init_sym_HwTq8Meas_Cli_HwTq8ReadTrim_HwTqReadTrimData();
    
    /* init for variable HwTq8Meas_Cli_HwTq8TrimPrfmdSts_HwTqOffsTrimPrfmdStsData */
    _main_gen_init_sym_HwTq8Meas_Cli_HwTq8TrimPrfmdSts_HwTqOffsTrimPrfmdStsData();
    
    /* init for variable HwTq8Meas_Cli_HwTq8WrTrim_HwTqWrOffsTrimData */
    _main_gen_init_sym_HwTq8Meas_Cli_HwTq8WrTrim_HwTqWrOffsTrimData();
    
}
