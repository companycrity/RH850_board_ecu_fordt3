/* Header file for contract folder of CM650A */

#ifndef ELECGLBPRM_H    /* Multiple include preventer */
#define ELECGLBPRM_H

#define ELECGLBPRM_HWTQOFFS_HWNWTMTR_F32                        10.0F
#define ELECGLBPRM_HWTQSATNLOWRLIM_HWNWTMTR_F32         (-10.0F)
#define ELECGLBPRM_HWTQSATNUPPRLIM_HWNWTMTR_F32         10.0F
#define ELECGLBPRM_HWTQSCA_ULS_F32                                      0.004884005F
#define ELECGLBPRM_NOFLT_CNT_U08                                        0U
#define ELECGLBPRM_OFFSTRIMNOTPRFMD_CNT_U08                     1U
#define ELECGLBPRM_PRTCLFLT_CNT_U08                                     1U
#define ELECGLBPRM_SNSRINTFLT_CNT_U08                           2U
#define ELECGLBPRM_SENTCOMSTSFRSMASK_CNT_U32            ((uint32)0x1U)
#define ELECGLBPRM_HWTQSENTBUFSIZE_CNT_U08                      ((uint8)4U)
#define ELECGLBPRM_SENTCOMSTSCLR_CNT_U32                        ((uint32)0x07FEU)
#define ELECGLBPRM_HWTQSNSRTICKCNT_CNT_U08                      17U
#define ELECGLBPRM_SENTSLOWRXDATAMASK_CNT_U32           ((uint32)0xFFU)
#define ELECGLBPRM_SENTCOMSTSERRMASK_CNT_U32            ((uint32)0xFEU)
#define ELECGLBPRM_SENTFASTRXNFCCNMASK_CNT_U32          ((uint32)0x30000000U)
#define ELECGLBPRM_SENTFASTRXNDATAMASK_CNT_U32          ((uint32)0xFFFU)
#define ELECGLBPRM_HWTQMINLIM_HWNWTMTR_F32              ((float32)-10.0F)
#define ELECGLBPRM_HWTQMAXLIM_HWNWTMTR_F32              ((float32)10.0F)
#define ELECGLBPRM_SENTSLOWRXDATAIDMASK_CNT_U32         ((uint32)0xF00U)
#define ELECGLBPRM_SENTSLOWRXDATAMASK_CNT_U32           ((uint32)0xFFU)
#define ELECGLBPRM_SENTCOMSTSSLOWMASK_CNT_U32           ((uint32)0x700U)
#define ELECGLBPRM_SENTFASTRXSNDMASK_CNT_U32            ((uint32)0x80000000U)
#endif
