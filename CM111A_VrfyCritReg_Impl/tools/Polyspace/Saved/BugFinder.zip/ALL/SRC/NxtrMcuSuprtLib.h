/******************************************* Multiple Include Protection *********************************************/
#ifndef NXTRMCUSUPRTLIB_H
#define NXTRMCUSUPRTLIB_H

extern INLINE FUNC(void, NxtrMcuSuprtLib_CODE) WrProtdRegEcm_u32(uint32 WrVal_Arg, P2VAR(volatile uint32, AUTOMATIC, NxtrMcuSuprtLib_APPL_VAR) WrAddr_Arg);

#endif
