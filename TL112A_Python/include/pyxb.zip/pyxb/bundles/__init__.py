"""Core binding modules for commonly referenced namespaces.

"""

