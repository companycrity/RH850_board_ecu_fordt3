#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_FordMsg459BusHiSpd_ClrDiagcFlgProxy_Val
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_ClrDiagcFlgProxy_Val(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg459BusHiSpd_FordCanDtcInhb_Logl
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_FordCanDtcInhb_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg459BusHiSpd_FordEpsLifeCycMod_Val
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_FordEpsLifeCycMod_Val(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg459BusHiSpd_FordTrlrBackupAssiEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_FordTrlrBackupAssiEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg459BusHiSpd_Ford_HitchToVehAxle_L_Calc_Ford_HitchToVehAxle_L_Calc
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_Ford_HitchToVehAxle_L_Calc_Ford_HitchToVehAxle_L_Calc(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg459BusHiSpd_Ford_TrlrAidTrgtId_No_Actl_Ford_TrlrAidTrgtId_No_Actl
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_Ford_TrlrAidTrgtId_No_Actl_Ford_TrlrAidTrgtId_No_Actl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg459BusHiSpd_Ford_TrlrAid_An3_Actl_Ford_TrlrAid_An3_Actl
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_Ford_TrlrAid_An3_Actl_Ford_TrlrAid_An3_Actl(__PST__g__36 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg459BusHiSpd_Ford_TrlrAid_AnRate2_Actl_Ford_TrlrAid_AnRate2_Actl
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_Ford_TrlrAid_AnRate2_Actl_Ford_TrlrAid_AnRate2_Actl(__PST__g__36 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg459BusHiSpd_Ford_TrlrAid_D2_Stat_Ford_TrlrAid_D2_Stat
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_Ford_TrlrAid_D2_Stat_Ford_TrlrAid_D2_Stat(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg459BusHiSpd_Ford_TrlrRvrse_D_Stat_Ford_TrlrRvrse_D_Stat
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_Ford_TrlrRvrse_D_Stat_Ford_TrlrRvrse_D_Stat(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg459BusHiSpd_Ford_TrlrTrgtAcquire_D_Stat_Ford_TrlrTrgtAcquire_D_Stat
 */


__PST__UINT8 Rte_Read_FordMsg459BusHiSpd_Ford_TrlrTrgtAcquire_D_Stat_Ford_TrlrTrgtAcquire_D_Stat(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidAcqSts_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidAcqSts_Val"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidAcqSts_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidHitchAg_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidHitchAg_Val"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidHitchAg_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidHitchAgRate_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidHitchAgRate_Val"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidHitchAgRate_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidIdnVal_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidIdnVal_Val"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidIdnVal_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidTrakgSt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidTrakgSt_Val"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidTrakgSt_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidTrakgStVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidTrakgStVld_Logl"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidTrakgStVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidTrlrRvsGuidcSts_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidTrlrRvsGuidcSts_Val"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrAidTrlrRvsGuidcSts_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrBallToAxle_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrBallToAxle_Val"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrBallToAxle_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrHitchAgVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrHitchAgVld_Logl"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrHitchAgVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrHitchRateVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrHitchRateVld_Logl"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrHitchRateVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_FordVehTrlrTarVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_FordVehTrlrTarVld_Logl"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_FordVehTrlrTarVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg459BusHiSpd_TrlrAidStsThreePrsntInt_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg459BusHiSpd_TrlrAidStsThreePrsntInt_Logl"


__PST__UINT8 Rte_Write_FordMsg459BusHiSpd_TrlrAidStsThreePrsntInt_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdDiagMsgMissTmrThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdDiagMsgMissTmrThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdDiagMsgMissTmrThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgInvldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgInvldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgInvldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgInvldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgInvldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgInvldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgRateInvldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgRateInvldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgRateInvldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgRateInvldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgRateInvldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdHitchAgRateInvldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdRcvrDiagMsgMissTmrThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdRcvrDiagMsgMissTmrThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdRcvrDiagMsgMissTmrThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdRcvrPrsntFlgTmrThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdRcvrPrsntFlgTmrThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdRcvrPrsntFlgTmrThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrackStInvldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrackStInvldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrackStInvldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrackStInvldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrackStInvldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrackStInvldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrHitchAgVldInvldMsgThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrHitchAgVldInvldMsgThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrHitchAgVldInvldMsgThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrHitchRateVldInvldMsgThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrHitchRateVldInvldMsgThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrHitchRateVldInvldMsgThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrHitchAgVldThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrHitchAgVldThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrHitchAgVldThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrHitchRateVldThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrHitchRateVldThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrHitchRateVldThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrTarVldThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrTarVldThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrTarVldThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrTrackStVldThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrTrackStVldThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrRcvrTrackStVldThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrTarVldMissMsgThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrTarVldMissMsgThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrTarVldMissMsgThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrTrackStVldInvldMsgThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrTrackStVldInvldMsgThd_Val"


__PST__UINT16 Rte_Prm_FordMsg459BusHiSpd_FordMsg459BusHiSpdTrlrTrackStVldInvldMsgThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

