#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__29 _main_gen_init_g29(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__g__23 _main_gen_init_g23(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__29 _main_gen_init_g29(void)
{
    static struct __PST__g__29 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotRefMdl_Ip_BrdgVltg(void)
{
    extern __PST__FLOAT32 MotRefMdl_Ip_BrdgVltg;
    
    /* initialization with random value */
    {
        MotRefMdl_Ip_BrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotRefMdl_Ip_DualEcuMotCtrlMtgtnEna(void)
{
    extern __PST__UINT8 MotRefMdl_Ip_DualEcuMotCtrlMtgtnEna;
    
    /* initialization with random value */
    {
        MotRefMdl_Ip_DualEcuMotCtrlMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotRefMdl_Ip_MotAndThermProtnLoaMod(void)
{
    extern __PST__UINT8 MotRefMdl_Ip_MotAndThermProtnLoaMod;
    
    /* initialization with random value */
    {
        MotRefMdl_Ip_MotAndThermProtnLoaMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotRefMdl_Ip_MotBackEmfConEstimd(void)
{
    extern __PST__FLOAT32 MotRefMdl_Ip_MotBackEmfConEstimd;
    
    /* initialization with random value */
    {
        MotRefMdl_Ip_MotBackEmfConEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotRefMdl_Ip_MotInduDaxEstimd(void)
{
    extern __PST__FLOAT32 MotRefMdl_Ip_MotInduDaxEstimd;
    
    /* initialization with random value */
    {
        MotRefMdl_Ip_MotInduDaxEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotRefMdl_Ip_MotInduQaxEstimd(void)
{
    extern __PST__FLOAT32 MotRefMdl_Ip_MotInduQaxEstimd;
    
    /* initialization with random value */
    {
        MotRefMdl_Ip_MotInduQaxEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotRefMdl_Ip_MotQuad(void)
{
    extern __PST__UINT8 MotRefMdl_Ip_MotQuad;
    
    /* initialization with random value */
    {
        MotRefMdl_Ip_MotQuad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotRefMdl_Ip_MotREstimd(void)
{
    extern __PST__FLOAT32 MotRefMdl_Ip_MotREstimd;
    
    /* initialization with random value */
    {
        MotRefMdl_Ip_MotREstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotRefMdl_Ip_MotTqCmdMrfScad(void)
{
    extern __PST__FLOAT32 MotRefMdl_Ip_MotTqCmdMrfScad;
    
    /* initialization with random value */
    {
        MotRefMdl_Ip_MotTqCmdMrfScad = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotRefMdl_Ip_MotVelMrf(void)
{
    extern __PST__FLOAT32 MotRefMdl_Ip_MotVelMrf;
    
    /* initialization with random value */
    {
        MotRefMdl_Ip_MotVelMrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlCurrDaxBoostGain(void)
{
    extern __PST__g__23 MotRefMdl_Cal_MotRefMdlCurrDaxBoostGain;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlCurrDaxBoostGain = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlCurrDaxBoostTqScaX(void)
{
    extern __PST__g__24 MotRefMdl_Cal_MotRefMdlCurrDaxBoostTqScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 11; _main_gen_tmp_6_0++)
            {
                /* base type */
                MotRefMdl_Cal_MotRefMdlCurrDaxBoostTqScaX[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlCurrDaxBoostTqScaY(void)
{
    extern __PST__g__24 MotRefMdl_Cal_MotRefMdlCurrDaxBoostTqScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 11; _main_gen_tmp_7_0++)
            {
                /* base type */
                MotRefMdl_Cal_MotRefMdlCurrDaxBoostTqScaY[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlCurrDaxQaxRefDelta(void)
{
    extern __PST__g__26 MotRefMdl_Cal_MotRefMdlCurrDaxQaxRefDelta;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 8; _main_gen_tmp_8_0++)
            {
                /* base type */
                MotRefMdl_Cal_MotRefMdlCurrDaxQaxRefDelta[_main_gen_tmp_8_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlCurrItrnTolr(void)
{
    extern __PST__g__23 MotRefMdl_Cal_MotRefMdlCurrItrnTolr;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlCurrItrnTolr = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlFbCtrlDi(void)
{
    extern __PST__g__27 MotRefMdl_Cal_MotRefMdlFbCtrlDi;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlFbCtrlDi = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlIvtrDeadTiBrdgVltgSca(void)
{
    extern __PST__g__23 MotRefMdl_Cal_MotRefMdlIvtrDeadTiBrdgVltgSca;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlIvtrDeadTiBrdgVltgSca = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlMinCurrItrnLim(void)
{
    extern __PST__g__27 MotRefMdl_Cal_MotRefMdlMinCurrItrnLim;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlMinCurrItrnLim = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlMotCurrDaxMaxSca(void)
{
    extern __PST__g__23 MotRefMdl_Cal_MotRefMdlMotCurrDaxMaxSca;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlMotCurrDaxMaxSca = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlMotVelLpFilFrq(void)
{
    extern __PST__g__23 MotRefMdl_Cal_MotRefMdlMotVelLpFilFrq;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlMotVelLpFilFrq = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlMotVltgDerivtvTiCon(void)
{
    extern __PST__g__23 MotRefMdl_Cal_MotRefMdlMotVltgDerivtvTiCon;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlMotVltgDerivtvTiCon = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlQuad13VltgSdlX(void)
{
    extern __PST__g__28 MotRefMdl_Cal_MotRefMdlQuad13VltgSdlX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 10; _main_gen_tmp_9_0++)
            {
                /* base type */
                MotRefMdl_Cal_MotRefMdlQuad13VltgSdlX[_main_gen_tmp_9_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlQuad13VltgSdlY(void)
{
    extern __PST__g__28 MotRefMdl_Cal_MotRefMdlQuad13VltgSdlY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 10; _main_gen_tmp_10_0++)
            {
                /* base type */
                MotRefMdl_Cal_MotRefMdlQuad13VltgSdlY[_main_gen_tmp_10_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlQuad24VltgSdlX(void)
{
    extern __PST__g__28 MotRefMdl_Cal_MotRefMdlQuad24VltgSdlX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 10; _main_gen_tmp_11_0++)
            {
                /* base type */
                MotRefMdl_Cal_MotRefMdlQuad24VltgSdlX[_main_gen_tmp_11_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlQuad24VltgSdlY(void)
{
    extern __PST__g__28 MotRefMdl_Cal_MotRefMdlQuad24VltgSdlY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 10; _main_gen_tmp_12_0++)
            {
                /* base type */
                MotRefMdl_Cal_MotRefMdlQuad24VltgSdlY[_main_gen_tmp_12_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlRefLocnItrnLim(void)
{
    extern __PST__g__27 MotRefMdl_Cal_MotRefMdlRefLocnItrnLim;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlRefLocnItrnLim = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlTqItrnLim(void)
{
    extern __PST__g__27 MotRefMdl_Cal_MotRefMdlTqItrnLim;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlTqItrnLim = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlTqItrnTolr(void)
{
    extern __PST__g__23 MotRefMdl_Cal_MotRefMdlTqItrnTolr;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlTqItrnTolr = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlVltgModDynCmpEna(void)
{
    extern __PST__g__27 MotRefMdl_Cal_MotRefMdlVltgModDynCmpEna;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlVltgModDynCmpEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlVltgOverRThdSca(void)
{
    extern __PST__g__23 MotRefMdl_Cal_MotRefMdlVltgOverRThdSca;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_MotRefMdlVltgOverRThdSca = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_MotRefMdl_Cal_SysGlbPrmMotPoleCnt(void)
{
    extern __PST__g__27 MotRefMdl_Cal_SysGlbPrmMotPoleCnt;
    
    /* initialization with random value */
    {
        MotRefMdl_Cal_SysGlbPrmMotPoleCnt = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MotRefMdl_Pim_CosDelta(void)
{
    extern __PST__g__17 MotRefMdl_Pim_CosDelta;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 8; _main_gen_tmp_13_0++)
            {
                /* base type */
                MotRefMdl_Pim_CosDelta[_main_gen_tmp_13_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_MotRefMdl_Pim_MotCurrDaxCmdPrev(void)
{
    extern __PST__FLOAT32 MotRefMdl_Pim_MotCurrDaxCmdPrev;
    
    /* initialization with random value */
    {
        MotRefMdl_Pim_MotCurrDaxCmdPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotRefMdl_Pim_MotCurrQaxCmdPrev(void)
{
    extern __PST__FLOAT32 MotRefMdl_Pim_MotCurrQaxCmdPrev;
    
    /* initialization with random value */
    {
        MotRefMdl_Pim_MotCurrQaxCmdPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotRefMdl_Pim_MotVelLpFil(void)
{
    extern struct __PST__g__29 MotRefMdl_Pim_MotVelLpFil;
    
    /* initialization with random value */
    {
        MotRefMdl_Pim_MotVelLpFil = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_MotRefMdl_Pim_SinDelta(void)
{
    extern __PST__g__17 MotRefMdl_Pim_SinDelta;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_14_0;
            
            for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 8; _main_gen_tmp_14_0++)
            {
                /* base type */
                MotRefMdl_Pim_SinDelta[_main_gen_tmp_14_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_MotRefMdl_Pim_VltgDaxFfTermPrev(void)
{
    extern __PST__FLOAT32 MotRefMdl_Pim_VltgDaxFfTermPrev;
    
    /* initialization with random value */
    {
        MotRefMdl_Pim_VltgDaxFfTermPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotRefMdl_Pim_VltgQaxFfTermPrev(void)
{
    extern __PST__FLOAT32 MotRefMdl_Pim_VltgQaxFfTermPrev;
    
    /* initialization with random value */
    {
        MotRefMdl_Pim_VltgQaxFfTermPrev = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotRefMdl_Ip_BrdgVltg */
    _main_gen_init_sym_MotRefMdl_Ip_BrdgVltg();
    
    /* init for variable MotRefMdl_Ip_DualEcuMotCtrlMtgtnEna */
    _main_gen_init_sym_MotRefMdl_Ip_DualEcuMotCtrlMtgtnEna();
    
    /* init for variable MotRefMdl_Ip_MotAndThermProtnLoaMod */
    _main_gen_init_sym_MotRefMdl_Ip_MotAndThermProtnLoaMod();
    
    /* init for variable MotRefMdl_Ip_MotBackEmfConEstimd */
    _main_gen_init_sym_MotRefMdl_Ip_MotBackEmfConEstimd();
    
    /* init for variable MotRefMdl_Ip_MotInduDaxEstimd */
    _main_gen_init_sym_MotRefMdl_Ip_MotInduDaxEstimd();
    
    /* init for variable MotRefMdl_Ip_MotInduQaxEstimd */
    _main_gen_init_sym_MotRefMdl_Ip_MotInduQaxEstimd();
    
    /* init for variable MotRefMdl_Ip_MotQuad */
    _main_gen_init_sym_MotRefMdl_Ip_MotQuad();
    
    /* init for variable MotRefMdl_Ip_MotREstimd */
    _main_gen_init_sym_MotRefMdl_Ip_MotREstimd();
    
    /* init for variable MotRefMdl_Ip_MotTqCmdMrfScad */
    _main_gen_init_sym_MotRefMdl_Ip_MotTqCmdMrfScad();
    
    /* init for variable MotRefMdl_Ip_MotVelMrf */
    _main_gen_init_sym_MotRefMdl_Ip_MotVelMrf();
    
    /* init for variable MotRefMdl_Op_MotBackEmfVltg : useless (never read) */

    /* init for variable MotRefMdl_Op_MotCurrAg : useless (never read) */

    /* init for variable MotRefMdl_Op_MotCurrDaxCmd : useless (never read) */

    /* init for variable MotRefMdl_Op_MotCurrDaxMax : useless (never read) */

    /* init for variable MotRefMdl_Op_MotCurrQaxCmd : useless (never read) */

    /* init for variable MotRefMdl_Op_MotReacncDax : useless (never read) */

    /* init for variable MotRefMdl_Op_MotReacncQax : useless (never read) */

    /* init for variable MotRefMdl_Op_MotVltgDaxFf : useless (never read) */

    /* init for variable MotRefMdl_Op_MotVltgDaxFfStat : useless (never read) */

    /* init for variable MotRefMdl_Op_MotVltgQaxFf : useless (never read) */

    /* init for variable MotRefMdl_Op_MotVltgQaxFfStat : useless (never read) */

    /* init for variable MotRefMdl_Op_MotVltgSatnIndFf : useless (never read) */

    /* init for variable MotRefMdl_Cal_MotRefMdlCurrDaxBoostGain */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlCurrDaxBoostGain();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlCurrDaxBoostTqScaX */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlCurrDaxBoostTqScaX();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlCurrDaxBoostTqScaY */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlCurrDaxBoostTqScaY();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlCurrDaxQaxRefDelta */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlCurrDaxQaxRefDelta();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlCurrItrnTolr */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlCurrItrnTolr();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlFbCtrlDi */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlFbCtrlDi();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlIvtrDeadTiBrdgVltgSca */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlIvtrDeadTiBrdgVltgSca();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlMinCurrItrnLim */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlMinCurrItrnLim();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlMotCurrDaxMaxSca */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlMotCurrDaxMaxSca();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlMotVelLpFilFrq */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlMotVelLpFilFrq();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlMotVltgDerivtvTiCon */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlMotVltgDerivtvTiCon();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlQuad13VltgSdlX */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlQuad13VltgSdlX();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlQuad13VltgSdlY */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlQuad13VltgSdlY();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlQuad24VltgSdlX */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlQuad24VltgSdlX();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlQuad24VltgSdlY */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlQuad24VltgSdlY();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlRefLocnItrnLim */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlRefLocnItrnLim();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlTqItrnLim */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlTqItrnLim();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlTqItrnTolr */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlTqItrnTolr();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlVltgModDynCmpEna */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlVltgModDynCmpEna();
    
    /* init for variable MotRefMdl_Cal_MotRefMdlVltgOverRThdSca */
    _main_gen_init_sym_MotRefMdl_Cal_MotRefMdlVltgOverRThdSca();
    
    /* init for variable MotRefMdl_Cal_SysGlbPrmMotPoleCnt */
    _main_gen_init_sym_MotRefMdl_Cal_SysGlbPrmMotPoleCnt();
    
    /* init for variable MotRefMdl_Pim_dMotRefMdlCurrDaxAtPeakTq : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlCurrDaxMin : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlCurrQaxMin : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlCurrSqdMin : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlInterCalcnCurrDaxMax : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlMinCurrNrItrn : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlMotCurrDaxBoost : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlMotTqCmdLimd : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlMotVelFildFf : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlMotVltgDaxFfDyn : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlMotVltgDaxFfDynTerm : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlMotVltgDaxFfStat : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlMotVltgQaxFfDyn : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlMotVltgQaxFfDynTerm : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlMotVltgQaxFfStat : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlPeakTq : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlPeakTqNrItrn : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlPhaAdvAtPeakTq : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlReacncDaxOverR : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlReacncQaxOverR : useless (never read) */

    /* init for variable MotRefMdl_Pim_dMotRefMdlRelncTqCoeff : useless (never read) */

    /* init for variable MotRefMdl_Pim_CosDelta */
    _main_gen_init_sym_MotRefMdl_Pim_CosDelta();
    
    /* init for variable MotRefMdl_Pim_MotCurrDaxCmdPrev */
    _main_gen_init_sym_MotRefMdl_Pim_MotCurrDaxCmdPrev();
    
    /* init for variable MotRefMdl_Pim_MotCurrQaxCmdPrev */
    _main_gen_init_sym_MotRefMdl_Pim_MotCurrQaxCmdPrev();
    
    /* init for variable MotRefMdl_Pim_MotVelLpFil */
    _main_gen_init_sym_MotRefMdl_Pim_MotVelLpFil();
    
    /* init for variable MotRefMdl_Pim_SinDelta */
    _main_gen_init_sym_MotRefMdl_Pim_SinDelta();
    
    /* init for variable MotRefMdl_Pim_VltgDaxFfTermPrev */
    _main_gen_init_sym_MotRefMdl_Pim_VltgDaxFfTermPrev();
    
    /* init for variable MotRefMdl_Pim_VltgQaxFfTermPrev */
    _main_gen_init_sym_MotRefMdl_Pim_VltgQaxFfTermPrev();
    
}
