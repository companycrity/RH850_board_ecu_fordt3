/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_PosnTrakgServo_HwAg_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PosnTrakgServo_HwAg_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PosnTrakgServo_HwAg_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PosnTrakgServo_HwAg_Val"
//
// __PST__UINT8 Rte_Read_PosnTrakgServo_HwAg_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PosnTrakgServo_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PosnTrakgServo_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PosnTrakgServo_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PosnTrakgServo_HwTq_Val"
//
// __PST__UINT8 Rte_Read_PosnTrakgServo_HwTq_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PosnTrakgServo_MotVelCrf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PosnTrakgServo_MotVelCrf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PosnTrakgServo_MotVelCrf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PosnTrakgServo_MotVelCrf_Val"
//
// __PST__UINT8 Rte_Read_PosnTrakgServo_MotVelCrf_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PosnTrakgServo_PosnServoEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_PosnTrakgServo_PosnServoEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_PosnTrakgServo_PosnServoEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_PosnTrakgServo_PosnServoEna_Logl"
//
// __PST__UINT8 Rte_Read_PosnTrakgServo_PosnServoEna_Logl(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PosnTrakgServo_PosnServoHwAg_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PosnTrakgServo_PosnServoHwAg_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PosnTrakgServo_PosnServoHwAg_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PosnTrakgServo_PosnServoHwAg_Val"
//
// __PST__UINT8 Rte_Read_PosnTrakgServo_PosnServoHwAg_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PosnTrakgServo_PosnServoHwVel_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PosnTrakgServo_PosnServoHwVel_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PosnTrakgServo_PosnServoHwVel_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PosnTrakgServo_PosnServoHwVel_Val"
//
// __PST__UINT8 Rte_Read_PosnTrakgServo_PosnServoHwVel_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PosnTrakgServo_PosnServoIntgtrOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PosnTrakgServo_PosnServoIntgtrOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PosnTrakgServo_PosnServoIntgtrOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PosnTrakgServo_PosnServoIntgtrOffs_Val"
//
// __PST__UINT8 Rte_Read_PosnTrakgServo_PosnServoIntgtrOffs_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PosnTrakgServo_PosnTrakgArbnFltMtgtnEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_PosnTrakgServo_PosnTrakgArbnFltMtgtnEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_PosnTrakgServo_PosnTrakgArbnFltMtgtnEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_PosnTrakgServo_PosnTrakgArbnFltMtgtnEna_Logl"
//
// __PST__UINT8 Rte_Read_PosnTrakgServo_PosnTrakgArbnFltMtgtnEna_Logl(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_PosnTrakgServo_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_PosnTrakgServo_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_PosnTrakgServo_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_PosnTrakgServo_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_PosnTrakgServo_VehSpd_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_PosnTrakgServo_PosnServoCmd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_PosnTrakgServo_PosnServoCmd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_PosnTrakgServo_PosnServoCmd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_PosnTrakgServo_PosnServoCmd_Val"
//
// __PST__UINT8 Rte_Write_PosnTrakgServo_PosnServoCmd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_PosnTrakgServo_PosnServoIntgtrSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_PosnTrakgServo_PosnServoIntgtrSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_PosnTrakgServo_PosnServoIntgtrSt_Val"
// #pragma POLYSPACE_WORST "Rte_Write_PosnTrakgServo_PosnServoIntgtrSt_Val"
//
// __PST__UINT8 Rte_Write_PosnTrakgServo_PosnServoIntgtrSt_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoArbnFltMtgtnLpFilCutOffFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoArbnFltMtgtnLpFilCutOffFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoArbnFltMtgtnLpFilCutOffFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoArbnFltMtgtnLpFilCutOffFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_PosnTrakgServo_PosnTrakgServoArbnFltMtgtnLpFilCutOffFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoIntgtrAntiWdupGain_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntgtrAntiWdupGain_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntgtrAntiWdupGain_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntgtrAntiWdupGain_Val"
//
// __PST__FLOAT32 Rte_Prm_PosnTrakgServo_PosnTrakgServoIntgtrAntiWdupGain_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoIntgtrStCorrnGain_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntgtrStCorrnGain_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntgtrStCorrnGain_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntgtrStCorrnGain_Val"
//
// __PST__FLOAT32 Rte_Prm_PosnTrakgServo_PosnTrakgServoIntgtrStCorrnGain_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoLpFilCutOffFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoLpFilCutOffFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoLpFilCutOffFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoLpFilCutOffFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_PosnTrakgServo_PosnTrakgServoLpFilCutOffFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoOutpAntiWdupGain_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoOutpAntiWdupGain_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoOutpAntiWdupGain_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoOutpAntiWdupGain_Val"
//
// __PST__FLOAT32 Rte_Prm_PosnTrakgServo_PosnTrakgServoOutpAntiWdupGain_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_SysGlbPrmSysKineRat_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_SysGlbPrmSysKineRat_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_SysGlbPrmSysKineRat_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_SysGlbPrmSysKineRat_Val"
//
// __PST__FLOAT32 Rte_Prm_PosnTrakgServo_SysGlbPrmSysKineRat_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_SysGlbPrmSysTqRat_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_SysGlbPrmSysTqRat_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_SysGlbPrmSysTqRat_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_SysGlbPrmSysTqRat_Val"
//
// __PST__FLOAT32 Rte_Prm_PosnTrakgServo_SysGlbPrmSysTqRat_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoEnaBlndFacTblX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoEnaBlndFacTblX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoEnaBlndFacTblX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoEnaBlndFacTblX_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoEnaBlndFacTblX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoEnaBlndFacTblY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoEnaBlndFacTblY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoEnaBlndFacTblY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoEnaBlndFacTblY_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoEnaBlndFacTblY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoFfGain_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoFfGain_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoFfGain_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoFfGain_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoFfGain_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoFfVelGain_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoFfVelGain_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoFfVelGain_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoFfVelGain_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoFfVelGain_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoGain1_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain1_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain1_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain1_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoGain1_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoGain2_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain2_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain2_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain2_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoGain2_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoGain3_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain3_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain3_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain3_Ary1D"
//
// __PST__g__37 Rte_Prm_PosnTrakgServo_PosnTrakgServoGain3_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoGain4_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain4_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain4_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoGain4_Ary1D"
//
// __PST__g__37 Rte_Prm_PosnTrakgServo_PosnTrakgServoGain4_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoGainArbnFltMtgtn_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoGainArbnFltMtgtn_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoGainArbnFltMtgtn_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoGainArbnFltMtgtn_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoGainArbnFltMtgtn_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoHwAgTarMgnLimTblY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoHwAgTarMgnLimTblY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoHwAgTarMgnLimTblY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoHwAgTarMgnLimTblY_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoHwAgTarMgnLimTblY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoHwAgTarRateLimTblY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoHwAgTarRateLimTblY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoHwAgTarRateLimTblY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoHwAgTarRateLimTblY_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoHwAgTarRateLimTblY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoHwVelTarRateLimTblY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoHwVelTarRateLimTblY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoHwVelTarRateLimTblY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoHwVelTarRateLimTblY_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoHwVelTarRateLimTblY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoIntglGain_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntglGain_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntglGain_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntglGain_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoIntglGain_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoIntglLim_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntglLim_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntglLim_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoIntglLim_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoIntglLim_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoOutpLim_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoOutpLim_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoOutpLim_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoOutpLim_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoOutpLim_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_PosnTrakgServo_PosnTrakgServoVehSpdTbl_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_PosnTrakgServo_PosnTrakgServoVehSpdTbl_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_PosnTrakgServo_PosnTrakgServoVehSpdTbl_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_PosnTrakgServo_PosnTrakgServoVehSpdTbl_Ary1D"
//
// __PST__g__34 Rte_Prm_PosnTrakgServo_PosnTrakgServoVehSpdTbl_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_u16_u16VariXu16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_u16_u16VariXu16VariY"
//
// __PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__34 P_0, __PST__g__34 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_s16_u16VariXs16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_s16_u16VariXs16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_s16_u16VariXs16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_s16_u16VariXs16VariY"
//
// __PST__SINT16 LnrIntrpn_s16_u16VariXs16VariY(__PST__g__34 P_0, __PST__g__37 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
// {
//    ...
// }

