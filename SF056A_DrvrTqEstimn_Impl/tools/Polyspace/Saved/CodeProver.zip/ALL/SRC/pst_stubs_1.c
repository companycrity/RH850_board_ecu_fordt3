#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__SINT8 _main_gen_init_g2(void);

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_DrvrTqEstimn_Ip_AssiMechPolarity(void)
{
    extern __PST__SINT8 DrvrTqEstimn_Ip_AssiMechPolarity;
    
    /* initialization with random value */
    {
        DrvrTqEstimn_Ip_AssiMechPolarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Ip_HwAg(void)
{
    extern __PST__FLOAT32 DrvrTqEstimn_Ip_HwAg;
    
    /* initialization with random value */
    {
        DrvrTqEstimn_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Ip_HwTq(void)
{
    extern __PST__FLOAT32 DrvrTqEstimn_Ip_HwTq;
    
    /* initialization with random value */
    {
        DrvrTqEstimn_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Ip_MotTqCmdPwrLimd(void)
{
    extern __PST__FLOAT32 DrvrTqEstimn_Ip_MotTqCmdPwrLimd;
    
    /* initialization with random value */
    {
        DrvrTqEstimn_Ip_MotTqCmdPwrLimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 DrvrTqEstimn_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        DrvrTqEstimn_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Cal_DrvrTqEstimnMtrxA(void)
{
    extern __PST__g__25 DrvrTqEstimn_Cal_DrvrTqEstimnMtrxA;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 5; _main_gen_tmp_0_0++)
            {
                __PST__UINT32 _main_gen_tmp_0_1;
                
                for (_main_gen_tmp_0_1 = 0; _main_gen_tmp_0_1 < 5; _main_gen_tmp_0_1++)
                {
                    /* base type */
                    DrvrTqEstimn_Cal_DrvrTqEstimnMtrxA[_main_gen_tmp_0_0][_main_gen_tmp_0_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Cal_DrvrTqEstimnMtrxB(void)
{
    extern __PST__g__28 DrvrTqEstimn_Cal_DrvrTqEstimnMtrxB;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 4; _main_gen_tmp_1_0++)
            {
                __PST__UINT32 _main_gen_tmp_1_1;
                
                for (_main_gen_tmp_1_1 = 0; _main_gen_tmp_1_1 < 5; _main_gen_tmp_1_1++)
                {
                    /* base type */
                    DrvrTqEstimn_Cal_DrvrTqEstimnMtrxB[_main_gen_tmp_1_0][_main_gen_tmp_1_1] = pst_random_g_10;
                }
            }
        }
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Cal_DrvrTqEstimnMtrxC(void)
{
    extern __PST__g__26 DrvrTqEstimn_Cal_DrvrTqEstimnMtrxC;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 5; _main_gen_tmp_2_0++)
            {
                /* base type */
                DrvrTqEstimn_Cal_DrvrTqEstimnMtrxC[_main_gen_tmp_2_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Cal_DrvrTqEstimnMtrxD(void)
{
    extern __PST__g__29 DrvrTqEstimn_Cal_DrvrTqEstimnMtrxD;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 4; _main_gen_tmp_3_0++)
            {
                /* base type */
                DrvrTqEstimn_Cal_DrvrTqEstimnMtrxD[_main_gen_tmp_3_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Cal_SysGlbPrmSysKineRat(void)
{
    extern __PST__g__27 DrvrTqEstimn_Cal_SysGlbPrmSysKineRat;
    
    /* initialization with random value */
    {
        DrvrTqEstimn_Cal_SysGlbPrmSysKineRat = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Cal_SysGlbPrmSysTqRat(void)
{
    extern __PST__g__27 DrvrTqEstimn_Cal_SysGlbPrmSysTqRat;
    
    /* initialization with random value */
    {
        DrvrTqEstimn_Cal_SysGlbPrmSysTqRat = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DrvrTqEstimn_Pim_DrvrTqStPrev(void)
{
    extern __PST__g__19 DrvrTqEstimn_Pim_DrvrTqStPrev;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 5; _main_gen_tmp_4_0++)
            {
                /* base type */
                DrvrTqEstimn_Pim_DrvrTqStPrev[_main_gen_tmp_4_0] = pst_random_g_10;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable DrvrTqEstimn_Ip_AssiMechPolarity */
    _main_gen_init_sym_DrvrTqEstimn_Ip_AssiMechPolarity();
    
    /* init for variable DrvrTqEstimn_Ip_HwAg */
    _main_gen_init_sym_DrvrTqEstimn_Ip_HwAg();
    
    /* init for variable DrvrTqEstimn_Ip_HwTq */
    _main_gen_init_sym_DrvrTqEstimn_Ip_HwTq();
    
    /* init for variable DrvrTqEstimn_Ip_MotTqCmdPwrLimd */
    _main_gen_init_sym_DrvrTqEstimn_Ip_MotTqCmdPwrLimd();
    
    /* init for variable DrvrTqEstimn_Ip_MotVelCrf */
    _main_gen_init_sym_DrvrTqEstimn_Ip_MotVelCrf();
    
    /* init for variable DrvrTqEstimn_Op_DrvrTqEstimd : useless (never read) */

    /* init for variable DrvrTqEstimn_Cal_DrvrTqEstimnMtrxA */
    _main_gen_init_sym_DrvrTqEstimn_Cal_DrvrTqEstimnMtrxA();
    
    /* init for variable DrvrTqEstimn_Cal_DrvrTqEstimnMtrxB */
    _main_gen_init_sym_DrvrTqEstimn_Cal_DrvrTqEstimnMtrxB();
    
    /* init for variable DrvrTqEstimn_Cal_DrvrTqEstimnMtrxC */
    _main_gen_init_sym_DrvrTqEstimn_Cal_DrvrTqEstimnMtrxC();
    
    /* init for variable DrvrTqEstimn_Cal_DrvrTqEstimnMtrxD */
    _main_gen_init_sym_DrvrTqEstimn_Cal_DrvrTqEstimnMtrxD();
    
    /* init for variable DrvrTqEstimn_Cal_SysGlbPrmSysKineRat */
    _main_gen_init_sym_DrvrTqEstimn_Cal_SysGlbPrmSysKineRat();
    
    /* init for variable DrvrTqEstimn_Cal_SysGlbPrmSysTqRat */
    _main_gen_init_sym_DrvrTqEstimn_Cal_SysGlbPrmSysTqRat();
    
    /* init for variable DrvrTqEstimn_Pim_DrvrTqStPrev */
    _main_gen_init_sym_DrvrTqEstimn_Pim_DrvrTqStPrev();
    
}
