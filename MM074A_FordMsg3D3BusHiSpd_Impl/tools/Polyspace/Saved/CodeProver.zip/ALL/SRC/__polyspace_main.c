#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__19 _main_gen_init_g19(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__19 _main_gen_init_g19(void)
{
    static struct __PST__g__19 x;
    /* struct/union type */
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_ComIPduCallout_LateralMotionControl_FD1_Oper(void)
{
    extern __PST__UINT8 ComIPduCallout_LateralMotionControl_FD1_Oper(__PST__UINT8, __PST__g__17);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__g__17 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static struct __PST__g__19 _main_gen_tmp_0[ARRAY_NBELEM(struct __PST__g__19)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct __PST__g__19); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g19();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct __PST__g__19) / 2];
    }
    
    /* call it */
    __ret__ = ComIPduCallout_LateralMotionControl_FD1_Oper(__arg__0, __arg__1);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function ComIPduCallout_LateralMotionControl_FD1_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_ComIPduCallout_LateralMotionControl_FD1_Oper();
        }
        
        /* call of function ComTimeoutNotification_LatCtlRampType_D_Rq_Oper */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID ComTimeoutNotification_LatCtlRampType_D_Rq_Oper(__PST__VOID);

            ComTimeoutNotification_LatCtlRampType_D_Rq_Oper();
        }
        
        /* call of function Rte_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_Stub(__PST__VOID);

            Rte_Stub();
        }
        
    }
}
