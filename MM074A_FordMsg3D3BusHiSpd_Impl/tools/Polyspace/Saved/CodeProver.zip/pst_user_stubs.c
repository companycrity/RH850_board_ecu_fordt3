/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_ClrDiagcFlgProxy_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_ClrDiagcFlgProxy_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_ClrDiagcFlgProxy_Val"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_ClrDiagcFlgProxy_Val"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_ClrDiagcFlgProxy_Val(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_FordCanDtcInhb_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_FordCanDtcInhb_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_FordCanDtcInhb_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_FordCanDtcInhb_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_FordCanDtcInhb_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_FordEpsLifeCycMod_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_FordEpsLifeCycMod_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_FordEpsLifeCycMod_Val"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_FordEpsLifeCycMod_Val"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_FordEpsLifeCycMod_Val(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_FordLaneCentrAssiEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_FordLaneCentrAssiEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_FordLaneCentrAssiEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_FordLaneCentrAssiEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_FordLaneCentrAssiEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_FordTrfcJamAssiEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_FordTrfcJamAssiEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_FordTrfcJamAssiEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_FordTrfcJamAssiEnad_Logl"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_FordTrfcJamAssiEnad_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_Ford_HandsOffCnfm_B_Rq_Ford_HandsOffCnfm_B_Rq
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_Ford_HandsOffCnfm_B_Rq_Ford_HandsOffCnfm_B_Rq"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_Ford_HandsOffCnfm_B_Rq_Ford_HandsOffCnfm_B_Rq"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_Ford_HandsOffCnfm_B_Rq_Ford_HandsOffCnfm_B_Rq"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_Ford_HandsOffCnfm_B_Rq_Ford_HandsOffCnfm_B_Rq(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlCurv_NoRate_Actl_Ford_LatCtlCurv_NoRate_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlCurv_NoRate_Actl_Ford_LatCtlCurv_NoRate_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlCurv_NoRate_Actl_Ford_LatCtlCurv_NoRate_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlCurv_NoRate_Actl_Ford_LatCtlCurv_NoRate_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlCurv_NoRate_Actl_Ford_LatCtlCurv_NoRate_Actl(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlCurv_No_Actl_Ford_LatCtlCurv_No_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlCurv_No_Actl_Ford_LatCtlCurv_No_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlCurv_No_Actl_Ford_LatCtlCurv_No_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlCurv_No_Actl_Ford_LatCtlCurv_No_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlCurv_No_Actl_Ford_LatCtlCurv_No_Actl(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPathOffst_L_Actl_Ford_LatCtlPathOffst_L_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPathOffst_L_Actl_Ford_LatCtlPathOffst_L_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPathOffst_L_Actl_Ford_LatCtlPathOffst_L_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPathOffst_L_Actl_Ford_LatCtlPathOffst_L_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPathOffst_L_Actl_Ford_LatCtlPathOffst_L_Actl(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPath_An_Actl_Ford_LatCtlPath_An_Actl
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPath_An_Actl_Ford_LatCtlPath_An_Actl"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPath_An_Actl_Ford_LatCtlPath_An_Actl"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPath_An_Actl_Ford_LatCtlPath_An_Actl"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPath_An_Actl_Ford_LatCtlPath_An_Actl(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPrecision_D_Rq_Ford_LatCtlPrecision_D_Rq
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPrecision_D_Rq_Ford_LatCtlPrecision_D_Rq"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPrecision_D_Rq_Ford_LatCtlPrecision_D_Rq"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPrecision_D_Rq_Ford_LatCtlPrecision_D_Rq"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlPrecision_D_Rq_Ford_LatCtlPrecision_D_Rq(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlRampType_D_Rq_Ford_LatCtlRampType_D_Rq
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlRampType_D_Rq_Ford_LatCtlRampType_D_Rq"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlRampType_D_Rq_Ford_LatCtlRampType_D_Rq"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlRampType_D_Rq_Ford_LatCtlRampType_D_Rq"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlRampType_D_Rq_Ford_LatCtlRampType_D_Rq(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlRng_L_Max_Ford_LatCtlRng_L_Max
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlRng_L_Max_Ford_LatCtlRng_L_Max"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlRng_L_Max_Ford_LatCtlRng_L_Max"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlRng_L_Max_Ford_LatCtlRng_L_Max"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtlRng_L_Max_Ford_LatCtlRng_L_Max(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtl_D_Rq_Ford_LatCtl_D_Rq
//
// #pragma POLYSPACE_PURE "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtl_D_Rq_Ford_LatCtl_D_Rq"
// #pragma POLYSPACE_CLEAN "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtl_D_Rq_Ford_LatCtl_D_Rq"
// #pragma POLYSPACE_WORST "Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtl_D_Rq_Ford_LatCtl_D_Rq"
//
// __PST__UINT8 Rte_Read_FordMsg3D3BusHiSpd_Ford_LatCtl_D_Rq_Ford_LatCtl_D_Rq(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvt_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvt_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvt_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvt_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRate_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRate_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRate_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRateRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRateRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRateRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRateRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRateRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlCrvtRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlHandsOffDetnTqStimlsReq_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlHandsOffDetnTqStimlsReq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlHandsOffDetnTqStimlsReq_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlHandsOffDetnTqStimlsReq_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlHandsOffDetnTqStimlsReq_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlImgProcrModlAVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlImgProcrModlAVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlImgProcrModlAVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlImgProcrModlAVld_Logl"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlImgProcrModlAVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPah_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPah_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPah_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPah_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPah_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahOffs_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahOffs_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahOffsRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahOffsRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahOffsRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahOffsRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahOffsRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahRaw_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahRaw_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahRaw_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahRaw_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPahRaw_Val(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPrcsn_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPrcsn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPrcsn_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPrcsn_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlPrcsn_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlRampTyp_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlRampTyp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlRampTyp_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlRampTyp_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlRampTyp_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlReq_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlReq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlReq_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlReq_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlReq_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlRingMax_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlRingMax_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlRingMax_Val"
// #pragma POLYSPACE_WORST "Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlRingMax_Val"
//
// __PST__UINT8 Rte_Write_FordMsg3D3BusHiSpd_FordVehLatCtrlRingMax_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdImgProcrModlAVldFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdImgProcrModlAVldFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdImgProcrModlAVldFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdImgProcrModlAVldFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdImgProcrModlAVldFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdImgProcrModlAVldPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdImgProcrModlAVldPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdImgProcrModlAVldPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdImgProcrModlAVldPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdImgProcrModlAVldPassdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdMissMsgFaildThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdMissMsgFaildThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdMissMsgFaildThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdMissMsgFaildThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdMissMsgFaildThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdMissMsgPassdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdMissMsgPassdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdMissMsgPassdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdMissMsgPassdThd_Val"
//
// __PST__UINT16 Rte_Prm_FordMsg3D3BusHiSpd_FordMsg3D3BusHiSpdMissMsgPassdThd_Val(__PST__VOID)
// {
//    ...
// }

