#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__60 _main_gen_init_g60(void);

extern __PST__g__57 _main_gen_init_g57(void);

extern __PST__g__54 _main_gen_init_g54(void);

extern __PST__g__51 _main_gen_init_g51(void);

extern __PST__g__47 _main_gen_init_g47(void);

extern __PST__g__44 _main_gen_init_g44(void);

extern __PST__g__41 _main_gen_init_g41(void);

extern __PST__g__38 _main_gen_init_g38(void);

extern struct __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__35 _main_gen_init_g35(void);

extern struct __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern struct __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__22 _main_gen_init_g22(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__22 _main_gen_init_g22(void)
{
    __PST__g__22 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__30 _main_gen_init_g30(void)
{
    static struct __PST__g__30 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 3);
        x._SUSMTD = bitf;
    }
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g30();
    return x;
}

struct __PST__g__34 _main_gen_init_g34(void)
{
    static struct __PST__g__34 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._ADDNT = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._DFMT = bitf;
    }
    return x;
}

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g34();
    return x;
}

struct __PST__g__37 _main_gen_init_g37(void)
{
    static struct __PST__g__37 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._IDEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._PEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._OWEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._ULEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._RDCLRE = bitf;
    }
    return x;
}

__PST__g__35 _main_gen_init_g35(void)
{
    __PST__g__35 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g37();
    return x;
}

__PST__g__38 _main_gen_init_g38(void)
{
    __PST__g__38 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__41 _main_gen_init_g41(void)
{
    __PST__g__41 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__44 _main_gen_init_g44(void)
{
    __PST__g__44 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__47 _main_gen_init_g47(void)
{
    __PST__g__47 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__51 _main_gen_init_g51(void)
{
    __PST__g__51 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__54 _main_gen_init_g54(void)
{
    __PST__g__54 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__57 _main_gen_init_g57(void)
{
    __PST__g__57 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__60 _main_gen_init_g60(void)
{
    __PST__g__60 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Adcf1CfgAndUse_Ip_AdcDiagcEndPtrOutp(void)
{
    extern __PST__UINT8 Adcf1CfgAndUse_Ip_AdcDiagcEndPtrOutp;
    
    /* initialization with random value */
    {
        Adcf1CfgAndUse_Ip_AdcDiagcEndPtrOutp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Adcf1CfgAndUse_Ip_AdcDiagcStrtPtrOutp(void)
{
    extern __PST__UINT8 Adcf1CfgAndUse_Ip_AdcDiagcStrtPtrOutp;
    
    /* initialization with random value */
    {
        Adcf1CfgAndUse_Ip_AdcDiagcStrtPtrOutp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Adcf1CfgAndUse_Pim_Adcf1DiagcEndPtr(void)
{
    extern __PST__UINT8 Adcf1CfgAndUse_Pim_Adcf1DiagcEndPtr;
    
    /* initialization with random value */
    {
        Adcf1CfgAndUse_Pim_Adcf1DiagcEndPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Adcf1CfgAndUse_Pim_Adcf1DiagcStrtPtr(void)
{
    extern __PST__UINT8 Adcf1CfgAndUse_Pim_Adcf1DiagcStrtPtr;
    
    /* initialization with random value */
    {
        Adcf1CfgAndUse_Pim_Adcf1DiagcStrtPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ADCF1VCR0_BASE(void)
{
    extern __PST__g__22 ADCF1VCR0_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR0_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR1_BASE(void)
{
    extern __PST__g__22 ADCF1VCR1_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR1_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR2_BASE(void)
{
    extern __PST__g__22 ADCF1VCR2_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR2_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR3_BASE(void)
{
    extern __PST__g__22 ADCF1VCR3_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR3_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR4_BASE(void)
{
    extern __PST__g__22 ADCF1VCR4_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR4_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR5_BASE(void)
{
    extern __PST__g__22 ADCF1VCR5_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR5_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR6_BASE(void)
{
    extern __PST__g__22 ADCF1VCR6_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR6_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR7_BASE(void)
{
    extern __PST__g__22 ADCF1VCR7_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR7_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR8_BASE(void)
{
    extern __PST__g__22 ADCF1VCR8_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR8_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR9_BASE(void)
{
    extern __PST__g__22 ADCF1VCR9_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR9_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR10_BASE(void)
{
    extern __PST__g__22 ADCF1VCR10_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR10_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR11_BASE(void)
{
    extern __PST__g__22 ADCF1VCR11_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR11_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR12_BASE(void)
{
    extern __PST__g__22 ADCF1VCR12_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR12_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR13_BASE(void)
{
    extern __PST__g__22 ADCF1VCR13_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR13_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR14_BASE(void)
{
    extern __PST__g__22 ADCF1VCR14_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR14_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR15_BASE(void)
{
    extern __PST__g__22 ADCF1VCR15_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR15_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR16_BASE(void)
{
    extern __PST__g__22 ADCF1VCR16_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR16_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR17_BASE(void)
{
    extern __PST__g__22 ADCF1VCR17_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR17_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR18_BASE(void)
{
    extern __PST__g__22 ADCF1VCR18_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR18_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR19_BASE(void)
{
    extern __PST__g__22 ADCF1VCR19_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR19_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR20_BASE(void)
{
    extern __PST__g__22 ADCF1VCR20_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR20_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR21_BASE(void)
{
    extern __PST__g__22 ADCF1VCR21_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR21_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR22_BASE(void)
{
    extern __PST__g__22 ADCF1VCR22_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR22_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1VCR23_BASE(void)
{
    extern __PST__g__22 ADCF1VCR23_BASE;
    
    /* initialization with random value */
    {
        ADCF1VCR23_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF1ADCR1_BASE(void)
{
    extern __PST__g__28 ADCF1ADCR1_BASE;
    
    /* initialization with random value */
    {
        ADCF1ADCR1_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ADCF1ADCR2_BASE(void)
{
    extern __PST__g__32 ADCF1ADCR2_BASE;
    
    /* initialization with random value */
    {
        ADCF1ADCR2_BASE = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_ADCF1SFTCR_BASE(void)
{
    extern __PST__g__35 ADCF1SFTCR_BASE;
    
    /* initialization with random value */
    {
        ADCF1SFTCR_BASE = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_ADCF1ULLMTBR0_BASE(void)
{
    extern __PST__g__38 ADCF1ULLMTBR0_BASE;
    
    /* initialization with random value */
    {
        ADCF1ULLMTBR0_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_ADCF1ULLMTBR1_BASE(void)
{
    extern __PST__g__38 ADCF1ULLMTBR1_BASE;
    
    /* initialization with random value */
    {
        ADCF1ULLMTBR1_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_ADCF1ULLMTBR2_BASE(void)
{
    extern __PST__g__38 ADCF1ULLMTBR2_BASE;
    
    /* initialization with random value */
    {
        ADCF1ULLMTBR2_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_ADCF1SGSTCR0_BASE(void)
{
    extern __PST__g__41 ADCF1SGSTCR0_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGSTCR0_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_ADCF1SGCR0_BASE(void)
{
    extern __PST__g__44 ADCF1SGCR0_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGCR0_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ADCF1SGVCSP0_BASE(void)
{
    extern __PST__g__47 ADCF1SGVCSP0_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGVCSP0_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ADCF1SGVCEP0_BASE(void)
{
    extern __PST__g__51 ADCF1SGVCEP0_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGVCEP0_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ADCF1SGMCYCR0_BASE(void)
{
    extern __PST__g__54 ADCF1SGMCYCR0_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGMCYCR0_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_ADCF1ULLMSR0_BASE(void)
{
    extern __PST__g__57 ADCF1ULLMSR0_BASE;
    
    /* initialization with random value */
    {
        ADCF1ULLMSR0_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_ADCF1SGSTCR1_BASE(void)
{
    extern __PST__g__41 ADCF1SGSTCR1_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGSTCR1_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_ADCF1SGCR1_BASE(void)
{
    extern __PST__g__44 ADCF1SGCR1_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGCR1_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ADCF1SGVCSP1_BASE(void)
{
    extern __PST__g__47 ADCF1SGVCSP1_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGVCSP1_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ADCF1SGVCEP1_BASE(void)
{
    extern __PST__g__51 ADCF1SGVCEP1_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGVCEP1_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ADCF1SGMCYCR1_BASE(void)
{
    extern __PST__g__54 ADCF1SGMCYCR1_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGMCYCR1_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_ADCF1SGSR1_BASE(void)
{
    extern __PST__g__60 ADCF1SGSR1_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGSR1_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_ADCF1ULLMSR1_BASE(void)
{
    extern __PST__g__57 ADCF1ULLMSR1_BASE;
    
    /* initialization with random value */
    {
        ADCF1ULLMSR1_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_ADCF1SGSTCR2_BASE(void)
{
    extern __PST__g__41 ADCF1SGSTCR2_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGSTCR2_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_ADCF1SGCR2_BASE(void)
{
    extern __PST__g__44 ADCF1SGCR2_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGCR2_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ADCF1SGVCSP2_BASE(void)
{
    extern __PST__g__47 ADCF1SGVCSP2_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGVCSP2_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ADCF1SGVCEP2_BASE(void)
{
    extern __PST__g__51 ADCF1SGVCEP2_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGVCEP2_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ADCF1SGMCYCR2_BASE(void)
{
    extern __PST__g__54 ADCF1SGMCYCR2_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGMCYCR2_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_ADCF1ULLMSR2_BASE(void)
{
    extern __PST__g__57 ADCF1ULLMSR2_BASE;
    
    /* initialization with random value */
    {
        ADCF1ULLMSR2_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_ADCF1SGSTCR3_BASE(void)
{
    extern __PST__g__41 ADCF1SGSTCR3_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGSTCR3_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_ADCF1SGCR3_BASE(void)
{
    extern __PST__g__44 ADCF1SGCR3_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGCR3_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ADCF1SGVCSP3_BASE(void)
{
    extern __PST__g__47 ADCF1SGVCSP3_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGVCSP3_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ADCF1SGVCEP3_BASE(void)
{
    extern __PST__g__51 ADCF1SGVCEP3_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGVCEP3_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ADCF1SGMCYCR3_BASE(void)
{
    extern __PST__g__54 ADCF1SGMCYCR3_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGMCYCR3_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_ADCF1ULLMSR3_BASE(void)
{
    extern __PST__g__57 ADCF1ULLMSR3_BASE;
    
    /* initialization with random value */
    {
        ADCF1ULLMSR3_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_ADCF1SGSTCR4_BASE(void)
{
    extern __PST__g__41 ADCF1SGSTCR4_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGSTCR4_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_ADCF1SGCR4_BASE(void)
{
    extern __PST__g__44 ADCF1SGCR4_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGCR4_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ADCF1SGVCSP4_BASE(void)
{
    extern __PST__g__47 ADCF1SGVCSP4_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGVCSP4_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ADCF1SGVCEP4_BASE(void)
{
    extern __PST__g__51 ADCF1SGVCEP4_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGVCEP4_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ADCF1SGMCYCR4_BASE(void)
{
    extern __PST__g__54 ADCF1SGMCYCR4_BASE;
    
    /* initialization with random value */
    {
        ADCF1SGMCYCR4_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_ADCF1ULLMSR4_BASE(void)
{
    extern __PST__g__57 ADCF1ULLMSR4_BASE;
    
    /* initialization with random value */
    {
        ADCF1ULLMSR4_BASE = _main_gen_init_g57();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Adcf1CfgAndUse_Ip_AdcDiagcEndPtrOutp */
    _main_gen_init_sym_Adcf1CfgAndUse_Ip_AdcDiagcEndPtrOutp();
    
    /* init for variable Adcf1CfgAndUse_Ip_AdcDiagcStrtPtrOutp */
    _main_gen_init_sym_Adcf1CfgAndUse_Ip_AdcDiagcStrtPtrOutp();
    
    /* init for variable Adcf1CfgAndUse_Pim_Adcf1DiagcEndPtr */
    _main_gen_init_sym_Adcf1CfgAndUse_Pim_Adcf1DiagcEndPtr();
    
    /* init for variable Adcf1CfgAndUse_Pim_Adcf1DiagcStrtPtr */
    _main_gen_init_sym_Adcf1CfgAndUse_Pim_Adcf1DiagcStrtPtr();
    
    /* init for variable ADCF1VCR0_BASE */
    _main_gen_init_sym_ADCF1VCR0_BASE();
    
    /* init for variable ADCF1VCR1_BASE */
    _main_gen_init_sym_ADCF1VCR1_BASE();
    
    /* init for variable ADCF1VCR2_BASE */
    _main_gen_init_sym_ADCF1VCR2_BASE();
    
    /* init for variable ADCF1VCR3_BASE */
    _main_gen_init_sym_ADCF1VCR3_BASE();
    
    /* init for variable ADCF1VCR4_BASE */
    _main_gen_init_sym_ADCF1VCR4_BASE();
    
    /* init for variable ADCF1VCR5_BASE */
    _main_gen_init_sym_ADCF1VCR5_BASE();
    
    /* init for variable ADCF1VCR6_BASE */
    _main_gen_init_sym_ADCF1VCR6_BASE();
    
    /* init for variable ADCF1VCR7_BASE */
    _main_gen_init_sym_ADCF1VCR7_BASE();
    
    /* init for variable ADCF1VCR8_BASE */
    _main_gen_init_sym_ADCF1VCR8_BASE();
    
    /* init for variable ADCF1VCR9_BASE */
    _main_gen_init_sym_ADCF1VCR9_BASE();
    
    /* init for variable ADCF1VCR10_BASE */
    _main_gen_init_sym_ADCF1VCR10_BASE();
    
    /* init for variable ADCF1VCR11_BASE */
    _main_gen_init_sym_ADCF1VCR11_BASE();
    
    /* init for variable ADCF1VCR12_BASE */
    _main_gen_init_sym_ADCF1VCR12_BASE();
    
    /* init for variable ADCF1VCR13_BASE */
    _main_gen_init_sym_ADCF1VCR13_BASE();
    
    /* init for variable ADCF1VCR14_BASE */
    _main_gen_init_sym_ADCF1VCR14_BASE();
    
    /* init for variable ADCF1VCR15_BASE */
    _main_gen_init_sym_ADCF1VCR15_BASE();
    
    /* init for variable ADCF1VCR16_BASE */
    _main_gen_init_sym_ADCF1VCR16_BASE();
    
    /* init for variable ADCF1VCR17_BASE */
    _main_gen_init_sym_ADCF1VCR17_BASE();
    
    /* init for variable ADCF1VCR18_BASE */
    _main_gen_init_sym_ADCF1VCR18_BASE();
    
    /* init for variable ADCF1VCR19_BASE */
    _main_gen_init_sym_ADCF1VCR19_BASE();
    
    /* init for variable ADCF1VCR20_BASE */
    _main_gen_init_sym_ADCF1VCR20_BASE();
    
    /* init for variable ADCF1VCR21_BASE */
    _main_gen_init_sym_ADCF1VCR21_BASE();
    
    /* init for variable ADCF1VCR22_BASE */
    _main_gen_init_sym_ADCF1VCR22_BASE();
    
    /* init for variable ADCF1VCR23_BASE */
    _main_gen_init_sym_ADCF1VCR23_BASE();
    
    /* init for variable ADCF1ADCR1_BASE */
    _main_gen_init_sym_ADCF1ADCR1_BASE();
    
    /* init for variable ADCF1ADCR2_BASE */
    _main_gen_init_sym_ADCF1ADCR2_BASE();
    
    /* init for variable ADCF1SFTCR_BASE */
    _main_gen_init_sym_ADCF1SFTCR_BASE();
    
    /* init for variable ADCF1ULLMTBR0_BASE */
    _main_gen_init_sym_ADCF1ULLMTBR0_BASE();
    
    /* init for variable ADCF1ULLMTBR1_BASE */
    _main_gen_init_sym_ADCF1ULLMTBR1_BASE();
    
    /* init for variable ADCF1ULLMTBR2_BASE */
    _main_gen_init_sym_ADCF1ULLMTBR2_BASE();
    
    /* init for variable ADCF1SGSTCR0_BASE */
    _main_gen_init_sym_ADCF1SGSTCR0_BASE();
    
    /* init for variable ADCF1SGCR0_BASE */
    _main_gen_init_sym_ADCF1SGCR0_BASE();
    
    /* init for variable ADCF1SGVCSP0_BASE */
    _main_gen_init_sym_ADCF1SGVCSP0_BASE();
    
    /* init for variable ADCF1SGVCEP0_BASE */
    _main_gen_init_sym_ADCF1SGVCEP0_BASE();
    
    /* init for variable ADCF1SGMCYCR0_BASE */
    _main_gen_init_sym_ADCF1SGMCYCR0_BASE();
    
    /* init for variable ADCF1ULLMSR0_BASE */
    _main_gen_init_sym_ADCF1ULLMSR0_BASE();
    
    /* init for variable ADCF1SGSTCR1_BASE */
    _main_gen_init_sym_ADCF1SGSTCR1_BASE();
    
    /* init for variable ADCF1SGCR1_BASE */
    _main_gen_init_sym_ADCF1SGCR1_BASE();
    
    /* init for variable ADCF1SGVCSP1_BASE */
    _main_gen_init_sym_ADCF1SGVCSP1_BASE();
    
    /* init for variable ADCF1SGVCEP1_BASE */
    _main_gen_init_sym_ADCF1SGVCEP1_BASE();
    
    /* init for variable ADCF1SGMCYCR1_BASE */
    _main_gen_init_sym_ADCF1SGMCYCR1_BASE();
    
    /* init for variable ADCF1SGSR1_BASE */
    _main_gen_init_sym_ADCF1SGSR1_BASE();
    
    /* init for variable ADCF1ULLMSR1_BASE */
    _main_gen_init_sym_ADCF1ULLMSR1_BASE();
    
    /* init for variable ADCF1SGSTCR2_BASE */
    _main_gen_init_sym_ADCF1SGSTCR2_BASE();
    
    /* init for variable ADCF1SGCR2_BASE */
    _main_gen_init_sym_ADCF1SGCR2_BASE();
    
    /* init for variable ADCF1SGVCSP2_BASE */
    _main_gen_init_sym_ADCF1SGVCSP2_BASE();
    
    /* init for variable ADCF1SGVCEP2_BASE */
    _main_gen_init_sym_ADCF1SGVCEP2_BASE();
    
    /* init for variable ADCF1SGMCYCR2_BASE */
    _main_gen_init_sym_ADCF1SGMCYCR2_BASE();
    
    /* init for variable ADCF1ULLMSR2_BASE */
    _main_gen_init_sym_ADCF1ULLMSR2_BASE();
    
    /* init for variable ADCF1SGSTCR3_BASE */
    _main_gen_init_sym_ADCF1SGSTCR3_BASE();
    
    /* init for variable ADCF1SGCR3_BASE */
    _main_gen_init_sym_ADCF1SGCR3_BASE();
    
    /* init for variable ADCF1SGVCSP3_BASE */
    _main_gen_init_sym_ADCF1SGVCSP3_BASE();
    
    /* init for variable ADCF1SGVCEP3_BASE */
    _main_gen_init_sym_ADCF1SGVCEP3_BASE();
    
    /* init for variable ADCF1SGMCYCR3_BASE */
    _main_gen_init_sym_ADCF1SGMCYCR3_BASE();
    
    /* init for variable ADCF1ULLMSR3_BASE */
    _main_gen_init_sym_ADCF1ULLMSR3_BASE();
    
    /* init for variable ADCF1SGSTCR4_BASE */
    _main_gen_init_sym_ADCF1SGSTCR4_BASE();
    
    /* init for variable ADCF1SGCR4_BASE */
    _main_gen_init_sym_ADCF1SGCR4_BASE();
    
    /* init for variable ADCF1SGVCSP4_BASE */
    _main_gen_init_sym_ADCF1SGVCSP4_BASE();
    
    /* init for variable ADCF1SGVCEP4_BASE */
    _main_gen_init_sym_ADCF1SGVCEP4_BASE();
    
    /* init for variable ADCF1SGMCYCR4_BASE */
    _main_gen_init_sym_ADCF1SGMCYCR4_BASE();
    
    /* init for variable ADCF1ULLMSR4_BASE */
    _main_gen_init_sym_ADCF1ULLMSR4_BASE();
    
}
