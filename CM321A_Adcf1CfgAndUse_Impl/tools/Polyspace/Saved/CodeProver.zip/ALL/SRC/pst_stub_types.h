typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT64 __PST__g__16(void);
typedef __PST__g__11 *__PST__g__18;
typedef volatile __PST__FLOAT64 __PST__g__19;
typedef __PST__SINT8 *__PST__g__21;
typedef volatile __PST__g__21 __PST__g__20;
typedef __PST__SINT32 __PST__g__108[1];
union __PST__g__23
  {
    __PST__g__108 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__23 __PST__g__22;
struct __PST__g__24
  {
    __PST__UINT32 __pst_unused_field_0 : 5;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 3;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
  };
struct __PST__g__30
  {
    __PST__UINT8 _SUSMTD : 2;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
  };
union __PST__g__29
  {
    struct __PST__g__30 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__29 __PST__g__28;
struct __PST__g__34
  {
    __PST__UINT8 _ADDNT : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 _DFMT : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__33
  {
    struct __PST__g__34 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__33 __PST__g__32;
struct __PST__g__37
  {
    __PST__UINT8 _IDEIE : 1;
    __PST__UINT8 _PEIE : 1;
    __PST__UINT8 _OWEIE : 1;
    __PST__UINT8 _ULEIE : 1;
    __PST__UINT8 _RDCLRE : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__36
  {
    struct __PST__g__37 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef volatile union __PST__g__36 __PST__g__35;
union __PST__g__39
  {
    __PST__g__108 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef volatile union __PST__g__39 __PST__g__38;
struct __PST__g__40
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_1 : 16;
  };
typedef __PST__SINT8 __PST__g__109[1];
union __PST__g__42
  {
    __PST__g__109 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef volatile union __PST__g__42 __PST__g__41;
struct __PST__g__43
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__45
  {
    __PST__g__109 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef volatile union __PST__g__45 __PST__g__44;
struct __PST__g__46
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__48
  {
    __PST__g__109 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef volatile union __PST__g__48 __PST__g__47;
struct __PST__g__49
  {
    __PST__UINT8 __pst_unused_field_0 : 6;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
  };
union __PST__g__52
  {
    __PST__g__109 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef volatile union __PST__g__52 __PST__g__51;
struct __PST__g__53
  {
    __PST__UINT8 __pst_unused_field_0 : 6;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
  };
union __PST__g__55
  {
    __PST__g__109 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef volatile union __PST__g__55 __PST__g__54;
struct __PST__g__56
  {
    __PST__UINT8 __pst_unused_field_0 : 8;
  };
union __PST__g__58
  {
    __PST__g__109 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef volatile union __PST__g__58 __PST__g__57;
struct __PST__g__59
  {
    __PST__UINT8 __pst_unused_field_0 : 2;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
  };
union __PST__g__62
  {
    __PST__g__109 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef const union __PST__g__62 __PST__g__61;
typedef volatile __PST__g__61 __PST__g__60;
struct __PST__g__64
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
  };
typedef const struct __PST__g__64 __PST__g__63;
typedef __PST__VOID __PST__g__66(__PST__SINT32);
typedef const __PST__UINT8 __PST__g__67;
typedef __PST__g__44 *__PST__g__68;
typedef volatile __PST__UINT8 __PST__g__69;
typedef __PST__g__69 *__PST__g__70;
typedef __PST__g__47 *__PST__g__71;
typedef __PST__g__51 *__PST__g__72;
typedef __PST__g__60 *__PST__g__73;
typedef volatile __PST__g__67 __PST__g__74;
typedef __PST__g__74 *__PST__g__75;
typedef __PST__g__22 *__PST__g__76;
typedef volatile __PST__UINT32 __PST__g__77;
typedef __PST__g__77 *__PST__g__78;
typedef __PST__g__28 *__PST__g__79;
typedef volatile struct __PST__g__30 __PST__g__80;
typedef __PST__g__80 *__PST__g__81;
typedef __PST__g__32 *__PST__g__84;
typedef volatile struct __PST__g__34 __PST__g__85;
typedef __PST__g__85 *__PST__g__86;
typedef __PST__g__35 *__PST__g__89;
typedef volatile struct __PST__g__37 __PST__g__90;
typedef __PST__g__90 *__PST__g__91;
typedef __PST__g__38 *__PST__g__92;
typedef __PST__g__41 *__PST__g__93;
typedef __PST__g__54 *__PST__g__94;
typedef __PST__g__57 *__PST__g__95;
typedef __PST__g__15 *__PST__g__96;
typedef volatile __PST__SINT32 __PST__g__97;
typedef __PST__SINT8 __PST__g__103(void);
typedef volatile __PST__SINT8 __PST__g__104;
typedef __PST__UINT8 __PST__g__105(void);
typedef __PST__SINT32 __PST__g__106(void);
typedef __PST__UINT32 __PST__g__107(void);
