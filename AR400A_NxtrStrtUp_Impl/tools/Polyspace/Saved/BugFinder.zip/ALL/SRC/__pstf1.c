/**********************************************************************************************************************
* Copyright 2015 Nexteer 
* Nexteer Confidential
*
* Module File Name  : NxtrStrtUp.h
* Module Description: Low level microcontroller startup library
* Project           : CBD
* Author            : Jared Julien
***********************************************************************************************************************
* Version Control:
* %version:          2 %
* %derived_by:       kzdyfh %
*----------------------------------------------------------------------------------------------------------------------
* Date      Rev      Author    Change Description                                                             SCR #
* -------   -------  --------  -----------------------------------------------------------------------------  ---------
* 12/10/15  1        JWJ       Initial Version                                                                EA4#9023
* 05/31/17  2        JWJ       Added linker symbols for cleared RAM ranges and cleaned up unused statements   EA4#12342
**********************************************************************************************************************/

#ifndef NXTRSTRTUP_H
#define NXTRSTRTUP_H

#include "Std_Types.h"

/********************************************** Local Type Definitions ************************************************/
typedef struct {
        P2VAR(uint32, AUTOMATIC, AUTOMATIC) TarPtr_Cnt_u32;
        P2VAR(uint32, AUTOMATIC, AUTOMATIC) SrcPtr_Cnt_u32;
        VAR(uint32, AUTOMATIC) Size_Cnt_u32;
} RomBlkDftTyp;


/********************************************* Function Prototypes ****************************************************/
extern void nxtr_strt_up(void);


/*********************************************** Extern Statements ****************************************************/
void __nxtr_strt_up(void);
extern int main(void);
extern VAR(uint32, AUTOMATIC) clearedRamStart[];
extern VAR(uint32, AUTOMATIC) clearedRamEnd[];

extern VAR(uint8, AUTOMATIC) __ghsbinfo_copy[];
extern VAR(uint8, AUTOMATIC) __ghseinfo_copy[];


#endif
