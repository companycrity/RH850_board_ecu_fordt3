#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordAbsPrsnt(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_FordAbsPrsnt;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_FordAbsPrsnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordActvNiblCtrlEnad(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_FordActvNiblCtrlEnad;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_FordActvNiblCtrlEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordBrkOscnRednEnad(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_FordBrkOscnRednEnad;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_FordBrkOscnRednEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordCanDtcInhb(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_FordCanDtcInhb;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_FordCanDtcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordEpsLifeCycMod(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_FordEpsLifeCycMod;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_FordEpsLifeCycMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordInvldMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_FordInvldMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_FordInvldMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordMfgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_FordMfgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_FordMfgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordMissMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_FordMissMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_FordMissMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordTqSteerCmpEnad(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_FordTqSteerCmpEnad;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_FordTqSteerCmpEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordTrlrBackupAssiEnad(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Ip_FordTrlrBackupAssiEnad;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Ip_FordTrlrBackupAssiEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlSpdInvldFaildThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlSpdInvldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlSpdInvldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlSpdInvldPassdThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlSpdInvldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlSpdInvldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldFaildThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldMissThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldPassdThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlSpdInvldFaildThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlSpdInvldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlSpdInvldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlSpdInvldPassdThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlSpdInvldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlSpdInvldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldFaildThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldMissThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldPassdThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdMissMsgFaildThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdMissMsgFaildThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdMissMsgFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdMissMsgPassdThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdMissMsgPassdThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdMissMsgPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlSpdInvldFaildThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlSpdInvldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlSpdInvldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlSpdInvldPassdThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlSpdInvldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlSpdInvldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldFaildThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldMissThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldPassdThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlSpdInvldFaildThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlSpdInvldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlSpdInvldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlSpdInvldPassdThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlSpdInvldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlSpdInvldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldFaildThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldMissThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldPassdThd(void)
{
    extern __PST__g__32 FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_ClrDiagcFlgProxyPrev(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Pim_ClrDiagcFlgProxyPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_ClrDiagcFlgProxyPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdInvldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdInvldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdInvldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdInvldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdInvldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdInvldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdPrev(void)
{
    extern __PST__FLOAT32 FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdRawPrev(void)
{
    extern __PST__UINT16 FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdRawPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldPrev(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdInvldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdInvldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdInvldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdInvldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdInvldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdInvldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdPrev(void)
{
    extern __PST__FLOAT32 FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdRawPrev(void)
{
    extern __PST__UINT16 FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdRawPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldPrev(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehMsg217Miss(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Pim_FordVehMsg217Miss;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehMsg217Miss = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehMsg217Rxd(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Pim_FordVehMsg217Rxd;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehMsg217Rxd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdInvldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdInvldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdInvldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdInvldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdInvldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdInvldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdPrev(void)
{
    extern __PST__FLOAT32 FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdRawPrev(void)
{
    extern __PST__UINT16 FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdRawPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldPrev(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdInvldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdInvldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdInvldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdInvldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdInvldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdInvldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdPrev(void)
{
    extern __PST__FLOAT32 FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdRawPrev(void)
{
    extern __PST__UINT16 FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdRawPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldPrev(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldPrev;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_MissMsgFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_MissMsgFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_MissMsgFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Pim_MissMsgPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Pim_MissMsgPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Pim_MissMsgPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 FordMsg217BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg217BusHiSpd_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 FordMsg217BusHiSpd_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        FordMsg217BusHiSpd_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FordMsg217BusHiSpd_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_ClrDiagcFlgProxy();
    
    /* init for variable FordMsg217BusHiSpd_Ip_FordAbsPrsnt */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordAbsPrsnt();
    
    /* init for variable FordMsg217BusHiSpd_Ip_FordActvNiblCtrlEnad */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordActvNiblCtrlEnad();
    
    /* init for variable FordMsg217BusHiSpd_Ip_FordBrkOscnRednEnad */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordBrkOscnRednEnad();
    
    /* init for variable FordMsg217BusHiSpd_Ip_FordCanDtcInhb */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordCanDtcInhb();
    
    /* init for variable FordMsg217BusHiSpd_Ip_FordEpsLifeCycMod */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordEpsLifeCycMod();
    
    /* init for variable FordMsg217BusHiSpd_Ip_FordInvldMsgDiagcInhb */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordInvldMsgDiagcInhb();
    
    /* init for variable FordMsg217BusHiSpd_Ip_FordMfgDiagcInhb */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordMfgDiagcInhb();
    
    /* init for variable FordMsg217BusHiSpd_Ip_FordMissMsgDiagcInhb */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordMissMsgDiagcInhb();
    
    /* init for variable FordMsg217BusHiSpd_Ip_FordTqSteerCmpEnad */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordTqSteerCmpEnad();
    
    /* init for variable FordMsg217BusHiSpd_Ip_FordTrlrBackupAssiEnad */
    _main_gen_init_sym_FordMsg217BusHiSpd_Ip_FordTrlrBackupAssiEnad();
    
    /* init for variable FordMsg217BusHiSpd_Op_FordVehFrntLeWhlSpd : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehFrntLeWhlSpdRaw : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehFrntLeWhlSpdVld : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehFrntRiWhlSpd : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehFrntRiWhlSpdRaw : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehFrntRiWhlSpdVld : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehReLeWhlSpd : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehReLeWhlSpdRaw : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehReLeWhlSpdVld : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehReRiWhlSpd : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehReRiWhlSpdRaw : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Op_FordVehReRiWhlSpdVld : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlSpdInvldFaildThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlSpdInvldFaildThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlSpdInvldPassdThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlSpdInvldPassdThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldFaildThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldFaildThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldMissThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldMissThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldPassdThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntLeWhlVldPassdThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlSpdInvldFaildThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlSpdInvldFaildThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlSpdInvldPassdThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlSpdInvldPassdThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldFaildThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldFaildThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldMissThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldMissThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldPassdThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdFrntRiWhlVldPassdThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdMissMsgFaildThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdMissMsgFaildThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdMissMsgPassdThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdMissMsgPassdThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlSpdInvldFaildThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlSpdInvldFaildThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlSpdInvldPassdThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlSpdInvldPassdThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldFaildThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldFaildThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldMissThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldMissThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldPassdThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReLeWhlVldPassdThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlSpdInvldFaildThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlSpdInvldFaildThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlSpdInvldPassdThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlSpdInvldPassdThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldFaildThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldFaildThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldMissThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldMissThd();
    
    /* init for variable FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldPassdThd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Cal_FordMsg217BusHiSpdReRiWhlVldPassdThd();
    
    /* init for variable FordMsg217BusHiSpd_Pim_ClrDiagcFlgProxyPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_ClrDiagcFlgProxyPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdInvldFaildRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdInvldFaildRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdInvldPassdRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdInvldPassdRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdRawPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdRawPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldFaildRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldFaildRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldMissRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldMissRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldPassdRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldPassdRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntLeWhlSpdVldPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdInvldFaildRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdInvldFaildRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdInvldPassdRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdInvldPassdRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdRawPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdRawPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldFaildRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldFaildRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldMissRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldMissRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldPassdRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldPassdRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehFrntRiWhlSpdVldPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehMsg217Miss */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehMsg217Miss();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehMsg217Rxd */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehMsg217Rxd();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdInvldFaildRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdInvldFaildRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdInvldPassdRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdInvldPassdRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdRawPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdRawPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldFaildRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldFaildRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldMissRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldMissRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldPassdRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldPassdRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReLeWhlSpdVldPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdInvldFaildRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdInvldFaildRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdInvldPassdRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdInvldPassdRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdRawPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdRawPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldFaildRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldFaildRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldMissRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldMissRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldPassdRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldPassdRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldPrev */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_FordVehReRiWhlSpdVldPrev();
    
    /* init for variable FordMsg217BusHiSpd_Pim_MissMsgFaildRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_MissMsgFaildRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Pim_MissMsgPassdRefTi */
    _main_gen_init_sym_FordMsg217BusHiSpd_Pim_MissMsgPassdRefTi();
    
    /* init for variable FordMsg217BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_FordMsg217BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable FordMsg217BusHiSpd_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_FordMsg217BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable FordMsg217BusHiSpd_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable FordMsg217BusHiSpd_Srv_SetNtcSts_Return */
    _main_gen_init_sym_FordMsg217BusHiSpd_Srv_SetNtcSts_Return();
    
}
