#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_DualEcuIdn_Ip_EcuComTiOut(void)
{
    extern __PST__UINT8 DualEcuIdn_Ip_EcuComTiOut;
    
    /* initialization with random value */
    {
        DualEcuIdn_Ip_EcuComTiOut = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Pim_EcuIdInt(void)
{
    extern __PST__UINT8 DualEcuIdn_Pim_EcuIdInt;
    
    /* initialization with random value */
    {
        DualEcuIdn_Pim_EcuIdInt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Pim_EcuIdnEvlnCmpl(void)
{
    extern __PST__UINT8 DualEcuIdn_Pim_EcuIdnEvlnCmpl;
    
    /* initialization with random value */
    {
        DualEcuIdn_Pim_EcuIdnEvlnCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Pim_SecdryEcuIdnReqTiOutCntr(void)
{
    extern __PST__UINT8 DualEcuIdn_Pim_SecdryEcuIdnReqTiOutCntr;
    
    /* initialization with random value */
    {
        DualEcuIdn_Pim_SecdryEcuIdnReqTiOutCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Srv_GetSigImcData_u08_Data(void)
{
    extern __PST__UINT8 DualEcuIdn_Srv_GetSigImcData_u08_Data;
    
    /* initialization with random value */
    {
        DualEcuIdn_Srv_GetSigImcData_u08_Data = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Srv_GetSigImcData_u08_Sts(void)
{
    extern __PST__UINT8 DualEcuIdn_Srv_GetSigImcData_u08_Sts;
    
    /* initialization with random value */
    {
        DualEcuIdn_Srv_GetSigImcData_u08_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Srv_GetSigImcData_u08_Return(void)
{
    extern __PST__UINT8 DualEcuIdn_Srv_GetSigImcData_u08_Return;
    
    /* initialization with random value */
    {
        DualEcuIdn_Srv_GetSigImcData_u08_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin1_PinSt(void)
{
    extern __PST__UINT8 DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin1_PinSt;
    
    /* initialization with random value */
    {
        DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin1_PinSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin1_Return(void)
{
    extern __PST__UINT8 DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin1_Return;
    
    /* initialization with random value */
    {
        DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin1_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin2_PinSt(void)
{
    extern __PST__UINT8 DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin2_PinSt;
    
    /* initialization with random value */
    {
        DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin2_PinSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin2_Return(void)
{
    extern __PST__UINT8 DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin2_Return;
    
    /* initialization with random value */
    {
        DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin2_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualEcuIdn_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 DualEcuIdn_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        DualEcuIdn_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable DualEcuIdn_Ip_EcuComTiOut */
    _main_gen_init_sym_DualEcuIdn_Ip_EcuComTiOut();
    
    /* init for variable DualEcuIdn_Op_EcuId : useless (never read) */

    /* init for variable DualEcuIdn_Pim_EcuIdInt */
    _main_gen_init_sym_DualEcuIdn_Pim_EcuIdInt();
    
    /* init for variable DualEcuIdn_Pim_EcuIdnEvlnCmpl */
    _main_gen_init_sym_DualEcuIdn_Pim_EcuIdnEvlnCmpl();
    
    /* init for variable DualEcuIdn_Pim_SecdryEcuIdnReqTiOutCntr */
    _main_gen_init_sym_DualEcuIdn_Pim_SecdryEcuIdnReqTiOutCntr();
    
    /* init for variable DualEcuIdn_Srv_GetSigImcData_u08_SigId : useless (never read) */

    /* init for variable DualEcuIdn_Srv_GetSigImcData_u08_Data */
    _main_gen_init_sym_DualEcuIdn_Srv_GetSigImcData_u08_Data();
    
    /* init for variable DualEcuIdn_Srv_GetSigImcData_u08_Sts */
    _main_gen_init_sym_DualEcuIdn_Srv_GetSigImcData_u08_Sts();
    
    /* init for variable DualEcuIdn_Srv_GetSigImcData_u08_Return */
    _main_gen_init_sym_DualEcuIdn_Srv_GetSigImcData_u08_Return();
    
    /* init for variable DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin1_PinSt */
    _main_gen_init_sym_DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin1_PinSt();
    
    /* init for variable DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin1_Return */
    _main_gen_init_sym_DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin1_Return();
    
    /* init for variable DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin2_PinSt */
    _main_gen_init_sym_DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin2_PinSt();
    
    /* init for variable DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin2_Return */
    _main_gen_init_sym_DualEcuIdn_Srv_IoHwAb_GetGpioEcuIdnPin2_Return();
    
    /* init for variable DualEcuIdn_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable DualEcuIdn_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable DualEcuIdn_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable DualEcuIdn_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable DualEcuIdn_Srv_SetNtcSts_Return */
    _main_gen_init_sym_DualEcuIdn_Srv_SetNtcSts_Return();
    
}
