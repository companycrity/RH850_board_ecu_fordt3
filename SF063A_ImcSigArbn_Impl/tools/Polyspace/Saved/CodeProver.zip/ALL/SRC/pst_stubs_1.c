#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct __PST__g__28 _main_gen_init_g28(void)
{
    static struct __PST__g__28 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ImcSigArbn_Ip_EcuIdn(void)
{
    extern __PST__UINT8 ImcSigArbn_Ip_EcuIdn;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_EcuIdn = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Ip_HwAg(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Ip_HwAg;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Ip_HwTq(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Ip_HwTq;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Ip_PosnServoHwAg(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Ip_PosnServoHwAg;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_PosnServoHwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Ip_PosnServoIntgtrSt(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Ip_PosnServoIntgtrSt;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_PosnServoIntgtrSt = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Ip_PosnTrakgIntgtrSt1(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Ip_PosnTrakgIntgtrSt1;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_PosnTrakgIntgtrSt1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Ip_PosnTrakgIntgtrSt2(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Ip_PosnTrakgIntgtrSt2;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_PosnTrakgIntgtrSt2 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Ip_PullCmpLongTermIntgtrSt(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Ip_PullCmpLongTermIntgtrSt;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_PullCmpLongTermIntgtrSt = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Ip_PullCmpShoTermIntgtrSt(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Ip_PullCmpShoTermIntgtrSt;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_PullCmpShoTermIntgtrSt = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Ip_VehSpd;
    
    /* initialization with random value */
    {
        ImcSigArbn_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnArbnFltTmr(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnArbnFltTmr;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnArbnFltTmr = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgArbnEna(void)
{
    extern __PST__g__27 ImcSigArbn_Cal_ImcSigArbnHwAgArbnEna;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnHwAgArbnEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgArbnLpFil(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnHwAgArbnLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnHwAgArbnLpFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgArbnOffsLim(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnHwAgArbnOffsLim;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnHwAgArbnOffsLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnEna(void)
{
    extern __PST__g__27 ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnEna;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnLpFil(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnLpFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnOffsLim(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnOffsLim;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnOffsLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwTqArbnEna(void)
{
    extern __PST__g__27 ImcSigArbn_Cal_ImcSigArbnHwTqArbnEna;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnHwTqArbnEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwTqArbnLpFil(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnHwTqArbnLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnHwTqArbnLpFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwTqArbnOffsLim(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnHwTqArbnOffsLim;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnHwTqArbnOffsLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnMotVelArbnEna(void)
{
    extern __PST__g__27 ImcSigArbn_Cal_ImcSigArbnMotVelArbnEna;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnMotVelArbnEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnMotVelArbnLpFil(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnMotVelArbnLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnMotVelArbnLpFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnMotVelArbnOffsLim(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnMotVelArbnOffsLim;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnMotVelArbnOffsLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPosnServoArbnOffsLim(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnPosnServoArbnOffsLim;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPosnServoArbnOffsLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPosnServoIntgtrStArbnEna(void)
{
    extern __PST__g__27 ImcSigArbn_Cal_ImcSigArbnPosnServoIntgtrStArbnEna;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPosnServoIntgtrStArbnEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPosnServoIntgtrStArbnLpFil(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnPosnServoIntgtrStArbnLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPosnServoIntgtrStArbnLpFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPosnTrakg1ArbnOffsLim(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnPosnTrakg1ArbnOffsLim;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPosnTrakg1ArbnOffsLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPosnTrakg2ArbnOffsLim(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnPosnTrakg2ArbnOffsLim;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPosnTrakg2ArbnOffsLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermArbnOffsLim(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermArbnOffsLim;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermArbnOffsLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermIntgtrStArbnEna(void)
{
    extern __PST__g__27 ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermIntgtrStArbnEna;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermIntgtrStArbnEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermIntgtrStArbnLpFil(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermIntgtrStArbnLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermIntgtrStArbnLpFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermArbnOffsLim(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermArbnOffsLim;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermArbnOffsLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermIntgtrStArbnEna(void)
{
    extern __PST__g__27 ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermIntgtrStArbnEna;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermIntgtrStArbnEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermIntgtrStArbnLpFil(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermIntgtrStArbnLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermIntgtrStArbnLpFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnSysStTmr(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnSysStTmr;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnSysStTmr = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt1ArbnEna(void)
{
    extern __PST__g__27 ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt1ArbnEna;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt1ArbnEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt1ArbnLpFil(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt1ArbnLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt1ArbnLpFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt2ArbnEna(void)
{
    extern __PST__g__27 ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt2ArbnEna;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt2ArbnEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt2ArbnLpFil(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt2ArbnLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt2ArbnLpFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnVehSpdArbnEna(void)
{
    extern __PST__g__27 ImcSigArbn_Cal_ImcSigArbnVehSpdArbnEna;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnVehSpdArbnEna = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnVehSpdArbnLpFil(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnVehSpdArbnLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnVehSpdArbnLpFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnVehSpdArbnOffsLim(void)
{
    extern __PST__g__26 ImcSigArbn_Cal_ImcSigArbnVehSpdArbnOffsLim;
    
    /* initialization with random value */
    {
        ImcSigArbn_Cal_ImcSigArbnVehSpdArbnOffsLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_ArbnErrPrev(void)
{
    extern __PST__UINT8 ImcSigArbn_Pim_ArbnErrPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_ArbnErrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_ArbnFltPrev(void)
{
    extern __PST__UINT8 ImcSigArbn_Pim_ArbnFltPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_ArbnFltPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_ArbnFltRefTiEnaLrng(void)
{
    extern __PST__UINT32 ImcSigArbn_Pim_ArbnFltRefTiEnaLrng;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_ArbnFltRefTiEnaLrng = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_HwAgLpFil(void)
{
    extern struct __PST__g__28 ImcSigArbn_Pim_HwAgLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_HwAgLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_HwAgOffsPrev(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Pim_HwAgOffsPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_HwAgOffsPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_HwAgTarLpFil(void)
{
    extern struct __PST__g__28 ImcSigArbn_Pim_HwAgTarLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_HwAgTarLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_HwAgTarOffsPrev(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Pim_HwAgTarOffsPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_HwAgTarOffsPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_HwTqLpFil(void)
{
    extern struct __PST__g__28 ImcSigArbn_Pim_HwTqLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_HwTqLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_HwTqOffsPrev(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Pim_HwTqOffsPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_HwTqOffsPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_MotVelCrfOffsPrev(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Pim_MotVelCrfOffsPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_MotVelCrfOffsPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_MotVelLpFil(void)
{
    extern struct __PST__g__28 ImcSigArbn_Pim_MotVelLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_MotVelLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_PosnServoIntgtrLpFil(void)
{
    extern struct __PST__g__28 ImcSigArbn_Pim_PosnServoIntgtrLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_PosnServoIntgtrLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_PosnServoIntgtrOffsPrev(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Pim_PosnServoIntgtrOffsPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_PosnServoIntgtrOffsPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_PullCmpLongTermCmpLpFil(void)
{
    extern struct __PST__g__28 ImcSigArbn_Pim_PullCmpLongTermCmpLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_PullCmpLongTermCmpLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_PullCmpLongTermIntgtrStOffsPrev(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Pim_PullCmpLongTermIntgtrStOffsPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_PullCmpLongTermIntgtrStOffsPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_PullCmpShoTermCmpLpFil(void)
{
    extern struct __PST__g__28 ImcSigArbn_Pim_PullCmpShoTermCmpLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_PullCmpShoTermCmpLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_PullCmpShoTermIntgtrStOffsPrev(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Pim_PullCmpShoTermIntgtrStOffsPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_PullCmpShoTermIntgtrStOffsPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_SysStLrngEnaPrev(void)
{
    extern __PST__UINT8 ImcSigArbn_Pim_SysStLrngEnaPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_SysStLrngEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_SysStRefTiEnaLrng(void)
{
    extern __PST__UINT32 ImcSigArbn_Pim_SysStRefTiEnaLrng;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_SysStRefTiEnaLrng = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_TrakgIntgtrSt1LpFil(void)
{
    extern struct __PST__g__28 ImcSigArbn_Pim_TrakgIntgtrSt1LpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_TrakgIntgtrSt1LpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_TrakgIntgtrSt1Offs(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Pim_TrakgIntgtrSt1Offs;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_TrakgIntgtrSt1Offs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_TrakgIntgtrSt2LpFil(void)
{
    extern struct __PST__g__28 ImcSigArbn_Pim_TrakgIntgtrSt2LpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_TrakgIntgtrSt2LpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_TrakgIntgtrSt2Offs(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Pim_TrakgIntgtrSt2Offs;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_TrakgIntgtrSt2Offs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_VehSpdLpFil(void)
{
    extern struct __PST__g__28 ImcSigArbn_Pim_VehSpdLpFil;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_VehSpdLpFil = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Pim_VehSpdOffsPrev(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Pim_VehSpdOffsPrev;
    
    /* initialization with random value */
    {
        ImcSigArbn_Pim_VehSpdOffsPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Irv_HwAgOffs(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Irv_HwAgOffs;
    
    /* initialization with random value */
    {
        ImcSigArbn_Irv_HwAgOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Irv_HwAgTarOffs(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Irv_HwAgTarOffs;
    
    /* initialization with random value */
    {
        ImcSigArbn_Irv_HwAgTarOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Irv_HwTqOffs(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Irv_HwTqOffs;
    
    /* initialization with random value */
    {
        ImcSigArbn_Irv_HwTqOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Irv_ImcSysSt10MilliSec(void)
{
    extern __PST__UINT8 ImcSigArbn_Irv_ImcSysSt10MilliSec;
    
    /* initialization with random value */
    {
        ImcSigArbn_Irv_ImcSysSt10MilliSec = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Irv_ImcSysStVld10MilliSec(void)
{
    extern __PST__UINT8 ImcSigArbn_Irv_ImcSysStVld10MilliSec;
    
    /* initialization with random value */
    {
        ImcSigArbn_Irv_ImcSysStVld10MilliSec = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Irv_MotVelCrfOffs(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Irv_MotVelCrfOffs;
    
    /* initialization with random value */
    {
        ImcSigArbn_Irv_MotVelCrfOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Irv_VehSpdOffs(void)
{
    extern __PST__FLOAT32 ImcSigArbn_Irv_VehSpdOffs;
    
    /* initialization with random value */
    {
        ImcSigArbn_Irv_VehSpdOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 ImcSigArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        ImcSigArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 ImcSigArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        ImcSigArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_ImcSigArbn_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 ImcSigArbn_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        ImcSigArbn_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ImcSigArbn_Ip_EcuIdn */
    _main_gen_init_sym_ImcSigArbn_Ip_EcuIdn();
    
    /* init for variable ImcSigArbn_Ip_HwAg */
    _main_gen_init_sym_ImcSigArbn_Ip_HwAg();
    
    /* init for variable ImcSigArbn_Ip_HwTq */
    _main_gen_init_sym_ImcSigArbn_Ip_HwTq();
    
    /* init for variable ImcSigArbn_Ip_MotVelCrf */
    _main_gen_init_sym_ImcSigArbn_Ip_MotVelCrf();
    
    /* init for variable ImcSigArbn_Ip_PosnServoHwAg */
    _main_gen_init_sym_ImcSigArbn_Ip_PosnServoHwAg();
    
    /* init for variable ImcSigArbn_Ip_PosnServoIntgtrSt */
    _main_gen_init_sym_ImcSigArbn_Ip_PosnServoIntgtrSt();
    
    /* init for variable ImcSigArbn_Ip_PosnTrakgIntgtrSt1 */
    _main_gen_init_sym_ImcSigArbn_Ip_PosnTrakgIntgtrSt1();
    
    /* init for variable ImcSigArbn_Ip_PosnTrakgIntgtrSt2 */
    _main_gen_init_sym_ImcSigArbn_Ip_PosnTrakgIntgtrSt2();
    
    /* init for variable ImcSigArbn_Ip_PullCmpLongTermIntgtrSt */
    _main_gen_init_sym_ImcSigArbn_Ip_PullCmpLongTermIntgtrSt();
    
    /* init for variable ImcSigArbn_Ip_PullCmpShoTermIntgtrSt */
    _main_gen_init_sym_ImcSigArbn_Ip_PullCmpShoTermIntgtrSt();
    
    /* init for variable ImcSigArbn_Ip_VehSpd */
    _main_gen_init_sym_ImcSigArbn_Ip_VehSpd();
    
    /* init for variable ImcSigArbn_Op_HwAgImcCorrd : useless (never read) */

    /* init for variable ImcSigArbn_Op_HwTqImcCorrd : useless (never read) */

    /* init for variable ImcSigArbn_Op_ImcSysSt : useless (never read) */

    /* init for variable ImcSigArbn_Op_ImcSysStVld : useless (never read) */

    /* init for variable ImcSigArbn_Op_MotVelCrfImcCorrd : useless (never read) */

    /* init for variable ImcSigArbn_Op_PosnServoHwAgImcCorrd : useless (never read) */

    /* init for variable ImcSigArbn_Op_PosnServoIntgtrOffs : useless (never read) */

    /* init for variable ImcSigArbn_Op_PosnTrakgArbnFltMtgtnEna : useless (never read) */

    /* init for variable ImcSigArbn_Op_PosnTrakgIntgtrSt1Offs : useless (never read) */

    /* init for variable ImcSigArbn_Op_PosnTrakgIntgtrSt2Offs : useless (never read) */

    /* init for variable ImcSigArbn_Op_PullCmpLongTermIntgtrStOffs : useless (never read) */

    /* init for variable ImcSigArbn_Op_PullCmpShoTermIntgtrStOffs : useless (never read) */

    /* init for variable ImcSigArbn_Op_VehSpdImcCorrd : useless (never read) */

    /* init for variable ImcSigArbn_Cal_ImcSigArbnArbnFltTmr */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnArbnFltTmr();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnHwAgArbnEna */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgArbnEna();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnHwAgArbnLpFil */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgArbnLpFil();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnHwAgArbnOffsLim */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgArbnOffsLim();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnEna */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnEna();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnLpFil */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnLpFil();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnOffsLim */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwAgTarArbnOffsLim();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnHwTqArbnEna */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwTqArbnEna();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnHwTqArbnLpFil */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwTqArbnLpFil();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnHwTqArbnOffsLim */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnHwTqArbnOffsLim();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnMotVelArbnEna */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnMotVelArbnEna();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnMotVelArbnLpFil */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnMotVelArbnLpFil();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnMotVelArbnOffsLim */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnMotVelArbnOffsLim();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPosnServoArbnOffsLim */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPosnServoArbnOffsLim();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPosnServoIntgtrStArbnEna */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPosnServoIntgtrStArbnEna();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPosnServoIntgtrStArbnLpFil */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPosnServoIntgtrStArbnLpFil();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPosnTrakg1ArbnOffsLim */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPosnTrakg1ArbnOffsLim();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPosnTrakg2ArbnOffsLim */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPosnTrakg2ArbnOffsLim();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermArbnOffsLim */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermArbnOffsLim();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermIntgtrStArbnEna */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermIntgtrStArbnEna();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermIntgtrStArbnLpFil */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpLongTermIntgtrStArbnLpFil();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermArbnOffsLim */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermArbnOffsLim();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermIntgtrStArbnEna */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermIntgtrStArbnEna();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermIntgtrStArbnLpFil */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnPullCmpShoTermIntgtrStArbnLpFil();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnSysStTmr */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnSysStTmr();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt1ArbnEna */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt1ArbnEna();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt1ArbnLpFil */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt1ArbnLpFil();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt2ArbnEna */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt2ArbnEna();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt2ArbnLpFil */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnTrakgIntgtrSt2ArbnLpFil();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnVehSpdArbnEna */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnVehSpdArbnEna();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnVehSpdArbnLpFil */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnVehSpdArbnLpFil();
    
    /* init for variable ImcSigArbn_Cal_ImcSigArbnVehSpdArbnOffsLim */
    _main_gen_init_sym_ImcSigArbn_Cal_ImcSigArbnVehSpdArbnOffsLim();
    
    /* init for variable ImcSigArbn_Pim_ArbnErrPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_ArbnErrPrev();
    
    /* init for variable ImcSigArbn_Pim_ArbnFltPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_ArbnFltPrev();
    
    /* init for variable ImcSigArbn_Pim_ArbnFltRefTiEnaLrng */
    _main_gen_init_sym_ImcSigArbn_Pim_ArbnFltRefTiEnaLrng();
    
    /* init for variable ImcSigArbn_Pim_HwAgLpFil */
    _main_gen_init_sym_ImcSigArbn_Pim_HwAgLpFil();
    
    /* init for variable ImcSigArbn_Pim_HwAgOffsPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_HwAgOffsPrev();
    
    /* init for variable ImcSigArbn_Pim_HwAgTarLpFil */
    _main_gen_init_sym_ImcSigArbn_Pim_HwAgTarLpFil();
    
    /* init for variable ImcSigArbn_Pim_HwAgTarOffsPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_HwAgTarOffsPrev();
    
    /* init for variable ImcSigArbn_Pim_HwTqLpFil */
    _main_gen_init_sym_ImcSigArbn_Pim_HwTqLpFil();
    
    /* init for variable ImcSigArbn_Pim_HwTqOffsPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_HwTqOffsPrev();
    
    /* init for variable ImcSigArbn_Pim_MotVelCrfOffsPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_MotVelCrfOffsPrev();
    
    /* init for variable ImcSigArbn_Pim_MotVelLpFil */
    _main_gen_init_sym_ImcSigArbn_Pim_MotVelLpFil();
    
    /* init for variable ImcSigArbn_Pim_PosnServoIntgtrLpFil */
    _main_gen_init_sym_ImcSigArbn_Pim_PosnServoIntgtrLpFil();
    
    /* init for variable ImcSigArbn_Pim_PosnServoIntgtrOffsPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_PosnServoIntgtrOffsPrev();
    
    /* init for variable ImcSigArbn_Pim_PullCmpLongTermCmpLpFil */
    _main_gen_init_sym_ImcSigArbn_Pim_PullCmpLongTermCmpLpFil();
    
    /* init for variable ImcSigArbn_Pim_PullCmpLongTermIntgtrStOffsPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_PullCmpLongTermIntgtrStOffsPrev();
    
    /* init for variable ImcSigArbn_Pim_PullCmpShoTermCmpLpFil */
    _main_gen_init_sym_ImcSigArbn_Pim_PullCmpShoTermCmpLpFil();
    
    /* init for variable ImcSigArbn_Pim_PullCmpShoTermIntgtrStOffsPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_PullCmpShoTermIntgtrStOffsPrev();
    
    /* init for variable ImcSigArbn_Pim_SysStLrngEnaPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_SysStLrngEnaPrev();
    
    /* init for variable ImcSigArbn_Pim_SysStRefTiEnaLrng */
    _main_gen_init_sym_ImcSigArbn_Pim_SysStRefTiEnaLrng();
    
    /* init for variable ImcSigArbn_Pim_TrakgIntgtrSt1LpFil */
    _main_gen_init_sym_ImcSigArbn_Pim_TrakgIntgtrSt1LpFil();
    
    /* init for variable ImcSigArbn_Pim_TrakgIntgtrSt1Offs */
    _main_gen_init_sym_ImcSigArbn_Pim_TrakgIntgtrSt1Offs();
    
    /* init for variable ImcSigArbn_Pim_TrakgIntgtrSt2LpFil */
    _main_gen_init_sym_ImcSigArbn_Pim_TrakgIntgtrSt2LpFil();
    
    /* init for variable ImcSigArbn_Pim_TrakgIntgtrSt2Offs */
    _main_gen_init_sym_ImcSigArbn_Pim_TrakgIntgtrSt2Offs();
    
    /* init for variable ImcSigArbn_Pim_VehSpdLpFil */
    _main_gen_init_sym_ImcSigArbn_Pim_VehSpdLpFil();
    
    /* init for variable ImcSigArbn_Pim_VehSpdOffsPrev */
    _main_gen_init_sym_ImcSigArbn_Pim_VehSpdOffsPrev();
    
    /* init for variable ImcSigArbn_Irv_HwAgOffs */
    _main_gen_init_sym_ImcSigArbn_Irv_HwAgOffs();
    
    /* init for variable ImcSigArbn_Irv_HwAgTarOffs */
    _main_gen_init_sym_ImcSigArbn_Irv_HwAgTarOffs();
    
    /* init for variable ImcSigArbn_Irv_HwTqOffs */
    _main_gen_init_sym_ImcSigArbn_Irv_HwTqOffs();
    
    /* init for variable ImcSigArbn_Irv_ImcSysSt10MilliSec */
    _main_gen_init_sym_ImcSigArbn_Irv_ImcSysSt10MilliSec();
    
    /* init for variable ImcSigArbn_Irv_ImcSysStVld10MilliSec */
    _main_gen_init_sym_ImcSigArbn_Irv_ImcSysStVld10MilliSec();
    
    /* init for variable ImcSigArbn_Irv_MotVelCrfOffs */
    _main_gen_init_sym_ImcSigArbn_Irv_MotVelCrfOffs();
    
    /* init for variable ImcSigArbn_Irv_VehSpdOffs */
    _main_gen_init_sym_ImcSigArbn_Irv_VehSpdOffs();
    
    /* init for variable ImcSigArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_ImcSigArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable ImcSigArbn_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable ImcSigArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_ImcSigArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable ImcSigArbn_Srv_SetNtcSts_NTCActv : useless (never read) */

    /* init for variable ImcSigArbn_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable ImcSigArbn_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable ImcSigArbn_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable ImcSigArbn_Srv_SetNtcSts_Return */
    _main_gen_init_sym_ImcSigArbn_Srv_SetNtcSts_Return();
    
}
