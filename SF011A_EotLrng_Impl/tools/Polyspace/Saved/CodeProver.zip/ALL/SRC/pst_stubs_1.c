#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__40 _main_gen_init_g40(void);

extern struct __PST__g__38 _main_gen_init_g38(void);

extern __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__37 _main_gen_init_g37(void)
{
    __PST__g__37 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__38 _main_gen_init_g38(void)
{
    static struct __PST__g__38 x;
    /* struct/union type */
    x.CwEot = _main_gen_init_g10();
    x.CcwEot = _main_gen_init_g10();
    x.CwEotDetd = _main_gen_init_g6();
    x.CcwEotDetd = _main_gen_init_g6();
    return x;
}

struct __PST__g__40 _main_gen_init_g40(void)
{
    static struct __PST__g__40 x;
    /* struct/union type */
    x.HwAgCcwMax = _main_gen_init_g10();
    x.HwAgCwMax = _main_gen_init_g10();
    x.HwAgOverTrvlCnt = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_EotLrng_Ip_HwAg(void)
{
    extern __PST__FLOAT32 EotLrng_Ip_HwAg;
    
    /* initialization with random value */
    {
        EotLrng_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Ip_HwAgAuthy(void)
{
    extern __PST__FLOAT32 EotLrng_Ip_HwAgAuthy;
    
    /* initialization with random value */
    {
        EotLrng_Ip_HwAgAuthy = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Ip_HwAgDiDiagSts(void)
{
    extern __PST__UINT8 EotLrng_Ip_HwAgDiDiagSts;
    
    /* initialization with random value */
    {
        EotLrng_Ip_HwAgDiDiagSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Ip_HwAgEotSig0Avl(void)
{
    extern __PST__UINT8 EotLrng_Ip_HwAgEotSig0Avl;
    
    /* initialization with random value */
    {
        EotLrng_Ip_HwAgEotSig0Avl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Ip_HwAgEotSig0Ccw(void)
{
    extern __PST__FLOAT32 EotLrng_Ip_HwAgEotSig0Ccw;
    
    /* initialization with random value */
    {
        EotLrng_Ip_HwAgEotSig0Ccw = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Ip_HwAgEotSig0Cw(void)
{
    extern __PST__FLOAT32 EotLrng_Ip_HwAgEotSig0Cw;
    
    /* initialization with random value */
    {
        EotLrng_Ip_HwAgEotSig0Cw = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Ip_HwAgEotSig1Avl(void)
{
    extern __PST__UINT8 EotLrng_Ip_HwAgEotSig1Avl;
    
    /* initialization with random value */
    {
        EotLrng_Ip_HwAgEotSig1Avl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Ip_HwAgEotSig1Ccw(void)
{
    extern __PST__FLOAT32 EotLrng_Ip_HwAgEotSig1Ccw;
    
    /* initialization with random value */
    {
        EotLrng_Ip_HwAgEotSig1Ccw = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Ip_HwAgEotSig1Cw(void)
{
    extern __PST__FLOAT32 EotLrng_Ip_HwAgEotSig1Cw;
    
    /* initialization with random value */
    {
        EotLrng_Ip_HwAgEotSig1Cw = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Ip_HwTq(void)
{
    extern __PST__FLOAT32 EotLrng_Ip_HwTq;
    
    /* initialization with random value */
    {
        EotLrng_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 EotLrng_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        EotLrng_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotLrngAuthyStrtLrn(void)
{
    extern __PST__g__36 EotLrng_Cal_EotLrngAuthyStrtLrn;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotLrngAuthyStrtLrn = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotLrngEntrAndExitHysRngLimr(void)
{
    extern __PST__g__36 EotLrng_Cal_EotLrngEntrAndExitHysRngLimr;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotLrngEntrAndExitHysRngLimr = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotLrngEotLrnTmr(void)
{
    extern __PST__g__30 EotLrng_Cal_EotLrngEotLrnTmr;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotLrngEotLrnTmr = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotLrngHwAgOverTrvlCntThd(void)
{
    extern __PST__g__37 EotLrng_Cal_EotLrngHwAgOverTrvlCntThd;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotLrngHwAgOverTrvlCntThd = _main_gen_init_g37();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotLrngHwTqEotLrn(void)
{
    extern __PST__g__36 EotLrng_Cal_EotLrngHwTqEotLrn;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotLrngHwTqEotLrn = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotLrngMotVelEotLrn(void)
{
    extern __PST__g__36 EotLrng_Cal_EotLrngMotVelEotLrn;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotLrngMotVelEotLrn = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotLrngRackTrvlMax(void)
{
    extern __PST__g__36 EotLrng_Cal_EotLrngRackTrvlMax;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotLrngRackTrvlMax = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotLrngRackTrvlMin(void)
{
    extern __PST__g__36 EotLrng_Cal_EotLrngRackTrvlMin;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotLrngRackTrvlMin = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotLrngRstAuthyMin(void)
{
    extern __PST__g__36 EotLrng_Cal_EotLrngRstAuthyMin;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotLrngRstAuthyMin = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotProtnRackTrvlLimrEna(void)
{
    extern __PST__g__37 EotLrng_Cal_EotProtnRackTrvlLimrEna;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotProtnRackTrvlLimrEna = _main_gen_init_g37();
    }
}

static void _main_gen_init_sym_EotLrng_Cal_EotProtnRackTrvlLimrRngLimd(void)
{
    extern __PST__g__36 EotLrng_Cal_EotProtnRackTrvlLimrRngLimd;
    
    /* initialization with random value */
    {
        EotLrng_Cal_EotProtnRackTrvlLimrRngLimd = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_EotLrng_Pim_EotNvmData(void)
{
    extern struct __PST__g__38 EotLrng_Pim_EotNvmData;
    
    /* initialization with random value */
    {
        EotLrng_Pim_EotNvmData = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_EotLrng_Pim_MaxHwAgCwAndCcw(void)
{
    extern struct __PST__g__40 EotLrng_Pim_MaxHwAgCwAndCcw;
    
    /* initialization with random value */
    {
        EotLrng_Pim_MaxHwAgCwAndCcw = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_EotLrng_Pim_CcwEotRefTmr(void)
{
    extern __PST__UINT32 EotLrng_Pim_CcwEotRefTmr;
    
    /* initialization with random value */
    {
        EotLrng_Pim_CcwEotRefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_EotLrng_Pim_CwEotRefTmr(void)
{
    extern __PST__UINT32 EotLrng_Pim_CwEotRefTmr;
    
    /* initialization with random value */
    {
        EotLrng_Pim_CwEotRefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_EotLrng_Pim_HwAgOverTrvlCntrNegDi(void)
{
    extern __PST__UINT8 EotLrng_Pim_HwAgOverTrvlCntrNegDi;
    
    /* initialization with random value */
    {
        EotLrng_Pim_HwAgOverTrvlCntrNegDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Pim_HwAgOverTrvlCntrPosDi(void)
{
    extern __PST__UINT8 EotLrng_Pim_HwAgOverTrvlCntrPosDi;
    
    /* initialization with random value */
    {
        EotLrng_Pim_HwAgOverTrvlCntrPosDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Pim_PrevCcwEot(void)
{
    extern __PST__FLOAT32 EotLrng_Pim_PrevCcwEot;
    
    /* initialization with random value */
    {
        EotLrng_Pim_PrevCcwEot = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Pim_PrevCwEot(void)
{
    extern __PST__FLOAT32 EotLrng_Pim_PrevCwEot;
    
    /* initialization with random value */
    {
        EotLrng_Pim_PrevCwEot = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Pim_RstLimReq(void)
{
    extern __PST__UINT8 EotLrng_Pim_RstLimReq;
    
    /* initialization with random value */
    {
        EotLrng_Pim_RstLimReq = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_EotNvmData_GetErrorStatus_ReqResPtr(void)
{
    extern __PST__UINT8 EotLrng_Srv_EotNvmData_GetErrorStatus_ReqResPtr;
    
    /* initialization with random value */
    {
        EotLrng_Srv_EotNvmData_GetErrorStatus_ReqResPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_EotNvmData_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 EotLrng_Srv_EotNvmData_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        EotLrng_Srv_EotNvmData_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_EotNvmData_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 EotLrng_Srv_EotNvmData_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        EotLrng_Srv_EotNvmData_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 EotLrng_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        EotLrng_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 EotLrng_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        EotLrng_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 EotLrng_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        EotLrng_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 EotLrng_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        EotLrng_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_MaxHwAgCwAndCcw_GetErrorStatus_ReqResPtr(void)
{
    extern __PST__UINT8 EotLrng_Srv_MaxHwAgCwAndCcw_GetErrorStatus_ReqResPtr;
    
    /* initialization with random value */
    {
        EotLrng_Srv_MaxHwAgCwAndCcw_GetErrorStatus_ReqResPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_MaxHwAgCwAndCcw_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 EotLrng_Srv_MaxHwAgCwAndCcw_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        EotLrng_Srv_MaxHwAgCwAndCcw_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_MaxHwAgCwAndCcw_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 EotLrng_Srv_MaxHwAgCwAndCcw_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        EotLrng_Srv_MaxHwAgCwAndCcw_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 EotLrng_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        EotLrng_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Cli_GetHwAgOverTrvlCnt_HwAgOverTrvlCnt(void)
{
    extern __PST__UINT8 EotLrng_Cli_GetHwAgOverTrvlCnt_HwAgOverTrvlCnt;
    
    /* initialization with random value */
    {
        EotLrng_Cli_GetHwAgOverTrvlCnt_HwAgOverTrvlCnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotLrng_Cli_RtnMaxHwAgCwAndCcw_HwAgCcwMax(void)
{
    extern __PST__FLOAT32 EotLrng_Cli_RtnMaxHwAgCwAndCcw_HwAgCcwMax;
    
    /* initialization with random value */
    {
        EotLrng_Cli_RtnMaxHwAgCwAndCcw_HwAgCcwMax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Cli_RtnMaxHwAgCwAndCcw_HwAgCwMax(void)
{
    extern __PST__FLOAT32 EotLrng_Cli_RtnMaxHwAgCwAndCcw_HwAgCwMax;
    
    /* initialization with random value */
    {
        EotLrng_Cli_RtnMaxHwAgCwAndCcw_HwAgCwMax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotLrng_Cli_SetHwAgOverTrvlCnt_HwAgOverTrvlCnt(void)
{
    extern __PST__UINT8 EotLrng_Cli_SetHwAgOverTrvlCnt_HwAgOverTrvlCnt;
    
    /* initialization with random value */
    {
        EotLrng_Cli_SetHwAgOverTrvlCnt_HwAgOverTrvlCnt = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable EotLrng_Ip_HwAg */
    _main_gen_init_sym_EotLrng_Ip_HwAg();
    
    /* init for variable EotLrng_Ip_HwAgAuthy */
    _main_gen_init_sym_EotLrng_Ip_HwAgAuthy();
    
    /* init for variable EotLrng_Ip_HwAgDiDiagSts */
    _main_gen_init_sym_EotLrng_Ip_HwAgDiDiagSts();
    
    /* init for variable EotLrng_Ip_HwAgEotSig0Avl */
    _main_gen_init_sym_EotLrng_Ip_HwAgEotSig0Avl();
    
    /* init for variable EotLrng_Ip_HwAgEotSig0Ccw */
    _main_gen_init_sym_EotLrng_Ip_HwAgEotSig0Ccw();
    
    /* init for variable EotLrng_Ip_HwAgEotSig0Cw */
    _main_gen_init_sym_EotLrng_Ip_HwAgEotSig0Cw();
    
    /* init for variable EotLrng_Ip_HwAgEotSig1Avl */
    _main_gen_init_sym_EotLrng_Ip_HwAgEotSig1Avl();
    
    /* init for variable EotLrng_Ip_HwAgEotSig1Ccw */
    _main_gen_init_sym_EotLrng_Ip_HwAgEotSig1Ccw();
    
    /* init for variable EotLrng_Ip_HwAgEotSig1Cw */
    _main_gen_init_sym_EotLrng_Ip_HwAgEotSig1Cw();
    
    /* init for variable EotLrng_Ip_HwTq */
    _main_gen_init_sym_EotLrng_Ip_HwTq();
    
    /* init for variable EotLrng_Ip_MotVelCrf */
    _main_gen_init_sym_EotLrng_Ip_MotVelCrf();
    
    /* init for variable EotLrng_Op_HwAgCcwDetd : useless (never read) */

    /* init for variable EotLrng_Op_HwAgCwDetd : useless (never read) */

    /* init for variable EotLrng_Op_HwAgEotCcw : useless (never read) */

    /* init for variable EotLrng_Op_HwAgEotCw : useless (never read) */

    /* init for variable EotLrng_Cal_EotLrngAuthyStrtLrn */
    _main_gen_init_sym_EotLrng_Cal_EotLrngAuthyStrtLrn();
    
    /* init for variable EotLrng_Cal_EotLrngEntrAndExitHysRngLimr */
    _main_gen_init_sym_EotLrng_Cal_EotLrngEntrAndExitHysRngLimr();
    
    /* init for variable EotLrng_Cal_EotLrngEotLrnTmr */
    _main_gen_init_sym_EotLrng_Cal_EotLrngEotLrnTmr();
    
    /* init for variable EotLrng_Cal_EotLrngHwAgOverTrvlCntThd */
    _main_gen_init_sym_EotLrng_Cal_EotLrngHwAgOverTrvlCntThd();
    
    /* init for variable EotLrng_Cal_EotLrngHwTqEotLrn */
    _main_gen_init_sym_EotLrng_Cal_EotLrngHwTqEotLrn();
    
    /* init for variable EotLrng_Cal_EotLrngMotVelEotLrn */
    _main_gen_init_sym_EotLrng_Cal_EotLrngMotVelEotLrn();
    
    /* init for variable EotLrng_Cal_EotLrngRackTrvlMax */
    _main_gen_init_sym_EotLrng_Cal_EotLrngRackTrvlMax();
    
    /* init for variable EotLrng_Cal_EotLrngRackTrvlMin */
    _main_gen_init_sym_EotLrng_Cal_EotLrngRackTrvlMin();
    
    /* init for variable EotLrng_Cal_EotLrngRstAuthyMin */
    _main_gen_init_sym_EotLrng_Cal_EotLrngRstAuthyMin();
    
    /* init for variable EotLrng_Cal_EotProtnRackTrvlLimrEna */
    _main_gen_init_sym_EotLrng_Cal_EotProtnRackTrvlLimrEna();
    
    /* init for variable EotLrng_Cal_EotProtnRackTrvlLimrRngLimd */
    _main_gen_init_sym_EotLrng_Cal_EotProtnRackTrvlLimrRngLimd();
    
    /* init for variable EotLrng_Pim_EotNvmData */
    _main_gen_init_sym_EotLrng_Pim_EotNvmData();
    
    /* init for variable EotLrng_Pim_MaxHwAgCwAndCcw */
    _main_gen_init_sym_EotLrng_Pim_MaxHwAgCwAndCcw();
    
    /* init for variable EotLrng_Pim_CcwEotRefTmr */
    _main_gen_init_sym_EotLrng_Pim_CcwEotRefTmr();
    
    /* init for variable EotLrng_Pim_CwEotRefTmr */
    _main_gen_init_sym_EotLrng_Pim_CwEotRefTmr();
    
    /* init for variable EotLrng_Pim_HwAgOverTrvlCntrNegDi */
    _main_gen_init_sym_EotLrng_Pim_HwAgOverTrvlCntrNegDi();
    
    /* init for variable EotLrng_Pim_HwAgOverTrvlCntrPosDi */
    _main_gen_init_sym_EotLrng_Pim_HwAgOverTrvlCntrPosDi();
    
    /* init for variable EotLrng_Pim_PrevCcwEot */
    _main_gen_init_sym_EotLrng_Pim_PrevCcwEot();
    
    /* init for variable EotLrng_Pim_PrevCwEot */
    _main_gen_init_sym_EotLrng_Pim_PrevCwEot();
    
    /* init for variable EotLrng_Pim_RstLimReq */
    _main_gen_init_sym_EotLrng_Pim_RstLimReq();
    
    /* init for variable EotLrng_Srv_EotNvmData_GetErrorStatus_ReqResPtr */
    _main_gen_init_sym_EotLrng_Srv_EotNvmData_GetErrorStatus_ReqResPtr();
    
    /* init for variable EotLrng_Srv_EotNvmData_GetErrorStatus_Return */
    _main_gen_init_sym_EotLrng_Srv_EotNvmData_GetErrorStatus_Return();
    
    /* init for variable EotLrng_Srv_EotNvmData_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable EotLrng_Srv_EotNvmData_SetRamBlockStatus_Return */
    _main_gen_init_sym_EotLrng_Srv_EotNvmData_SetRamBlockStatus_Return();
    
    /* init for variable EotLrng_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable EotLrng_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_EotLrng_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable EotLrng_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_EotLrng_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable EotLrng_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_EotLrng_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable EotLrng_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable EotLrng_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_EotLrng_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable EotLrng_Srv_MaxHwAgCwAndCcw_GetErrorStatus_ReqResPtr */
    _main_gen_init_sym_EotLrng_Srv_MaxHwAgCwAndCcw_GetErrorStatus_ReqResPtr();
    
    /* init for variable EotLrng_Srv_MaxHwAgCwAndCcw_GetErrorStatus_Return */
    _main_gen_init_sym_EotLrng_Srv_MaxHwAgCwAndCcw_GetErrorStatus_Return();
    
    /* init for variable EotLrng_Srv_MaxHwAgCwAndCcw_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable EotLrng_Srv_MaxHwAgCwAndCcw_SetRamBlockStatus_Return */
    _main_gen_init_sym_EotLrng_Srv_MaxHwAgCwAndCcw_SetRamBlockStatus_Return();
    
    /* init for variable EotLrng_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable EotLrng_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable EotLrng_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable EotLrng_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable EotLrng_Srv_SetNtcSts_Return */
    _main_gen_init_sym_EotLrng_Srv_SetNtcSts_Return();
    
    /* init for variable EotLrng_Cli_GetHwAgOverTrvlCnt_HwAgOverTrvlCnt */
    _main_gen_init_sym_EotLrng_Cli_GetHwAgOverTrvlCnt_HwAgOverTrvlCnt();
    
    /* init for variable EotLrng_Cli_RtnMaxHwAgCwAndCcw_HwAgCcwMax */
    _main_gen_init_sym_EotLrng_Cli_RtnMaxHwAgCwAndCcw_HwAgCcwMax();
    
    /* init for variable EotLrng_Cli_RtnMaxHwAgCwAndCcw_HwAgCwMax */
    _main_gen_init_sym_EotLrng_Cli_RtnMaxHwAgCwAndCcw_HwAgCwMax();
    
    /* init for variable EotLrng_Cli_SetHwAgOverTrvlCnt_HwAgOverTrvlCnt */
    _main_gen_init_sym_EotLrng_Cli_SetHwAgOverTrvlCnt_HwAgOverTrvlCnt();
    
}
