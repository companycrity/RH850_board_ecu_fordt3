#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__24 _main_gen_init_g24(void);

extern __PST__g__23 _main_gen_init_g23(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__24 _main_gen_init_g24(void)
{
    __PST__g__24 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_LoaMgr_Ip_CurrMeasIdptSig(void)
{
    extern __PST__UINT8 LoaMgr_Ip_CurrMeasIdptSig;
    
    /* initialization with random value */
    {
        LoaMgr_Ip_CurrMeasIdptSig = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Ip_DiagcStsIvtr1Inactv(void)
{
    extern __PST__UINT8 LoaMgr_Ip_DiagcStsIvtr1Inactv;
    
    /* initialization with random value */
    {
        LoaMgr_Ip_DiagcStsIvtr1Inactv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Ip_DiagcStsIvtr2Inactv(void)
{
    extern __PST__UINT8 LoaMgr_Ip_DiagcStsIvtr2Inactv;
    
    /* initialization with random value */
    {
        LoaMgr_Ip_DiagcStsIvtr2Inactv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Ip_HwTqIdptSig(void)
{
    extern __PST__UINT8 LoaMgr_Ip_HwTqIdptSig;
    
    /* initialization with random value */
    {
        LoaMgr_Ip_HwTqIdptSig = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Ip_IvtrFetFltTyp(void)
{
    extern __PST__UINT8 LoaMgr_Ip_IvtrFetFltTyp;
    
    /* initialization with random value */
    {
        LoaMgr_Ip_IvtrFetFltTyp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Ip_LoaScaDi(void)
{
    extern __PST__UINT8 LoaMgr_Ip_LoaScaDi;
    
    /* initialization with random value */
    {
        LoaMgr_Ip_LoaScaDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Ip_MotAgMeclIdptSig(void)
{
    extern __PST__UINT8 LoaMgr_Ip_MotAgMeclIdptSig;
    
    /* initialization with random value */
    {
        LoaMgr_Ip_MotAgMeclIdptSig = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Ip_MotAgSnsrlsAvl(void)
{
    extern __PST__UINT8 LoaMgr_Ip_MotAgSnsrlsAvl;
    
    /* initialization with random value */
    {
        LoaMgr_Ip_MotAgSnsrlsAvl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Ip_TqLoaAvl(void)
{
    extern __PST__UINT8 LoaMgr_Ip_TqLoaAvl;
    
    /* initialization with random value */
    {
        LoaMgr_Ip_TqLoaAvl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Ip_VehSteerMod(void)
{
    extern __PST__UINT8 LoaMgr_Ip_VehSteerMod;
    
    /* initialization with random value */
    {
        LoaMgr_Ip_VehSteerMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrIvtrMtgtnRate(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrCurrIvtrMtgtnRate;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrCurrIvtrMtgtnRate = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrIvtrMtgtnSca(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrCurrIvtrMtgtnSca;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrCurrIvtrMtgtnSca = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrIvtrMtgtnScaZeroEna(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrCurrIvtrMtgtnScaZeroEna;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrCurrIvtrMtgtnScaZeroEna = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasIdptSig0Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrCurrMeasIdptSig0Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrCurrMeasIdptSig0Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasIdptSig1Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrCurrMeasIdptSig1Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrCurrMeasIdptSig1Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasIdptSig2Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrCurrMeasIdptSig2Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrCurrMeasIdptSig2Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasIdptSigFltThd(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrCurrMeasIdptSigFltThd;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrCurrMeasIdptSigFltThd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasMtgtnRate(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrCurrMeasMtgtnRate;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrCurrMeasMtgtnRate = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasMtgtnSca(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrCurrMeasMtgtnSca;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrCurrMeasMtgtnSca = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasMtgtnScaZeroEna(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrCurrMeasMtgtnScaZeroEna;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrCurrMeasMtgtnScaZeroEna = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrFadeOutStRate(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrFadeOutStRate;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrFadeOutStRate = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSig0NoTqLoaResp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrHwTqIdptSig0NoTqLoaResp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrHwTqIdptSig0NoTqLoaResp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSig1NoTqLoaResp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrHwTqIdptSig1NoTqLoaResp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrHwTqIdptSig1NoTqLoaResp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSig2Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrHwTqIdptSig2Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrHwTqIdptSig2Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSig3Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrHwTqIdptSig3Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrHwTqIdptSig3Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSig4Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrHwTqIdptSig4Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrHwTqIdptSig4Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSigFltThd(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrHwTqIdptSigFltThd;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrHwTqIdptSigFltThd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqLoaAvlResp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrHwTqLoaAvlResp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrHwTqLoaAvlResp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrIdptSig0Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrIvtrIdptSig0Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrIvtrIdptSig0Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrIdptSig1Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrIvtrIdptSig1Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrIvtrIdptSig1Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrIdptSig2Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrIvtrIdptSig2Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrIvtrIdptSig2Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrIdptSigFltThd(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrIvtrIdptSigFltThd;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrIvtrIdptSigFltThd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrMtgtnRate(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrIvtrMtgtnRate;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrIvtrMtgtnRate = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrMtgtnSca(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrIvtrMtgtnSca;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrIvtrMtgtnSca = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrMtgtnScaZeroEna(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrIvtrMtgtnScaZeroEna;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrIvtrMtgtnScaZeroEna = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrLimdStRate(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrLimdStRate;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrLimdStRate = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrLimdStSca(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrLimdStSca;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrLimdStSca = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgAvlSnsrlsResp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrMotAgAvlSnsrlsResp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrMotAgAvlSnsrlsResp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgIdptSig0NoSnsrlsResp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrMotAgIdptSig0NoSnsrlsResp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrMotAgIdptSig0NoSnsrlsResp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgIdptSig1NoSnsrlsResp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrMotAgIdptSig1NoSnsrlsResp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrMotAgIdptSig1NoSnsrlsResp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgIdptSig2Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrMotAgIdptSig2Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrMotAgIdptSig2Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgIdptSig3Resp(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrMotAgIdptSig3Resp;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrMotAgIdptSig3Resp = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgIdptSigFltThd(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrMotAgIdptSigFltThd;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrMotAgIdptSigFltThd = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgMtgtnRate(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrMotAgMtgtnRate;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrMotAgMtgtnRate = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgMtgtnSca(void)
{
    extern __PST__g__23 LoaMgr_Cal_LoaMgrMotAgMtgtnSca;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrMotAgMtgtnSca = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgMtgtnScaZeroEna(void)
{
    extern __PST__g__24 LoaMgr_Cal_LoaMgrMotAgMtgtnScaZeroEna;
    
    /* initialization with random value */
    {
        LoaMgr_Cal_LoaMgrMotAgMtgtnScaZeroEna = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevCurrMeasIdptSigResp(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevCurrMeasIdptSigResp;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevCurrMeasIdptSigResp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevCurrMeasIdptSigVal(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevCurrMeasIdptSigVal;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevCurrMeasIdptSigVal = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevCurrMeasLoaStSwMtgtnEna(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevCurrMeasLoaStSwMtgtnEna;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevCurrMeasLoaStSwMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevHwTqIdptSigResp(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevHwTqIdptSigResp;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevHwTqIdptSigResp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevHwTqIdptSigVal(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevHwTqIdptSigVal;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevHwTqIdptSigVal = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevHwTqLoaStSwMtgtnEna(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevHwTqLoaStSwMtgtnEna;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevHwTqLoaStSwMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevIvtrIdptSigResp(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevIvtrIdptSigResp;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevIvtrIdptSigResp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevIvtrIdptSigVal(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevIvtrIdptSigVal;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevIvtrIdptSigVal = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevIvtrLoaStSwMtgtnEna(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevIvtrLoaStSwMtgtnEna;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevIvtrLoaStSwMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevMotAgLoaMtgtnEna(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevMotAgLoaMtgtnEna;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevMotAgLoaMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevMotAgLoaStSwMtgtnEna(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevMotAgLoaStSwMtgtnEna;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevMotAgLoaStSwMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevMotAgMeclIdptSigResp(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevMotAgMeclIdptSigResp;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevMotAgMeclIdptSigResp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevMotAgMeclIdptSigVal(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevMotAgMeclIdptSigVal;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevMotAgMeclIdptSigVal = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Pim_PrevVltgModSrc(void)
{
    extern __PST__UINT8 LoaMgr_Pim_PrevVltgModSrc;
    
    /* initialization with random value */
    {
        LoaMgr_Pim_PrevVltgModSrc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_LoaMgr_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 LoaMgr_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        LoaMgr_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable LoaMgr_Ip_CurrMeasIdptSig */
    _main_gen_init_sym_LoaMgr_Ip_CurrMeasIdptSig();
    
    /* init for variable LoaMgr_Ip_DiagcStsIvtr1Inactv */
    _main_gen_init_sym_LoaMgr_Ip_DiagcStsIvtr1Inactv();
    
    /* init for variable LoaMgr_Ip_DiagcStsIvtr2Inactv */
    _main_gen_init_sym_LoaMgr_Ip_DiagcStsIvtr2Inactv();
    
    /* init for variable LoaMgr_Ip_HwTqIdptSig */
    _main_gen_init_sym_LoaMgr_Ip_HwTqIdptSig();
    
    /* init for variable LoaMgr_Ip_IvtrFetFltTyp */
    _main_gen_init_sym_LoaMgr_Ip_IvtrFetFltTyp();
    
    /* init for variable LoaMgr_Ip_LoaScaDi */
    _main_gen_init_sym_LoaMgr_Ip_LoaScaDi();
    
    /* init for variable LoaMgr_Ip_MotAgMeclIdptSig */
    _main_gen_init_sym_LoaMgr_Ip_MotAgMeclIdptSig();
    
    /* init for variable LoaMgr_Ip_MotAgSnsrlsAvl */
    _main_gen_init_sym_LoaMgr_Ip_MotAgSnsrlsAvl();
    
    /* init for variable LoaMgr_Ip_TqLoaAvl */
    _main_gen_init_sym_LoaMgr_Ip_TqLoaAvl();
    
    /* init for variable LoaMgr_Ip_VehSteerMod */
    _main_gen_init_sym_LoaMgr_Ip_VehSteerMod();
    
    /* init for variable LoaMgr_Op_HwTqLoaMtgtnEna : useless (never read) */

    /* init for variable LoaMgr_Op_LoaRateLim : useless (never read) */

    /* init for variable LoaMgr_Op_LoaSca : useless (never read) */

    /* init for variable LoaMgr_Op_LoaSt : useless (never read) */

    /* init for variable LoaMgr_Op_MotAgLoaMtgtnEna : useless (never read) */

    /* init for variable LoaMgr_Op_MotAndThermProtnLoaMod : useless (never read) */

    /* init for variable LoaMgr_Cal_LoaMgrCurrIvtrMtgtnRate */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrIvtrMtgtnRate();
    
    /* init for variable LoaMgr_Cal_LoaMgrCurrIvtrMtgtnSca */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrIvtrMtgtnSca();
    
    /* init for variable LoaMgr_Cal_LoaMgrCurrIvtrMtgtnScaZeroEna */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrIvtrMtgtnScaZeroEna();
    
    /* init for variable LoaMgr_Cal_LoaMgrCurrMeasIdptSig0Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasIdptSig0Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrCurrMeasIdptSig1Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasIdptSig1Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrCurrMeasIdptSig2Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasIdptSig2Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrCurrMeasIdptSigFltThd */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasIdptSigFltThd();
    
    /* init for variable LoaMgr_Cal_LoaMgrCurrMeasMtgtnRate */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasMtgtnRate();
    
    /* init for variable LoaMgr_Cal_LoaMgrCurrMeasMtgtnSca */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasMtgtnSca();
    
    /* init for variable LoaMgr_Cal_LoaMgrCurrMeasMtgtnScaZeroEna */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrCurrMeasMtgtnScaZeroEna();
    
    /* init for variable LoaMgr_Cal_LoaMgrFadeOutStRate */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrFadeOutStRate();
    
    /* init for variable LoaMgr_Cal_LoaMgrHwTqIdptSig0NoTqLoaResp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSig0NoTqLoaResp();
    
    /* init for variable LoaMgr_Cal_LoaMgrHwTqIdptSig1NoTqLoaResp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSig1NoTqLoaResp();
    
    /* init for variable LoaMgr_Cal_LoaMgrHwTqIdptSig2Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSig2Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrHwTqIdptSig3Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSig3Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrHwTqIdptSig4Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSig4Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrHwTqIdptSigFltThd */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqIdptSigFltThd();
    
    /* init for variable LoaMgr_Cal_LoaMgrHwTqLoaAvlResp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrHwTqLoaAvlResp();
    
    /* init for variable LoaMgr_Cal_LoaMgrIvtrIdptSig0Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrIdptSig0Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrIvtrIdptSig1Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrIdptSig1Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrIvtrIdptSig2Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrIdptSig2Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrIvtrIdptSigFltThd */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrIdptSigFltThd();
    
    /* init for variable LoaMgr_Cal_LoaMgrIvtrMtgtnRate */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrMtgtnRate();
    
    /* init for variable LoaMgr_Cal_LoaMgrIvtrMtgtnSca */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrMtgtnSca();
    
    /* init for variable LoaMgr_Cal_LoaMgrIvtrMtgtnScaZeroEna */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrIvtrMtgtnScaZeroEna();
    
    /* init for variable LoaMgr_Cal_LoaMgrLimdStRate */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrLimdStRate();
    
    /* init for variable LoaMgr_Cal_LoaMgrLimdStSca */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrLimdStSca();
    
    /* init for variable LoaMgr_Cal_LoaMgrMotAgAvlSnsrlsResp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgAvlSnsrlsResp();
    
    /* init for variable LoaMgr_Cal_LoaMgrMotAgIdptSig0NoSnsrlsResp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgIdptSig0NoSnsrlsResp();
    
    /* init for variable LoaMgr_Cal_LoaMgrMotAgIdptSig1NoSnsrlsResp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgIdptSig1NoSnsrlsResp();
    
    /* init for variable LoaMgr_Cal_LoaMgrMotAgIdptSig2Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgIdptSig2Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrMotAgIdptSig3Resp */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgIdptSig3Resp();
    
    /* init for variable LoaMgr_Cal_LoaMgrMotAgIdptSigFltThd */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgIdptSigFltThd();
    
    /* init for variable LoaMgr_Cal_LoaMgrMotAgMtgtnRate */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgMtgtnRate();
    
    /* init for variable LoaMgr_Cal_LoaMgrMotAgMtgtnSca */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgMtgtnSca();
    
    /* init for variable LoaMgr_Cal_LoaMgrMotAgMtgtnScaZeroEna */
    _main_gen_init_sym_LoaMgr_Cal_LoaMgrMotAgMtgtnScaZeroEna();
    
    /* init for variable LoaMgr_Pim_PrevCurrMeasIdptSigResp */
    _main_gen_init_sym_LoaMgr_Pim_PrevCurrMeasIdptSigResp();
    
    /* init for variable LoaMgr_Pim_PrevCurrMeasIdptSigVal */
    _main_gen_init_sym_LoaMgr_Pim_PrevCurrMeasIdptSigVal();
    
    /* init for variable LoaMgr_Pim_PrevCurrMeasLoaStSwMtgtnEna */
    _main_gen_init_sym_LoaMgr_Pim_PrevCurrMeasLoaStSwMtgtnEna();
    
    /* init for variable LoaMgr_Pim_PrevHwTqIdptSigResp */
    _main_gen_init_sym_LoaMgr_Pim_PrevHwTqIdptSigResp();
    
    /* init for variable LoaMgr_Pim_PrevHwTqIdptSigVal */
    _main_gen_init_sym_LoaMgr_Pim_PrevHwTqIdptSigVal();
    
    /* init for variable LoaMgr_Pim_PrevHwTqLoaStSwMtgtnEna */
    _main_gen_init_sym_LoaMgr_Pim_PrevHwTqLoaStSwMtgtnEna();
    
    /* init for variable LoaMgr_Pim_PrevIvtrIdptSigResp */
    _main_gen_init_sym_LoaMgr_Pim_PrevIvtrIdptSigResp();
    
    /* init for variable LoaMgr_Pim_PrevIvtrIdptSigVal */
    _main_gen_init_sym_LoaMgr_Pim_PrevIvtrIdptSigVal();
    
    /* init for variable LoaMgr_Pim_PrevIvtrLoaStSwMtgtnEna */
    _main_gen_init_sym_LoaMgr_Pim_PrevIvtrLoaStSwMtgtnEna();
    
    /* init for variable LoaMgr_Pim_PrevMotAgLoaMtgtnEna */
    _main_gen_init_sym_LoaMgr_Pim_PrevMotAgLoaMtgtnEna();
    
    /* init for variable LoaMgr_Pim_PrevMotAgLoaStSwMtgtnEna */
    _main_gen_init_sym_LoaMgr_Pim_PrevMotAgLoaStSwMtgtnEna();
    
    /* init for variable LoaMgr_Pim_PrevMotAgMeclIdptSigResp */
    _main_gen_init_sym_LoaMgr_Pim_PrevMotAgMeclIdptSigResp();
    
    /* init for variable LoaMgr_Pim_PrevMotAgMeclIdptSigVal */
    _main_gen_init_sym_LoaMgr_Pim_PrevMotAgMeclIdptSigVal();
    
    /* init for variable LoaMgr_Pim_PrevVltgModSrc */
    _main_gen_init_sym_LoaMgr_Pim_PrevVltgModSrc();
    
    /* init for variable LoaMgr_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable LoaMgr_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable LoaMgr_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable LoaMgr_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable LoaMgr_Srv_SetNtcSts_Return */
    _main_gen_init_sym_LoaMgr_Srv_SetNtcSts_Return();
    
}
