#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__45 _main_gen_init_g45(void);

extern __PST__g__42 _main_gen_init_g42(void);

extern __PST__g__39 _main_gen_init_g39(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__g__31 _main_gen_init_g31(void);

extern __PST__g__24 _main_gen_init_g24(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__24 _main_gen_init_g24(void)
{
    __PST__g__24 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__31 _main_gen_init_g31(void)
{
    __PST__g__31 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__39 _main_gen_init_g39(void)
{
    __PST__g__39 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__42 _main_gen_init_g42(void)
{
    __PST__g__42 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__45 _main_gen_init_g45(void)
{
    __PST__g__45 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_CoreVltgMonr_Pim_CoreVltgMonrStrtUpFltPrmByte(void)
{
    extern __PST__UINT8 CoreVltgMonr_Pim_CoreVltgMonrStrtUpFltPrmByte;
    
    /* initialization with random value */
    {
        CoreVltgMonr_Pim_CoreVltgMonrStrtUpFltPrmByte = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CVMF_BASE(void)
{
    extern __PST__g__24 CVMF_BASE;
    
    /* initialization with random value */
    {
        CVMF_BASE = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_CVMDE_BASE(void)
{
    extern __PST__g__31 CVMDE_BASE;
    
    /* initialization with random value */
    {
        CVMDE_BASE = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_CVMDMASK_BASE(void)
{
    extern __PST__g__36 CVMDMASK_BASE;
    
    /* initialization with random value */
    {
        CVMDMASK_BASE = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_CVMDIAG_BASE(void)
{
    extern __PST__g__39 CVMDIAG_BASE;
    
    /* initialization with random value */
    {
        CVMDIAG_BASE = _main_gen_init_g39();
    }
}

static void _main_gen_init_sym_CVMFC_BASE(void)
{
    extern __PST__g__42 CVMFC_BASE;
    
    /* initialization with random value */
    {
        CVMFC_BASE = _main_gen_init_g42();
    }
}

static void _main_gen_init_sym_CVMDEW_BASE(void)
{
    extern __PST__g__45 CVMDEW_BASE;
    
    /* initialization with random value */
    {
        CVMDEW_BASE = _main_gen_init_g45();
    }
}

static void _main_gen_init_sym_CoreVltgMonr_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 CoreVltgMonr_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        CoreVltgMonr_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable CoreVltgMonr_Pim_CoreVltgMonrStrtUpFltPrmByte */
    _main_gen_init_sym_CoreVltgMonr_Pim_CoreVltgMonrStrtUpFltPrmByte();
    
    /* init for variable CoreVltgMonr_Pim_dCoreVltgMonrStrtUpTestCmpl : useless (never read) */

    /* init for variable CVMF_BASE */
    _main_gen_init_sym_CVMF_BASE();
    
    /* init for variable CVMDE_BASE */
    _main_gen_init_sym_CVMDE_BASE();
    
    /* init for variable CVMDMASK_BASE */
    _main_gen_init_sym_CVMDMASK_BASE();
    
    /* init for variable CVMDIAG_BASE */
    _main_gen_init_sym_CVMDIAG_BASE();
    
    /* init for variable CVMFC_BASE */
    _main_gen_init_sym_CVMFC_BASE();
    
    /* init for variable CVMDEW_BASE */
    _main_gen_init_sym_CVMDEW_BASE();
    
    /* init for variable CoreVltgMonr_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable CoreVltgMonr_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable CoreVltgMonr_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable CoreVltgMonr_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable CoreVltgMonr_Srv_SetNtcSts_Return */
    _main_gen_init_sym_CoreVltgMonr_Srv_SetNtcSts_Return();
    
}
