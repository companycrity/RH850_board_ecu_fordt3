#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__32 _main_gen_init_g32(void);

extern struct __PST__g__31 _main_gen_init_g31(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__31 _main_gen_init_g31(void)
{
    static struct __PST__g__31 x;
    /* struct/union type */
    x.FilSiLpStVal = _main_gen_init_g10();
    x.FilMagLpStVal = _main_gen_init_g10();
    x.FilCuLpStVal = _main_gen_init_g10();
    x.FilAssisMechLpStVal = _main_gen_init_g10();
    x.FilSiLLStVal = _main_gen_init_g10();
    x.FilMagLLStVal = _main_gen_init_g10();
    x.FilCuLLStVal = _main_gen_init_g10();
    x.FilAssisMechLLStVal = _main_gen_init_g10();
    return x;
}

struct __PST__g__32 _main_gen_init_g32(void)
{
    static struct __PST__g__32 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_TEstimn_Srv_TFilStVal_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 TEstimn_Srv_TFilStVal_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        TEstimn_Srv_TFilStVal_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Srv_TFilStVal_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 TEstimn_Srv_TFilStVal_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        TEstimn_Srv_TFilStVal_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Srv_TFilStVal_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 TEstimn_Srv_TFilStVal_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        TEstimn_Srv_TFilStVal_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_AmbT(void)
{
    extern __PST__FLOAT32 TEstimn_Ip_AmbT;
    
    /* initialization with random value */
    {
        TEstimn_Ip_AmbT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_AmbTVld(void)
{
    extern __PST__UINT8 TEstimn_Ip_AmbTVld;
    
    /* initialization with random value */
    {
        TEstimn_Ip_AmbTVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_AssiMechTEstimnDi(void)
{
    extern __PST__UINT8 TEstimn_Ip_AssiMechTEstimnDi;
    
    /* initialization with random value */
    {
        TEstimn_Ip_AssiMechTEstimnDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_DualEcuFltMtgtnEna(void)
{
    extern __PST__UINT8 TEstimn_Ip_DualEcuFltMtgtnEna;
    
    /* initialization with random value */
    {
        TEstimn_Ip_DualEcuFltMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_EcuTFild(void)
{
    extern __PST__FLOAT32 TEstimn_Ip_EcuTFild;
    
    /* initialization with random value */
    {
        TEstimn_Ip_EcuTFild = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_EngOilT(void)
{
    extern __PST__FLOAT32 TEstimn_Ip_EngOilT;
    
    /* initialization with random value */
    {
        TEstimn_Ip_EngOilT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_EngOilTVld(void)
{
    extern __PST__UINT8 TEstimn_Ip_EngOilTVld;
    
    /* initialization with random value */
    {
        TEstimn_Ip_EngOilTVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_HwVel(void)
{
    extern __PST__FLOAT32 TEstimn_Ip_HwVel;
    
    /* initialization with random value */
    {
        TEstimn_Ip_HwVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_IgnTiOff(void)
{
    extern __PST__UINT32 TEstimn_Ip_IgnTiOff;
    
    /* initialization with random value */
    {
        TEstimn_Ip_IgnTiOff = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_MotAndThermProtnLoaMod(void)
{
    extern __PST__UINT8 TEstimn_Ip_MotAndThermProtnLoaMod;
    
    /* initialization with random value */
    {
        TEstimn_Ip_MotAndThermProtnLoaMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_MotCurrPeakEstimd(void)
{
    extern __PST__FLOAT32 TEstimn_Ip_MotCurrPeakEstimd;
    
    /* initialization with random value */
    {
        TEstimn_Ip_MotCurrPeakEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Ip_VehTiVld(void)
{
    extern __PST__UINT8 TEstimn_Ip_VehTiVld;
    
    /* initialization with random value */
    {
        TEstimn_Ip_VehTiVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAmbPwrMplr(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnAmbPwrMplr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 3; _main_gen_tmp_1_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnAmbPwrMplr[_main_gen_tmp_1_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAmbTSca(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnAmbTSca;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 3; _main_gen_tmp_2_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnAmbTSca[_main_gen_tmp_2_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechAmbLpFilFrq(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnAssiMechAmbLpFilFrq;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnAssiMechAmbLpFilFrq = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechAmbLpFilFrqDualEcuFltMtgtn(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnAssiMechAmbLpFilFrqDualEcuFltMtgtn;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnAssiMechAmbLpFilFrqDualEcuFltMtgtn = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechAmbLpFilFrqFetMtgtnEna(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnAssiMechAmbLpFilFrqFetMtgtnEna;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnAssiMechAmbLpFilFrqFetMtgtnEna = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechAmbMplr(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnAssiMechAmbMplr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 3; _main_gen_tmp_3_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnAssiMechAmbMplr[_main_gen_tmp_3_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechCorrLim(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnAssiMechCorrLim;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 3; _main_gen_tmp_4_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnAssiMechCorrLim[_main_gen_tmp_4_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechDampgSca(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnAssiMechDampgSca;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 3; _main_gen_tmp_5_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnAssiMechDampgSca[_main_gen_tmp_5_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechDftT(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnAssiMechDftT;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 3; _main_gen_tmp_6_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnAssiMechDftT[_main_gen_tmp_6_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechLLFilCoeffA1(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnAssiMechLLFilCoeffA1;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 3; _main_gen_tmp_7_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnAssiMechLLFilCoeffA1[_main_gen_tmp_7_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechLLFilCoeffB0(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnAssiMechLLFilCoeffB0;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 3; _main_gen_tmp_8_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnAssiMechLLFilCoeffB0[_main_gen_tmp_8_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechLLFilCoeffB1(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnAssiMechLLFilCoeffB1;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 3; _main_gen_tmp_9_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnAssiMechLLFilCoeffB1[_main_gen_tmp_9_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechSlew(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnAssiMechSlew;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 3; _main_gen_tmp_10_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnAssiMechSlew[_main_gen_tmp_10_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCorrnTAssiMech(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnCorrnTAssiMech;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 3; _main_gen_tmp_11_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnCorrnTAssiMech[_main_gen_tmp_11_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCorrnTCu(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnCorrnTCu;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 3; _main_gen_tmp_12_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnCorrnTCu[_main_gen_tmp_12_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCorrnTMag(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnCorrnTMag;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 3; _main_gen_tmp_13_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnCorrnTMag[_main_gen_tmp_13_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCorrnTSi(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnCorrnTSi;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_14_0;
            
            for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 3; _main_gen_tmp_14_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnCorrnTSi[_main_gen_tmp_14_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCuAmbLpFilFrq(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnCuAmbLpFilFrq;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnCuAmbLpFilFrq = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCuAmbLpFilFrqDualEcuFltMtgtn(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnCuAmbLpFilFrqDualEcuFltMtgtn;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnCuAmbLpFilFrqDualEcuFltMtgtn = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCuAmbLpFilFrqFetMtgtnEna(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnCuAmbLpFilFrqFetMtgtnEna;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnCuAmbLpFilFrqFetMtgtnEna = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCuAmbMplr(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnCuAmbMplr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 3; _main_gen_tmp_15_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnCuAmbMplr[_main_gen_tmp_15_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCuCorrnLim(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnCuCorrnLim;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_16_0;
            
            for (_main_gen_tmp_16_0 = 0; _main_gen_tmp_16_0 < 3; _main_gen_tmp_16_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnCuCorrnLim[_main_gen_tmp_16_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCuLLFilCoeffA1(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnCuLLFilCoeffA1;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_17_0;
            
            for (_main_gen_tmp_17_0 = 0; _main_gen_tmp_17_0 < 3; _main_gen_tmp_17_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnCuLLFilCoeffA1[_main_gen_tmp_17_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCuLLFilCoeffB0(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnCuLLFilCoeffB0;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_18_0;
            
            for (_main_gen_tmp_18_0 = 0; _main_gen_tmp_18_0 < 3; _main_gen_tmp_18_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnCuLLFilCoeffB0[_main_gen_tmp_18_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnCuLLFilCoeffB1(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnCuLLFilCoeffB1;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_19_0;
            
            for (_main_gen_tmp_19_0 = 0; _main_gen_tmp_19_0 < 3; _main_gen_tmp_19_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnCuLLFilCoeffB1[_main_gen_tmp_19_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnEngTSca(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnEngTSca;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_20_0;
            
            for (_main_gen_tmp_20_0 = 0; _main_gen_tmp_20_0 < 3; _main_gen_tmp_20_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnEngTSca[_main_gen_tmp_20_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnIgnOffCtrlEna(void)
{
    extern __PST__g__29 TEstimn_Cal_TEstimnIgnOffCtrlEna;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnIgnOffCtrlEna = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnIgnOffMsgWaitTi(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnIgnOffMsgWaitTi;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnIgnOffMsgWaitTi = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnMagAmbLpFilFrq(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnMagAmbLpFilFrq;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnMagAmbLpFilFrq = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnMagAmbLpFilFrqDualEcuFltMtgtn(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnMagAmbLpFilFrqDualEcuFltMtgtn;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnMagAmbLpFilFrqDualEcuFltMtgtn = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnMagAmbLpFilFrqFetMtgtnEna(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnMagAmbLpFilFrqFetMtgtnEna;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnMagAmbLpFilFrqFetMtgtnEna = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnMagAmbMplr(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnMagAmbMplr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_21_0;
            
            for (_main_gen_tmp_21_0 = 0; _main_gen_tmp_21_0 < 3; _main_gen_tmp_21_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnMagAmbMplr[_main_gen_tmp_21_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnMagCorrnLim(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnMagCorrnLim;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_22_0;
            
            for (_main_gen_tmp_22_0 = 0; _main_gen_tmp_22_0 < 3; _main_gen_tmp_22_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnMagCorrnLim[_main_gen_tmp_22_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnMagLLFilCoeffA1(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnMagLLFilCoeffA1;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_23_0;
            
            for (_main_gen_tmp_23_0 = 0; _main_gen_tmp_23_0 < 3; _main_gen_tmp_23_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnMagLLFilCoeffA1[_main_gen_tmp_23_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnMagLLFilCoeffB0(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnMagLLFilCoeffB0;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_24_0;
            
            for (_main_gen_tmp_24_0 = 0; _main_gen_tmp_24_0 < 3; _main_gen_tmp_24_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnMagLLFilCoeffB0[_main_gen_tmp_24_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnMagLLFilCoeffB1(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnMagLLFilCoeffB1;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_25_0;
            
            for (_main_gen_tmp_25_0 = 0; _main_gen_tmp_25_0 < 3; _main_gen_tmp_25_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnMagLLFilCoeffB1[_main_gen_tmp_25_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnSiAmbLpFilFrq(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnSiAmbLpFilFrq;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnSiAmbLpFilFrq = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnSiAmbLpFilFrqDualEcuFltMtgtn(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnSiAmbLpFilFrqDualEcuFltMtgtn;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnSiAmbLpFilFrqDualEcuFltMtgtn = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnSiAmbLpFilFrqFetMtgtnEna(void)
{
    extern __PST__g__28 TEstimn_Cal_TEstimnSiAmbLpFilFrqFetMtgtnEna;
    
    /* initialization with random value */
    {
        TEstimn_Cal_TEstimnSiAmbLpFilFrqFetMtgtnEna = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnSiAmbMplr(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnSiAmbMplr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_26_0;
            
            for (_main_gen_tmp_26_0 = 0; _main_gen_tmp_26_0 < 3; _main_gen_tmp_26_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnSiAmbMplr[_main_gen_tmp_26_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnSiCorrnLim(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnSiCorrnLim;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_27_0;
            
            for (_main_gen_tmp_27_0 = 0; _main_gen_tmp_27_0 < 3; _main_gen_tmp_27_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnSiCorrnLim[_main_gen_tmp_27_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnSiLLFilCoeffA1(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnSiLLFilCoeffA1;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_28_0;
            
            for (_main_gen_tmp_28_0 = 0; _main_gen_tmp_28_0 < 3; _main_gen_tmp_28_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnSiLLFilCoeffA1[_main_gen_tmp_28_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnSiLLFilCoeffB0(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnSiLLFilCoeffB0;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_29_0;
            
            for (_main_gen_tmp_29_0 = 0; _main_gen_tmp_29_0 < 3; _main_gen_tmp_29_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnSiLLFilCoeffB0[_main_gen_tmp_29_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnSiLLFilCoeffB1(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnSiLLFilCoeffB1;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_30_0;
            
            for (_main_gen_tmp_30_0 = 0; _main_gen_tmp_30_0 < 3; _main_gen_tmp_30_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnSiLLFilCoeffB1[_main_gen_tmp_30_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnTauAssiMech(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnTauAssiMech;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_31_0;
            
            for (_main_gen_tmp_31_0 = 0; _main_gen_tmp_31_0 < 3; _main_gen_tmp_31_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnTauAssiMech[_main_gen_tmp_31_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnTauCu(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnTauCu;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_32_0;
            
            for (_main_gen_tmp_32_0 = 0; _main_gen_tmp_32_0 < 3; _main_gen_tmp_32_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnTauCu[_main_gen_tmp_32_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnTauMag(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnTauMag;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_33_0;
            
            for (_main_gen_tmp_33_0 = 0; _main_gen_tmp_33_0 < 3; _main_gen_tmp_33_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnTauMag[_main_gen_tmp_33_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnTauSi(void)
{
    extern __PST__g__27 TEstimn_Cal_TEstimnTauSi;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_34_0;
            
            for (_main_gen_tmp_34_0 = 0; _main_gen_tmp_34_0 < 3; _main_gen_tmp_34_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnTauSi[_main_gen_tmp_34_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Cal_TEstimnWghtAvrgTDi(void)
{
    extern __PST__g__30 TEstimn_Cal_TEstimnWghtAvrgTDi;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_35_0;
            
            for (_main_gen_tmp_35_0 = 0; _main_gen_tmp_35_0 < 3; _main_gen_tmp_35_0++)
            {
                /* base type */
                TEstimn_Cal_TEstimnWghtAvrgTDi[_main_gen_tmp_35_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_TEstimn_Pim_TFilStVal(void)
{
    extern struct __PST__g__31 TEstimn_Pim_TFilStVal;
    
    /* initialization with random value */
    {
        TEstimn_Pim_TFilStVal = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_AmbTVldPrev(void)
{
    extern __PST__UINT8 TEstimn_Pim_AmbTVldPrev;
    
    /* initialization with random value */
    {
        TEstimn_Pim_AmbTVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_AssiMechFilLp(void)
{
    extern struct __PST__g__32 TEstimn_Pim_AssiMechFilLp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_AssiMechFilLp = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_AssiMechTEstimnPrev(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_AssiMechTEstimnPrev;
    
    /* initialization with random value */
    {
        TEstimn_Pim_AssiMechTEstimnPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_AssiMechTInitEna(void)
{
    extern __PST__UINT8 TEstimn_Pim_AssiMechTInitEna;
    
    /* initialization with random value */
    {
        TEstimn_Pim_AssiMechTInitEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_AssiMechTSlewLimPrev(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_AssiMechTSlewLimPrev;
    
    /* initialization with random value */
    {
        TEstimn_Pim_AssiMechTSlewLimPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_CuFilLp(void)
{
    extern struct __PST__g__32 TEstimn_Pim_CuFilLp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_CuFilLp = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_CuTEstimnPrev(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_CuTEstimnPrev;
    
    /* initialization with random value */
    {
        TEstimn_Pim_CuTEstimnPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_DualEcuFltMtgtnPrev(void)
{
    extern __PST__UINT8 TEstimn_Pim_DualEcuFltMtgtnPrev;
    
    /* initialization with random value */
    {
        TEstimn_Pim_DualEcuFltMtgtnPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_EngOilTVldPrev(void)
{
    extern __PST__UINT8 TEstimn_Pim_EngOilTVldPrev;
    
    /* initialization with random value */
    {
        TEstimn_Pim_EngOilTVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_FetMtgtnEnaPrev(void)
{
    extern __PST__UINT8 TEstimn_Pim_FetMtgtnEnaPrev;
    
    /* initialization with random value */
    {
        TEstimn_Pim_FetMtgtnEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_FilAssiMechLLValPwrUp(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_FilAssiMechLLValPwrUp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_FilAssiMechLLValPwrUp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_FilAssiMechLpValPwrUp(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_FilAssiMechLpValPwrUp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_FilAssiMechLpValPwrUp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_FilCuLLValPwrUp(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_FilCuLLValPwrUp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_FilCuLLValPwrUp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_FilCuLpValPwrUp(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_FilCuLpValPwrUp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_FilCuLpValPwrUp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_FilMagLLValPwrUp(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_FilMagLLValPwrUp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_FilMagLLValPwrUp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_FilMagLpValPwrUp(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_FilMagLpValPwrUp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_FilMagLpValPwrUp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_FilSiLLValPwrUp(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_FilSiLLValPwrUp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_FilSiLLValPwrUp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_FilSiLpValPwrUp(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_FilSiLpValPwrUp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_FilSiLpValPwrUp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_MagFilLp(void)
{
    extern struct __PST__g__32 TEstimn_Pim_MagFilLp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_MagFilLp = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_MagTEstimnPrev(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_MagTEstimnPrev;
    
    /* initialization with random value */
    {
        TEstimn_Pim_MagTEstimnPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_RepInitCntrFlg(void)
{
    extern __PST__UINT8 TEstimn_Pim_RepInitCntrFlg;
    
    /* initialization with random value */
    {
        TEstimn_Pim_RepInitCntrFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_RepInitCntrVal(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_RepInitCntrVal;
    
    /* initialization with random value */
    {
        TEstimn_Pim_RepInitCntrVal = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_SiFilLp(void)
{
    extern struct __PST__g__32 TEstimn_Pim_SiFilLp;
    
    /* initialization with random value */
    {
        TEstimn_Pim_SiFilLp = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_SiTEstimnPrev(void)
{
    extern __PST__FLOAT32 TEstimn_Pim_SiTEstimnPrev;
    
    /* initialization with random value */
    {
        TEstimn_Pim_SiTEstimnPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TEstimn_Pim_TEstimnFltMtgtnCalIdx(void)
{
    extern __PST__UINT8 TEstimn_Pim_TEstimnFltMtgtnCalIdx;
    
    /* initialization with random value */
    {
        TEstimn_Pim_TEstimnFltMtgtnCalIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TEstimn_Irv_FilStVariRepInitFlg(void)
{
    extern __PST__UINT8 TEstimn_Irv_FilStVariRepInitFlg;
    
    /* initialization with random value */
    {
        TEstimn_Irv_FilStVariRepInitFlg = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable TEstimn_Srv_TFilStVal_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_TEstimn_Srv_TFilStVal_GetErrorStatus_RequestResultPtr();
    
    /* init for variable TEstimn_Srv_TFilStVal_GetErrorStatus_Return */
    _main_gen_init_sym_TEstimn_Srv_TFilStVal_GetErrorStatus_Return();
    
    /* init for variable TEstimn_Srv_TFilStVal_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable TEstimn_Srv_TFilStVal_SetRamBlockStatus_Return */
    _main_gen_init_sym_TEstimn_Srv_TFilStVal_SetRamBlockStatus_Return();
    
    /* init for variable TEstimn_Ip_AmbT */
    _main_gen_init_sym_TEstimn_Ip_AmbT();
    
    /* init for variable TEstimn_Ip_AmbTVld */
    _main_gen_init_sym_TEstimn_Ip_AmbTVld();
    
    /* init for variable TEstimn_Ip_AssiMechTEstimnDi */
    _main_gen_init_sym_TEstimn_Ip_AssiMechTEstimnDi();
    
    /* init for variable TEstimn_Ip_DualEcuFltMtgtnEna */
    _main_gen_init_sym_TEstimn_Ip_DualEcuFltMtgtnEna();
    
    /* init for variable TEstimn_Ip_EcuTFild */
    _main_gen_init_sym_TEstimn_Ip_EcuTFild();
    
    /* init for variable TEstimn_Ip_EngOilT */
    _main_gen_init_sym_TEstimn_Ip_EngOilT();
    
    /* init for variable TEstimn_Ip_EngOilTVld */
    _main_gen_init_sym_TEstimn_Ip_EngOilTVld();
    
    /* init for variable TEstimn_Ip_HwVel */
    _main_gen_init_sym_TEstimn_Ip_HwVel();
    
    /* init for variable TEstimn_Ip_IgnTiOff */
    _main_gen_init_sym_TEstimn_Ip_IgnTiOff();
    
    /* init for variable TEstimn_Ip_MotAndThermProtnLoaMod */
    _main_gen_init_sym_TEstimn_Ip_MotAndThermProtnLoaMod();
    
    /* init for variable TEstimn_Ip_MotCurrPeakEstimd */
    _main_gen_init_sym_TEstimn_Ip_MotCurrPeakEstimd();
    
    /* init for variable TEstimn_Ip_VehTiVld */
    _main_gen_init_sym_TEstimn_Ip_VehTiVld();
    
    /* init for variable TEstimn_Op_AssiMechT : useless (never read) */

    /* init for variable TEstimn_Op_MotFetT : useless (never read) */

    /* init for variable TEstimn_Op_MotMagT : useless (never read) */

    /* init for variable TEstimn_Op_MotWidgT : useless (never read) */

    /* init for variable TEstimn_Cal_TEstimnAmbPwrMplr */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAmbPwrMplr();
    
    /* init for variable TEstimn_Cal_TEstimnAmbTSca */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAmbTSca();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechAmbLpFilFrq */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechAmbLpFilFrq();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechAmbLpFilFrqDualEcuFltMtgtn */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechAmbLpFilFrqDualEcuFltMtgtn();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechAmbLpFilFrqFetMtgtnEna */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechAmbLpFilFrqFetMtgtnEna();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechAmbMplr */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechAmbMplr();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechCorrLim */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechCorrLim();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechDampgSca */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechDampgSca();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechDftT */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechDftT();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechLLFilCoeffA1 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechLLFilCoeffA1();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechLLFilCoeffB0 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechLLFilCoeffB0();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechLLFilCoeffB1 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechLLFilCoeffB1();
    
    /* init for variable TEstimn_Cal_TEstimnAssiMechSlew */
    _main_gen_init_sym_TEstimn_Cal_TEstimnAssiMechSlew();
    
    /* init for variable TEstimn_Cal_TEstimnCorrnTAssiMech */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCorrnTAssiMech();
    
    /* init for variable TEstimn_Cal_TEstimnCorrnTCu */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCorrnTCu();
    
    /* init for variable TEstimn_Cal_TEstimnCorrnTMag */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCorrnTMag();
    
    /* init for variable TEstimn_Cal_TEstimnCorrnTSi */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCorrnTSi();
    
    /* init for variable TEstimn_Cal_TEstimnCuAmbLpFilFrq */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCuAmbLpFilFrq();
    
    /* init for variable TEstimn_Cal_TEstimnCuAmbLpFilFrqDualEcuFltMtgtn */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCuAmbLpFilFrqDualEcuFltMtgtn();
    
    /* init for variable TEstimn_Cal_TEstimnCuAmbLpFilFrqFetMtgtnEna */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCuAmbLpFilFrqFetMtgtnEna();
    
    /* init for variable TEstimn_Cal_TEstimnCuAmbMplr */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCuAmbMplr();
    
    /* init for variable TEstimn_Cal_TEstimnCuCorrnLim */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCuCorrnLim();
    
    /* init for variable TEstimn_Cal_TEstimnCuLLFilCoeffA1 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCuLLFilCoeffA1();
    
    /* init for variable TEstimn_Cal_TEstimnCuLLFilCoeffB0 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCuLLFilCoeffB0();
    
    /* init for variable TEstimn_Cal_TEstimnCuLLFilCoeffB1 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnCuLLFilCoeffB1();
    
    /* init for variable TEstimn_Cal_TEstimnEngTSca */
    _main_gen_init_sym_TEstimn_Cal_TEstimnEngTSca();
    
    /* init for variable TEstimn_Cal_TEstimnIgnOffCtrlEna */
    _main_gen_init_sym_TEstimn_Cal_TEstimnIgnOffCtrlEna();
    
    /* init for variable TEstimn_Cal_TEstimnIgnOffMsgWaitTi */
    _main_gen_init_sym_TEstimn_Cal_TEstimnIgnOffMsgWaitTi();
    
    /* init for variable TEstimn_Cal_TEstimnMagAmbLpFilFrq */
    _main_gen_init_sym_TEstimn_Cal_TEstimnMagAmbLpFilFrq();
    
    /* init for variable TEstimn_Cal_TEstimnMagAmbLpFilFrqDualEcuFltMtgtn */
    _main_gen_init_sym_TEstimn_Cal_TEstimnMagAmbLpFilFrqDualEcuFltMtgtn();
    
    /* init for variable TEstimn_Cal_TEstimnMagAmbLpFilFrqFetMtgtnEna */
    _main_gen_init_sym_TEstimn_Cal_TEstimnMagAmbLpFilFrqFetMtgtnEna();
    
    /* init for variable TEstimn_Cal_TEstimnMagAmbMplr */
    _main_gen_init_sym_TEstimn_Cal_TEstimnMagAmbMplr();
    
    /* init for variable TEstimn_Cal_TEstimnMagCorrnLim */
    _main_gen_init_sym_TEstimn_Cal_TEstimnMagCorrnLim();
    
    /* init for variable TEstimn_Cal_TEstimnMagLLFilCoeffA1 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnMagLLFilCoeffA1();
    
    /* init for variable TEstimn_Cal_TEstimnMagLLFilCoeffB0 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnMagLLFilCoeffB0();
    
    /* init for variable TEstimn_Cal_TEstimnMagLLFilCoeffB1 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnMagLLFilCoeffB1();
    
    /* init for variable TEstimn_Cal_TEstimnSiAmbLpFilFrq */
    _main_gen_init_sym_TEstimn_Cal_TEstimnSiAmbLpFilFrq();
    
    /* init for variable TEstimn_Cal_TEstimnSiAmbLpFilFrqDualEcuFltMtgtn */
    _main_gen_init_sym_TEstimn_Cal_TEstimnSiAmbLpFilFrqDualEcuFltMtgtn();
    
    /* init for variable TEstimn_Cal_TEstimnSiAmbLpFilFrqFetMtgtnEna */
    _main_gen_init_sym_TEstimn_Cal_TEstimnSiAmbLpFilFrqFetMtgtnEna();
    
    /* init for variable TEstimn_Cal_TEstimnSiAmbMplr */
    _main_gen_init_sym_TEstimn_Cal_TEstimnSiAmbMplr();
    
    /* init for variable TEstimn_Cal_TEstimnSiCorrnLim */
    _main_gen_init_sym_TEstimn_Cal_TEstimnSiCorrnLim();
    
    /* init for variable TEstimn_Cal_TEstimnSiLLFilCoeffA1 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnSiLLFilCoeffA1();
    
    /* init for variable TEstimn_Cal_TEstimnSiLLFilCoeffB0 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnSiLLFilCoeffB0();
    
    /* init for variable TEstimn_Cal_TEstimnSiLLFilCoeffB1 */
    _main_gen_init_sym_TEstimn_Cal_TEstimnSiLLFilCoeffB1();
    
    /* init for variable TEstimn_Cal_TEstimnTauAssiMech */
    _main_gen_init_sym_TEstimn_Cal_TEstimnTauAssiMech();
    
    /* init for variable TEstimn_Cal_TEstimnTauCu */
    _main_gen_init_sym_TEstimn_Cal_TEstimnTauCu();
    
    /* init for variable TEstimn_Cal_TEstimnTauMag */
    _main_gen_init_sym_TEstimn_Cal_TEstimnTauMag();
    
    /* init for variable TEstimn_Cal_TEstimnTauSi */
    _main_gen_init_sym_TEstimn_Cal_TEstimnTauSi();
    
    /* init for variable TEstimn_Cal_TEstimnWghtAvrgTDi */
    _main_gen_init_sym_TEstimn_Cal_TEstimnWghtAvrgTDi();
    
    /* init for variable TEstimn_Pim_TFilStVal */
    _main_gen_init_sym_TEstimn_Pim_TFilStVal();
    
    /* init for variable TEstimn_Pim_dTEstimnAmbPwr : useless (never read) */

    /* init for variable TEstimn_Pim_dTEstimnAssiMechCorrn : useless (never read) */

    /* init for variable TEstimn_Pim_dTEstimnAssiMechDampgSca : useless (never read) */

    /* init for variable TEstimn_Pim_dTEstimnAssiMechFil : useless (never read) */

    /* init for variable TEstimn_Pim_dTEstimnCuCorrn : useless (never read) */

    /* init for variable TEstimn_Pim_dTEstimnMagCorrn : useless (never read) */

    /* init for variable TEstimn_Pim_dTEstimnScadAmbT : useless (never read) */

    /* init for variable TEstimn_Pim_dTEstimnScadEngT : useless (never read) */

    /* init for variable TEstimn_Pim_dTEstimnSiCorrn : useless (never read) */

    /* init for variable TEstimn_Pim_dTEstimnWghtAvrgT : useless (never read) */

    /* init for variable TEstimn_Pim_AmbTVldPrev */
    _main_gen_init_sym_TEstimn_Pim_AmbTVldPrev();
    
    /* init for variable TEstimn_Pim_AssiMechFilLp */
    _main_gen_init_sym_TEstimn_Pim_AssiMechFilLp();
    
    /* init for variable TEstimn_Pim_AssiMechTEstimnPrev */
    _main_gen_init_sym_TEstimn_Pim_AssiMechTEstimnPrev();
    
    /* init for variable TEstimn_Pim_AssiMechTInitEna */
    _main_gen_init_sym_TEstimn_Pim_AssiMechTInitEna();
    
    /* init for variable TEstimn_Pim_AssiMechTSlewLimPrev */
    _main_gen_init_sym_TEstimn_Pim_AssiMechTSlewLimPrev();
    
    /* init for variable TEstimn_Pim_CuFilLp */
    _main_gen_init_sym_TEstimn_Pim_CuFilLp();
    
    /* init for variable TEstimn_Pim_CuTEstimnPrev */
    _main_gen_init_sym_TEstimn_Pim_CuTEstimnPrev();
    
    /* init for variable TEstimn_Pim_DualEcuFltMtgtnPrev */
    _main_gen_init_sym_TEstimn_Pim_DualEcuFltMtgtnPrev();
    
    /* init for variable TEstimn_Pim_EngOilTVldPrev */
    _main_gen_init_sym_TEstimn_Pim_EngOilTVldPrev();
    
    /* init for variable TEstimn_Pim_FetMtgtnEnaPrev */
    _main_gen_init_sym_TEstimn_Pim_FetMtgtnEnaPrev();
    
    /* init for variable TEstimn_Pim_FilAssiMechLLValPwrUp */
    _main_gen_init_sym_TEstimn_Pim_FilAssiMechLLValPwrUp();
    
    /* init for variable TEstimn_Pim_FilAssiMechLpValPwrUp */
    _main_gen_init_sym_TEstimn_Pim_FilAssiMechLpValPwrUp();
    
    /* init for variable TEstimn_Pim_FilCuLLValPwrUp */
    _main_gen_init_sym_TEstimn_Pim_FilCuLLValPwrUp();
    
    /* init for variable TEstimn_Pim_FilCuLpValPwrUp */
    _main_gen_init_sym_TEstimn_Pim_FilCuLpValPwrUp();
    
    /* init for variable TEstimn_Pim_FilMagLLValPwrUp */
    _main_gen_init_sym_TEstimn_Pim_FilMagLLValPwrUp();
    
    /* init for variable TEstimn_Pim_FilMagLpValPwrUp */
    _main_gen_init_sym_TEstimn_Pim_FilMagLpValPwrUp();
    
    /* init for variable TEstimn_Pim_FilSiLLValPwrUp */
    _main_gen_init_sym_TEstimn_Pim_FilSiLLValPwrUp();
    
    /* init for variable TEstimn_Pim_FilSiLpValPwrUp */
    _main_gen_init_sym_TEstimn_Pim_FilSiLpValPwrUp();
    
    /* init for variable TEstimn_Pim_MagFilLp */
    _main_gen_init_sym_TEstimn_Pim_MagFilLp();
    
    /* init for variable TEstimn_Pim_MagTEstimnPrev */
    _main_gen_init_sym_TEstimn_Pim_MagTEstimnPrev();
    
    /* init for variable TEstimn_Pim_RepInitCntrFlg */
    _main_gen_init_sym_TEstimn_Pim_RepInitCntrFlg();
    
    /* init for variable TEstimn_Pim_RepInitCntrVal */
    _main_gen_init_sym_TEstimn_Pim_RepInitCntrVal();
    
    /* init for variable TEstimn_Pim_SiFilLp */
    _main_gen_init_sym_TEstimn_Pim_SiFilLp();
    
    /* init for variable TEstimn_Pim_SiTEstimnPrev */
    _main_gen_init_sym_TEstimn_Pim_SiTEstimnPrev();
    
    /* init for variable TEstimn_Pim_TEstimnFltMtgtnCalIdx */
    _main_gen_init_sym_TEstimn_Pim_TEstimnFltMtgtnCalIdx();
    
    /* init for variable TEstimn_Irv_FilStVariRepInitFlg */
    _main_gen_init_sym_TEstimn_Irv_FilStVariRepInitFlg();
    
}
