#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__31 _main_gen_init_g31(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__g__23 _main_gen_init_g23(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__31 _main_gen_init_g31(void)
{
    __PST__g__31 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__34 _main_gen_init_g34(void)
{
    __PST__g__34 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__37 _main_gen_init_g37(void)
{
    __PST__g__37 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_CLMA5CTL0_BASE(void)
{
    extern __PST__g__23 CLMA5CTL0_BASE;
    
    /* initialization with random value */
    {
        CLMA5CTL0_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_CLMA5CMPL_BASE(void)
{
    extern __PST__g__27 CLMA5CMPL_BASE;
    
    /* initialization with random value */
    {
        CLMA5CMPL_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_CLMA5CMPH_BASE(void)
{
    extern __PST__g__31 CLMA5CMPH_BASE;
    
    /* initialization with random value */
    {
        CLMA5CMPH_BASE = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_CLMA5PCMD_BASE(void)
{
    extern __PST__g__34 CLMA5PCMD_BASE;
    
    /* initialization with random value */
    {
        CLMA5PCMD_BASE = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_CLMA5PS_BASE(void)
{
    extern __PST__g__37 CLMA5PS_BASE;
    
    /* initialization with random value */
    {
        CLMA5PS_BASE = _main_gen_init_g37();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable CLMA5CTL0_BASE */
    _main_gen_init_sym_CLMA5CTL0_BASE();
    
    /* init for variable CLMA5CMPL_BASE */
    _main_gen_init_sym_CLMA5CMPL_BASE();
    
    /* init for variable CLMA5CMPH_BASE */
    _main_gen_init_sym_CLMA5CMPH_BASE();
    
    /* init for variable CLMA5PCMD_BASE */
    _main_gen_init_sym_CLMA5PCMD_BASE();
    
    /* init for variable CLMA5PS_BASE */
    _main_gen_init_sym_CLMA5PS_BASE();
    
}
