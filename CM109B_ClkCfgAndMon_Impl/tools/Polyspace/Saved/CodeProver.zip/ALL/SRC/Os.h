/* Os Stub File */

extern void SuspendOSInterrupts(void);
extern void ResumeOSInterrupts(void);

extern void SuspendAllInterrupts(void);
extern void ResumeAllInterrupts(void);
