#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_DualCtrlrOutpMgr_Ip_ImcSysSt(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Ip_ImcSysSt;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Ip_ImcSysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Ip_ImcSysStVld(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Ip_ImcSysStVld;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Ip_ImcSysStVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Ip_MotAndThermProtnLoaMod(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Ip_MotAndThermProtnLoaMod;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Ip_MotAndThermProtnLoaMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Ip_SysSt(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Ip_SysSt;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 DualCtrlrOutpMgr_Ip_VehSpd;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrConOutpSca(void)
{
    extern __PST__g__27 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrConOutpSca;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrConOutpSca = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrDiRateTblY(void)
{
    extern __PST__g__28 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrDiRateTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 10; _main_gen_tmp_0_0++)
            {
                /* base type */
                DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrDiRateTblY[_main_gen_tmp_0_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrEnaRate(void)
{
    extern __PST__g__27 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrEnaRate;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrEnaRate = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrFltThdTmr(void)
{
    extern __PST__g__29 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrFltThdTmr;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrFltThdTmr = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrLimdOutpSca(void)
{
    extern __PST__g__27 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrLimdOutpSca;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrLimdOutpSca = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMaxOutpSca(void)
{
    extern __PST__g__27 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMaxOutpSca;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMaxOutpSca = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMaxOutpTmr(void)
{
    extern __PST__g__29 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMaxOutpTmr;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMaxOutpTmr = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMinOutpTmr(void)
{
    extern __PST__g__29 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMinOutpTmr;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMinOutpTmr = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrNonRecFltThdTmr(void)
{
    extern __PST__g__29 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrNonRecFltThdTmr;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrNonRecFltThdTmr = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrThdTmr(void)
{
    extern __PST__g__29 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrThdTmr;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrThdTmr = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrVehSpdRefTblX(void)
{
    extern __PST__g__28 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrVehSpdRefTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 10; _main_gen_tmp_1_0++)
            {
                /* base type */
                DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrVehSpdRefTblX[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrVltgModFltThdTmr(void)
{
    extern __PST__g__29 DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrVltgModFltThdTmr;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrVltgModFltThdTmr = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_FltLrngEnaPrev(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Pim_FltLrngEnaPrev;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_FltLrngEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_FltRefTiEnaLrng(void)
{
    extern __PST__UINT32 DualCtrlrOutpMgr_Pim_FltRefTiEnaLrng;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_FltRefTiEnaLrng = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_FltStsPrev(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Pim_FltStsPrev;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_FltStsPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_LtchImcDualEcuMotCtrlMtgtnEnaPrev(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Pim_LtchImcDualEcuMotCtrlMtgtnEnaPrev;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_LtchImcDualEcuMotCtrlMtgtnEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_LtchRefTiEnaLrng(void)
{
    extern __PST__UINT32 DualCtrlrOutpMgr_Pim_LtchRefTiEnaLrng;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_LtchRefTiEnaLrng = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_LtchSysStPrev(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Pim_LtchSysStPrev;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_LtchSysStPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_MaxOutpRefTiEna(void)
{
    extern __PST__UINT32 DualCtrlrOutpMgr_Pim_MaxOutpRefTiEna;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_MaxOutpRefTiEna = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_MaxOutpTmrCmpl(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Pim_MaxOutpTmrCmpl;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_MaxOutpTmrCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_NonRecFltEnaPrev(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Pim_NonRecFltEnaPrev;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_NonRecFltEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_NonRecFltRefTiEnaLrng(void)
{
    extern __PST__UINT32 DualCtrlrOutpMgr_Pim_NonRecFltRefTiEnaLrng;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_NonRecFltRefTiEnaLrng = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_OutpSca(void)
{
    extern __PST__FLOAT32 DualCtrlrOutpMgr_Pim_OutpSca;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_OutpSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_PrevLtch(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Pim_PrevLtch;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_PrevLtch = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_PrevLtchNonRecFlt(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Pim_PrevLtchNonRecFlt;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_PrevLtchNonRecFlt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_RefTiEnaLrng(void)
{
    extern __PST__UINT32 DualCtrlrOutpMgr_Pim_RefTiEnaLrng;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_RefTiEnaLrng = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_SysStLrngEnaPrev(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Pim_SysStLrngEnaPrev;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_SysStLrngEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Pim_SysStRefTiEnaLrng(void)
{
    extern __PST__UINT32 DualCtrlrOutpMgr_Pim_SysStRefTiEnaLrng;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Pim_SysStRefTiEnaLrng = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Irv_ImcDiagcStsNonRcvrlReqDiFltPrsnt(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Irv_ImcDiagcStsNonRcvrlReqDiFltPrsnt;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Irv_ImcDiagcStsNonRcvrlReqDiFltPrsnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Irv_ImcDiagcStsNonRcvrlReqDiFltPrsntVld(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Irv_ImcDiagcStsNonRcvrlReqDiFltPrsntVld;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Irv_ImcDiagcStsNonRcvrlReqDiFltPrsntVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Irv_ImcDualEcuMotCtrlMtgtnEna(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Irv_ImcDualEcuMotCtrlMtgtnEna;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Irv_ImcDualEcuMotCtrlMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Irv_ImcDualEcuMotCtrlMtgtnEnaVld(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Irv_ImcDualEcuMotCtrlMtgtnEnaVld;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Irv_ImcDualEcuMotCtrlMtgtnEnaVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 DualCtrlrOutpMgr_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Data(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Data;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Data = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Sts(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Sts;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Sts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Return(void)
{
    extern __PST__UINT8 DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Return;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DualCtrlrOutpMgr_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 DualCtrlrOutpMgr_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        DualCtrlrOutpMgr_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable DualCtrlrOutpMgr_Ip_ImcSysSt */
    _main_gen_init_sym_DualCtrlrOutpMgr_Ip_ImcSysSt();
    
    /* init for variable DualCtrlrOutpMgr_Ip_ImcSysStVld */
    _main_gen_init_sym_DualCtrlrOutpMgr_Ip_ImcSysStVld();
    
    /* init for variable DualCtrlrOutpMgr_Ip_MotAndThermProtnLoaMod */
    _main_gen_init_sym_DualCtrlrOutpMgr_Ip_MotAndThermProtnLoaMod();
    
    /* init for variable DualCtrlrOutpMgr_Ip_SysSt */
    _main_gen_init_sym_DualCtrlrOutpMgr_Ip_SysSt();
    
    /* init for variable DualCtrlrOutpMgr_Ip_VehSpd */
    _main_gen_init_sym_DualCtrlrOutpMgr_Ip_VehSpd();
    
    /* init for variable DualCtrlrOutpMgr_Op_DualEcuFltMtgtnEna : useless (never read) */

    /* init for variable DualCtrlrOutpMgr_Op_DualEcuFltMtgtnSca : useless (never read) */

    /* init for variable DualCtrlrOutpMgr_Op_DualEcuMotCtrlMtgtnEna : useless (never read) */

    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrConOutpSca */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrConOutpSca();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrDiRateTblY */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrDiRateTblY();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrEnaRate */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrEnaRate();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrFltThdTmr */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrFltThdTmr();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrLimdOutpSca */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrLimdOutpSca();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMaxOutpSca */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMaxOutpSca();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMaxOutpTmr */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMaxOutpTmr();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMinOutpTmr */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrMinOutpTmr();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrNonRecFltThdTmr */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrNonRecFltThdTmr();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrThdTmr */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrThdTmr();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrVehSpdRefTblX */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrVehSpdRefTblX();
    
    /* init for variable DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrVltgModFltThdTmr */
    _main_gen_init_sym_DualCtrlrOutpMgr_Cal_DualCtrlrOutpMgrVltgModFltThdTmr();
    
    /* init for variable DualCtrlrOutpMgr_Pim_FltLrngEnaPrev */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_FltLrngEnaPrev();
    
    /* init for variable DualCtrlrOutpMgr_Pim_FltRefTiEnaLrng */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_FltRefTiEnaLrng();
    
    /* init for variable DualCtrlrOutpMgr_Pim_FltStsPrev */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_FltStsPrev();
    
    /* init for variable DualCtrlrOutpMgr_Pim_LtchImcDualEcuMotCtrlMtgtnEnaPrev */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_LtchImcDualEcuMotCtrlMtgtnEnaPrev();
    
    /* init for variable DualCtrlrOutpMgr_Pim_LtchRefTiEnaLrng */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_LtchRefTiEnaLrng();
    
    /* init for variable DualCtrlrOutpMgr_Pim_LtchSysStPrev */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_LtchSysStPrev();
    
    /* init for variable DualCtrlrOutpMgr_Pim_MaxOutpRefTiEna */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_MaxOutpRefTiEna();
    
    /* init for variable DualCtrlrOutpMgr_Pim_MaxOutpTmrCmpl */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_MaxOutpTmrCmpl();
    
    /* init for variable DualCtrlrOutpMgr_Pim_NonRecFltEnaPrev */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_NonRecFltEnaPrev();
    
    /* init for variable DualCtrlrOutpMgr_Pim_NonRecFltRefTiEnaLrng */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_NonRecFltRefTiEnaLrng();
    
    /* init for variable DualCtrlrOutpMgr_Pim_OutpSca */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_OutpSca();
    
    /* init for variable DualCtrlrOutpMgr_Pim_PrevLtch */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_PrevLtch();
    
    /* init for variable DualCtrlrOutpMgr_Pim_PrevLtchNonRecFlt */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_PrevLtchNonRecFlt();
    
    /* init for variable DualCtrlrOutpMgr_Pim_RefTiEnaLrng */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_RefTiEnaLrng();
    
    /* init for variable DualCtrlrOutpMgr_Pim_SysStLrngEnaPrev */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_SysStLrngEnaPrev();
    
    /* init for variable DualCtrlrOutpMgr_Pim_SysStRefTiEnaLrng */
    _main_gen_init_sym_DualCtrlrOutpMgr_Pim_SysStRefTiEnaLrng();
    
    /* init for variable DualCtrlrOutpMgr_Irv_ImcDiagcStsNonRcvrlReqDiFltPrsnt */
    _main_gen_init_sym_DualCtrlrOutpMgr_Irv_ImcDiagcStsNonRcvrlReqDiFltPrsnt();
    
    /* init for variable DualCtrlrOutpMgr_Irv_ImcDiagcStsNonRcvrlReqDiFltPrsntVld */
    _main_gen_init_sym_DualCtrlrOutpMgr_Irv_ImcDiagcStsNonRcvrlReqDiFltPrsntVld();
    
    /* init for variable DualCtrlrOutpMgr_Irv_ImcDualEcuMotCtrlMtgtnEna */
    _main_gen_init_sym_DualCtrlrOutpMgr_Irv_ImcDualEcuMotCtrlMtgtnEna();
    
    /* init for variable DualCtrlrOutpMgr_Irv_ImcDualEcuMotCtrlMtgtnEnaVld */
    _main_gen_init_sym_DualCtrlrOutpMgr_Irv_ImcDualEcuMotCtrlMtgtnEnaVld();
    
    /* init for variable DualCtrlrOutpMgr_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_DualCtrlrOutpMgr_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable DualCtrlrOutpMgr_Srv_GetSigImcData_logl_SigId : useless (never read) */

    /* init for variable DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Data */
    _main_gen_init_sym_DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Data();
    
    /* init for variable DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Sts */
    _main_gen_init_sym_DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Sts();
    
    /* init for variable DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Return */
    _main_gen_init_sym_DualCtrlrOutpMgr_Srv_GetSigImcData_logl_Return();
    
    /* init for variable DualCtrlrOutpMgr_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable DualCtrlrOutpMgr_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_DualCtrlrOutpMgr_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
}
