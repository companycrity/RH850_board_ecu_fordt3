#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_PolarityCfg_Pim_PolarityCfgSaved(void)
{
    extern __PST__UINT32 PolarityCfg_Pim_PolarityCfgSaved;
    
    /* initialization with random value */
    {
        PolarityCfg_Pim_PolarityCfgSaved = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PolarityCfg_Srv_PolarityCfgSaved_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 PolarityCfg_Srv_PolarityCfgSaved_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        PolarityCfg_Srv_PolarityCfgSaved_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PolarityCfg_Cli_PolarityCfgRead_PolarityCfgSaved(void)
{
    extern __PST__UINT32 PolarityCfg_Cli_PolarityCfgRead_PolarityCfgSaved;
    
    /* initialization with random value */
    {
        PolarityCfg_Cli_PolarityCfgRead_PolarityCfgSaved = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PolarityCfg_Cli_PolarityCfgWr_PolarityCfgSaved(void)
{
    extern __PST__UINT32 PolarityCfg_Cli_PolarityCfgWr_PolarityCfgSaved;
    
    /* initialization with random value */
    {
        PolarityCfg_Cli_PolarityCfgWr_PolarityCfgSaved = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable PolarityCfg_Op_AssiMechPolarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwAg0Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwAg1Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwAg2Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwAg3Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwAg4Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwAg5Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwAg6Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwAg7Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwTq0Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwTq1Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwTq2Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwTq3Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwTq4Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwTq5Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwTq6Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_HwTq7Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_MotAgMecl0Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_MotAgMecl1Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_MotAgMecl2Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_MotAgMecl3Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_MotAgMecl4Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_MotAgMecl5Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_MotAgMecl6Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_MotAgMecl7Polarity : useless (never read) */

    /* init for variable PolarityCfg_Op_MotElecMeclPolarity : useless (never read) */

    /* init for variable PolarityCfg_Pim_PolarityCfgSaved */
    _main_gen_init_sym_PolarityCfg_Pim_PolarityCfgSaved();
    
    /* init for variable PolarityCfg_Srv_PolarityCfgSaved_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable PolarityCfg_Srv_PolarityCfgSaved_SetRamBlockStatus_Return */
    _main_gen_init_sym_PolarityCfg_Srv_PolarityCfgSaved_SetRamBlockStatus_Return();
    
    /* init for variable PolarityCfg_Cli_PolarityCfgRead_PolarityCfgSaved */
    _main_gen_init_sym_PolarityCfg_Cli_PolarityCfgRead_PolarityCfgSaved();
    
    /* init for variable PolarityCfg_Cli_PolarityCfgRead_Return : useless (never read) */

    /* init for variable PolarityCfg_Cli_PolarityCfgWr_PolarityCfgSaved */
    _main_gen_init_sym_PolarityCfg_Cli_PolarityCfgWr_PolarityCfgSaved();
    
    /* init for variable PolarityCfg_Cli_PolarityCfgWr_Return : useless (never read) */

}
