typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__UINT8 __PST__g__15(__PST__UINT8);
typedef __PST__UINT8 *__PST__g__17;
typedef __PST__VOID __PST__g__16(__PST__UINT8, __PST__UINT8, __PST__g__17, __PST__g__17);
typedef __PST__VOID __PST__g__18(__PST__UINT8, __PST__UINT8, __PST__UINT8, __PST__UINT8, __PST__g__17, __PST__g__17, __PST__g__17);
typedef __PST__UINT32 *__PST__g__20;
typedef __PST__UINT8 __PST__g__19(__PST__UINT32, __PST__g__20, __PST__UINT8);
typedef __PST__VOID __PST__g__21(__PST__UINT8, __PST__UINT8, __PST__UINT8);
typedef __PST__VOID __PST__g__22(void);
typedef __PST__UINT8 __PST__g__23(__PST__UINT32);
typedef __PST__SINT8 __PST__g__28[1];
struct __PST__g__27
  {
    __PST__UINT16 SrcIdx_u16;
    __PST__UINT16 DestIdx_u16;
    __PST__UINT8 SigIdx_u08;
    __PST__g__28 __pst_unused_field___pstfiller;
  };
typedef const struct __PST__g__27 __PST__g__26;
typedef __PST__g__26 __PST__g__25[9];
typedef __PST__g__26 __PST__g__29[30];
typedef __PST__SINT8 __PST__g__33[3];
struct __PST__g__32
  {
    __PST__g__17 RamStructPtr_u08;
    __PST__UINT16 StructSize_u16;
    __PST__UINT16 TblIdx_u16;
    __PST__UINT8 GroupIdx_u08;
    __PST__g__33 __pst_unused_field___pstfiller;
  };
typedef const struct __PST__g__32 __PST__g__31;
typedef __PST__g__31 __PST__g__30[18];
typedef const __PST__UINT32 __PST__g__35;
typedef __PST__g__35 __PST__g__34[3];
typedef const __PST__VOID __PST__g__40;
typedef __PST__g__40 *__PST__g__39;
typedef __PST__g__39 __PST__g__38[36];
struct __PST__g__37
  {
    __PST__g__38 PrmRefTblPtr;
    __PST__UINT32 PrmTblCrc_u32;
  };
typedef struct __PST__g__37 __PST__g__36[2];
struct __PST__g__43
  {
    __PST__UINT32 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__42
  {
    struct __PST__g__43 CalRegn03CmnGroupA;
    struct __PST__g__43 CalRegn02CmnGroupA;
    struct __PST__g__43 CalRegn01Inin00GroupA;
    struct __PST__g__43 CalRegn03Inin00GroupA;
    struct __PST__g__43 CalRegn03Rt00GroupA;
    struct __PST__g__43 CalRegn01Rt00GroupA;
  };
struct __PST__g__44
  {
    struct __PST__g__43 CalRegn01CmnGroupB;
    struct __PST__g__43 CalRegn03CmnGroupB;
    struct __PST__g__43 CalRegn02CmnGroupB;
    struct __PST__g__43 CalRegn01Inin00GroupB;
    struct __PST__g__43 CalRegn03Inin00GroupB;
    struct __PST__g__43 CalRegn01Rt00GroupB;
    struct __PST__g__43 CalRegn03Rt00GroupB;
  };
struct __PST__g__45
  {
    struct __PST__g__43 CalRegn01CmnGroupC;
    struct __PST__g__43 CalRegn02CmnGroupC;
    struct __PST__g__43 CalRegn01Inin00GroupC;
    struct __PST__g__43 CalRegn03Inin00GroupC;
    struct __PST__g__43 CalRegn01Rt00GroupC;
  };
typedef __PST__UINT8 __PST__g__46[5120];
union __PST__g__41
  {
    struct __PST__g__42 GroupA;
    struct __PST__g__44 GroupB;
    struct __PST__g__45 GroupC;
    __PST__g__46 byte;
  };
typedef __PST__FLOAT64 __PST__g__47(void);
typedef __PST__g__11 *__PST__g__48;
typedef volatile __PST__FLOAT64 __PST__g__49;
typedef __PST__SINT8 *__PST__g__51;
typedef volatile __PST__g__51 __PST__g__50;
typedef const __PST__g__39 __PST__g__53;
typedef __PST__g__53 *__PST__g__52;
typedef const struct Rte_CDS_TunSelnMngt __PST__g__56;
typedef __PST__g__56 *__PST__g__55;
typedef const __PST__g__55 __PST__g__54;
typedef struct __PST__g__59 *__PST__g__58;
struct Rte_CDS_TunSelnMngt
  {
    __PST__g__58 Pim_OnlineCalSts;
    __PST__g__17 Pim_PrevActvIninIdx;
    __PST__g__17 Pim_PrevActvRtIdx;
    __PST__g__17 Pim_PrevRamPageAcs;
    __PST__g__17 Pim_RamTblSwt;
  };
struct __PST__g__63
  {
    __PST__UINT8 PageAcs;
  };
typedef struct __PST__g__63 __PST__g__62[2];
struct __PST__g__61
  {
    __PST__g__62 Page;
  };
typedef struct __PST__g__61 __PST__g__60[3];
struct __PST__g__59
  {
    __PST__g__60 Seg;
    __PST__UINT8 CopySts;
    __PST__UINT8 ActvGroup;
    __PST__UINT8 ActvInin;
    __PST__UINT8 ActvRt;
  };
typedef __PST__g__53 __PST__g__64[36];
typedef __PST__VOID __PST__g__65(__PST__SINT32);
typedef __PST__UINT8 __PST__g__66(__PST__g__17);
typedef __PST__UINT8 __PST__g__67(__PST__g__20, __PST__UINT32, __PST__UINT32, __PST__UINT8, __PST__g__20);
typedef __PST__UINT8 __PST__g__68(void);
typedef __PST__UINT8 __PST__g__69(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);
typedef __PST__g__22 *__PST__g__70;
typedef const __PST__g__58 __PST__g__71;
typedef __PST__g__71 *__PST__g__72;
typedef const __PST__g__17 __PST__g__73;
typedef __PST__g__73 *__PST__g__74;
typedef __PST__g__60 *__PST__g__75;
typedef struct __PST__g__61 *__PST__g__76;
typedef __PST__g__62 *__PST__g__77;
typedef struct __PST__g__63 *__PST__g__78;
enum __PST__g__79
  {
    GETSEGMODSEGINFO_ADR = 0,
    GETSEGMODSEGINFO_LEN = 1
  };
typedef __PST__UINT8 __PST__g__80(__PST__UINT8, enum __PST__g__79, __PST__g__17, __PST__g__17);
typedef __PST__g__80 *__PST__g__81;
typedef __PST__UINT8 __PST__g__82(__PST__UINT8, __PST__g__17, __PST__g__17);
typedef __PST__g__82 *__PST__g__83;
enum __PST__g__84
  {
    GETSEGMODMPGIDX_DESTADR = 1,
    GETSEGMODMPGIDX_LEN = 2,
    GETSEGMODMPGIDX_SRCADR = 0
  };
typedef __PST__UINT8 __PST__g__85(__PST__UINT8, enum __PST__g__84, __PST__UINT8, __PST__g__17, __PST__g__17);
typedef __PST__g__85 *__PST__g__86;
typedef __PST__g__30 *__PST__g__87;
typedef __PST__g__31 *__PST__g__88;
typedef const __PST__UINT8 __PST__g__89;
typedef __PST__g__89 *__PST__g__90;
typedef __PST__g__65 *__PST__g__91;
typedef __PST__g__64 *__PST__g__92;
typedef const __PST__UINT16 __PST__g__93;
typedef __PST__g__93 *__PST__g__94;
typedef __PST__g__23 *__PST__g__95;
typedef __PST__g__66 *__PST__g__96;
typedef __PST__VOID __PST__g__97(__PST__g__11, __PST__g__39, __PST__UINT16);
typedef __PST__g__97 *__PST__g__98;
typedef __PST__g__36 *__PST__g__99;
typedef struct __PST__g__37 *__PST__g__100;
typedef __PST__g__38 *__PST__g__101;
typedef __PST__g__67 *__PST__g__102;
typedef __PST__g__26 *__PST__g__103;
typedef __PST__UINT8 __PST__g__104(__PST__UINT8, __PST__UINT8, __PST__g__103);
typedef __PST__g__104 *__PST__g__105;
typedef __PST__g__25 *__PST__g__106;
typedef __PST__g__69 *__PST__g__107;
typedef __PST__g__15 *__PST__g__108;
typedef __PST__g__29 *__PST__g__109;
typedef __PST__g__39 *__PST__g__110;
typedef __PST__g__68 *__PST__g__111;
typedef __PST__g__35 *__PST__g__112;
typedef union __PST__g__41 *__PST__g__113;
typedef __PST__g__46 *__PST__g__114;
typedef __PST__g__34 *__PST__g__115;
typedef __PST__UINT8 __PST__g__116[18];
typedef __PST__g__116 *__PST__g__117;
typedef struct __PST__g__42 *__PST__g__118;
typedef struct __PST__g__43 *__PST__g__119;
typedef struct __PST__g__44 *__PST__g__120;
typedef struct __PST__g__45 *__PST__g__121;
typedef volatile __PST__SINT32 __PST__g__122;
typedef __PST__SINT8 __PST__g__126(void);
typedef volatile __PST__SINT8 __PST__g__127;
typedef volatile __PST__UINT8 __PST__g__128;
typedef __PST__SINT32 __PST__g__129(void);
typedef __PST__UINT32 __PST__g__130(void);
typedef volatile __PST__UINT32 __PST__g__131;
