#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_CopyCalPageReq_Oper(void)
{
    extern __PST__UINT8 CopyCalPageReq_Oper(__PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    
    __arg__0 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = CopyCalPageReq_Oper(__arg__0);
}

static void _main_gen_call_GetCalPageReq_Oper(void)
{
    extern __PST__VOID GetCalPageReq_Oper(__PST__UINT8, __PST__UINT8, __PST__g__17, __PST__g__17);

    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__g__17 __arg__2;
    __PST__g__17 __arg__3;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g6();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g6();
        }
        __arg__3 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    GetCalPageReq_Oper(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_GetSegInfoReq_Oper(void)
{
    extern __PST__VOID GetSegInfoReq_Oper(__PST__UINT8, __PST__UINT8, __PST__UINT8, __PST__UINT8, __PST__g__17, __PST__g__17, __PST__g__17);

    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    __PST__UINT8 __arg__3;
    __PST__g__17 __arg__4;
    __PST__g__17 __arg__5;
    __PST__g__17 __arg__6;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    __arg__3 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g6();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g6();
        }
        __arg__6 = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    GetSegInfoReq_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6);
}

static void _main_gen_call_OnlineTunRamAdrMpg_Oper(void)
{
    extern __PST__UINT8 OnlineTunRamAdrMpg_Oper(__PST__UINT32, __PST__g__20, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT32 __arg__0;
    __PST__g__20 __arg__1;
    __PST__UINT8 __arg__2;
    
    __arg__0 = _main_gen_init_g8();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    __arg__2 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = OnlineTunRamAdrMpg_Oper(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_SetCalPageReq_Oper(void)
{
    extern __PST__VOID SetCalPageReq_Oper(__PST__UINT8, __PST__UINT8, __PST__UINT8);

    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    
    /* call it */
    SetCalPageReq_Oper(__arg__0, __arg__1, __arg__2);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function CopyCalPageReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_CopyCalPageReq_Oper();
        }
        
        /* call of function GetCalPageReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetCalPageReq_Oper();
        }
        
        /* call of function GetSegInfoReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetSegInfoReq_Oper();
        }
        
        /* call of function OnlineTunRamAdrMpg_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_OnlineTunRamAdrMpg_Oper();
        }
        
        /* call of function SetCalPageReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_SetCalPageReq_Oper();
        }
        
        /* call of function TunSelnMngtInit1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID TunSelnMngtInit1(__PST__VOID);

            TunSelnMngtInit1();
        }
        
        /* call of function TunSelnMngtPer1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID TunSelnMngtPer1(__PST__VOID);

            TunSelnMngtPer1();
        }
        
    }
}
