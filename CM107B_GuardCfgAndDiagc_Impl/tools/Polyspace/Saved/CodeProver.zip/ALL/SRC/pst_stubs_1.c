#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__106 _main_gen_init_g106(void);

extern __PST__g__102 _main_gen_init_g102(void);

extern __PST__g__99 _main_gen_init_g99(void);

extern __PST__g__97 _main_gen_init_g97(void);

extern __PST__g__93 _main_gen_init_g93(void);

extern __PST__g__90 _main_gen_init_g90(void);

extern __PST__g__87 _main_gen_init_g87(void);

extern __PST__g__84 _main_gen_init_g84(void);

extern __PST__g__81 _main_gen_init_g81(void);

extern __PST__g__78 _main_gen_init_g78(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__g__75 _main_gen_init_g75(void);

extern __PST__g__72 _main_gen_init_g72(void);

extern __PST__g__69 _main_gen_init_g69(void);

extern __PST__g__66 _main_gen_init_g66(void);

extern __PST__g__63 _main_gen_init_g63(void);

extern __PST__g__60 _main_gen_init_g60(void);

extern __PST__g__57 _main_gen_init_g57(void);

extern __PST__g__54 _main_gen_init_g54(void);

extern __PST__g__51 _main_gen_init_g51(void);

extern __PST__g__48 _main_gen_init_g48(void);

extern __PST__g__45 _main_gen_init_g45(void);

extern __PST__g__42 _main_gen_init_g42(void);

extern __PST__g__39 _main_gen_init_g39(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__23 _main_gen_init_g23(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__39 _main_gen_init_g39(void)
{
    __PST__g__39 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__42 _main_gen_init_g42(void)
{
    __PST__g__42 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__45 _main_gen_init_g45(void)
{
    __PST__g__45 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__48 _main_gen_init_g48(void)
{
    __PST__g__48 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__51 _main_gen_init_g51(void)
{
    __PST__g__51 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__54 _main_gen_init_g54(void)
{
    __PST__g__54 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__57 _main_gen_init_g57(void)
{
    __PST__g__57 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__60 _main_gen_init_g60(void)
{
    __PST__g__60 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__63 _main_gen_init_g63(void)
{
    __PST__g__63 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__66 _main_gen_init_g66(void)
{
    __PST__g__66 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__69 _main_gen_init_g69(void)
{
    __PST__g__69 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__72 _main_gen_init_g72(void)
{
    __PST__g__72 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__75 _main_gen_init_g75(void)
{
    __PST__g__75 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__78 _main_gen_init_g78(void)
{
    __PST__g__78 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__81 _main_gen_init_g81(void)
{
    __PST__g__81 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__84 _main_gen_init_g84(void)
{
    __PST__g__84 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__87 _main_gen_init_g87(void)
{
    __PST__g__87 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__90 _main_gen_init_g90(void)
{
    __PST__g__90 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__93 _main_gen_init_g93(void)
{
    __PST__g__93 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__97 _main_gen_init_g97(void)
{
    __PST__g__97 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__99 _main_gen_init_g99(void)
{
    __PST__g__99 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__102 _main_gen_init_g102(void)
{
    __PST__g__102 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__106 _main_gen_init_g106(void)
{
    __PST__g__106 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FSGD1APROT00_BASE(void)
{
    extern __PST__g__23 FSGD1APROT00_BASE;
    
    /* initialization with random value */
    {
        FSGD1APROT00_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1ASPID00_BASE(void)
{
    extern __PST__g__27 FSGD1ASPID00_BASE;
    
    /* initialization with random value */
    {
        FSGD1ASPID00_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1APROT01_BASE(void)
{
    extern __PST__g__23 FSGD1APROT01_BASE;
    
    /* initialization with random value */
    {
        FSGD1APROT01_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1ASPID01_BASE(void)
{
    extern __PST__g__27 FSGD1ASPID01_BASE;
    
    /* initialization with random value */
    {
        FSGD1ASPID01_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1APROT02_BASE(void)
{
    extern __PST__g__23 FSGD1APROT02_BASE;
    
    /* initialization with random value */
    {
        FSGD1APROT02_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1ASPID02_BASE(void)
{
    extern __PST__g__27 FSGD1ASPID02_BASE;
    
    /* initialization with random value */
    {
        FSGD1ASPID02_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1APROT03_BASE(void)
{
    extern __PST__g__23 FSGD1APROT03_BASE;
    
    /* initialization with random value */
    {
        FSGD1APROT03_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1ASPID03_BASE(void)
{
    extern __PST__g__27 FSGD1ASPID03_BASE;
    
    /* initialization with random value */
    {
        FSGD1ASPID03_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1APROT04_BASE(void)
{
    extern __PST__g__23 FSGD1APROT04_BASE;
    
    /* initialization with random value */
    {
        FSGD1APROT04_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1ASPID04_BASE(void)
{
    extern __PST__g__27 FSGD1ASPID04_BASE;
    
    /* initialization with random value */
    {
        FSGD1ASPID04_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1APROT05_BASE(void)
{
    extern __PST__g__23 FSGD1APROT05_BASE;
    
    /* initialization with random value */
    {
        FSGD1APROT05_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1ASPID05_BASE(void)
{
    extern __PST__g__27 FSGD1ASPID05_BASE;
    
    /* initialization with random value */
    {
        FSGD1ASPID05_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1BPROT00_BASE(void)
{
    extern __PST__g__23 FSGD1BPROT00_BASE;
    
    /* initialization with random value */
    {
        FSGD1BPROT00_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1BSPID00_BASE(void)
{
    extern __PST__g__27 FSGD1BSPID00_BASE;
    
    /* initialization with random value */
    {
        FSGD1BSPID00_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1BPROT01_BASE(void)
{
    extern __PST__g__23 FSGD1BPROT01_BASE;
    
    /* initialization with random value */
    {
        FSGD1BPROT01_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1BSPID01_BASE(void)
{
    extern __PST__g__27 FSGD1BSPID01_BASE;
    
    /* initialization with random value */
    {
        FSGD1BSPID01_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1BPROT06_BASE(void)
{
    extern __PST__g__23 FSGD1BPROT06_BASE;
    
    /* initialization with random value */
    {
        FSGD1BPROT06_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1BSPID06_BASE(void)
{
    extern __PST__g__27 FSGD1BSPID06_BASE;
    
    /* initialization with random value */
    {
        FSGD1BSPID06_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1BPROT07_BASE(void)
{
    extern __PST__g__23 FSGD1BPROT07_BASE;
    
    /* initialization with random value */
    {
        FSGD1BPROT07_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1BSPID07_BASE(void)
{
    extern __PST__g__27 FSGD1BSPID07_BASE;
    
    /* initialization with random value */
    {
        FSGD1BSPID07_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1BPROT10_BASE(void)
{
    extern __PST__g__23 FSGD1BPROT10_BASE;
    
    /* initialization with random value */
    {
        FSGD1BPROT10_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1BSPID10_BASE(void)
{
    extern __PST__g__27 FSGD1BSPID10_BASE;
    
    /* initialization with random value */
    {
        FSGD1BSPID10_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1BPROT11_BASE(void)
{
    extern __PST__g__23 FSGD1BPROT11_BASE;
    
    /* initialization with random value */
    {
        FSGD1BPROT11_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1BSPID11_BASE(void)
{
    extern __PST__g__27 FSGD1BSPID11_BASE;
    
    /* initialization with random value */
    {
        FSGD1BSPID11_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1BPROT12_BASE(void)
{
    extern __PST__g__23 FSGD1BPROT12_BASE;
    
    /* initialization with random value */
    {
        FSGD1BPROT12_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1BSPID12_BASE(void)
{
    extern __PST__g__27 FSGD1BSPID12_BASE;
    
    /* initialization with random value */
    {
        FSGD1BSPID12_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD1BPROT13_BASE(void)
{
    extern __PST__g__23 FSGD1BPROT13_BASE;
    
    /* initialization with random value */
    {
        FSGD1BPROT13_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD1BSPID13_BASE(void)
{
    extern __PST__g__27 FSGD1BSPID13_BASE;
    
    /* initialization with random value */
    {
        FSGD1BSPID13_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD2APROT00_BASE(void)
{
    extern __PST__g__23 FSGD2APROT00_BASE;
    
    /* initialization with random value */
    {
        FSGD2APROT00_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD2ASPID00_BASE(void)
{
    extern __PST__g__27 FSGD2ASPID00_BASE;
    
    /* initialization with random value */
    {
        FSGD2ASPID00_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD2APROT01_BASE(void)
{
    extern __PST__g__23 FSGD2APROT01_BASE;
    
    /* initialization with random value */
    {
        FSGD2APROT01_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD2ASPID01_BASE(void)
{
    extern __PST__g__27 FSGD2ASPID01_BASE;
    
    /* initialization with random value */
    {
        FSGD2ASPID01_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD2APROT02_BASE(void)
{
    extern __PST__g__23 FSGD2APROT02_BASE;
    
    /* initialization with random value */
    {
        FSGD2APROT02_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD2ASPID02_BASE(void)
{
    extern __PST__g__27 FSGD2ASPID02_BASE;
    
    /* initialization with random value */
    {
        FSGD2ASPID02_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD2APROT03_BASE(void)
{
    extern __PST__g__23 FSGD2APROT03_BASE;
    
    /* initialization with random value */
    {
        FSGD2APROT03_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD2ASPID03_BASE(void)
{
    extern __PST__g__27 FSGD2ASPID03_BASE;
    
    /* initialization with random value */
    {
        FSGD2ASPID03_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD2APROT04_BASE(void)
{
    extern __PST__g__23 FSGD2APROT04_BASE;
    
    /* initialization with random value */
    {
        FSGD2APROT04_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD2ASPID04_BASE(void)
{
    extern __PST__g__27 FSGD2ASPID04_BASE;
    
    /* initialization with random value */
    {
        FSGD2ASPID04_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD2APROT05_BASE(void)
{
    extern __PST__g__23 FSGD2APROT05_BASE;
    
    /* initialization with random value */
    {
        FSGD2APROT05_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD2ASPID05_BASE(void)
{
    extern __PST__g__27 FSGD2ASPID05_BASE;
    
    /* initialization with random value */
    {
        FSGD2ASPID05_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD2APROT06_BASE(void)
{
    extern __PST__g__23 FSGD2APROT06_BASE;
    
    /* initialization with random value */
    {
        FSGD2APROT06_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD2ASPID06_BASE(void)
{
    extern __PST__g__27 FSGD2ASPID06_BASE;
    
    /* initialization with random value */
    {
        FSGD2ASPID06_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD2APROT07_BASE(void)
{
    extern __PST__g__23 FSGD2APROT07_BASE;
    
    /* initialization with random value */
    {
        FSGD2APROT07_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD2ASPID07_BASE(void)
{
    extern __PST__g__27 FSGD2ASPID07_BASE;
    
    /* initialization with random value */
    {
        FSGD2ASPID07_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD2APROT10_BASE(void)
{
    extern __PST__g__23 FSGD2APROT10_BASE;
    
    /* initialization with random value */
    {
        FSGD2APROT10_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD2ASPID10_BASE(void)
{
    extern __PST__g__27 FSGD2ASPID10_BASE;
    
    /* initialization with random value */
    {
        FSGD2ASPID10_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD2APROT11_BASE(void)
{
    extern __PST__g__23 FSGD2APROT11_BASE;
    
    /* initialization with random value */
    {
        FSGD2APROT11_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD2ASPID11_BASE(void)
{
    extern __PST__g__27 FSGD2ASPID11_BASE;
    
    /* initialization with random value */
    {
        FSGD2ASPID11_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT00_BASE(void)
{
    extern __PST__g__23 FSGD3APROT00_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT00_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID00_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID00_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID00_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT01_BASE(void)
{
    extern __PST__g__23 FSGD3APROT01_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT01_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID01_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID01_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID01_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT02_BASE(void)
{
    extern __PST__g__23 FSGD3APROT02_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT02_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID02_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID02_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID02_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT03_BASE(void)
{
    extern __PST__g__23 FSGD3APROT03_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT03_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID03_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID03_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID03_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT04_BASE(void)
{
    extern __PST__g__23 FSGD3APROT04_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT04_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID04_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID04_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID04_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT05_BASE(void)
{
    extern __PST__g__23 FSGD3APROT05_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT05_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID05_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID05_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID05_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT06_BASE(void)
{
    extern __PST__g__23 FSGD3APROT06_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT06_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID06_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID06_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID06_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT07_BASE(void)
{
    extern __PST__g__23 FSGD3APROT07_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT07_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID07_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID07_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID07_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT08_BASE(void)
{
    extern __PST__g__23 FSGD3APROT08_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT08_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID08_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID08_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID08_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT09_BASE(void)
{
    extern __PST__g__23 FSGD3APROT09_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT09_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID09_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID09_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID09_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT10_BASE(void)
{
    extern __PST__g__23 FSGD3APROT10_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT10_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID10_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID10_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID10_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT11_BASE(void)
{
    extern __PST__g__23 FSGD3APROT11_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT11_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID11_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID11_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID11_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT12_BASE(void)
{
    extern __PST__g__23 FSGD3APROT12_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT12_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID12_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID12_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID12_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT13_BASE(void)
{
    extern __PST__g__23 FSGD3APROT13_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT13_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID13_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID13_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID13_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT14_BASE(void)
{
    extern __PST__g__23 FSGD3APROT14_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT14_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID14_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID14_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID14_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3APROT15_BASE(void)
{
    extern __PST__g__23 FSGD3APROT15_BASE;
    
    /* initialization with random value */
    {
        FSGD3APROT15_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3ASPID15_BASE(void)
{
    extern __PST__g__27 FSGD3ASPID15_BASE;
    
    /* initialization with random value */
    {
        FSGD3ASPID15_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3BPROT00_BASE(void)
{
    extern __PST__g__23 FSGD3BPROT00_BASE;
    
    /* initialization with random value */
    {
        FSGD3BPROT00_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3BSPID00_BASE(void)
{
    extern __PST__g__27 FSGD3BSPID00_BASE;
    
    /* initialization with random value */
    {
        FSGD3BSPID00_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3BPROT01_BASE(void)
{
    extern __PST__g__23 FSGD3BPROT01_BASE;
    
    /* initialization with random value */
    {
        FSGD3BPROT01_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3BSPID01_BASE(void)
{
    extern __PST__g__27 FSGD3BSPID01_BASE;
    
    /* initialization with random value */
    {
        FSGD3BSPID01_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3BPROT02_BASE(void)
{
    extern __PST__g__23 FSGD3BPROT02_BASE;
    
    /* initialization with random value */
    {
        FSGD3BPROT02_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3BSPID02_BASE(void)
{
    extern __PST__g__27 FSGD3BSPID02_BASE;
    
    /* initialization with random value */
    {
        FSGD3BSPID02_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3BPROT03_BASE(void)
{
    extern __PST__g__23 FSGD3BPROT03_BASE;
    
    /* initialization with random value */
    {
        FSGD3BPROT03_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3BSPID03_BASE(void)
{
    extern __PST__g__27 FSGD3BSPID03_BASE;
    
    /* initialization with random value */
    {
        FSGD3BSPID03_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3BPROT06_BASE(void)
{
    extern __PST__g__23 FSGD3BPROT06_BASE;
    
    /* initialization with random value */
    {
        FSGD3BPROT06_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3BSPID06_BASE(void)
{
    extern __PST__g__27 FSGD3BSPID06_BASE;
    
    /* initialization with random value */
    {
        FSGD3BSPID06_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3BPROT07_BASE(void)
{
    extern __PST__g__23 FSGD3BPROT07_BASE;
    
    /* initialization with random value */
    {
        FSGD3BPROT07_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3BSPID07_BASE(void)
{
    extern __PST__g__27 FSGD3BSPID07_BASE;
    
    /* initialization with random value */
    {
        FSGD3BSPID07_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3BPROT10_BASE(void)
{
    extern __PST__g__23 FSGD3BPROT10_BASE;
    
    /* initialization with random value */
    {
        FSGD3BPROT10_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3BSPID10_BASE(void)
{
    extern __PST__g__27 FSGD3BSPID10_BASE;
    
    /* initialization with random value */
    {
        FSGD3BSPID10_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3BPROT11_BASE(void)
{
    extern __PST__g__23 FSGD3BPROT11_BASE;
    
    /* initialization with random value */
    {
        FSGD3BPROT11_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3BSPID11_BASE(void)
{
    extern __PST__g__27 FSGD3BSPID11_BASE;
    
    /* initialization with random value */
    {
        FSGD3BSPID11_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3BPROT12_BASE(void)
{
    extern __PST__g__23 FSGD3BPROT12_BASE;
    
    /* initialization with random value */
    {
        FSGD3BPROT12_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3BSPID12_BASE(void)
{
    extern __PST__g__27 FSGD3BSPID12_BASE;
    
    /* initialization with random value */
    {
        FSGD3BSPID12_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD3BPROT13_BASE(void)
{
    extern __PST__g__23 FSGD3BPROT13_BASE;
    
    /* initialization with random value */
    {
        FSGD3BPROT13_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD3BSPID13_BASE(void)
{
    extern __PST__g__27 FSGD3BSPID13_BASE;
    
    /* initialization with random value */
    {
        FSGD3BSPID13_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT00_BASE(void)
{
    extern __PST__g__23 FSGD4APROT00_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT00_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID00_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID00_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID00_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT01_BASE(void)
{
    extern __PST__g__23 FSGD4APROT01_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT01_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID01_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID01_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID01_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT02_BASE(void)
{
    extern __PST__g__23 FSGD4APROT02_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT02_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID02_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID02_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID02_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT03_BASE(void)
{
    extern __PST__g__23 FSGD4APROT03_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT03_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID03_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID03_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID03_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT04_BASE(void)
{
    extern __PST__g__23 FSGD4APROT04_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT04_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID04_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID04_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID04_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT05_BASE(void)
{
    extern __PST__g__23 FSGD4APROT05_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT05_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID05_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID05_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID05_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT06_BASE(void)
{
    extern __PST__g__23 FSGD4APROT06_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT06_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID06_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID06_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID06_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT07_BASE(void)
{
    extern __PST__g__23 FSGD4APROT07_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT07_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID07_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID07_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID07_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT08_BASE(void)
{
    extern __PST__g__23 FSGD4APROT08_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT08_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID08_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID08_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID08_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT09_BASE(void)
{
    extern __PST__g__23 FSGD4APROT09_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT09_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID09_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID09_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID09_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT10_BASE(void)
{
    extern __PST__g__23 FSGD4APROT10_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT10_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID10_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID10_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID10_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT11_BASE(void)
{
    extern __PST__g__23 FSGD4APROT11_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT11_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID11_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID11_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID11_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT12_BASE(void)
{
    extern __PST__g__23 FSGD4APROT12_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT12_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID12_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID12_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID12_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT13_BASE(void)
{
    extern __PST__g__23 FSGD4APROT13_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT13_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID13_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID13_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID13_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT14_BASE(void)
{
    extern __PST__g__23 FSGD4APROT14_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT14_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID14_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID14_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID14_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4APROT15_BASE(void)
{
    extern __PST__g__23 FSGD4APROT15_BASE;
    
    /* initialization with random value */
    {
        FSGD4APROT15_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4ASPID15_BASE(void)
{
    extern __PST__g__27 FSGD4ASPID15_BASE;
    
    /* initialization with random value */
    {
        FSGD4ASPID15_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT00_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT00_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT00_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID00_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID00_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID00_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT01_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT01_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT01_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID01_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID01_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID01_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT02_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT02_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT02_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID02_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID02_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID02_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT03_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT03_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT03_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID03_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID03_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID03_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT04_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT04_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT04_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID04_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID04_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID04_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT05_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT05_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT05_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID05_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID05_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID05_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT06_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT06_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT06_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID06_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID06_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID06_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT07_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT07_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT07_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID07_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID07_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID07_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT08_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT08_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT08_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID08_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID08_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID08_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT09_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT09_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT09_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID09_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID09_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID09_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT10_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT10_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT10_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID10_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID10_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID10_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT11_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT11_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT11_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID11_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID11_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID11_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT12_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT12_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT12_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID12_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID12_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID12_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FSGD4BPROT13_BASE(void)
{
    extern __PST__g__23 FSGD4BPROT13_BASE;
    
    /* initialization with random value */
    {
        FSGD4BPROT13_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_FSGD4BSPID13_BASE(void)
{
    extern __PST__g__27 FSGD4BSPID13_BASE;
    
    /* initialization with random value */
    {
        FSGD4BSPID13_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_PEGG0MK_BASE(void)
{
    extern __PST__g__30 PEGG0MK_BASE;
    
    /* initialization with random value */
    {
        PEGG0MK_BASE = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_PEGG0BA_BASE(void)
{
    extern __PST__g__36 PEGG0BA_BASE;
    
    /* initialization with random value */
    {
        PEGG0BA_BASE = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_PEGG0SP_BASE(void)
{
    extern __PST__g__39 PEGG0SP_BASE;
    
    /* initialization with random value */
    {
        PEGG0SP_BASE = _main_gen_init_g39();
    }
}

static void _main_gen_init_sym_PEGG1MK_BASE(void)
{
    extern __PST__g__42 PEGG1MK_BASE;
    
    /* initialization with random value */
    {
        PEGG1MK_BASE = _main_gen_init_g42();
    }
}

static void _main_gen_init_sym_PEGG1BA_BASE(void)
{
    extern __PST__g__45 PEGG1BA_BASE;
    
    /* initialization with random value */
    {
        PEGG1BA_BASE = _main_gen_init_g45();
    }
}

static void _main_gen_init_sym_PEGG1SP_BASE(void)
{
    extern __PST__g__48 PEGG1SP_BASE;
    
    /* initialization with random value */
    {
        PEGG1SP_BASE = _main_gen_init_g48();
    }
}

static void _main_gen_init_sym_PEGG2MK_BASE(void)
{
    extern __PST__g__51 PEGG2MK_BASE;
    
    /* initialization with random value */
    {
        PEGG2MK_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_PEGG2BA_BASE(void)
{
    extern __PST__g__54 PEGG2BA_BASE;
    
    /* initialization with random value */
    {
        PEGG2BA_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_PEGG2SP_BASE(void)
{
    extern __PST__g__57 PEGG2SP_BASE;
    
    /* initialization with random value */
    {
        PEGG2SP_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_PEGG3BA_BASE(void)
{
    extern __PST__g__60 PEGG3BA_BASE;
    
    /* initialization with random value */
    {
        PEGG3BA_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_PEGG4BA_BASE(void)
{
    extern __PST__g__63 PEGG4BA_BASE;
    
    /* initialization with random value */
    {
        PEGG4BA_BASE = _main_gen_init_g63();
    }
}

static void _main_gen_init_sym_PEGG5BA_BASE(void)
{
    extern __PST__g__66 PEGG5BA_BASE;
    
    /* initialization with random value */
    {
        PEGG5BA_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_PEGG6BA_BASE(void)
{
    extern __PST__g__69 PEGG6BA_BASE;
    
    /* initialization with random value */
    {
        PEGG6BA_BASE = _main_gen_init_g69();
    }
}

static void _main_gen_init_sym_PEGG7BA_BASE(void)
{
    extern __PST__g__72 PEGG7BA_BASE;
    
    /* initialization with random value */
    {
        PEGG7BA_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_PBG_A_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_PBG_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_PBG_A_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_PBG_A_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_PBG_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_PBG_A_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_PBG_B_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_PBG_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_PBG_B_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_PBG_B_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_PBG_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_PBG_B_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_SP1_A_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_SP1_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_SP1_A_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_SP1_A_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_SP1_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_SP1_A_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_SP1_B_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_SP1_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_SP1_B_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_SP1_B_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_SP1_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_SP1_B_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_SP4_A_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_SP4_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_SP4_A_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_SP4_A_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_SP4_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_SP4_A_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_SP4_B_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_SP4_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_SP4_B_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_SP4_B_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_SP4_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_SP4_B_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_PDMACM_A_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_PDMACM_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_PDMACM_A_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_PDMACM_A_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_PDMACM_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_PDMACM_A_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_PDMACM_B_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_PDMACM_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_PDMACM_B_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_PDMACM_B_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_PDMACM_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_PDMACM_B_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_PDMACH_A_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_PDMACH_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_PDMACH_A_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_PDMACH_A_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_PDMACH_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_PDMACH_A_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_PDMACH_B_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_PDMACH_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_PDMACH_B_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_PDMACH_B_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_PDMACH_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_PDMACH_B_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_INTC2_A_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_INTC2_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_INTC2_A_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_INTC2_A_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_INTC2_A_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_INTC2_A_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_APBFSGDPROT_INTC2_B_BASE(void)
{
    extern __PST__g__23 APBFSGDPROT_INTC2_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDPROT_INTC2_B_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_APBFSGDSPID_INTC2_B_BASE(void)
{
    extern __PST__g__27 APBFSGDSPID_INTC2_B_BASE;
    
    /* initialization with random value */
    {
        APBFSGDSPID_INTC2_B_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_IPGENUM_BASE(void)
{
    extern __PST__g__75 IPGENUM_BASE;
    
    /* initialization with random value */
    {
        IPGENUM_BASE = _main_gen_init_g75();
    }
}

static void _main_gen_init_sym_IPGPMTUM0_BASE(void)
{
    extern __PST__g__78 IPGPMTUM0_BASE;
    
    /* initialization with random value */
    {
        IPGPMTUM0_BASE = _main_gen_init_g78();
    }
}

static void _main_gen_init_sym_IPGPMTUM1_BASE(void)
{
    extern __PST__g__81 IPGPMTUM1_BASE;
    
    /* initialization with random value */
    {
        IPGPMTUM1_BASE = _main_gen_init_g81();
    }
}

static void _main_gen_init_sym_IPGPMTUM2_BASE(void)
{
    extern __PST__g__84 IPGPMTUM2_BASE;
    
    /* initialization with random value */
    {
        IPGPMTUM2_BASE = _main_gen_init_g84();
    }
}

static void _main_gen_init_sym_IPGPMTUM3_BASE(void)
{
    extern __PST__g__87 IPGPMTUM3_BASE;
    
    /* initialization with random value */
    {
        IPGPMTUM3_BASE = _main_gen_init_g87();
    }
}

static void _main_gen_init_sym_IPGPMTUM4_BASE(void)
{
    extern __PST__g__90 IPGPMTUM4_BASE;
    
    /* initialization with random value */
    {
        IPGPMTUM4_BASE = _main_gen_init_g90();
    }
}

static void _main_gen_init_sym_FSGDF0PROT00_BASE(void)
{
    extern __PST__g__93 FSGDF0PROT00_BASE;
    
    /* initialization with random value */
    {
        FSGDF0PROT00_BASE = _main_gen_init_g93();
    }
}

static void _main_gen_init_sym_FSGDF0SPID00_BASE(void)
{
    extern __PST__g__97 FSGDF0SPID00_BASE;
    
    /* initialization with random value */
    {
        FSGDF0SPID00_BASE = _main_gen_init_g97();
    }
}

static void _main_gen_init_sym_FSGDF0PROT01_BASE(void)
{
    extern __PST__g__93 FSGDF0PROT01_BASE;
    
    /* initialization with random value */
    {
        FSGDF0PROT01_BASE = _main_gen_init_g93();
    }
}

static void _main_gen_init_sym_FSGDF0SPID01_BASE(void)
{
    extern __PST__g__97 FSGDF0SPID01_BASE;
    
    /* initialization with random value */
    {
        FSGDF0SPID01_BASE = _main_gen_init_g97();
    }
}

static void _main_gen_init_sym_FSGDE0PROT00_BASE(void)
{
    extern __PST__g__93 FSGDE0PROT00_BASE;
    
    /* initialization with random value */
    {
        FSGDE0PROT00_BASE = _main_gen_init_g93();
    }
}

static void _main_gen_init_sym_FSGDE0SPID00_BASE(void)
{
    extern __PST__g__97 FSGDE0SPID00_BASE;
    
    /* initialization with random value */
    {
        FSGDE0SPID00_BASE = _main_gen_init_g97();
    }
}

static void _main_gen_init_sym_MGDGRPROT0_BASE(void)
{
    extern __PST__g__99 MGDGRPROT0_BASE;
    
    /* initialization with random value */
    {
        MGDGRPROT0_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_MGDGRSPID0_BASE(void)
{
    extern __PST__g__27 MGDGRSPID0_BASE;
    
    /* initialization with random value */
    {
        MGDGRSPID0_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_MGDGRBAD0_BASE(void)
{
    extern __PST__g__102 MGDGRBAD0_BASE;
    
    /* initialization with random value */
    {
        MGDGRBAD0_BASE = _main_gen_init_g102();
    }
}

static void _main_gen_init_sym_MGDGRADV0_BASE(void)
{
    extern __PST__g__106 MGDGRADV0_BASE;
    
    /* initialization with random value */
    {
        MGDGRADV0_BASE = _main_gen_init_g106();
    }
}

static void _main_gen_init_sym_MGDGRPROT1_BASE(void)
{
    extern __PST__g__99 MGDGRPROT1_BASE;
    
    /* initialization with random value */
    {
        MGDGRPROT1_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_MGDGRPROT2_BASE(void)
{
    extern __PST__g__99 MGDGRPROT2_BASE;
    
    /* initialization with random value */
    {
        MGDGRPROT2_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_MGDGRPROT3_BASE(void)
{
    extern __PST__g__99 MGDGRPROT3_BASE;
    
    /* initialization with random value */
    {
        MGDGRPROT3_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_MGDGRPROT4_BASE(void)
{
    extern __PST__g__99 MGDGRPROT4_BASE;
    
    /* initialization with random value */
    {
        MGDGRPROT4_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_MGDGRPROT5_BASE(void)
{
    extern __PST__g__99 MGDGRPROT5_BASE;
    
    /* initialization with random value */
    {
        MGDGRPROT5_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_MGDGRPROT6_BASE(void)
{
    extern __PST__g__99 MGDGRPROT6_BASE;
    
    /* initialization with random value */
    {
        MGDGRPROT6_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_MGDGRPROT7_BASE(void)
{
    extern __PST__g__99 MGDGRPROT7_BASE;
    
    /* initialization with random value */
    {
        MGDGRPROT7_BASE = _main_gen_init_g99();
    }
}

static void _main_gen_init_sym_DmaWrRamBasAddr(void)
{
    extern __PST__g__109 DmaWrRamBasAddr;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < pst_random_g_8; _main_gen_tmp_0_0++)
            {
                /* base type */
                DmaWrRamBasAddr[_main_gen_tmp_0_0] = pst_random_g_6;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FSGD1APROT00_BASE */
    _main_gen_init_sym_FSGD1APROT00_BASE();
    
    /* init for variable FSGD1ASPID00_BASE */
    _main_gen_init_sym_FSGD1ASPID00_BASE();
    
    /* init for variable FSGD1APROT01_BASE */
    _main_gen_init_sym_FSGD1APROT01_BASE();
    
    /* init for variable FSGD1ASPID01_BASE */
    _main_gen_init_sym_FSGD1ASPID01_BASE();
    
    /* init for variable FSGD1APROT02_BASE */
    _main_gen_init_sym_FSGD1APROT02_BASE();
    
    /* init for variable FSGD1ASPID02_BASE */
    _main_gen_init_sym_FSGD1ASPID02_BASE();
    
    /* init for variable FSGD1APROT03_BASE */
    _main_gen_init_sym_FSGD1APROT03_BASE();
    
    /* init for variable FSGD1ASPID03_BASE */
    _main_gen_init_sym_FSGD1ASPID03_BASE();
    
    /* init for variable FSGD1APROT04_BASE */
    _main_gen_init_sym_FSGD1APROT04_BASE();
    
    /* init for variable FSGD1ASPID04_BASE */
    _main_gen_init_sym_FSGD1ASPID04_BASE();
    
    /* init for variable FSGD1APROT05_BASE */
    _main_gen_init_sym_FSGD1APROT05_BASE();
    
    /* init for variable FSGD1ASPID05_BASE */
    _main_gen_init_sym_FSGD1ASPID05_BASE();
    
    /* init for variable FSGD1BPROT00_BASE */
    _main_gen_init_sym_FSGD1BPROT00_BASE();
    
    /* init for variable FSGD1BSPID00_BASE */
    _main_gen_init_sym_FSGD1BSPID00_BASE();
    
    /* init for variable FSGD1BPROT01_BASE */
    _main_gen_init_sym_FSGD1BPROT01_BASE();
    
    /* init for variable FSGD1BSPID01_BASE */
    _main_gen_init_sym_FSGD1BSPID01_BASE();
    
    /* init for variable FSGD1BPROT06_BASE */
    _main_gen_init_sym_FSGD1BPROT06_BASE();
    
    /* init for variable FSGD1BSPID06_BASE */
    _main_gen_init_sym_FSGD1BSPID06_BASE();
    
    /* init for variable FSGD1BPROT07_BASE */
    _main_gen_init_sym_FSGD1BPROT07_BASE();
    
    /* init for variable FSGD1BSPID07_BASE */
    _main_gen_init_sym_FSGD1BSPID07_BASE();
    
    /* init for variable FSGD1BPROT10_BASE */
    _main_gen_init_sym_FSGD1BPROT10_BASE();
    
    /* init for variable FSGD1BSPID10_BASE */
    _main_gen_init_sym_FSGD1BSPID10_BASE();
    
    /* init for variable FSGD1BPROT11_BASE */
    _main_gen_init_sym_FSGD1BPROT11_BASE();
    
    /* init for variable FSGD1BSPID11_BASE */
    _main_gen_init_sym_FSGD1BSPID11_BASE();
    
    /* init for variable FSGD1BPROT12_BASE */
    _main_gen_init_sym_FSGD1BPROT12_BASE();
    
    /* init for variable FSGD1BSPID12_BASE */
    _main_gen_init_sym_FSGD1BSPID12_BASE();
    
    /* init for variable FSGD1BPROT13_BASE */
    _main_gen_init_sym_FSGD1BPROT13_BASE();
    
    /* init for variable FSGD1BSPID13_BASE */
    _main_gen_init_sym_FSGD1BSPID13_BASE();
    
    /* init for variable FSGD2APROT00_BASE */
    _main_gen_init_sym_FSGD2APROT00_BASE();
    
    /* init for variable FSGD2ASPID00_BASE */
    _main_gen_init_sym_FSGD2ASPID00_BASE();
    
    /* init for variable FSGD2APROT01_BASE */
    _main_gen_init_sym_FSGD2APROT01_BASE();
    
    /* init for variable FSGD2ASPID01_BASE */
    _main_gen_init_sym_FSGD2ASPID01_BASE();
    
    /* init for variable FSGD2APROT02_BASE */
    _main_gen_init_sym_FSGD2APROT02_BASE();
    
    /* init for variable FSGD2ASPID02_BASE */
    _main_gen_init_sym_FSGD2ASPID02_BASE();
    
    /* init for variable FSGD2APROT03_BASE */
    _main_gen_init_sym_FSGD2APROT03_BASE();
    
    /* init for variable FSGD2ASPID03_BASE */
    _main_gen_init_sym_FSGD2ASPID03_BASE();
    
    /* init for variable FSGD2APROT04_BASE */
    _main_gen_init_sym_FSGD2APROT04_BASE();
    
    /* init for variable FSGD2ASPID04_BASE */
    _main_gen_init_sym_FSGD2ASPID04_BASE();
    
    /* init for variable FSGD2APROT05_BASE */
    _main_gen_init_sym_FSGD2APROT05_BASE();
    
    /* init for variable FSGD2ASPID05_BASE */
    _main_gen_init_sym_FSGD2ASPID05_BASE();
    
    /* init for variable FSGD2APROT06_BASE */
    _main_gen_init_sym_FSGD2APROT06_BASE();
    
    /* init for variable FSGD2ASPID06_BASE */
    _main_gen_init_sym_FSGD2ASPID06_BASE();
    
    /* init for variable FSGD2APROT07_BASE */
    _main_gen_init_sym_FSGD2APROT07_BASE();
    
    /* init for variable FSGD2ASPID07_BASE */
    _main_gen_init_sym_FSGD2ASPID07_BASE();
    
    /* init for variable FSGD2APROT10_BASE */
    _main_gen_init_sym_FSGD2APROT10_BASE();
    
    /* init for variable FSGD2ASPID10_BASE */
    _main_gen_init_sym_FSGD2ASPID10_BASE();
    
    /* init for variable FSGD2APROT11_BASE */
    _main_gen_init_sym_FSGD2APROT11_BASE();
    
    /* init for variable FSGD2ASPID11_BASE */
    _main_gen_init_sym_FSGD2ASPID11_BASE();
    
    /* init for variable FSGD3APROT00_BASE */
    _main_gen_init_sym_FSGD3APROT00_BASE();
    
    /* init for variable FSGD3ASPID00_BASE */
    _main_gen_init_sym_FSGD3ASPID00_BASE();
    
    /* init for variable FSGD3APROT01_BASE */
    _main_gen_init_sym_FSGD3APROT01_BASE();
    
    /* init for variable FSGD3ASPID01_BASE */
    _main_gen_init_sym_FSGD3ASPID01_BASE();
    
    /* init for variable FSGD3APROT02_BASE */
    _main_gen_init_sym_FSGD3APROT02_BASE();
    
    /* init for variable FSGD3ASPID02_BASE */
    _main_gen_init_sym_FSGD3ASPID02_BASE();
    
    /* init for variable FSGD3APROT03_BASE */
    _main_gen_init_sym_FSGD3APROT03_BASE();
    
    /* init for variable FSGD3ASPID03_BASE */
    _main_gen_init_sym_FSGD3ASPID03_BASE();
    
    /* init for variable FSGD3APROT04_BASE */
    _main_gen_init_sym_FSGD3APROT04_BASE();
    
    /* init for variable FSGD3ASPID04_BASE */
    _main_gen_init_sym_FSGD3ASPID04_BASE();
    
    /* init for variable FSGD3APROT05_BASE */
    _main_gen_init_sym_FSGD3APROT05_BASE();
    
    /* init for variable FSGD3ASPID05_BASE */
    _main_gen_init_sym_FSGD3ASPID05_BASE();
    
    /* init for variable FSGD3APROT06_BASE */
    _main_gen_init_sym_FSGD3APROT06_BASE();
    
    /* init for variable FSGD3ASPID06_BASE */
    _main_gen_init_sym_FSGD3ASPID06_BASE();
    
    /* init for variable FSGD3APROT07_BASE */
    _main_gen_init_sym_FSGD3APROT07_BASE();
    
    /* init for variable FSGD3ASPID07_BASE */
    _main_gen_init_sym_FSGD3ASPID07_BASE();
    
    /* init for variable FSGD3APROT08_BASE */
    _main_gen_init_sym_FSGD3APROT08_BASE();
    
    /* init for variable FSGD3ASPID08_BASE */
    _main_gen_init_sym_FSGD3ASPID08_BASE();
    
    /* init for variable FSGD3APROT09_BASE */
    _main_gen_init_sym_FSGD3APROT09_BASE();
    
    /* init for variable FSGD3ASPID09_BASE */
    _main_gen_init_sym_FSGD3ASPID09_BASE();
    
    /* init for variable FSGD3APROT10_BASE */
    _main_gen_init_sym_FSGD3APROT10_BASE();
    
    /* init for variable FSGD3ASPID10_BASE */
    _main_gen_init_sym_FSGD3ASPID10_BASE();
    
    /* init for variable FSGD3APROT11_BASE */
    _main_gen_init_sym_FSGD3APROT11_BASE();
    
    /* init for variable FSGD3ASPID11_BASE */
    _main_gen_init_sym_FSGD3ASPID11_BASE();
    
    /* init for variable FSGD3APROT12_BASE */
    _main_gen_init_sym_FSGD3APROT12_BASE();
    
    /* init for variable FSGD3ASPID12_BASE */
    _main_gen_init_sym_FSGD3ASPID12_BASE();
    
    /* init for variable FSGD3APROT13_BASE */
    _main_gen_init_sym_FSGD3APROT13_BASE();
    
    /* init for variable FSGD3ASPID13_BASE */
    _main_gen_init_sym_FSGD3ASPID13_BASE();
    
    /* init for variable FSGD3APROT14_BASE */
    _main_gen_init_sym_FSGD3APROT14_BASE();
    
    /* init for variable FSGD3ASPID14_BASE */
    _main_gen_init_sym_FSGD3ASPID14_BASE();
    
    /* init for variable FSGD3APROT15_BASE */
    _main_gen_init_sym_FSGD3APROT15_BASE();
    
    /* init for variable FSGD3ASPID15_BASE */
    _main_gen_init_sym_FSGD3ASPID15_BASE();
    
    /* init for variable FSGD3BPROT00_BASE */
    _main_gen_init_sym_FSGD3BPROT00_BASE();
    
    /* init for variable FSGD3BSPID00_BASE */
    _main_gen_init_sym_FSGD3BSPID00_BASE();
    
    /* init for variable FSGD3BPROT01_BASE */
    _main_gen_init_sym_FSGD3BPROT01_BASE();
    
    /* init for variable FSGD3BSPID01_BASE */
    _main_gen_init_sym_FSGD3BSPID01_BASE();
    
    /* init for variable FSGD3BPROT02_BASE */
    _main_gen_init_sym_FSGD3BPROT02_BASE();
    
    /* init for variable FSGD3BSPID02_BASE */
    _main_gen_init_sym_FSGD3BSPID02_BASE();
    
    /* init for variable FSGD3BPROT03_BASE */
    _main_gen_init_sym_FSGD3BPROT03_BASE();
    
    /* init for variable FSGD3BSPID03_BASE */
    _main_gen_init_sym_FSGD3BSPID03_BASE();
    
    /* init for variable FSGD3BPROT06_BASE */
    _main_gen_init_sym_FSGD3BPROT06_BASE();
    
    /* init for variable FSGD3BSPID06_BASE */
    _main_gen_init_sym_FSGD3BSPID06_BASE();
    
    /* init for variable FSGD3BPROT07_BASE */
    _main_gen_init_sym_FSGD3BPROT07_BASE();
    
    /* init for variable FSGD3BSPID07_BASE */
    _main_gen_init_sym_FSGD3BSPID07_BASE();
    
    /* init for variable FSGD3BPROT10_BASE */
    _main_gen_init_sym_FSGD3BPROT10_BASE();
    
    /* init for variable FSGD3BSPID10_BASE */
    _main_gen_init_sym_FSGD3BSPID10_BASE();
    
    /* init for variable FSGD3BPROT11_BASE */
    _main_gen_init_sym_FSGD3BPROT11_BASE();
    
    /* init for variable FSGD3BSPID11_BASE */
    _main_gen_init_sym_FSGD3BSPID11_BASE();
    
    /* init for variable FSGD3BPROT12_BASE */
    _main_gen_init_sym_FSGD3BPROT12_BASE();
    
    /* init for variable FSGD3BSPID12_BASE */
    _main_gen_init_sym_FSGD3BSPID12_BASE();
    
    /* init for variable FSGD3BPROT13_BASE */
    _main_gen_init_sym_FSGD3BPROT13_BASE();
    
    /* init for variable FSGD3BSPID13_BASE */
    _main_gen_init_sym_FSGD3BSPID13_BASE();
    
    /* init for variable FSGD4APROT00_BASE */
    _main_gen_init_sym_FSGD4APROT00_BASE();
    
    /* init for variable FSGD4ASPID00_BASE */
    _main_gen_init_sym_FSGD4ASPID00_BASE();
    
    /* init for variable FSGD4APROT01_BASE */
    _main_gen_init_sym_FSGD4APROT01_BASE();
    
    /* init for variable FSGD4ASPID01_BASE */
    _main_gen_init_sym_FSGD4ASPID01_BASE();
    
    /* init for variable FSGD4APROT02_BASE */
    _main_gen_init_sym_FSGD4APROT02_BASE();
    
    /* init for variable FSGD4ASPID02_BASE */
    _main_gen_init_sym_FSGD4ASPID02_BASE();
    
    /* init for variable FSGD4APROT03_BASE */
    _main_gen_init_sym_FSGD4APROT03_BASE();
    
    /* init for variable FSGD4ASPID03_BASE */
    _main_gen_init_sym_FSGD4ASPID03_BASE();
    
    /* init for variable FSGD4APROT04_BASE */
    _main_gen_init_sym_FSGD4APROT04_BASE();
    
    /* init for variable FSGD4ASPID04_BASE */
    _main_gen_init_sym_FSGD4ASPID04_BASE();
    
    /* init for variable FSGD4APROT05_BASE */
    _main_gen_init_sym_FSGD4APROT05_BASE();
    
    /* init for variable FSGD4ASPID05_BASE */
    _main_gen_init_sym_FSGD4ASPID05_BASE();
    
    /* init for variable FSGD4APROT06_BASE */
    _main_gen_init_sym_FSGD4APROT06_BASE();
    
    /* init for variable FSGD4ASPID06_BASE */
    _main_gen_init_sym_FSGD4ASPID06_BASE();
    
    /* init for variable FSGD4APROT07_BASE */
    _main_gen_init_sym_FSGD4APROT07_BASE();
    
    /* init for variable FSGD4ASPID07_BASE */
    _main_gen_init_sym_FSGD4ASPID07_BASE();
    
    /* init for variable FSGD4APROT08_BASE */
    _main_gen_init_sym_FSGD4APROT08_BASE();
    
    /* init for variable FSGD4ASPID08_BASE */
    _main_gen_init_sym_FSGD4ASPID08_BASE();
    
    /* init for variable FSGD4APROT09_BASE */
    _main_gen_init_sym_FSGD4APROT09_BASE();
    
    /* init for variable FSGD4ASPID09_BASE */
    _main_gen_init_sym_FSGD4ASPID09_BASE();
    
    /* init for variable FSGD4APROT10_BASE */
    _main_gen_init_sym_FSGD4APROT10_BASE();
    
    /* init for variable FSGD4ASPID10_BASE */
    _main_gen_init_sym_FSGD4ASPID10_BASE();
    
    /* init for variable FSGD4APROT11_BASE */
    _main_gen_init_sym_FSGD4APROT11_BASE();
    
    /* init for variable FSGD4ASPID11_BASE */
    _main_gen_init_sym_FSGD4ASPID11_BASE();
    
    /* init for variable FSGD4APROT12_BASE */
    _main_gen_init_sym_FSGD4APROT12_BASE();
    
    /* init for variable FSGD4ASPID12_BASE */
    _main_gen_init_sym_FSGD4ASPID12_BASE();
    
    /* init for variable FSGD4APROT13_BASE */
    _main_gen_init_sym_FSGD4APROT13_BASE();
    
    /* init for variable FSGD4ASPID13_BASE */
    _main_gen_init_sym_FSGD4ASPID13_BASE();
    
    /* init for variable FSGD4APROT14_BASE */
    _main_gen_init_sym_FSGD4APROT14_BASE();
    
    /* init for variable FSGD4ASPID14_BASE */
    _main_gen_init_sym_FSGD4ASPID14_BASE();
    
    /* init for variable FSGD4APROT15_BASE */
    _main_gen_init_sym_FSGD4APROT15_BASE();
    
    /* init for variable FSGD4ASPID15_BASE */
    _main_gen_init_sym_FSGD4ASPID15_BASE();
    
    /* init for variable FSGD4BPROT00_BASE */
    _main_gen_init_sym_FSGD4BPROT00_BASE();
    
    /* init for variable FSGD4BSPID00_BASE */
    _main_gen_init_sym_FSGD4BSPID00_BASE();
    
    /* init for variable FSGD4BPROT01_BASE */
    _main_gen_init_sym_FSGD4BPROT01_BASE();
    
    /* init for variable FSGD4BSPID01_BASE */
    _main_gen_init_sym_FSGD4BSPID01_BASE();
    
    /* init for variable FSGD4BPROT02_BASE */
    _main_gen_init_sym_FSGD4BPROT02_BASE();
    
    /* init for variable FSGD4BSPID02_BASE */
    _main_gen_init_sym_FSGD4BSPID02_BASE();
    
    /* init for variable FSGD4BPROT03_BASE */
    _main_gen_init_sym_FSGD4BPROT03_BASE();
    
    /* init for variable FSGD4BSPID03_BASE */
    _main_gen_init_sym_FSGD4BSPID03_BASE();
    
    /* init for variable FSGD4BPROT04_BASE */
    _main_gen_init_sym_FSGD4BPROT04_BASE();
    
    /* init for variable FSGD4BSPID04_BASE */
    _main_gen_init_sym_FSGD4BSPID04_BASE();
    
    /* init for variable FSGD4BPROT05_BASE */
    _main_gen_init_sym_FSGD4BPROT05_BASE();
    
    /* init for variable FSGD4BSPID05_BASE */
    _main_gen_init_sym_FSGD4BSPID05_BASE();
    
    /* init for variable FSGD4BPROT06_BASE */
    _main_gen_init_sym_FSGD4BPROT06_BASE();
    
    /* init for variable FSGD4BSPID06_BASE */
    _main_gen_init_sym_FSGD4BSPID06_BASE();
    
    /* init for variable FSGD4BPROT07_BASE */
    _main_gen_init_sym_FSGD4BPROT07_BASE();
    
    /* init for variable FSGD4BSPID07_BASE */
    _main_gen_init_sym_FSGD4BSPID07_BASE();
    
    /* init for variable FSGD4BPROT08_BASE */
    _main_gen_init_sym_FSGD4BPROT08_BASE();
    
    /* init for variable FSGD4BSPID08_BASE */
    _main_gen_init_sym_FSGD4BSPID08_BASE();
    
    /* init for variable FSGD4BPROT09_BASE */
    _main_gen_init_sym_FSGD4BPROT09_BASE();
    
    /* init for variable FSGD4BSPID09_BASE */
    _main_gen_init_sym_FSGD4BSPID09_BASE();
    
    /* init for variable FSGD4BPROT10_BASE */
    _main_gen_init_sym_FSGD4BPROT10_BASE();
    
    /* init for variable FSGD4BSPID10_BASE */
    _main_gen_init_sym_FSGD4BSPID10_BASE();
    
    /* init for variable FSGD4BPROT11_BASE */
    _main_gen_init_sym_FSGD4BPROT11_BASE();
    
    /* init for variable FSGD4BSPID11_BASE */
    _main_gen_init_sym_FSGD4BSPID11_BASE();
    
    /* init for variable FSGD4BPROT12_BASE */
    _main_gen_init_sym_FSGD4BPROT12_BASE();
    
    /* init for variable FSGD4BSPID12_BASE */
    _main_gen_init_sym_FSGD4BSPID12_BASE();
    
    /* init for variable FSGD4BPROT13_BASE */
    _main_gen_init_sym_FSGD4BPROT13_BASE();
    
    /* init for variable FSGD4BSPID13_BASE */
    _main_gen_init_sym_FSGD4BSPID13_BASE();
    
    /* init for variable PEGG0MK_BASE */
    _main_gen_init_sym_PEGG0MK_BASE();
    
    /* init for variable PEGG0BA_BASE */
    _main_gen_init_sym_PEGG0BA_BASE();
    
    /* init for variable PEGG0SP_BASE */
    _main_gen_init_sym_PEGG0SP_BASE();
    
    /* init for variable PEGG1MK_BASE */
    _main_gen_init_sym_PEGG1MK_BASE();
    
    /* init for variable PEGG1BA_BASE */
    _main_gen_init_sym_PEGG1BA_BASE();
    
    /* init for variable PEGG1SP_BASE */
    _main_gen_init_sym_PEGG1SP_BASE();
    
    /* init for variable PEGG2MK_BASE */
    _main_gen_init_sym_PEGG2MK_BASE();
    
    /* init for variable PEGG2BA_BASE */
    _main_gen_init_sym_PEGG2BA_BASE();
    
    /* init for variable PEGG2SP_BASE */
    _main_gen_init_sym_PEGG2SP_BASE();
    
    /* init for variable PEGG3BA_BASE */
    _main_gen_init_sym_PEGG3BA_BASE();
    
    /* init for variable PEGG4BA_BASE */
    _main_gen_init_sym_PEGG4BA_BASE();
    
    /* init for variable PEGG5BA_BASE */
    _main_gen_init_sym_PEGG5BA_BASE();
    
    /* init for variable PEGG6BA_BASE */
    _main_gen_init_sym_PEGG6BA_BASE();
    
    /* init for variable PEGG7BA_BASE */
    _main_gen_init_sym_PEGG7BA_BASE();
    
    /* init for variable APBFSGDPROT_PBG_A_BASE */
    _main_gen_init_sym_APBFSGDPROT_PBG_A_BASE();
    
    /* init for variable APBFSGDSPID_PBG_A_BASE */
    _main_gen_init_sym_APBFSGDSPID_PBG_A_BASE();
    
    /* init for variable APBFSGDPROT_PBG_B_BASE */
    _main_gen_init_sym_APBFSGDPROT_PBG_B_BASE();
    
    /* init for variable APBFSGDSPID_PBG_B_BASE */
    _main_gen_init_sym_APBFSGDSPID_PBG_B_BASE();
    
    /* init for variable APBFSGDPROT_SP1_A_BASE */
    _main_gen_init_sym_APBFSGDPROT_SP1_A_BASE();
    
    /* init for variable APBFSGDSPID_SP1_A_BASE */
    _main_gen_init_sym_APBFSGDSPID_SP1_A_BASE();
    
    /* init for variable APBFSGDPROT_SP1_B_BASE */
    _main_gen_init_sym_APBFSGDPROT_SP1_B_BASE();
    
    /* init for variable APBFSGDSPID_SP1_B_BASE */
    _main_gen_init_sym_APBFSGDSPID_SP1_B_BASE();
    
    /* init for variable APBFSGDPROT_SP4_A_BASE */
    _main_gen_init_sym_APBFSGDPROT_SP4_A_BASE();
    
    /* init for variable APBFSGDSPID_SP4_A_BASE */
    _main_gen_init_sym_APBFSGDSPID_SP4_A_BASE();
    
    /* init for variable APBFSGDPROT_SP4_B_BASE */
    _main_gen_init_sym_APBFSGDPROT_SP4_B_BASE();
    
    /* init for variable APBFSGDSPID_SP4_B_BASE */
    _main_gen_init_sym_APBFSGDSPID_SP4_B_BASE();
    
    /* init for variable APBFSGDPROT_PDMACM_A_BASE */
    _main_gen_init_sym_APBFSGDPROT_PDMACM_A_BASE();
    
    /* init for variable APBFSGDSPID_PDMACM_A_BASE */
    _main_gen_init_sym_APBFSGDSPID_PDMACM_A_BASE();
    
    /* init for variable APBFSGDPROT_PDMACM_B_BASE */
    _main_gen_init_sym_APBFSGDPROT_PDMACM_B_BASE();
    
    /* init for variable APBFSGDSPID_PDMACM_B_BASE */
    _main_gen_init_sym_APBFSGDSPID_PDMACM_B_BASE();
    
    /* init for variable APBFSGDPROT_PDMACH_A_BASE */
    _main_gen_init_sym_APBFSGDPROT_PDMACH_A_BASE();
    
    /* init for variable APBFSGDSPID_PDMACH_A_BASE */
    _main_gen_init_sym_APBFSGDSPID_PDMACH_A_BASE();
    
    /* init for variable APBFSGDPROT_PDMACH_B_BASE */
    _main_gen_init_sym_APBFSGDPROT_PDMACH_B_BASE();
    
    /* init for variable APBFSGDSPID_PDMACH_B_BASE */
    _main_gen_init_sym_APBFSGDSPID_PDMACH_B_BASE();
    
    /* init for variable APBFSGDPROT_INTC2_A_BASE */
    _main_gen_init_sym_APBFSGDPROT_INTC2_A_BASE();
    
    /* init for variable APBFSGDSPID_INTC2_A_BASE */
    _main_gen_init_sym_APBFSGDSPID_INTC2_A_BASE();
    
    /* init for variable APBFSGDPROT_INTC2_B_BASE */
    _main_gen_init_sym_APBFSGDPROT_INTC2_B_BASE();
    
    /* init for variable APBFSGDSPID_INTC2_B_BASE */
    _main_gen_init_sym_APBFSGDSPID_INTC2_B_BASE();
    
    /* init for variable IPGENUM_BASE */
    _main_gen_init_sym_IPGENUM_BASE();
    
    /* init for variable IPGPMTUM0_BASE */
    _main_gen_init_sym_IPGPMTUM0_BASE();
    
    /* init for variable IPGPMTUM1_BASE */
    _main_gen_init_sym_IPGPMTUM1_BASE();
    
    /* init for variable IPGPMTUM2_BASE */
    _main_gen_init_sym_IPGPMTUM2_BASE();
    
    /* init for variable IPGPMTUM3_BASE */
    _main_gen_init_sym_IPGPMTUM3_BASE();
    
    /* init for variable IPGPMTUM4_BASE */
    _main_gen_init_sym_IPGPMTUM4_BASE();
    
    /* init for variable FSGDF0PROT00_BASE */
    _main_gen_init_sym_FSGDF0PROT00_BASE();
    
    /* init for variable FSGDF0SPID00_BASE */
    _main_gen_init_sym_FSGDF0SPID00_BASE();
    
    /* init for variable FSGDF0PROT01_BASE */
    _main_gen_init_sym_FSGDF0PROT01_BASE();
    
    /* init for variable FSGDF0SPID01_BASE */
    _main_gen_init_sym_FSGDF0SPID01_BASE();
    
    /* init for variable FSGDE0PROT00_BASE */
    _main_gen_init_sym_FSGDE0PROT00_BASE();
    
    /* init for variable FSGDE0SPID00_BASE */
    _main_gen_init_sym_FSGDE0SPID00_BASE();
    
    /* init for variable MGDGRPROT0_BASE */
    _main_gen_init_sym_MGDGRPROT0_BASE();
    
    /* init for variable MGDGRSPID0_BASE */
    _main_gen_init_sym_MGDGRSPID0_BASE();
    
    /* init for variable MGDGRBAD0_BASE */
    _main_gen_init_sym_MGDGRBAD0_BASE();
    
    /* init for variable MGDGRADV0_BASE */
    _main_gen_init_sym_MGDGRADV0_BASE();
    
    /* init for variable MGDGRPROT1_BASE */
    _main_gen_init_sym_MGDGRPROT1_BASE();
    
    /* init for variable MGDGRPROT2_BASE */
    _main_gen_init_sym_MGDGRPROT2_BASE();
    
    /* init for variable MGDGRPROT3_BASE */
    _main_gen_init_sym_MGDGRPROT3_BASE();
    
    /* init for variable MGDGRPROT4_BASE */
    _main_gen_init_sym_MGDGRPROT4_BASE();
    
    /* init for variable MGDGRPROT5_BASE */
    _main_gen_init_sym_MGDGRPROT5_BASE();
    
    /* init for variable MGDGRPROT6_BASE */
    _main_gen_init_sym_MGDGRPROT6_BASE();
    
    /* init for variable MGDGRPROT7_BASE */
    _main_gen_init_sym_MGDGRPROT7_BASE();
    
    /* init for variable DmaWrRamBasAddr */
    _main_gen_init_sym_DmaWrRamBasAddr();
    
}
