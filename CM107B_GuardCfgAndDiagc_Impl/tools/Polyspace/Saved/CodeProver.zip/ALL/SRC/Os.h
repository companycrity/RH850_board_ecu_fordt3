/* for contract folder of CM107B_MemProtn */

#ifndef OS_H
#define OS_H

void Call_IpgInin(void);

#endif
