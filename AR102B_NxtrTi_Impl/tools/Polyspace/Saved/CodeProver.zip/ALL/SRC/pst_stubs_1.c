#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__g__70 _main_gen_init_g70(void);

extern __PST__g__67 _main_gen_init_g67(void);

extern __PST__g__64 _main_gen_init_g64(void);

extern __PST__g__60 _main_gen_init_g60(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct Rte_CDS_CDD_NxtrTi _main_gen_init_g57(void);

struct Rte_CDS_CDD_NxtrTi _main_gen_init_g57(void)
{
    static struct Rte_CDS_CDD_NxtrTi x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_13[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_14;
        for (_i_main_gen_tmp_14 = 0; _i_main_gen_tmp_14 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_14++)
        {
            _main_gen_tmp_13[_i_main_gen_tmp_14] = _main_gen_init_g8();
        }
        x.Pim_PrevTi = PST_TRUE() ? 0 : &_main_gen_tmp_13[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    return x;
}

__PST__g__60 _main_gen_init_g60(void)
{
    __PST__g__60 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__64 _main_gen_init_g64(void)
{
    __PST__g__64 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__67 _main_gen_init_g67(void)
{
    __PST__g__67 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__70 _main_gen_init_g70(void)
{
    __PST__g__70 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_NxtrTi(void)
{
    extern __PST__g__54 Rte_Inst_CDD_NxtrTi;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_NxtrTi _main_gen_tmp_11[ARRAY_NBELEM(struct Rte_CDS_CDD_NxtrTi)];
            __PST__UINT32 _i_main_gen_tmp_12;
            for (_i_main_gen_tmp_12 = 0; _i_main_gen_tmp_12 < ARRAY_NBELEM(struct Rte_CDS_CDD_NxtrTi); _i_main_gen_tmp_12++)
            {
                _main_gen_tmp_11[_i_main_gen_tmp_12] = _main_gen_init_g57();
            }
            Rte_Inst_CDD_NxtrTi = PST_TRUE() ? 0 : &_main_gen_tmp_11[ARRAY_NBELEM(struct Rte_CDS_CDD_NxtrTi) / 2];
        }
    }
}

static void _main_gen_init_sym_NXTRMATH_SINCNVNCONTBL_ULS_U16(void)
{
    extern __PST__g__58 NXTRMATH_SINCNVNCONTBL_ULS_U16;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 513; _main_gen_tmp_15_0++)
            {
                /* base type */
                NXTRMATH_SINCNVNCONTBL_ULS_U16[_main_gen_tmp_15_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_STM0TS_BASE(void)
{
    extern __PST__g__60 STM0TS_BASE;
    
    /* initialization with random value */
    {
        STM0TS_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_STM0TT_BASE(void)
{
    extern __PST__g__64 STM0TT_BASE;
    
    /* initialization with random value */
    {
        STM0TT_BASE = _main_gen_init_g64();
    }
}

static void _main_gen_init_sym_STM0CNT0L_BASE(void)
{
    extern __PST__g__67 STM0CNT0L_BASE;
    
    /* initialization with random value */
    {
        STM0CNT0L_BASE = _main_gen_init_g67();
    }
}

static void _main_gen_init_sym_STM0CNT0H_BASE(void)
{
    extern __PST__g__70 STM0CNT0H_BASE;
    
    /* initialization with random value */
    {
        STM0CNT0H_BASE = _main_gen_init_g70();
    }
}

static void _main_gen_init_sym_NxtrTi_Srv_ReadErrInjReg_ErrId(void)
{
    extern __PST__UINT32 NxtrTi_Srv_ReadErrInjReg_ErrId;
    
    /* initialization with random value */
    {
        NxtrTi_Srv_ReadErrInjReg_ErrId = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 NxtrTi_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        NxtrTi_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetRefTmr1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetRefTmr1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetRefTmr1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetTiSpan100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetTiSpan100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetTiSpan100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetTiSpan1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetTiSpan1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetTiSpan1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrTi_Cli_GetTiSpan1MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 NxtrTi_Cli_GetTiSpan1MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        NxtrTi_Cli_GetTiSpan1MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_NxtrTi */
    _main_gen_init_sym_Rte_Inst_CDD_NxtrTi();
    
    /* init for variable NXTRMATH_SINCNVNCONTBL_ULS_U16 */
    _main_gen_init_sym_NXTRMATH_SINCNVNCONTBL_ULS_U16();
    
    /* init for variable STM0TS_BASE */
    _main_gen_init_sym_STM0TS_BASE();
    
    /* init for variable STM0TT_BASE */
    _main_gen_init_sym_STM0TT_BASE();
    
    /* init for variable STM0CNT0L_BASE */
    _main_gen_init_sym_STM0CNT0L_BASE();
    
    /* init for variable STM0CNT0H_BASE */
    _main_gen_init_sym_STM0CNT0H_BASE();
    
    /* init for variable NxtrTi_Srv_ReadErrInjReg_ErrId */
    _main_gen_init_sym_NxtrTi_Srv_ReadErrInjReg_ErrId();
    
    /* init for variable NxtrTi_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable NxtrTi_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable NxtrTi_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable NxtrTi_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable NxtrTi_Srv_SetNtcSts_Return */
    _main_gen_init_sym_NxtrTi_Srv_SetNtcSts_Return();
    
    /* init for variable NxtrTi_Cli_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_NxtrTi_Cli_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable NxtrTi_Cli_GetRefTmr1MicroSec32bit_RefTmr */
    _main_gen_init_sym_NxtrTi_Cli_GetRefTmr1MicroSec32bit_RefTmr();
    
    /* init for variable NxtrTi_Cli_GetTiSpan100MicroSec32bit_RefTmr */
    _main_gen_init_sym_NxtrTi_Cli_GetTiSpan100MicroSec32bit_RefTmr();
    
    /* init for variable NxtrTi_Cli_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_NxtrTi_Cli_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable NxtrTi_Cli_GetTiSpan1MicroSec32bit_RefTmr */
    _main_gen_init_sym_NxtrTi_Cli_GetTiSpan1MicroSec32bit_RefTmr();
    
    /* init for variable NxtrTi_Cli_GetTiSpan1MicroSec32bit_TiSpan */
    _main_gen_init_sym_NxtrTi_Cli_GetTiSpan1MicroSec32bit_TiSpan();
    
}
