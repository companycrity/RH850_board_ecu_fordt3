#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_Blnd_f32(void)
{
    extern __PST__FLOAT32 Blnd_f32(__PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    __PST__FLOAT32 __arg__2;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    __arg__2 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Blnd_f32(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Abslt_u08_s08(void)
{
    extern __PST__UINT8 Abslt_u08_s08(__PST__SINT8);

    __PST__UINT8 __ret__;
    __PST__SINT8 __arg__0;
    
    __arg__0 = _main_gen_init_g2();
    
    /* call it */
    __ret__ = Abslt_u08_s08(__arg__0);
}

static void _main_gen_call_Abslt_u16_s16(void)
{
    extern __PST__UINT16 Abslt_u16_s16(__PST__SINT16);

    __PST__UINT16 __ret__;
    __PST__SINT16 __arg__0;
    
    __arg__0 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = Abslt_u16_s16(__arg__0);
}

static void _main_gen_call_Abslt_f32_f32(void)
{
    extern __PST__FLOAT32 Abslt_f32_f32(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Abslt_f32_f32(__arg__0);
}

static void _main_gen_call_Sign_s08_s08(void)
{
    extern __PST__SINT8 Sign_s08_s08(__PST__SINT8);

    __PST__SINT8 __ret__;
    __PST__SINT8 __arg__0;
    
    __arg__0 = _main_gen_init_g2();
    
    /* call it */
    __ret__ = Sign_s08_s08(__arg__0);
}

static void _main_gen_call_Sign_s08_s16(void)
{
    extern __PST__SINT8 Sign_s08_s16(__PST__SINT16);

    __PST__SINT8 __ret__;
    __PST__SINT16 __arg__0;
    
    __arg__0 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = Sign_s08_s16(__arg__0);
}

static void _main_gen_call_Sign_s08_s32(void)
{
    extern __PST__SINT8 Sign_s08_s32(__PST__SINT32);

    __PST__SINT8 __ret__;
    __PST__SINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g4();
    
    /* call it */
    __ret__ = Sign_s08_s32(__arg__0);
}

static void _main_gen_call_Sign_s08_f32(void)
{
    extern __PST__SINT8 Sign_s08_f32(__PST__FLOAT32);

    __PST__SINT8 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Sign_s08_f32(__arg__0);
}

static void _main_gen_call_Min_s08(void)
{
    extern __PST__SINT8 Min_s08(__PST__SINT8, __PST__SINT8);

    __PST__SINT8 __ret__;
    __PST__SINT8 __arg__0;
    __PST__SINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g2();
    __arg__1 = _main_gen_init_g2();
    
    /* call it */
    __ret__ = Min_s08(__arg__0, __arg__1);
}

static void _main_gen_call_Min_u08(void)
{
    extern __PST__UINT8 Min_u08(__PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = Min_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Min_s16(void)
{
    extern __PST__SINT16 Min_s16(__PST__SINT16, __PST__SINT16);

    __PST__SINT16 __ret__;
    __PST__SINT16 __arg__0;
    __PST__SINT16 __arg__1;
    
    __arg__0 = _main_gen_init_g3();
    __arg__1 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = Min_s16(__arg__0, __arg__1);
}

static void _main_gen_call_Min_u16(void)
{
    extern __PST__UINT16 Min_u16(__PST__UINT16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT16 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = Min_u16(__arg__0, __arg__1);
}

static void _main_gen_call_Min_s32(void)
{
    extern __PST__SINT32 Min_s32(__PST__SINT32, __PST__SINT32);

    __PST__SINT32 __ret__;
    __PST__SINT32 __arg__0;
    __PST__SINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g4();
    __arg__1 = _main_gen_init_g4();
    
    /* call it */
    __ret__ = Min_s32(__arg__0, __arg__1);
}

static void _main_gen_call_Min_u32(void)
{
    extern __PST__UINT32 Min_u32(__PST__UINT32, __PST__UINT32);

    __PST__UINT32 __ret__;
    __PST__UINT32 __arg__0;
    __PST__UINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    __arg__1 = _main_gen_init_g8();
    
    /* call it */
    __ret__ = Min_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Min_f32(void)
{
    extern __PST__FLOAT32 Min_f32(__PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Min_f32(__arg__0, __arg__1);
}

static void _main_gen_call_Max_s08(void)
{
    extern __PST__SINT8 Max_s08(__PST__SINT8, __PST__SINT8);

    __PST__SINT8 __ret__;
    __PST__SINT8 __arg__0;
    __PST__SINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g2();
    __arg__1 = _main_gen_init_g2();
    
    /* call it */
    __ret__ = Max_s08(__arg__0, __arg__1);
}

static void _main_gen_call_Max_u08(void)
{
    extern __PST__UINT8 Max_u08(__PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = Max_u08(__arg__0, __arg__1);
}

static void _main_gen_call_Max_s16(void)
{
    extern __PST__SINT16 Max_s16(__PST__SINT16, __PST__SINT16);

    __PST__SINT16 __ret__;
    __PST__SINT16 __arg__0;
    __PST__SINT16 __arg__1;
    
    __arg__0 = _main_gen_init_g3();
    __arg__1 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = Max_s16(__arg__0, __arg__1);
}

static void _main_gen_call_Max_u16(void)
{
    extern __PST__UINT16 Max_u16(__PST__UINT16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT16 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = Max_u16(__arg__0, __arg__1);
}

static void _main_gen_call_Max_s32(void)
{
    extern __PST__SINT32 Max_s32(__PST__SINT32, __PST__SINT32);

    __PST__SINT32 __ret__;
    __PST__SINT32 __arg__0;
    __PST__SINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g4();
    __arg__1 = _main_gen_init_g4();
    
    /* call it */
    __ret__ = Max_s32(__arg__0, __arg__1);
}

static void _main_gen_call_Max_u32(void)
{
    extern __PST__UINT32 Max_u32(__PST__UINT32, __PST__UINT32);

    __PST__UINT32 __ret__;
    __PST__UINT32 __arg__0;
    __PST__UINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    __arg__1 = _main_gen_init_g8();
    
    /* call it */
    __ret__ = Max_u32(__arg__0, __arg__1);
}

static void _main_gen_call_Max_f32(void)
{
    extern __PST__FLOAT32 Max_f32(__PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Max_f32(__arg__0, __arg__1);
}

static void _main_gen_call_Lim_s08(void)
{
    extern __PST__SINT8 Lim_s08(__PST__SINT8, __PST__SINT8, __PST__SINT8);

    __PST__SINT8 __ret__;
    __PST__SINT8 __arg__0;
    __PST__SINT8 __arg__1;
    __PST__SINT8 __arg__2;
    
    __arg__0 = _main_gen_init_g2();
    __arg__1 = _main_gen_init_g2();
    __arg__2 = _main_gen_init_g2();
    
    /* call it */
    __ret__ = Lim_s08(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Lim_u08(void)
{
    extern __PST__UINT8 Lim_u08(__PST__UINT8, __PST__UINT8, __PST__UINT8);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    
    /* call it */
    __ret__ = Lim_u08(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Lim_s16(void)
{
    extern __PST__SINT16 Lim_s16(__PST__SINT16, __PST__SINT16, __PST__SINT16);

    __PST__SINT16 __ret__;
    __PST__SINT16 __arg__0;
    __PST__SINT16 __arg__1;
    __PST__SINT16 __arg__2;
    
    __arg__0 = _main_gen_init_g3();
    __arg__1 = _main_gen_init_g3();
    __arg__2 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = Lim_s16(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Lim_u16(void)
{
    extern __PST__UINT16 Lim_u16(__PST__UINT16, __PST__UINT16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT16 __arg__1;
    __PST__UINT16 __arg__2;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g7();
    __arg__2 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = Lim_u16(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Lim_s32(void)
{
    extern __PST__SINT32 Lim_s32(__PST__SINT32, __PST__SINT32, __PST__SINT32);

    __PST__SINT32 __ret__;
    __PST__SINT32 __arg__0;
    __PST__SINT32 __arg__1;
    __PST__SINT32 __arg__2;
    
    __arg__0 = _main_gen_init_g4();
    __arg__1 = _main_gen_init_g4();
    __arg__2 = _main_gen_init_g4();
    
    /* call it */
    __ret__ = Lim_s32(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Lim_u32(void)
{
    extern __PST__UINT32 Lim_u32(__PST__UINT32, __PST__UINT32, __PST__UINT32);

    __PST__UINT32 __ret__;
    __PST__UINT32 __arg__0;
    __PST__UINT32 __arg__1;
    __PST__UINT32 __arg__2;
    
    __arg__0 = _main_gen_init_g8();
    __arg__1 = _main_gen_init_g8();
    __arg__2 = _main_gen_init_g8();
    
    /* call it */
    __ret__ = Lim_u32(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Lim_f32(void)
{
    extern __PST__FLOAT32 Lim_f32(__PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    __PST__FLOAT32 __arg__2;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    __arg__2 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Lim_f32(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_Arctan2_f32(void)
{
    extern __PST__FLOAT32 Arctan2_f32(__PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Arctan2_f32(__arg__0, __arg__1);
}

static void _main_gen_call_Sin_f32(void)
{
    extern __PST__FLOAT32 Sin_f32(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Sin_f32(__arg__0);
}

static void _main_gen_call_Cos_f32(void)
{
    extern __PST__FLOAT32 Cos_f32(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Cos_f32(__arg__0);
}

static void _main_gen_call_Exp_f32(void)
{
    extern __PST__FLOAT32 Exp_f32(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Exp_f32(__arg__0);
}

static void _main_gen_call_Sqrt_f32(void)
{
    extern __PST__FLOAT32 Sqrt_f32(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Sqrt_f32(__arg__0);
}

static void _main_gen_call_Mod_f32(void)
{
    extern __PST__FLOAT32 Mod_f32(__PST__FLOAT32, __PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = Mod_f32(__arg__0, __arg__1);
}

static void _main_gen_call_SinCos_f32(void)
{
    extern __PST__VOID SinCos_f32(__PST__FLOAT32, __PST__g__38, __PST__g__38);

    __PST__FLOAT32 __arg__0;
    __PST__g__38 __arg__1;
    __PST__g__38 __arg__2;
    
    __arg__0 = _main_gen_init_g10();
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_7[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_8;
        for (_i_main_gen_tmp_8 = 0; _i_main_gen_tmp_8 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_8++)
        {
            _main_gen_tmp_7[_i_main_gen_tmp_8] = _main_gen_init_g10();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_7[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_9[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_10;
        for (_i_main_gen_tmp_10 = 0; _i_main_gen_tmp_10 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_10++)
        {
            _main_gen_tmp_9[_i_main_gen_tmp_10] = _main_gen_init_g10();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_9[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    
    /* call it */
    SinCos_f32(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_SinLookup(void)
{
    extern __PST__FLOAT32 SinLookup(__PST__FLOAT32);

    __PST__FLOAT32 __ret__;
    __PST__FLOAT32 __arg__0;
    
    __arg__0 = _main_gen_init_g10();
    
    /* call it */
    __ret__ = SinLookup(__arg__0);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function Blnd_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Blnd_f32();
        }
        
        /* call of function Abslt_u08_s08 */
        if (PST_TRUE())
        {
            _main_gen_call_Abslt_u08_s08();
        }
        
        /* call of function Abslt_u16_s16 */
        if (PST_TRUE())
        {
            _main_gen_call_Abslt_u16_s16();
        }
        
        /* call of function Abslt_f32_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Abslt_f32_f32();
        }
        
        /* call of function Sign_s08_s08 */
        if (PST_TRUE())
        {
            _main_gen_call_Sign_s08_s08();
        }
        
        /* call of function Sign_s08_s16 */
        if (PST_TRUE())
        {
            _main_gen_call_Sign_s08_s16();
        }
        
        /* call of function Sign_s08_s32 */
        if (PST_TRUE())
        {
            _main_gen_call_Sign_s08_s32();
        }
        
        /* call of function Sign_s08_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Sign_s08_f32();
        }
        
        /* call of function Min_s08 */
        if (PST_TRUE())
        {
            _main_gen_call_Min_s08();
        }
        
        /* call of function Min_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Min_u08();
        }
        
        /* call of function Min_s16 */
        if (PST_TRUE())
        {
            _main_gen_call_Min_s16();
        }
        
        /* call of function Min_u16 */
        if (PST_TRUE())
        {
            _main_gen_call_Min_u16();
        }
        
        /* call of function Min_s32 */
        if (PST_TRUE())
        {
            _main_gen_call_Min_s32();
        }
        
        /* call of function Min_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Min_u32();
        }
        
        /* call of function Min_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Min_f32();
        }
        
        /* call of function Max_s08 */
        if (PST_TRUE())
        {
            _main_gen_call_Max_s08();
        }
        
        /* call of function Max_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Max_u08();
        }
        
        /* call of function Max_s16 */
        if (PST_TRUE())
        {
            _main_gen_call_Max_s16();
        }
        
        /* call of function Max_u16 */
        if (PST_TRUE())
        {
            _main_gen_call_Max_u16();
        }
        
        /* call of function Max_s32 */
        if (PST_TRUE())
        {
            _main_gen_call_Max_s32();
        }
        
        /* call of function Max_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Max_u32();
        }
        
        /* call of function Max_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Max_f32();
        }
        
        /* call of function Lim_s08 */
        if (PST_TRUE())
        {
            _main_gen_call_Lim_s08();
        }
        
        /* call of function Lim_u08 */
        if (PST_TRUE())
        {
            _main_gen_call_Lim_u08();
        }
        
        /* call of function Lim_s16 */
        if (PST_TRUE())
        {
            _main_gen_call_Lim_s16();
        }
        
        /* call of function Lim_u16 */
        if (PST_TRUE())
        {
            _main_gen_call_Lim_u16();
        }
        
        /* call of function Lim_s32 */
        if (PST_TRUE())
        {
            _main_gen_call_Lim_s32();
        }
        
        /* call of function Lim_u32 */
        if (PST_TRUE())
        {
            _main_gen_call_Lim_u32();
        }
        
        /* call of function Lim_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Lim_f32();
        }
        
        /* call of function Arctan2_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Arctan2_f32();
        }
        
        /* call of function Sin_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Sin_f32();
        }
        
        /* call of function Cos_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Cos_f32();
        }
        
        /* call of function Exp_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Exp_f32();
        }
        
        /* call of function Sqrt_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Sqrt_f32();
        }
        
        /* call of function Mod_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_Mod_f32();
        }
        
        /* call of function SinCos_f32 */
        if (PST_TRUE())
        {
            _main_gen_call_SinCos_f32();
        }
        
        /* call of function SinLookup */
        if (PST_TRUE())
        {
            _main_gen_call_SinLookup();
        }
        
        /* call of function Rte_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_Stub(__PST__VOID);

            Rte_Stub();
        }
        
    }
}
