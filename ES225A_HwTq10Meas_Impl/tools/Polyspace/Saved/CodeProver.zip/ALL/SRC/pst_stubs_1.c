#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__36 _main_gen_init_g36(void);

extern __PST__SINT8 _main_gen_init_g2(void);

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__36 _main_gen_init_g36(void)
{
    static struct __PST__g__36 x;
    /* struct/union type */
    x.OffsTrim = _main_gen_init_g10();
    x.OffsTrimPrfmdSts = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_HwTq10Meas_Ip_HwTq10Polarity(void)
{
    extern __PST__SINT8 HwTq10Meas_Ip_HwTq10Polarity;
    
    /* initialization with random value */
    {
        HwTq10Meas_Ip_HwTq10Polarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Pim_HwTq10Offs(void)
{
    extern struct __PST__g__36 HwTq10Meas_Pim_HwTq10Offs;
    
    /* initialization with random value */
    {
        HwTq10Meas_Pim_HwTq10Offs = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Pim_HwTq10PrevHwTq(void)
{
    extern __PST__FLOAT32 HwTq10Meas_Pim_HwTq10PrevHwTq;
    
    /* initialization with random value */
    {
        HwTq10Meas_Pim_HwTq10PrevHwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Pim_HwTq10RawDataBuf(void)
{
    extern __PST__g__38 HwTq10Meas_Pim_HwTq10RawDataBuf;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 5; _main_gen_tmp_0_0++)
            {
                /* base type */
                HwTq10Meas_Pim_HwTq10RawDataBuf[_main_gen_tmp_0_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_HwTq10Meas_Pim_HwTq10RollgCntrPrev(void)
{
    extern __PST__UINT8 HwTq10Meas_Pim_HwTq10RollgCntrPrev;
    
    /* initialization with random value */
    {
        HwTq10Meas_Pim_HwTq10RollgCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Pim_HwTq10TiStamp(void)
{
    extern __PST__UINT32 HwTq10Meas_Pim_HwTq10TiStamp;
    
    /* initialization with random value */
    {
        HwTq10Meas_Pim_HwTq10TiStamp = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Pim_HwTq10TiStampPrev(void)
{
    extern __PST__UINT32 HwTq10Meas_Pim_HwTq10TiStampPrev;
    
    /* initialization with random value */
    {
        HwTq10Meas_Pim_HwTq10TiStampPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 HwTq10Meas_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        HwTq10Meas_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 HwTq10Meas_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        HwTq10Meas_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Srv_GtmGetSent1Data_BufStrt(void)
{
    extern __PST__g__40 HwTq10Meas_Srv_GtmGetSent1Data_BufStrt;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 32; _main_gen_tmp_1_0++)
            {
                /* base type */
                HwTq10Meas_Srv_GtmGetSent1Data_BufStrt[_main_gen_tmp_1_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_HwTq10Meas_Srv_GtmGetSent1Data_Return(void)
{
    extern __PST__UINT8 HwTq10Meas_Srv_GtmGetSent1Data_Return;
    
    /* initialization with random value */
    {
        HwTq10Meas_Srv_GtmGetSent1Data_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Srv_HwTq10Offs_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 HwTq10Meas_Srv_HwTq10Offs_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        HwTq10Meas_Srv_HwTq10Offs_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Srv_HwTq10Offs_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 HwTq10Meas_Srv_HwTq10Offs_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        HwTq10Meas_Srv_HwTq10Offs_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Srv_HwTq10Offs_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 HwTq10Meas_Srv_HwTq10Offs_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        HwTq10Meas_Srv_HwTq10Offs_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 HwTq10Meas_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        HwTq10Meas_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Srv_SetNtcStsAndSnpshtData_Return(void)
{
    extern __PST__UINT8 HwTq10Meas_Srv_SetNtcStsAndSnpshtData_Return;
    
    /* initialization with random value */
    {
        HwTq10Meas_Srv_SetNtcStsAndSnpshtData_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Cli_HwTq10MeasHwTq10ReadTrim_HwTqReadTrimData(void)
{
    extern __PST__FLOAT32 HwTq10Meas_Cli_HwTq10MeasHwTq10ReadTrim_HwTqReadTrimData;
    
    /* initialization with random value */
    {
        HwTq10Meas_Cli_HwTq10MeasHwTq10ReadTrim_HwTqReadTrimData = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Cli_HwTq10MeasHwTq10TrimPrfmdSts_HwTqOffsTrimPrfmdStsData(void)
{
    extern __PST__UINT8 HwTq10Meas_Cli_HwTq10MeasHwTq10TrimPrfmdSts_HwTqOffsTrimPrfmdStsData;
    
    /* initialization with random value */
    {
        HwTq10Meas_Cli_HwTq10MeasHwTq10TrimPrfmdSts_HwTqOffsTrimPrfmdStsData = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq10Meas_Cli_HwTq10MeasHwTq10WrTrim_HwTqWrOffsTrimData(void)
{
    extern __PST__FLOAT32 HwTq10Meas_Cli_HwTq10MeasHwTq10WrTrim_HwTqWrOffsTrimData;
    
    /* initialization with random value */
    {
        HwTq10Meas_Cli_HwTq10MeasHwTq10WrTrim_HwTqWrOffsTrimData = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable HwTq10Meas_Ip_HwTq10Polarity */
    _main_gen_init_sym_HwTq10Meas_Ip_HwTq10Polarity();
    
    /* init for variable HwTq10Meas_Op_HwTq10 : useless (never read) */

    /* init for variable HwTq10Meas_Op_HwTq10Qlfr : useless (never read) */

    /* init for variable HwTq10Meas_Op_HwTq10RollgCntr : useless (never read) */

    /* init for variable HwTq10Meas_Pim_HwTq10Offs */
    _main_gen_init_sym_HwTq10Meas_Pim_HwTq10Offs();
    
    /* init for variable HwTq10Meas_Pim_HwTq10PrevHwTq */
    _main_gen_init_sym_HwTq10Meas_Pim_HwTq10PrevHwTq();
    
    /* init for variable HwTq10Meas_Pim_HwTq10RawDataBuf */
    _main_gen_init_sym_HwTq10Meas_Pim_HwTq10RawDataBuf();
    
    /* init for variable HwTq10Meas_Pim_HwTq10RollgCntrPrev */
    _main_gen_init_sym_HwTq10Meas_Pim_HwTq10RollgCntrPrev();
    
    /* init for variable HwTq10Meas_Pim_HwTq10TiStamp */
    _main_gen_init_sym_HwTq10Meas_Pim_HwTq10TiStamp();
    
    /* init for variable HwTq10Meas_Pim_HwTq10TiStampPrev */
    _main_gen_init_sym_HwTq10Meas_Pim_HwTq10TiStampPrev();
    
    /* init for variable HwTq10Meas_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable HwTq10Meas_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_HwTq10Meas_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable HwTq10Meas_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_HwTq10Meas_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable HwTq10Meas_Srv_GtmGetSent1Data_BufStrt */
    _main_gen_init_sym_HwTq10Meas_Srv_GtmGetSent1Data_BufStrt();
    
    /* init for variable HwTq10Meas_Srv_GtmGetSent1Data_Return */
    _main_gen_init_sym_HwTq10Meas_Srv_GtmGetSent1Data_Return();
    
    /* init for variable HwTq10Meas_Srv_HwTq10Offs_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_HwTq10Meas_Srv_HwTq10Offs_GetErrorStatus_RequestResultPtr();
    
    /* init for variable HwTq10Meas_Srv_HwTq10Offs_GetErrorStatus_Return */
    _main_gen_init_sym_HwTq10Meas_Srv_HwTq10Offs_GetErrorStatus_Return();
    
    /* init for variable HwTq10Meas_Srv_HwTq10Offs_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable HwTq10Meas_Srv_HwTq10Offs_SetRamBlockStatus_Return */
    _main_gen_init_sym_HwTq10Meas_Srv_HwTq10Offs_SetRamBlockStatus_Return();
    
    /* init for variable HwTq10Meas_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcSts_Return */
    _main_gen_init_sym_HwTq10Meas_Srv_SetNtcSts_Return();
    
    /* init for variable HwTq10Meas_Srv_SetNtcStsAndSnpshtData_NtcNr : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcStsAndSnpshtData_NtcStInfo : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcStsAndSnpshtData_NtcSts : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcStsAndSnpshtData_DebStep : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData0 : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData1 : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData2 : useless (never read) */

    /* init for variable HwTq10Meas_Srv_SetNtcStsAndSnpshtData_Return */
    _main_gen_init_sym_HwTq10Meas_Srv_SetNtcStsAndSnpshtData_Return();
    
    /* init for variable HwTq10Meas_Cli_HwTq10MeasHwTq10ReadTrim_HwTqReadTrimData */
    _main_gen_init_sym_HwTq10Meas_Cli_HwTq10MeasHwTq10ReadTrim_HwTqReadTrimData();
    
    /* init for variable HwTq10Meas_Cli_HwTq10MeasHwTq10TrimPrfmdSts_HwTqOffsTrimPrfmdStsData */
    _main_gen_init_sym_HwTq10Meas_Cli_HwTq10MeasHwTq10TrimPrfmdSts_HwTqOffsTrimPrfmdStsData();
    
    /* init for variable HwTq10Meas_Cli_HwTq10MeasHwTq10WrTrim_HwTqWrOffsTrimData */
    _main_gen_init_sym_HwTq10Meas_Cli_HwTq10MeasHwTq10WrTrim_HwTqWrOffsTrimData();
    
}
