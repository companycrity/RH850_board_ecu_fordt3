#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__g__21 _main_gen_init_g21(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__21 _main_gen_init_g21(void)
{
    __PST__g__21 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqA(void)
{
    extern __PST__FLOAT32 HwTqCorrln_Ip_HwTqA;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqAQlfr(void)
{
    extern __PST__UINT8 HwTqCorrln_Ip_HwTqAQlfr;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqAQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqARollgCntr(void)
{
    extern __PST__UINT8 HwTqCorrln_Ip_HwTqARollgCntr;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqARollgCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqB(void)
{
    extern __PST__FLOAT32 HwTqCorrln_Ip_HwTqB;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqBQlfr(void)
{
    extern __PST__UINT8 HwTqCorrln_Ip_HwTqBQlfr;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqBQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqBRollgCntr(void)
{
    extern __PST__UINT8 HwTqCorrln_Ip_HwTqBRollgCntr;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqBRollgCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqC(void)
{
    extern __PST__FLOAT32 HwTqCorrln_Ip_HwTqC;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqCQlfr(void)
{
    extern __PST__UINT8 HwTqCorrln_Ip_HwTqCQlfr;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqCQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqCRollgCntr(void)
{
    extern __PST__UINT8 HwTqCorrln_Ip_HwTqCRollgCntr;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqCRollgCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqD(void)
{
    extern __PST__FLOAT32 HwTqCorrln_Ip_HwTqD;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqD = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqDQlfr(void)
{
    extern __PST__UINT8 HwTqCorrln_Ip_HwTqDQlfr;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqDQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Ip_HwTqDRollgCntr(void)
{
    extern __PST__UINT8 HwTqCorrln_Ip_HwTqDRollgCntr;
    
    /* initialization with random value */
    {
        HwTqCorrln_Ip_HwTqDRollgCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Cal_HwTqCorrlnImdtCorrlnChkFailThd(void)
{
    extern __PST__g__27 HwTqCorrln_Cal_HwTqCorrlnImdtCorrlnChkFailThd;
    
    /* initialization with random value */
    {
        HwTqCorrln_Cal_HwTqCorrlnImdtCorrlnChkFailThd = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Cal_HwTqCorrlnNtcFailStep(void)
{
    extern __PST__g__21 HwTqCorrln_Cal_HwTqCorrlnNtcFailStep;
    
    /* initialization with random value */
    {
        HwTqCorrln_Cal_HwTqCorrlnNtcFailStep = _main_gen_init_g21();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Cal_HwTqCorrlnNtcPassStep(void)
{
    extern __PST__g__21 HwTqCorrln_Cal_HwTqCorrlnNtcPassStep;
    
    /* initialization with random value */
    {
        HwTqCorrln_Cal_HwTqCorrlnNtcPassStep = _main_gen_init_g21();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Cal_HwTqArbnHwTqMaxStallCnt(void)
{
    extern __PST__g__28 HwTqCorrln_Cal_HwTqArbnHwTqMaxStallCnt;
    
    /* initialization with random value */
    {
        HwTqCorrln_Cal_HwTqArbnHwTqMaxStallCnt = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Pim_HwTqARollgCntrPrev(void)
{
    extern __PST__UINT8 HwTqCorrln_Pim_HwTqARollgCntrPrev;
    
    /* initialization with random value */
    {
        HwTqCorrln_Pim_HwTqARollgCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Pim_HwTqAStallCntrPrev(void)
{
    extern __PST__UINT8 HwTqCorrln_Pim_HwTqAStallCntrPrev;
    
    /* initialization with random value */
    {
        HwTqCorrln_Pim_HwTqAStallCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Pim_HwTqBRollgCntrPrev(void)
{
    extern __PST__UINT8 HwTqCorrln_Pim_HwTqBRollgCntrPrev;
    
    /* initialization with random value */
    {
        HwTqCorrln_Pim_HwTqBRollgCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Pim_HwTqBStallCntrPrev(void)
{
    extern __PST__UINT8 HwTqCorrln_Pim_HwTqBStallCntrPrev;
    
    /* initialization with random value */
    {
        HwTqCorrln_Pim_HwTqBStallCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Pim_HwTqCRollgCntrPrev(void)
{
    extern __PST__UINT8 HwTqCorrln_Pim_HwTqCRollgCntrPrev;
    
    /* initialization with random value */
    {
        HwTqCorrln_Pim_HwTqCRollgCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Pim_HwTqCStallCntrPrev(void)
{
    extern __PST__UINT8 HwTqCorrln_Pim_HwTqCStallCntrPrev;
    
    /* initialization with random value */
    {
        HwTqCorrln_Pim_HwTqCStallCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Pim_HwTqDRollgCntrPrev(void)
{
    extern __PST__UINT8 HwTqCorrln_Pim_HwTqDRollgCntrPrev;
    
    /* initialization with random value */
    {
        HwTqCorrln_Pim_HwTqDRollgCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Pim_HwTqDStallCntrPrev(void)
{
    extern __PST__UINT8 HwTqCorrln_Pim_HwTqDStallCntrPrev;
    
    /* initialization with random value */
    {
        HwTqCorrln_Pim_HwTqDStallCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 HwTqCorrln_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        HwTqCorrln_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 HwTqCorrln_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        HwTqCorrln_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTqCorrln_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 HwTqCorrln_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        HwTqCorrln_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable HwTqCorrln_Ip_HwTqA */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqA();
    
    /* init for variable HwTqCorrln_Ip_HwTqAQlfr */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqAQlfr();
    
    /* init for variable HwTqCorrln_Ip_HwTqARollgCntr */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqARollgCntr();
    
    /* init for variable HwTqCorrln_Ip_HwTqB */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqB();
    
    /* init for variable HwTqCorrln_Ip_HwTqBQlfr */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqBQlfr();
    
    /* init for variable HwTqCorrln_Ip_HwTqBRollgCntr */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqBRollgCntr();
    
    /* init for variable HwTqCorrln_Ip_HwTqC */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqC();
    
    /* init for variable HwTqCorrln_Ip_HwTqCQlfr */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqCQlfr();
    
    /* init for variable HwTqCorrln_Ip_HwTqCRollgCntr */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqCRollgCntr();
    
    /* init for variable HwTqCorrln_Ip_HwTqD */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqD();
    
    /* init for variable HwTqCorrln_Ip_HwTqDQlfr */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqDQlfr();
    
    /* init for variable HwTqCorrln_Ip_HwTqDRollgCntr */
    _main_gen_init_sym_HwTqCorrln_Ip_HwTqDRollgCntr();
    
    /* init for variable HwTqCorrln_Op_HwTqCorrlnSts : useless (never read) */

    /* init for variable HwTqCorrln_Op_HwTqIdptSig : useless (never read) */

    /* init for variable HwTqCorrln_Cal_HwTqCorrlnImdtCorrlnChkFailThd */
    _main_gen_init_sym_HwTqCorrln_Cal_HwTqCorrlnImdtCorrlnChkFailThd();
    
    /* init for variable HwTqCorrln_Cal_HwTqCorrlnNtcFailStep */
    _main_gen_init_sym_HwTqCorrln_Cal_HwTqCorrlnNtcFailStep();
    
    /* init for variable HwTqCorrln_Cal_HwTqCorrlnNtcPassStep */
    _main_gen_init_sym_HwTqCorrln_Cal_HwTqCorrlnNtcPassStep();
    
    /* init for variable HwTqCorrln_Cal_HwTqArbnHwTqMaxStallCnt */
    _main_gen_init_sym_HwTqCorrln_Cal_HwTqArbnHwTqMaxStallCnt();
    
    /* init for variable HwTqCorrln_Pim_dHwTqCorrlnAvl : useless (never read) */

    /* init for variable HwTqCorrln_Pim_dHwTqCorrlnImdtCorrlnSts : useless (never read) */

    /* init for variable HwTqCorrln_Pim_HwTqARollgCntrPrev */
    _main_gen_init_sym_HwTqCorrln_Pim_HwTqARollgCntrPrev();
    
    /* init for variable HwTqCorrln_Pim_HwTqAStallCntrPrev */
    _main_gen_init_sym_HwTqCorrln_Pim_HwTqAStallCntrPrev();
    
    /* init for variable HwTqCorrln_Pim_HwTqBRollgCntrPrev */
    _main_gen_init_sym_HwTqCorrln_Pim_HwTqBRollgCntrPrev();
    
    /* init for variable HwTqCorrln_Pim_HwTqBStallCntrPrev */
    _main_gen_init_sym_HwTqCorrln_Pim_HwTqBStallCntrPrev();
    
    /* init for variable HwTqCorrln_Pim_HwTqCRollgCntrPrev */
    _main_gen_init_sym_HwTqCorrln_Pim_HwTqCRollgCntrPrev();
    
    /* init for variable HwTqCorrln_Pim_HwTqCStallCntrPrev */
    _main_gen_init_sym_HwTqCorrln_Pim_HwTqCStallCntrPrev();
    
    /* init for variable HwTqCorrln_Pim_HwTqDRollgCntrPrev */
    _main_gen_init_sym_HwTqCorrln_Pim_HwTqDRollgCntrPrev();
    
    /* init for variable HwTqCorrln_Pim_HwTqDStallCntrPrev */
    _main_gen_init_sym_HwTqCorrln_Pim_HwTqDStallCntrPrev();
    
    /* init for variable HwTqCorrln_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable HwTqCorrln_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_HwTqCorrln_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable HwTqCorrln_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_HwTqCorrln_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable HwTqCorrln_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable HwTqCorrln_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable HwTqCorrln_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable HwTqCorrln_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable HwTqCorrln_Srv_SetNtcSts_Return */
    _main_gen_init_sym_HwTqCorrln_Srv_SetNtcSts_Return();
    
}
