#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 FordMsg40ABusHiSpd_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Ip_FordCanDtcInhb(void)
{
    extern __PST__UINT8 FordMsg40ABusHiSpd_Ip_FordCanDtcInhb;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Ip_FordCanDtcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Ip_FordEpsLifeCycMod(void)
{
    extern __PST__UINT8 FordMsg40ABusHiSpd_Ip_FordEpsLifeCycMod;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Ip_FordEpsLifeCycMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Ip_FordMfgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg40ABusHiSpd_Ip_FordMfgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Ip_FordMfgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Ip_FordMissMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg40ABusHiSpd_Ip_FordMissMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Ip_FordMissMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Cal_FordMsg40ABusHiSpdMissMsgFaildThd(void)
{
    extern __PST__g__32 FordMsg40ABusHiSpd_Cal_FordMsg40ABusHiSpdMissMsgFaildThd;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Cal_FordMsg40ABusHiSpdMissMsgFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Cal_FordMsg40ABusHiSpdMissMsgPassdThd(void)
{
    extern __PST__g__32 FordMsg40ABusHiSpd_Cal_FordMsg40ABusHiSpdMissMsgPassdThd;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Cal_FordMsg40ABusHiSpdMissMsgPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordClrDiagcFlgProxyPrev(void)
{
    extern __PST__UINT8 FordMsg40ABusHiSpd_Pim_FordClrDiagcFlgProxyPrev;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Pim_FordClrDiagcFlgProxyPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehGlbRealTiPrev(void)
{
    extern __PST__FLOAT32 FordMsg40ABusHiSpd_Pim_FordVehGlbRealTiPrev;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Pim_FordVehGlbRealTiPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehIdnNrC100Prev(void)
{
    extern __PST__g__33 FordMsg40ABusHiSpd_Pim_FordVehIdnNrC100Prev;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 6; _main_gen_tmp_2_0++)
            {
                /* base type */
                FordMsg40ABusHiSpd_Pim_FordVehIdnNrC100Prev[_main_gen_tmp_2_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehIdnNrC101Prev(void)
{
    extern __PST__g__33 FordMsg40ABusHiSpd_Pim_FordVehIdnNrC101Prev;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 6; _main_gen_tmp_3_0++)
            {
                /* base type */
                FordMsg40ABusHiSpd_Pim_FordVehIdnNrC101Prev[_main_gen_tmp_3_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehIdnNrC102Prev(void)
{
    extern __PST__g__34 FordMsg40ABusHiSpd_Pim_FordVehIdnNrC102Prev;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 5; _main_gen_tmp_4_0++)
            {
                /* base type */
                FordMsg40ABusHiSpd_Pim_FordVehIdnNrC102Prev[_main_gen_tmp_4_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehIdnNrPrev(void)
{
    extern __PST__g__35 FordMsg40ABusHiSpd_Pim_FordVehIdnNrPrev;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 17; _main_gen_tmp_5_0++)
            {
                /* base type */
                FordMsg40ABusHiSpd_Pim_FordVehIdnNrPrev[_main_gen_tmp_5_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehMsg40AMiss(void)
{
    extern __PST__UINT8 FordMsg40ABusHiSpd_Pim_FordVehMsg40AMiss;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Pim_FordVehMsg40AMiss = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehMsg40ARxd(void)
{
    extern __PST__UINT8 FordMsg40ABusHiSpd_Pim_FordVehMsg40ARxd;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Pim_FordVehMsg40ARxd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehTireCircumPrev(void)
{
    extern __PST__FLOAT32 FordMsg40ABusHiSpd_Pim_FordVehTireCircumPrev;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Pim_FordVehTireCircumPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_MissMsgFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg40ABusHiSpd_Pim_MissMsgFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Pim_MissMsgFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_MissMsgPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg40ABusHiSpd_Pim_MissMsgPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Pim_MissMsgPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 FordMsg40ABusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 FordMsg40ABusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg40ABusHiSpd_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 FordMsg40ABusHiSpd_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        FordMsg40ABusHiSpd_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FordMsg40ABusHiSpd_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Ip_ClrDiagcFlgProxy();
    
    /* init for variable FordMsg40ABusHiSpd_Ip_FordCanDtcInhb */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Ip_FordCanDtcInhb();
    
    /* init for variable FordMsg40ABusHiSpd_Ip_FordEpsLifeCycMod */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Ip_FordEpsLifeCycMod();
    
    /* init for variable FordMsg40ABusHiSpd_Ip_FordMfgDiagcInhb */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Ip_FordMfgDiagcInhb();
    
    /* init for variable FordMsg40ABusHiSpd_Ip_FordMissMsgDiagcInhb */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Ip_FordMissMsgDiagcInhb();
    
    /* init for variable FordMsg40ABusHiSpd_Op_FordVehGlbRealTi : useless (never read) */

    /* init for variable FordMsg40ABusHiSpd_Op_FordVehTireCircum : useless (never read) */

    /* init for variable FordMsg40ABusHiSpd_Cal_FordMsg40ABusHiSpdMissMsgFaildThd */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Cal_FordMsg40ABusHiSpdMissMsgFaildThd();
    
    /* init for variable FordMsg40ABusHiSpd_Cal_FordMsg40ABusHiSpdMissMsgPassdThd */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Cal_FordMsg40ABusHiSpdMissMsgPassdThd();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_FordClrDiagcFlgProxyPrev */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordClrDiagcFlgProxyPrev();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_FordVehGlbRealTiPrev */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehGlbRealTiPrev();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_FordVehIdnNrC100Prev */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehIdnNrC100Prev();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_FordVehIdnNrC101Prev */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehIdnNrC101Prev();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_FordVehIdnNrC102Prev */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehIdnNrC102Prev();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_FordVehIdnNrPrev */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehIdnNrPrev();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_FordVehMsg40AMiss */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehMsg40AMiss();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_FordVehMsg40ARxd */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehMsg40ARxd();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_FordVehTireCircumPrev */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_FordVehTireCircumPrev();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_MissMsgFaildRefTi */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_MissMsgFaildRefTi();
    
    /* init for variable FordMsg40ABusHiSpd_Pim_MissMsgPassdRefTi */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Pim_MissMsgPassdRefTi();
    
    /* init for variable FordMsg40ABusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable FordMsg40ABusHiSpd_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable FordMsg40ABusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable FordMsg40ABusHiSpd_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable FordMsg40ABusHiSpd_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable FordMsg40ABusHiSpd_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable FordMsg40ABusHiSpd_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable FordMsg40ABusHiSpd_Srv_SetNtcSts_Return */
    _main_gen_init_sym_FordMsg40ABusHiSpd_Srv_SetNtcSts_Return();
    
}
