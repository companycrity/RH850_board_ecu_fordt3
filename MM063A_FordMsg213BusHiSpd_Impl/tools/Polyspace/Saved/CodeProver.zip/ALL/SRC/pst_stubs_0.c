#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_FordMsg213BusHiSpd_ClrDiagcFlgProxy_Val
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_ClrDiagcFlgProxy_Val(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_FordBrkOscnRednEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_FordBrkOscnRednEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_FordCanDtcInhb_Logl
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_FordCanDtcInhb_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_FordEpsLifeCycMod_Val
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_FordEpsLifeCycMod_Val(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_FordEvasSteerAssiEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_FordEvasSteerAssiEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_FordLaneCentrAssiEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_FordLaneCentrAssiEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_FordLaneDetnWarnEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_FordLaneDetnWarnEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_FordLkaEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_FordLkaEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_FordTrfcJamAssiEnad_Logl
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_FordTrfcJamAssiEnad_Logl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_Ford_AbsActv_B_Actl_Ford_AbsActv_B_Actl
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_Ford_AbsActv_B_Actl_Ford_AbsActv_B_Actl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_Ford_CmbbBrkDis_B_Actl_Ford_CmbbBrkDis_B_Actl
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_Ford_CmbbBrkDis_B_Actl_Ford_CmbbBrkDis_B_Actl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_Ford_CmbbDeny_B_ActlBrk_Ford_CmbbDeny_B_ActlBrk
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_Ford_CmbbDeny_B_ActlBrk_Ford_CmbbDeny_B_ActlBrk(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg213BusHiSpd_Ford_StabCtlBrkActv_B_Actl_Ford_StabCtlBrkActv_B_Actl
 */


__PST__UINT8 Rte_Read_FordMsg213BusHiSpd_Ford_StabCtlBrkActv_B_Actl_Ford_StabCtlBrkActv_B_Actl(__PST__g__20 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg213BusHiSpd_FordVehAbsActv_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg213BusHiSpd_FordVehAbsActv_Val"


__PST__UINT8 Rte_Write_FordMsg213BusHiSpd_FordVehAbsActv_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg213BusHiSpd_FordVehAbsEscStsVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg213BusHiSpd_FordVehAbsEscStsVld_Logl"


__PST__UINT8 Rte_Write_FordMsg213BusHiSpd_FordVehAbsEscStsVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg213BusHiSpd_FordVehCllsnMtgtnByBrkgDenied_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg213BusHiSpd_FordVehCllsnMtgtnByBrkgDenied_Val"


__PST__UINT8 Rte_Write_FordMsg213BusHiSpd_FordVehCllsnMtgtnByBrkgDenied_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg213BusHiSpd_FordVehCllsnMtgtnByBrkgDisad_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg213BusHiSpd_FordVehCllsnMtgtnByBrkgDisad_Val"


__PST__UINT8 Rte_Write_FordMsg213BusHiSpd_FordVehCllsnMtgtnByBrkgDisad_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg213BusHiSpd_FordVehEscActv_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg213BusHiSpd_FordVehEscActv_Val"


__PST__UINT8 Rte_Write_FordMsg213BusHiSpd_FordVehEscActv_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdAbsActvVldFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdAbsActvVldFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdAbsActvVldFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdAbsActvVldPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdAbsActvVldPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdAbsActvVldPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdEvasSteerAssiEnadThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdEvasSteerAssiEnadThd_Val"


__PST__UINT16 Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdEvasSteerAssiEnadThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdMissMsgFaildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdMissMsgFaildThd_Val"


__PST__UINT16 Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdMissMsgFaildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdMissMsgPassdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdMissMsgPassdThd_Val"


__PST__UINT16 Rte_Prm_FordMsg213BusHiSpd_FordMsg213BusHiSpdMissMsgPassdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

