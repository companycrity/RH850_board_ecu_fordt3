#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__g__24 _main_gen_init_g24(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__SINT32 _main_gen_init_g4(void);

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__24 _main_gen_init_g24(void)
{
    __PST__g__24 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotQuadDetn_Ip_MotAgCumvAlgndMrf(void)
{
    extern __PST__SINT32 MotQuadDetn_Ip_MotAgCumvAlgndMrf;
    
    /* initialization with random value */
    {
        MotQuadDetn_Ip_MotAgCumvAlgndMrf = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_MotQuadDetn_Ip_MotTqCmd(void)
{
    extern __PST__FLOAT32 MotQuadDetn_Ip_MotTqCmd;
    
    /* initialization with random value */
    {
        MotQuadDetn_Ip_MotTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotQuadDetn_Cal_MotQuadDetnMotDirHysInsts(void)
{
    extern __PST__g__24 MotQuadDetn_Cal_MotQuadDetnMotDirHysInsts;
    
    /* initialization with random value */
    {
        MotQuadDetn_Cal_MotQuadDetnMotDirHysInsts = _main_gen_init_g24();
    }
}

static void _main_gen_init_sym_MotQuadDetn_Pim_MotAgCumvPrev(void)
{
    extern __PST__SINT32 MotQuadDetn_Pim_MotAgCumvPrev;
    
    /* initialization with random value */
    {
        MotQuadDetn_Pim_MotAgCumvPrev = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_MotQuadDetn_Pim_MotDirInstsPrev(void)
{
    extern __PST__SINT8 MotQuadDetn_Pim_MotDirInstsPrev;
    
    /* initialization with random value */
    {
        MotQuadDetn_Pim_MotDirInstsPrev = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_MotQuadDetn_Pim_MotTqCmdSignPrev(void)
{
    extern __PST__SINT8 MotQuadDetn_Pim_MotTqCmdSignPrev;
    
    /* initialization with random value */
    {
        MotQuadDetn_Pim_MotTqCmdSignPrev = _main_gen_init_g2();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotQuadDetn_Ip_MotAgCumvAlgndMrf */
    _main_gen_init_sym_MotQuadDetn_Ip_MotAgCumvAlgndMrf();
    
    /* init for variable MotQuadDetn_Ip_MotTqCmd */
    _main_gen_init_sym_MotQuadDetn_Ip_MotTqCmd();
    
    /* init for variable MotQuadDetn_Op_MotDirInsts : useless (never read) */

    /* init for variable MotQuadDetn_Op_MotQuad : useless (never read) */

    /* init for variable MotQuadDetn_Cal_MotQuadDetnMotDirHysInsts */
    _main_gen_init_sym_MotQuadDetn_Cal_MotQuadDetnMotDirHysInsts();
    
    /* init for variable MotQuadDetn_Pim_dMotQuadDetnMotAgCumvDelta : useless (never read) */

    /* init for variable MotQuadDetn_Pim_dMotQuadDetnTqCmdSign : useless (never read) */

    /* init for variable MotQuadDetn_Pim_MotAgCumvPrev */
    _main_gen_init_sym_MotQuadDetn_Pim_MotAgCumvPrev();
    
    /* init for variable MotQuadDetn_Pim_MotDirInstsPrev */
    _main_gen_init_sym_MotQuadDetn_Pim_MotDirInstsPrev();
    
    /* init for variable MotQuadDetn_Pim_MotTqCmdSignPrev */
    _main_gen_init_sym_MotQuadDetn_Pim_MotTqCmdSignPrev();
    
}
