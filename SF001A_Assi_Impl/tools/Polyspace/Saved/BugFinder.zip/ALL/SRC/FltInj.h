
#ifndef FLTINJ_H
#define FLTINJ_H

/* Fault Injection Assist Command */
#define FLTINJ_ASSI_ASSICMDBAS          (1U)

#endif
