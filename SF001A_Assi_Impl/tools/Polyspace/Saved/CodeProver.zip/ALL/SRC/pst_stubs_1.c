#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Assi_Ip_AssiCmdBasSca(void)
{
    extern __PST__FLOAT32 Assi_Ip_AssiCmdBasSca;
    
    /* initialization with random value */
    {
        Assi_Ip_AssiCmdBasSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Assi_Ip_AssiLnrGain(void)
{
    extern __PST__FLOAT32 Assi_Ip_AssiLnrGain;
    
    /* initialization with random value */
    {
        Assi_Ip_AssiLnrGain = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Assi_Ip_AssiLnrGainEna(void)
{
    extern __PST__UINT8 Assi_Ip_AssiLnrGainEna;
    
    /* initialization with random value */
    {
        Assi_Ip_AssiLnrGainEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Assi_Ip_HwTq(void)
{
    extern __PST__FLOAT32 Assi_Ip_HwTq;
    
    /* initialization with random value */
    {
        Assi_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Assi_Ip_HwTqHysOvrl(void)
{
    extern __PST__FLOAT32 Assi_Ip_HwTqHysOvrl;
    
    /* initialization with random value */
    {
        Assi_Ip_HwTqHysOvrl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Assi_Ip_HwTqOvrl(void)
{
    extern __PST__FLOAT32 Assi_Ip_HwTqOvrl;
    
    /* initialization with random value */
    {
        Assi_Ip_HwTqOvrl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Assi_Ip_ThermLimSlowFilMax(void)
{
    extern __PST__FLOAT32 Assi_Ip_ThermLimSlowFilMax;
    
    /* initialization with random value */
    {
        Assi_Ip_ThermLimSlowFilMax = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Assi_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 Assi_Ip_VehSpd;
    
    /* initialization with random value */
    {
        Assi_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Assi_Ip_WhlImbRejctnAmp(void)
{
    extern __PST__FLOAT32 Assi_Ip_WhlImbRejctnAmp;
    
    /* initialization with random value */
    {
        Assi_Ip_WhlImbRejctnAmp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Assi_Cal_AssiMotTqWhlImbRejctnMaxX(void)
{
    extern __PST__g__24 Assi_Cal_AssiMotTqWhlImbRejctnMaxX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 12; _main_gen_tmp_1_0++)
            {
                __PST__UINT32 _main_gen_tmp_1_1;
                
                for (_main_gen_tmp_1_1 = 0; _main_gen_tmp_1_1 < 20; _main_gen_tmp_1_1++)
                {
                    /* base type */
                    Assi_Cal_AssiMotTqWhlImbRejctnMaxX[_main_gen_tmp_1_0][_main_gen_tmp_1_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Assi_Cal_AssiMotTqWhlImbRejctnMaxY(void)
{
    extern __PST__g__26 Assi_Cal_AssiMotTqWhlImbRejctnMaxY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 12; _main_gen_tmp_2_0++)
            {
                __PST__UINT32 _main_gen_tmp_2_1;
                
                for (_main_gen_tmp_2_1 = 0; _main_gen_tmp_2_1 < 20; _main_gen_tmp_2_1++)
                {
                    /* base type */
                    Assi_Cal_AssiMotTqWhlImbRejctnMaxY[_main_gen_tmp_2_0][_main_gen_tmp_2_1] = pst_random_g_3;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Assi_Cal_AssiMotTqWhlImbRejctnMinX(void)
{
    extern __PST__g__24 Assi_Cal_AssiMotTqWhlImbRejctnMinX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 12; _main_gen_tmp_3_0++)
            {
                __PST__UINT32 _main_gen_tmp_3_1;
                
                for (_main_gen_tmp_3_1 = 0; _main_gen_tmp_3_1 < 20; _main_gen_tmp_3_1++)
                {
                    /* base type */
                    Assi_Cal_AssiMotTqWhlImbRejctnMinX[_main_gen_tmp_3_0][_main_gen_tmp_3_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Assi_Cal_AssiMotTqWhlImbRejctnMinY(void)
{
    extern __PST__g__26 Assi_Cal_AssiMotTqWhlImbRejctnMinY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 12; _main_gen_tmp_4_0++)
            {
                __PST__UINT32 _main_gen_tmp_4_1;
                
                for (_main_gen_tmp_4_1 = 0; _main_gen_tmp_4_1 < 20; _main_gen_tmp_4_1++)
                {
                    /* base type */
                    Assi_Cal_AssiMotTqWhlImbRejctnMinY[_main_gen_tmp_4_0][_main_gen_tmp_4_1] = pst_random_g_3;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Assi_Cal_AssiThermScaX(void)
{
    extern __PST__g__29 Assi_Cal_AssiThermScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 2; _main_gen_tmp_5_0++)
            {
                /* base type */
                Assi_Cal_AssiThermScaX[_main_gen_tmp_5_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Assi_Cal_AssiThermScaY(void)
{
    extern __PST__g__29 Assi_Cal_AssiThermScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 2; _main_gen_tmp_6_0++)
            {
                /* base type */
                Assi_Cal_AssiThermScaY[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Assi_Cal_AssiWhlImbRejctnBlndScaX(void)
{
    extern __PST__g__30 Assi_Cal_AssiWhlImbRejctnBlndScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 12; _main_gen_tmp_7_0++)
            {
                __PST__UINT32 _main_gen_tmp_7_1;
                
                for (_main_gen_tmp_7_1 = 0; _main_gen_tmp_7_1 < 5; _main_gen_tmp_7_1++)
                {
                    /* base type */
                    Assi_Cal_AssiWhlImbRejctnBlndScaX[_main_gen_tmp_7_0][_main_gen_tmp_7_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Assi_Cal_AssiWhlImbRejctnBlndScaY(void)
{
    extern __PST__g__30 Assi_Cal_AssiWhlImbRejctnBlndScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 12; _main_gen_tmp_8_0++)
            {
                __PST__UINT32 _main_gen_tmp_8_1;
                
                for (_main_gen_tmp_8_1 = 0; _main_gen_tmp_8_1 < 5; _main_gen_tmp_8_1++)
                {
                    /* base type */
                    Assi_Cal_AssiWhlImbRejctnBlndScaY[_main_gen_tmp_8_0][_main_gen_tmp_8_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Assi_Cal_SysGlbPrmVehSpdBilnrSeln(void)
{
    extern __PST__g__32 Assi_Cal_SysGlbPrmVehSpdBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 12; _main_gen_tmp_9_0++)
            {
                /* base type */
                Assi_Cal_SysGlbPrmVehSpdBilnrSeln[_main_gen_tmp_9_0] = pst_random_g_7;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Assi_Ip_AssiCmdBasSca */
    _main_gen_init_sym_Assi_Ip_AssiCmdBasSca();
    
    /* init for variable Assi_Ip_AssiLnrGain */
    _main_gen_init_sym_Assi_Ip_AssiLnrGain();
    
    /* init for variable Assi_Ip_AssiLnrGainEna */
    _main_gen_init_sym_Assi_Ip_AssiLnrGainEna();
    
    /* init for variable Assi_Ip_HwTq */
    _main_gen_init_sym_Assi_Ip_HwTq();
    
    /* init for variable Assi_Ip_HwTqHysOvrl */
    _main_gen_init_sym_Assi_Ip_HwTqHysOvrl();
    
    /* init for variable Assi_Ip_HwTqOvrl */
    _main_gen_init_sym_Assi_Ip_HwTqOvrl();
    
    /* init for variable Assi_Ip_ThermLimSlowFilMax */
    _main_gen_init_sym_Assi_Ip_ThermLimSlowFilMax();
    
    /* init for variable Assi_Ip_VehSpd */
    _main_gen_init_sym_Assi_Ip_VehSpd();
    
    /* init for variable Assi_Ip_WhlImbRejctnAmp */
    _main_gen_init_sym_Assi_Ip_WhlImbRejctnAmp();
    
    /* init for variable Assi_Op_AssiCmdBas : useless (never read) */

    /* init for variable Assi_Cal_AssiMotTqWhlImbRejctnMaxX */
    _main_gen_init_sym_Assi_Cal_AssiMotTqWhlImbRejctnMaxX();
    
    /* init for variable Assi_Cal_AssiMotTqWhlImbRejctnMaxY */
    _main_gen_init_sym_Assi_Cal_AssiMotTqWhlImbRejctnMaxY();
    
    /* init for variable Assi_Cal_AssiMotTqWhlImbRejctnMinX */
    _main_gen_init_sym_Assi_Cal_AssiMotTqWhlImbRejctnMinX();
    
    /* init for variable Assi_Cal_AssiMotTqWhlImbRejctnMinY */
    _main_gen_init_sym_Assi_Cal_AssiMotTqWhlImbRejctnMinY();
    
    /* init for variable Assi_Cal_AssiThermScaX */
    _main_gen_init_sym_Assi_Cal_AssiThermScaX();
    
    /* init for variable Assi_Cal_AssiThermScaY */
    _main_gen_init_sym_Assi_Cal_AssiThermScaY();
    
    /* init for variable Assi_Cal_AssiWhlImbRejctnBlndScaX */
    _main_gen_init_sym_Assi_Cal_AssiWhlImbRejctnBlndScaX();
    
    /* init for variable Assi_Cal_AssiWhlImbRejctnBlndScaY */
    _main_gen_init_sym_Assi_Cal_AssiWhlImbRejctnBlndScaY();
    
    /* init for variable Assi_Cal_SysGlbPrmVehSpdBilnrSeln */
    _main_gen_init_sym_Assi_Cal_SysGlbPrmVehSpdBilnrSeln();
    
    /* init for variable Assi_Pim_dAssiThermAssiSca : useless (never read) */

    /* init for variable Assi_Pim_dAssiWhlImbRejctnBlnd : useless (never read) */

}
