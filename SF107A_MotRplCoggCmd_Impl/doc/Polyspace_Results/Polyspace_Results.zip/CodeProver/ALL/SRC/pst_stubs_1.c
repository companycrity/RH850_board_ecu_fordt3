#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern struct Rte_CDS_CDD_MotRplCoggCmd _main_gen_init_g30(void);

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct Rte_CDS_CDD_MotRplCoggCmd _main_gen_init_g30(void)
{
    static struct Rte_CDS_CDD_MotRplCoggCmd x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__g__32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__g__32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__g__32); _i_main_gen_tmp_7++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_8_0;
                
                for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 512; _main_gen_tmp_8_0++)
                {
                    /* base type */
                    _main_gen_tmp_6[_i_main_gen_tmp_7][_main_gen_tmp_8_0] = pst_random_g_3;
                }
            }
        }
        x.Pim_MotCoggCmdY = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__g__32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_9[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_10;
        for (_i_main_gen_tmp_10 = 0; _i_main_gen_tmp_10 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_10++)
        {
            _main_gen_tmp_9[_i_main_gen_tmp_10] = _main_gen_init_g7();
        }
        x.Pim_dMotRplCoggCmdCoggIdx = PST_TRUE() ? 0 : &_main_gen_tmp_9[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_11[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_12;
        for (_i_main_gen_tmp_12 = 0; _i_main_gen_tmp_12 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_12++)
        {
            _main_gen_tmp_11[_i_main_gen_tmp_12] = _main_gen_init_g10();
        }
        x.Pim_dMotRplCoggCmdMotCoggCmd = PST_TRUE() ? 0 : &_main_gen_tmp_11[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_13[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_14;
        for (_i_main_gen_tmp_14 = 0; _i_main_gen_tmp_14 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_14++)
        {
            _main_gen_tmp_13[_i_main_gen_tmp_14] = _main_gen_init_g10();
        }
        x.Pim_dMotRplCoggCmdMotCurrQaxCoggCmdPreLim = PST_TRUE() ? 0 : &_main_gen_tmp_13[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_15[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_16;
        for (_i_main_gen_tmp_16 = 0; _i_main_gen_tmp_16 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_16++)
        {
            _main_gen_tmp_15[_i_main_gen_tmp_16] = _main_gen_init_g10();
        }
        x.Pim_dMotRplCoggCmdMotRplCmdPreLim = PST_TRUE() ? 0 : &_main_gen_tmp_15[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_MotRplCoggCmd(void)
{
    extern __PST__g__27 Rte_Inst_CDD_MotRplCoggCmd;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_MotRplCoggCmd _main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_CDD_MotRplCoggCmd)];
            __PST__UINT32 _i_main_gen_tmp_5;
            for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct Rte_CDS_CDD_MotRplCoggCmd); _i_main_gen_tmp_5++)
            {
                _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g30();
            }
            Rte_Inst_CDD_MotRplCoggCmd = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_CDD_MotRplCoggCmd) / 2];
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElec(void)
{
    extern __PST__UINT16 MOTCTRLMGR_MotCtrlMotAgElec;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgElec = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElecDlyRpl(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAgElecDlyRpl;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgElecDlyRpl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder1Mgn(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotTqRplCoggOrder1Mgn;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotTqRplCoggOrder1Mgn = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder2Mgn(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotTqRplCoggOrder2Mgn;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotTqRplCoggOrder2Mgn = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder1Pha(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotTqRplCoggOrder1Pha;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotTqRplCoggOrder1Pha = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder2Pha(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotTqRplCoggOrder2Pha;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotTqRplCoggOrder2Pha = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder3Mgn(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotTqRplCoggOrder3Mgn;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotTqRplCoggOrder3Mgn = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder3Pha(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotTqRplCoggOrder3Pha;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotTqRplCoggOrder3Pha = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxToMotTqGain(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrQaxToMotTqGain;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrQaxToMotTqGain = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotElecMeclPolarity(void)
{
    extern __PST__SINT8 MOTCTRLMGR_MotCtrlMotElecMeclPolarity;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotElecMeclPolarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_NXTRMATH_SINCNVNCONTBL_ULS_U16(void)
{
    extern __PST__g__40 NXTRMATH_SINCNVNCONTBL_ULS_U16;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_17_0;
            
            for (_main_gen_tmp_17_0 = 0; _main_gen_tmp_17_0 < 513; _main_gen_tmp_17_0++)
            {
                /* base type */
                NXTRMATH_SINCNVNCONTBL_ULS_U16[_main_gen_tmp_17_0] = pst_random_g_7;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_MotRplCoggCmd */
    _main_gen_init_sym_Rte_Inst_CDD_MotRplCoggCmd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgElec */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElec();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgElecDlyRpl */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElecDlyRpl();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotTqRplCoggOrder1Mgn */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder1Mgn();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotTqRplCoggOrder2Mgn */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder2Mgn();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotTqRplCoggOrder1Pha */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder1Pha();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotTqRplCoggOrder2Pha */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder2Pha();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotTqRplCoggOrder3Mgn */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder3Mgn();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotTqRplCoggOrder3Pha */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotTqRplCoggOrder3Pha();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxToMotTqGain */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrQaxToMotTqGain();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxRplCmd : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotCurrQaxCoggCmd : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotElecMeclPolarity */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotElecMeclPolarity();
    
    /* init for variable NXTRMATH_SINCNVNCONTBL_ULS_U16 */
    _main_gen_init_sym_NXTRMATH_SINCNVNCONTBL_ULS_U16();
    
}
