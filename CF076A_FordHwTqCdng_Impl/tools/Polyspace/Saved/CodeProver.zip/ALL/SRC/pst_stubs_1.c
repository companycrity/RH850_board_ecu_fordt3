#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FordHwTqCdng_Ip_AssiCmd(void)
{
    extern __PST__FLOAT32 FordHwTqCdng_Ip_AssiCmd;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Ip_AssiCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Ip_AssiCmdBas(void)
{
    extern __PST__FLOAT32 FordHwTqCdng_Ip_AssiCmdBas;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Ip_AssiCmdBas = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Ip_AvlMotTq(void)
{
    extern __PST__FLOAT32 FordHwTqCdng_Ip_AvlMotTq;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Ip_AvlMotTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Ip_EcuId(void)
{
    extern __PST__UINT8 FordHwTqCdng_Ip_EcuId;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Ip_EcuId = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Ip_HwTq(void)
{
    extern __PST__FLOAT32 FordHwTqCdng_Ip_HwTq;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Ip_HwTqHysOvrl(void)
{
    extern __PST__FLOAT32 FordHwTqCdng_Ip_HwTqHysOvrl;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Ip_HwTqHysOvrl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Ip_HwTqOvrl(void)
{
    extern __PST__FLOAT32 FordHwTqCdng_Ip_HwTqOvrl;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Ip_HwTqOvrl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Ip_MotTqCmd(void)
{
    extern __PST__FLOAT32 FordHwTqCdng_Ip_MotTqCmd;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Ip_MotTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Ip_MotTqCmdPwrLimd(void)
{
    extern __PST__FLOAT32 FordHwTqCdng_Ip_MotTqCmdPwrLimd;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Ip_MotTqCmdPwrLimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Cal_FordHwTqCdngAppldFinalMotTqVldTiThd(void)
{
    extern __PST__g__27 FordHwTqCdng_Cal_FordHwTqCdngAppldFinalMotTqVldTiThd;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Cal_FordHwTqCdngAppldFinalMotTqVldTiThd = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Cal_FordHwTqCdngInpTqRawVldTiThd(void)
{
    extern __PST__g__27 FordHwTqCdng_Cal_FordHwTqCdngInpTqRawVldTiThd;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Cal_FordHwTqCdngInpTqRawVldTiThd = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Cal_PwrLimrStdOperMotEnvlpY(void)
{
    extern __PST__g__28 FordHwTqCdng_Cal_PwrLimrStdOperMotEnvlpY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 6; _main_gen_tmp_0_0++)
            {
                /* base type */
                FordHwTqCdng_Cal_PwrLimrStdOperMotEnvlpY[_main_gen_tmp_0_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Cal_SysGlbPrmSysKineRat(void)
{
    extern __PST__g__29 FordHwTqCdng_Cal_SysGlbPrmSysKineRat;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Cal_SysGlbPrmSysKineRat = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Pim_AppldFinalMotTqVldRefTi(void)
{
    extern __PST__UINT32 FordHwTqCdng_Pim_AppldFinalMotTqVldRefTi;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Pim_AppldFinalMotTqVldRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Pim_InpTqRawVldRefTi(void)
{
    extern __PST__UINT32 FordHwTqCdng_Pim_InpTqRawVldRefTi;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Pim_InpTqRawVldRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 FordHwTqCdng_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 FordHwTqCdng_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 FordHwTqCdng_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordHwTqCdng_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 FordHwTqCdng_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        FordHwTqCdng_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FordHwTqCdng_Ip_AssiCmd */
    _main_gen_init_sym_FordHwTqCdng_Ip_AssiCmd();
    
    /* init for variable FordHwTqCdng_Ip_AssiCmdBas */
    _main_gen_init_sym_FordHwTqCdng_Ip_AssiCmdBas();
    
    /* init for variable FordHwTqCdng_Ip_AvlMotTq */
    _main_gen_init_sym_FordHwTqCdng_Ip_AvlMotTq();
    
    /* init for variable FordHwTqCdng_Ip_EcuId */
    _main_gen_init_sym_FordHwTqCdng_Ip_EcuId();
    
    /* init for variable FordHwTqCdng_Ip_HwTq */
    _main_gen_init_sym_FordHwTqCdng_Ip_HwTq();
    
    /* init for variable FordHwTqCdng_Ip_HwTqHysOvrl */
    _main_gen_init_sym_FordHwTqCdng_Ip_HwTqHysOvrl();
    
    /* init for variable FordHwTqCdng_Ip_HwTqOvrl */
    _main_gen_init_sym_FordHwTqCdng_Ip_HwTqOvrl();
    
    /* init for variable FordHwTqCdng_Ip_MotTqCmd */
    _main_gen_init_sym_FordHwTqCdng_Ip_MotTqCmd();
    
    /* init for variable FordHwTqCdng_Ip_MotTqCmdPwrLimd */
    _main_gen_init_sym_FordHwTqCdng_Ip_MotTqCmdPwrLimd();
    
    /* init for variable FordHwTqCdng_Op_FordAppldFinalMotTq : useless (never read) */

    /* init for variable FordHwTqCdng_Op_FordAppldFinalMotTqVld : useless (never read) */

    /* init for variable FordHwTqCdng_Op_FordBoostCrvAssiTq : useless (never read) */

    /* init for variable FordHwTqCdng_Op_FordBoostCrvInpTq : useless (never read) */

    /* init for variable FordHwTqCdng_Op_FordInpTqRaw : useless (never read) */

    /* init for variable FordHwTqCdng_Op_FordInpTqRawVld : useless (never read) */

    /* init for variable FordHwTqCdng_Op_FordMaxAsscTq : useless (never read) */

    /* init for variable FordHwTqCdng_Op_FordReqdFinalMotTq : useless (never read) */

    /* init for variable FordHwTqCdng_Cal_FordHwTqCdngAppldFinalMotTqVldTiThd */
    _main_gen_init_sym_FordHwTqCdng_Cal_FordHwTqCdngAppldFinalMotTqVldTiThd();
    
    /* init for variable FordHwTqCdng_Cal_FordHwTqCdngInpTqRawVldTiThd */
    _main_gen_init_sym_FordHwTqCdng_Cal_FordHwTqCdngInpTqRawVldTiThd();
    
    /* init for variable FordHwTqCdng_Cal_PwrLimrStdOperMotEnvlpY */
    _main_gen_init_sym_FordHwTqCdng_Cal_PwrLimrStdOperMotEnvlpY();
    
    /* init for variable FordHwTqCdng_Cal_SysGlbPrmSysKineRat */
    _main_gen_init_sym_FordHwTqCdng_Cal_SysGlbPrmSysKineRat();
    
    /* init for variable FordHwTqCdng_Pim_dFordHwTqCdngFildBoostCrvAssiTq : useless (never read) */

    /* init for variable FordHwTqCdng_Pim_AppldFinalMotTqVldRefTi */
    _main_gen_init_sym_FordHwTqCdng_Pim_AppldFinalMotTqVldRefTi();
    
    /* init for variable FordHwTqCdng_Pim_InpTqRawVldRefTi */
    _main_gen_init_sym_FordHwTqCdng_Pim_InpTqRawVldRefTi();
    
    /* init for variable FordHwTqCdng_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable FordHwTqCdng_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_FordHwTqCdng_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable FordHwTqCdng_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_FordHwTqCdng_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable FordHwTqCdng_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_FordHwTqCdng_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable FordHwTqCdng_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable FordHwTqCdng_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_FordHwTqCdng_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
}
