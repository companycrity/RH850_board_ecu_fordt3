#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__38 _main_gen_init_g38(void);

extern struct __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__g__31 _main_gen_init_g31(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__31 _main_gen_init_g31(void)
{
    __PST__g__31 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

struct __PST__g__37 _main_gen_init_g37(void)
{
    static struct __PST__g__37 x;
    /* struct/union type */
    x.Fil3StVal = _main_gen_init_g6();
    x.Fil4StVal = _main_gen_init_g6();
    x.Fil5StVal = _main_gen_init_g6();
    x.Fil6StVal = _main_gen_init_g6();
    return x;
}

struct __PST__g__38 _main_gen_init_g38(void)
{
    static struct __PST__g__38 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_DutyCycThermProtn_Ip_DiagcStsLimdTPrfmnc(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Ip_DiagcStsLimdTPrfmnc;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_DiagcStsLimdTPrfmnc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_DualEcuFltMtgtnEna(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Ip_DualEcuFltMtgtnEna;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_DualEcuFltMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_DutyCycThermProtnDi(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Ip_DutyCycThermProtnDi;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_DutyCycThermProtnDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_EcuTFild(void)
{
    extern __PST__FLOAT32 DutyCycThermProtn_Ip_EcuTFild;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_EcuTFild = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_IgnTiOff(void)
{
    extern __PST__UINT32 DutyCycThermProtn_Ip_IgnTiOff;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_IgnTiOff = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_MotAndThermProtnLoaMod(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Ip_MotAndThermProtnLoaMod;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_MotAndThermProtnLoaMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_MotCurrPeakEstimd(void)
{
    extern __PST__FLOAT32 DutyCycThermProtn_Ip_MotCurrPeakEstimd;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_MotCurrPeakEstimd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_MotCurrPeakEstimdFild(void)
{
    extern __PST__FLOAT32 DutyCycThermProtn_Ip_MotCurrPeakEstimdFild;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_MotCurrPeakEstimdFild = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_MotFetT(void)
{
    extern __PST__FLOAT32 DutyCycThermProtn_Ip_MotFetT;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_MotFetT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_MotMagT(void)
{
    extern __PST__FLOAT32 DutyCycThermProtn_Ip_MotMagT;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_MotMagT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 DutyCycThermProtn_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_MotWidgT(void)
{
    extern __PST__FLOAT32 DutyCycThermProtn_Ip_MotWidgT;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_MotWidgT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Ip_VehTiVld(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Ip_VehTiVld;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Ip_VehTiVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTFetMtgtnTblX(void)
{
    extern __PST__g__26 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTFetMtgtnTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 4; _main_gen_tmp_1_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTFetMtgtnTblX[_main_gen_tmp_1_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTblX(void)
{
    extern __PST__g__26 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 4; _main_gen_tmp_2_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTblX[_main_gen_tmp_2_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTqFetMtgtnTblY(void)
{
    extern __PST__g__28 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTqFetMtgtnTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 4; _main_gen_tmp_3_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTqFetMtgtnTblY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTqTblY(void)
{
    extern __PST__g__28 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTqTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 4; _main_gen_tmp_4_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTqTblY[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTFetMtgtnTblX(void)
{
    extern __PST__g__26 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTFetMtgtnTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 4; _main_gen_tmp_5_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTFetMtgtnTblX[_main_gen_tmp_5_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTblX(void)
{
    extern __PST__g__26 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 4; _main_gen_tmp_6_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTblX[_main_gen_tmp_6_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTqFetMtgtnTblY(void)
{
    extern __PST__g__28 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTqFetMtgtnTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 4; _main_gen_tmp_7_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTqFetMtgtnTblY[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTqTblY(void)
{
    extern __PST__g__28 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTqTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 4; _main_gen_tmp_8_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTqTblY[_main_gen_tmp_8_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltMotVelBreakPt(void)
{
    extern __PST__g__30 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltMotVelBreakPt;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnAbsltMotVelBreakPt = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltTTqSlewHiLim(void)
{
    extern __PST__g__30 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltTTqSlewHiLim;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnAbsltTTqSlewHiLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltTTqSlewLoLim(void)
{
    extern __PST__g__30 DutyCycThermProtn_Cal_DutyCycThermProtnAbsltTTqSlewLoLim;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnAbsltTTqSlewLoLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnCtrlT(void)
{
    extern __PST__g__30 DutyCycThermProtn_Cal_DutyCycThermProtnCtrlT;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnCtrlT = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnCtrlTSeln(void)
{
    extern __PST__g__31 DutyCycThermProtn_Cal_DutyCycThermProtnCtrlTSeln;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnCtrlTSeln = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnDutyCycFildThd(void)
{
    extern __PST__g__29 DutyCycThermProtn_Cal_DutyCycThermProtnDutyCycFildThd;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnDutyCycFildThd = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnIgnOffCtrlEna(void)
{
    extern __PST__g__31 DutyCycThermProtn_Cal_DutyCycThermProtnIgnOffCtrlEna;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnIgnOffCtrlEna = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnIgnOffMsgWaitTi(void)
{
    extern __PST__g__30 DutyCycThermProtn_Cal_DutyCycThermProtnIgnOffMsgWaitTi;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnIgnOffMsgWaitTi = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnLstTblValNonStall(void)
{
    extern __PST__g__32 DutyCycThermProtn_Cal_DutyCycThermProtnLstTblValNonStall;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 5; _main_gen_tmp_9_0++)
            {
                __PST__UINT32 _main_gen_tmp_9_1;
                
                for (_main_gen_tmp_9_1 = 0; _main_gen_tmp_9_1 < 2; _main_gen_tmp_9_1++)
                {
                    /* base type */
                    DutyCycThermProtn_Cal_DutyCycThermProtnLstTblValNonStall[_main_gen_tmp_9_0][_main_gen_tmp_9_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnLstTblValStall(void)
{
    extern __PST__g__32 DutyCycThermProtn_Cal_DutyCycThermProtnLstTblValStall;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 5; _main_gen_tmp_10_0++)
            {
                __PST__UINT32 _main_gen_tmp_10_1;
                
                for (_main_gen_tmp_10_1 = 0; _main_gen_tmp_10_1 < 2; _main_gen_tmp_10_1++)
                {
                    /* base type */
                    DutyCycThermProtn_Cal_DutyCycThermProtnLstTblValStall[_main_gen_tmp_10_0][_main_gen_tmp_10_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMotPrTSeln(void)
{
    extern __PST__g__31 DutyCycThermProtn_Cal_DutyCycThermProtnMotPrTSeln;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnMotPrTSeln = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr1FetMtgtnNonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr1FetMtgtnNonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 5; _main_gen_tmp_11_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr1FetMtgtnNonStallTblY[_main_gen_tmp_11_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr1FetMtgtnStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr1FetMtgtnStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 5; _main_gen_tmp_12_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr1FetMtgtnStallTblY[_main_gen_tmp_12_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr1NonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr1NonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 5; _main_gen_tmp_13_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr1NonStallTblY[_main_gen_tmp_13_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr1StallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr1StallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_14_0;
            
            for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 5; _main_gen_tmp_14_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr1StallTblY[_main_gen_tmp_14_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr2FetMtgtnNonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr2FetMtgtnNonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 5; _main_gen_tmp_15_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr2FetMtgtnNonStallTblY[_main_gen_tmp_15_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr2FetMtgtnStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr2FetMtgtnStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_16_0;
            
            for (_main_gen_tmp_16_0 = 0; _main_gen_tmp_16_0 < 5; _main_gen_tmp_16_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr2FetMtgtnStallTblY[_main_gen_tmp_16_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr2NonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr2NonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_17_0;
            
            for (_main_gen_tmp_17_0 = 0; _main_gen_tmp_17_0 < 5; _main_gen_tmp_17_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr2NonStallTblY[_main_gen_tmp_17_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr2StallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr2StallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_18_0;
            
            for (_main_gen_tmp_18_0 = 0; _main_gen_tmp_18_0 < 5; _main_gen_tmp_18_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr2StallTblY[_main_gen_tmp_18_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr3FetMtgtnNonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr3FetMtgtnNonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_19_0;
            
            for (_main_gen_tmp_19_0 = 0; _main_gen_tmp_19_0 < 5; _main_gen_tmp_19_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr3FetMtgtnNonStallTblY[_main_gen_tmp_19_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr3FetMtgtnStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr3FetMtgtnStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_20_0;
            
            for (_main_gen_tmp_20_0 = 0; _main_gen_tmp_20_0 < 5; _main_gen_tmp_20_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr3FetMtgtnStallTblY[_main_gen_tmp_20_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr3NonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr3NonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_21_0;
            
            for (_main_gen_tmp_21_0 = 0; _main_gen_tmp_21_0 < 5; _main_gen_tmp_21_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr3NonStallTblY[_main_gen_tmp_21_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr3StallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr3StallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_22_0;
            
            for (_main_gen_tmp_22_0 = 0; _main_gen_tmp_22_0 < 5; _main_gen_tmp_22_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr3StallTblY[_main_gen_tmp_22_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr4FetMtgtnNonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr4FetMtgtnNonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_23_0;
            
            for (_main_gen_tmp_23_0 = 0; _main_gen_tmp_23_0 < 5; _main_gen_tmp_23_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr4FetMtgtnNonStallTblY[_main_gen_tmp_23_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr4FetMtgtnStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr4FetMtgtnStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_24_0;
            
            for (_main_gen_tmp_24_0 = 0; _main_gen_tmp_24_0 < 5; _main_gen_tmp_24_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr4FetMtgtnStallTblY[_main_gen_tmp_24_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr4NonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr4NonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_25_0;
            
            for (_main_gen_tmp_25_0 = 0; _main_gen_tmp_25_0 < 5; _main_gen_tmp_25_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr4NonStallTblY[_main_gen_tmp_25_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr4StallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr4StallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_26_0;
            
            for (_main_gen_tmp_26_0 = 0; _main_gen_tmp_26_0 < 5; _main_gen_tmp_26_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr4StallTblY[_main_gen_tmp_26_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr5FetMtgtnNonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr5FetMtgtnNonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_27_0;
            
            for (_main_gen_tmp_27_0 = 0; _main_gen_tmp_27_0 < 5; _main_gen_tmp_27_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr5FetMtgtnNonStallTblY[_main_gen_tmp_27_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr5FetMtgtnStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr5FetMtgtnStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_28_0;
            
            for (_main_gen_tmp_28_0 = 0; _main_gen_tmp_28_0 < 5; _main_gen_tmp_28_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr5FetMtgtnStallTblY[_main_gen_tmp_28_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr5NonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr5NonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_29_0;
            
            for (_main_gen_tmp_29_0 = 0; _main_gen_tmp_29_0 < 5; _main_gen_tmp_29_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr5NonStallTblY[_main_gen_tmp_29_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr5StallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr5StallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_30_0;
            
            for (_main_gen_tmp_30_0 = 0; _main_gen_tmp_30_0 < 5; _main_gen_tmp_30_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr5StallTblY[_main_gen_tmp_30_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr6FetMtgtnNonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr6FetMtgtnNonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_31_0;
            
            for (_main_gen_tmp_31_0 = 0; _main_gen_tmp_31_0 < 5; _main_gen_tmp_31_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr6FetMtgtnNonStallTblY[_main_gen_tmp_31_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr6FetMtgtnStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr6FetMtgtnStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_32_0;
            
            for (_main_gen_tmp_32_0 = 0; _main_gen_tmp_32_0 < 5; _main_gen_tmp_32_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr6FetMtgtnStallTblY[_main_gen_tmp_32_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr6NonStallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr6NonStallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_33_0;
            
            for (_main_gen_tmp_33_0 = 0; _main_gen_tmp_33_0 < 5; _main_gen_tmp_33_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr6NonStallTblY[_main_gen_tmp_33_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr6StallTblY(void)
{
    extern __PST__g__34 DutyCycThermProtn_Cal_DutyCycThermProtnMplr6StallTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_34_0;
            
            for (_main_gen_tmp_34_0 = 0; _main_gen_tmp_34_0 < 5; _main_gen_tmp_34_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplr6StallTblY[_main_gen_tmp_34_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplrFetMtgtnTblX(void)
{
    extern __PST__g__35 DutyCycThermProtn_Cal_DutyCycThermProtnMplrFetMtgtnTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_35_0;
            
            for (_main_gen_tmp_35_0 = 0; _main_gen_tmp_35_0 < 5; _main_gen_tmp_35_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplrFetMtgtnTblX[_main_gen_tmp_35_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplrTSeln(void)
{
    extern __PST__g__31 DutyCycThermProtn_Cal_DutyCycThermProtnMplrTSeln;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnMplrTSeln = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplrTblX(void)
{
    extern __PST__g__35 DutyCycThermProtn_Cal_DutyCycThermProtnMplrTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_36_0;
            
            for (_main_gen_tmp_36_0 = 0; _main_gen_tmp_36_0 < 5; _main_gen_tmp_36_0++)
            {
                /* base type */
                DutyCycThermProtn_Cal_DutyCycThermProtnMplrTblX[_main_gen_tmp_36_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnSlowFilTSeln(void)
{
    extern __PST__g__31 DutyCycThermProtn_Cal_DutyCycThermProtnSlowFilTSeln;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnSlowFilTSeln = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnThermLimScaFac(void)
{
    extern __PST__g__30 DutyCycThermProtn_Cal_DutyCycThermProtnThermLimScaFac;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnThermLimScaFac = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnThermLoadLimTblX(void)
{
    extern __PST__g__36 DutyCycThermProtn_Cal_DutyCycThermProtnThermLoadLimTblX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_37_0;
            
            for (_main_gen_tmp_37_0 = 0; _main_gen_tmp_37_0 < 8; _main_gen_tmp_37_0++)
            {
                __PST__UINT32 _main_gen_tmp_37_1;
                
                for (_main_gen_tmp_37_1 = 0; _main_gen_tmp_37_1 < 2; _main_gen_tmp_37_1++)
                {
                    /* base type */
                    DutyCycThermProtn_Cal_DutyCycThermProtnThermLoadLimTblX[_main_gen_tmp_37_0][_main_gen_tmp_37_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnThermLoadLimTblY(void)
{
    extern __PST__g__36 DutyCycThermProtn_Cal_DutyCycThermProtnThermLoadLimTblY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_38_0;
            
            for (_main_gen_tmp_38_0 = 0; _main_gen_tmp_38_0 < 8; _main_gen_tmp_38_0++)
            {
                __PST__UINT32 _main_gen_tmp_38_1;
                
                for (_main_gen_tmp_38_1 = 0; _main_gen_tmp_38_1 < 2; _main_gen_tmp_38_1++)
                {
                    /* base type */
                    DutyCycThermProtn_Cal_DutyCycThermProtnThermLoadLimTblY[_main_gen_tmp_38_0][_main_gen_tmp_38_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnTqCmdSlewDwn(void)
{
    extern __PST__g__30 DutyCycThermProtn_Cal_DutyCycThermProtnTqCmdSlewDwn;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnTqCmdSlewDwn = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnTqCmdSlewUp(void)
{
    extern __PST__g__30 DutyCycThermProtn_Cal_DutyCycThermProtnTqCmdSlewUp;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Cal_DutyCycThermProtnTqCmdSlewUp = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_FilStVal(void)
{
    extern struct __PST__g__37 DutyCycThermProtn_Pim_FilStVal;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_FilStVal = _main_gen_init_g37();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_AbsltTLimSlewStVari(void)
{
    extern __PST__FLOAT32 DutyCycThermProtn_Pim_AbsltTLimSlewStVari;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_AbsltTLimSlewStVari = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_FetLoaMtgtnEnaPrev(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Pim_FetLoaMtgtnEnaPrev;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_FetLoaMtgtnEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_FetMtgtnEnaCalIdx(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Pim_FetMtgtnEnaCalIdx;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_FetMtgtnEnaCalIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_Fil1ValStVari(void)
{
    extern struct __PST__g__38 DutyCycThermProtn_Pim_Fil1ValStVari;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_Fil1ValStVari = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_Fil2ValStVari(void)
{
    extern struct __PST__g__38 DutyCycThermProtn_Pim_Fil2ValStVari;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_Fil2ValStVari = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_Fil3ValPwrUp(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Pim_Fil3ValPwrUp;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_Fil3ValPwrUp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_Fil4ValPwrUp(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Pim_Fil4ValPwrUp;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_Fil4ValPwrUp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_Fil5ValPwrUp(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Pim_Fil5ValPwrUp;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_Fil5ValPwrUp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_Fil6ValPwrUp(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Pim_Fil6ValPwrUp;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_Fil6ValPwrUp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_Fild3Val(void)
{
    extern struct __PST__g__38 DutyCycThermProtn_Pim_Fild3Val;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_Fild3Val = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_Fild4Val(void)
{
    extern struct __PST__g__38 DutyCycThermProtn_Pim_Fild4Val;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_Fild4Val = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_Fild5Val(void)
{
    extern struct __PST__g__38 DutyCycThermProtn_Pim_Fild5Val;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_Fild5Val = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_Fild6Val(void)
{
    extern struct __PST__g__38 DutyCycThermProtn_Pim_Fild6Val;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_Fild6Val = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_LstTblValRateLimrStVari(void)
{
    extern __PST__FLOAT32 DutyCycThermProtn_Pim_LstTblValRateLimrStVari;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_LstTblValRateLimrStVari = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_ReInitCntrFlg(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Pim_ReInitCntrFlg;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_ReInitCntrFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Pim_ReInitCntrVal(void)
{
    extern __PST__FLOAT32 DutyCycThermProtn_Pim_ReInitCntrVal;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Pim_ReInitCntrVal = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Irv_FilStVariReInitFlg(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Irv_FilStVariReInitFlg;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Irv_FilStVariReInitFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Srv_FilStVal_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Srv_FilStVal_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Srv_FilStVal_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Srv_FilStVal_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Srv_FilStVal_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Srv_FilStVal_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Srv_FilStVal_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Srv_FilStVal_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Srv_FilStVal_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DutyCycThermProtn_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 DutyCycThermProtn_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        DutyCycThermProtn_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable DutyCycThermProtn_Ip_DiagcStsLimdTPrfmnc */
    _main_gen_init_sym_DutyCycThermProtn_Ip_DiagcStsLimdTPrfmnc();
    
    /* init for variable DutyCycThermProtn_Ip_DualEcuFltMtgtnEna */
    _main_gen_init_sym_DutyCycThermProtn_Ip_DualEcuFltMtgtnEna();
    
    /* init for variable DutyCycThermProtn_Ip_DutyCycThermProtnDi */
    _main_gen_init_sym_DutyCycThermProtn_Ip_DutyCycThermProtnDi();
    
    /* init for variable DutyCycThermProtn_Ip_EcuTFild */
    _main_gen_init_sym_DutyCycThermProtn_Ip_EcuTFild();
    
    /* init for variable DutyCycThermProtn_Ip_IgnTiOff */
    _main_gen_init_sym_DutyCycThermProtn_Ip_IgnTiOff();
    
    /* init for variable DutyCycThermProtn_Ip_MotAndThermProtnLoaMod */
    _main_gen_init_sym_DutyCycThermProtn_Ip_MotAndThermProtnLoaMod();
    
    /* init for variable DutyCycThermProtn_Ip_MotCurrPeakEstimd */
    _main_gen_init_sym_DutyCycThermProtn_Ip_MotCurrPeakEstimd();
    
    /* init for variable DutyCycThermProtn_Ip_MotCurrPeakEstimdFild */
    _main_gen_init_sym_DutyCycThermProtn_Ip_MotCurrPeakEstimdFild();
    
    /* init for variable DutyCycThermProtn_Ip_MotFetT */
    _main_gen_init_sym_DutyCycThermProtn_Ip_MotFetT();
    
    /* init for variable DutyCycThermProtn_Ip_MotMagT */
    _main_gen_init_sym_DutyCycThermProtn_Ip_MotMagT();
    
    /* init for variable DutyCycThermProtn_Ip_MotVelCrf */
    _main_gen_init_sym_DutyCycThermProtn_Ip_MotVelCrf();
    
    /* init for variable DutyCycThermProtn_Ip_MotWidgT */
    _main_gen_init_sym_DutyCycThermProtn_Ip_MotWidgT();
    
    /* init for variable DutyCycThermProtn_Ip_VehTiVld */
    _main_gen_init_sym_DutyCycThermProtn_Ip_VehTiVld();
    
    /* init for variable DutyCycThermProtn_Op_DutyCycThermProtnMaxOutp : useless (never read) */

    /* init for variable DutyCycThermProtn_Op_ThermDutyCycProtnLoadDptLim : useless (never read) */

    /* init for variable DutyCycThermProtn_Op_ThermDutyCycProtnTDptLim : useless (never read) */

    /* init for variable DutyCycThermProtn_Op_ThermLimSlowFilMax : useless (never read) */

    /* init for variable DutyCycThermProtn_Op_ThermMotTqLim : useless (never read) */

    /* init for variable DutyCycThermProtn_Op_ThermRednFac : useless (never read) */

    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTFetMtgtnTblX */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTFetMtgtnTblX();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTblX */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTblX();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTqFetMtgtnTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTqFetMtgtnTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTqTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCtrlTTqTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTFetMtgtnTblX */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTFetMtgtnTblX();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTblX */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTblX();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTqFetMtgtnTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTqFetMtgtnTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTqTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltCuTTqTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltMotVelBreakPt */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltMotVelBreakPt();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltTTqSlewHiLim */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltTTqSlewHiLim();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnAbsltTTqSlewLoLim */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnAbsltTTqSlewLoLim();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnCtrlT */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnCtrlT();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnCtrlTSeln */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnCtrlTSeln();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnDutyCycFildThd */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnDutyCycFildThd();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnIgnOffCtrlEna */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnIgnOffCtrlEna();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnIgnOffMsgWaitTi */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnIgnOffMsgWaitTi();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnLstTblValNonStall */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnLstTblValNonStall();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnLstTblValStall */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnLstTblValStall();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMotPrTSeln */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMotPrTSeln();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr1FetMtgtnNonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr1FetMtgtnNonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr1FetMtgtnStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr1FetMtgtnStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr1NonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr1NonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr1StallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr1StallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr2FetMtgtnNonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr2FetMtgtnNonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr2FetMtgtnStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr2FetMtgtnStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr2NonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr2NonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr2StallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr2StallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr3FetMtgtnNonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr3FetMtgtnNonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr3FetMtgtnStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr3FetMtgtnStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr3NonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr3NonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr3StallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr3StallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr4FetMtgtnNonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr4FetMtgtnNonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr4FetMtgtnStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr4FetMtgtnStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr4NonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr4NonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr4StallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr4StallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr5FetMtgtnNonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr5FetMtgtnNonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr5FetMtgtnStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr5FetMtgtnStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr5NonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr5NonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr5StallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr5StallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr6FetMtgtnNonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr6FetMtgtnNonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr6FetMtgtnStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr6FetMtgtnStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr6NonStallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr6NonStallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplr6StallTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplr6StallTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplrFetMtgtnTblX */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplrFetMtgtnTblX();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplrTSeln */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplrTSeln();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnMplrTblX */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnMplrTblX();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnSlowFilTSeln */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnSlowFilTSeln();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnThermLimScaFac */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnThermLimScaFac();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnThermLoadLimTblX */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnThermLoadLimTblX();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnThermLoadLimTblY */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnThermLoadLimTblY();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnTqCmdSlewDwn */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnTqCmdSlewDwn();
    
    /* init for variable DutyCycThermProtn_Cal_DutyCycThermProtnTqCmdSlewUp */
    _main_gen_init_sym_DutyCycThermProtn_Cal_DutyCycThermProtnTqCmdSlewUp();
    
    /* init for variable DutyCycThermProtn_Pim_FilStVal */
    _main_gen_init_sym_DutyCycThermProtn_Pim_FilStVal();
    
    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnAbsltCtrlrTTqLim : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnAbsltCuTTqLim : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnAbsltTTqLim : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnLstTblVal : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnLstTblValSlew : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnMplr1 : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnMplr12T : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnMplr2 : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnMplr3 : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnMplr36T : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnMplr4 : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnMplr5 : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnMplr6 : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnThermLoadLim : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_dDutyCycThermProtnThermLoadLimTblYVal : useless (never read) */

    /* init for variable DutyCycThermProtn_Pim_AbsltTLimSlewStVari */
    _main_gen_init_sym_DutyCycThermProtn_Pim_AbsltTLimSlewStVari();
    
    /* init for variable DutyCycThermProtn_Pim_FetLoaMtgtnEnaPrev */
    _main_gen_init_sym_DutyCycThermProtn_Pim_FetLoaMtgtnEnaPrev();
    
    /* init for variable DutyCycThermProtn_Pim_FetMtgtnEnaCalIdx */
    _main_gen_init_sym_DutyCycThermProtn_Pim_FetMtgtnEnaCalIdx();
    
    /* init for variable DutyCycThermProtn_Pim_Fil1ValStVari */
    _main_gen_init_sym_DutyCycThermProtn_Pim_Fil1ValStVari();
    
    /* init for variable DutyCycThermProtn_Pim_Fil2ValStVari */
    _main_gen_init_sym_DutyCycThermProtn_Pim_Fil2ValStVari();
    
    /* init for variable DutyCycThermProtn_Pim_Fil3ValPwrUp */
    _main_gen_init_sym_DutyCycThermProtn_Pim_Fil3ValPwrUp();
    
    /* init for variable DutyCycThermProtn_Pim_Fil4ValPwrUp */
    _main_gen_init_sym_DutyCycThermProtn_Pim_Fil4ValPwrUp();
    
    /* init for variable DutyCycThermProtn_Pim_Fil5ValPwrUp */
    _main_gen_init_sym_DutyCycThermProtn_Pim_Fil5ValPwrUp();
    
    /* init for variable DutyCycThermProtn_Pim_Fil6ValPwrUp */
    _main_gen_init_sym_DutyCycThermProtn_Pim_Fil6ValPwrUp();
    
    /* init for variable DutyCycThermProtn_Pim_Fild3Val */
    _main_gen_init_sym_DutyCycThermProtn_Pim_Fild3Val();
    
    /* init for variable DutyCycThermProtn_Pim_Fild4Val */
    _main_gen_init_sym_DutyCycThermProtn_Pim_Fild4Val();
    
    /* init for variable DutyCycThermProtn_Pim_Fild5Val */
    _main_gen_init_sym_DutyCycThermProtn_Pim_Fild5Val();
    
    /* init for variable DutyCycThermProtn_Pim_Fild6Val */
    _main_gen_init_sym_DutyCycThermProtn_Pim_Fild6Val();
    
    /* init for variable DutyCycThermProtn_Pim_LstTblValRateLimrStVari */
    _main_gen_init_sym_DutyCycThermProtn_Pim_LstTblValRateLimrStVari();
    
    /* init for variable DutyCycThermProtn_Pim_ReInitCntrFlg */
    _main_gen_init_sym_DutyCycThermProtn_Pim_ReInitCntrFlg();
    
    /* init for variable DutyCycThermProtn_Pim_ReInitCntrVal */
    _main_gen_init_sym_DutyCycThermProtn_Pim_ReInitCntrVal();
    
    /* init for variable DutyCycThermProtn_Irv_FilStVariReInitFlg */
    _main_gen_init_sym_DutyCycThermProtn_Irv_FilStVariReInitFlg();
    
    /* init for variable DutyCycThermProtn_Srv_FilStVal_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_DutyCycThermProtn_Srv_FilStVal_GetErrorStatus_RequestResultPtr();
    
    /* init for variable DutyCycThermProtn_Srv_FilStVal_GetErrorStatus_Return */
    _main_gen_init_sym_DutyCycThermProtn_Srv_FilStVal_GetErrorStatus_Return();
    
    /* init for variable DutyCycThermProtn_Srv_FilStVal_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable DutyCycThermProtn_Srv_FilStVal_SetRamBlockStatus_Return */
    _main_gen_init_sym_DutyCycThermProtn_Srv_FilStVal_SetRamBlockStatus_Return();
    
    /* init for variable DutyCycThermProtn_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable DutyCycThermProtn_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable DutyCycThermProtn_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable DutyCycThermProtn_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable DutyCycThermProtn_Srv_SetNtcSts_Return */
    _main_gen_init_sym_DutyCycThermProtn_Srv_SetNtcSts_Return();
    
}
