# define WdgMConf_WdgMCheckpoint_ChkPt_10msBSW_Appl10_Strt (0u) 
# define WdgMConf_WdgMCheckpoint_ChkPt_10msBSW_Appl10_End (1u) 

# define WdgMConf_WdgMSupervisedEntity_SE_10msBSW_Appl10 (0u) 
# define WdgMConf_WdgMSupervisedEntity_SE_2ms_Appl10 (1u) 
# define WdgMConf_WdgMSupervisedEntity_SE_4ms_Appl10 (2u) 
# define WdgMConf_WdgMSupervisedEntity_SE_10ms_Appl10 (3u) 
# define WdgMConf_WdgMSupervisedEntity_SE_100ms_Appl10 (4u)
