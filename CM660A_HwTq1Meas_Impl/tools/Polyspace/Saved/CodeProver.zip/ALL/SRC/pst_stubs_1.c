#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__109 _main_gen_init_g109(void);

extern union __PST__g__107 _main_gen_init_g107(void);

extern union __PST__g__83 _main_gen_init_g83(void);

extern struct __PST__g__76 _main_gen_init_g76(void);

extern union __PST__g__75 _main_gen_init_g75(void);

extern struct __PST__g__73 _main_gen_init_g73(void);

extern union __PST__g__71 _main_gen_init_g71(void);

extern union __PST__g__66 _main_gen_init_g66(void);

extern union __PST__g__62 _main_gen_init_g62(void);

extern union __PST__g__59 _main_gen_init_g59(void);

extern union __PST__g__56 _main_gen_init_g56(void);

extern union __PST__g__52 _main_gen_init_g52(void);

extern union __PST__g__47 _main_gen_init_g47(void);

extern union __PST__g__39 _main_gen_init_g39(void);

extern __PST__g__37 _main_gen_init_g37(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__35 _main_gen_init_g35(void);

extern __PST__g__34 _main_gen_init_g34(void);

extern __PST__SINT8 _main_gen_init_g2(void);

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__g__34 _main_gen_init_g34(void)
{
    __PST__g__34 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__35 _main_gen_init_g35(void)
{
    static struct __PST__g__35 x;
    /* struct/union type */
    x.OffsTrim = _main_gen_init_g10();
    x.OffsTrimPrfmdSts = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__39 _main_gen_init_g39(void)
{
    static union __PST__g__39 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__47 _main_gen_init_g47(void)
{
    static union __PST__g__47 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__52 _main_gen_init_g52(void)
{
    static union __PST__g__52 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__56 _main_gen_init_g56(void)
{
    static union __PST__g__56 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__59 _main_gen_init_g59(void)
{
    static union __PST__g__59 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__62 _main_gen_init_g62(void)
{
    static union __PST__g__62 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__66 _main_gen_init_g66(void)
{
    static union __PST__g__66 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__73 _main_gen_init_g73(void)
{
    static struct __PST__g__73 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FRS = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRS = bitf;
    }
    return x;
}

union __PST__g__71 _main_gen_init_g71(void)
{
    static union __PST__g__71 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g73();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__76 _main_gen_init_g76(void)
{
    static struct __PST__g__76 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRC = bitf;
    }
    return x;
}

union __PST__g__75 _main_gen_init_g75(void)
{
    static union __PST__g__75 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g76();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__83 _main_gen_init_g83(void)
{
    static union __PST__g__83 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__109 _main_gen_init_g109(void)
{
    static struct __PST__g__109 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FND = bitf;
    }
    return x;
}

union __PST__g__107 _main_gen_init_g107(void)
{
    static union __PST__g__107 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g109();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__37 _main_gen_init_g37(void)
{
    __PST__g__37 x;
    /* struct/union type */
    x.TSPC = _main_gen_init_g39();
    x._CC = _main_gen_init_g47();
    x.BRP = _main_gen_init_g52();
    x.IDE = _main_gen_init_g56();
    x.MDC = _main_gen_init_g59();
    x.SPCT = _main_gen_init_g62();
    x.MST = _main_gen_init_g66();
    x.CS = _main_gen_init_g71();
    x.CSC = _main_gen_init_g75();
    x.SRXD = _main_gen_init_g83();
    x.FRXD = _main_gen_init_g107();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_HwTq1Meas_Ip_HwTq1Polarity(void)
{
    extern __PST__SINT8 HwTq1Meas_Ip_HwTq1Polarity;
    
    /* initialization with random value */
    {
        HwTq1Meas_Ip_HwTq1Polarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Cal_HwTq1MeasHwTq1PrtclFltFailStep(void)
{
    extern __PST__g__34 HwTq1Meas_Cal_HwTq1MeasHwTq1PrtclFltFailStep;
    
    /* initialization with random value */
    {
        HwTq1Meas_Cal_HwTq1MeasHwTq1PrtclFltFailStep = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Cal_HwTq1MeasHwTq1PrtclFltPassStep(void)
{
    extern __PST__g__34 HwTq1Meas_Cal_HwTq1MeasHwTq1PrtclFltPassStep;
    
    /* initialization with random value */
    {
        HwTq1Meas_Cal_HwTq1MeasHwTq1PrtclFltPassStep = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_HwTq1Offs(void)
{
    extern struct __PST__g__35 HwTq1Meas_Pim_HwTq1Offs;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_HwTq1Offs = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_HwTq1ComStsErrCntr(void)
{
    extern __PST__UINT8 HwTq1Meas_Pim_HwTq1ComStsErrCntr;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_HwTq1ComStsErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_HwTq1IntSnsrErrCntr(void)
{
    extern __PST__UINT8 HwTq1Meas_Pim_HwTq1IntSnsrErrCntr;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_HwTq1IntSnsrErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_HwTq1MeasPrevHwTq1(void)
{
    extern __PST__FLOAT32 HwTq1Meas_Pim_HwTq1MeasPrevHwTq1;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_HwTq1MeasPrevHwTq1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_HwTq1MsgMissRxCnt(void)
{
    extern __PST__UINT32 HwTq1Meas_Pim_HwTq1MsgMissRxCnt;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_HwTq1MsgMissRxCnt = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_HwTq1MeasPrevRollgCntr(void)
{
    extern __PST__UINT8 HwTq1Meas_Pim_HwTq1MeasPrevRollgCntr;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_HwTq1MeasPrevRollgCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_RackLimrCcwEot1(void)
{
    extern __PST__FLOAT32 HwTq1Meas_Pim_RackLimrCcwEot1;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_RackLimrCcwEot1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_RackLimrCwEot1(void)
{
    extern __PST__FLOAT32 HwTq1Meas_Pim_RackLimrCwEot1;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_RackLimrCwEot1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Avl(void)
{
    extern __PST__UINT8 HwTq1Meas_Pim_RackLimrEot1Avl;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_RackLimrEot1Avl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Data0(void)
{
    extern __PST__UINT8 HwTq1Meas_Pim_RackLimrEot1Data0;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_RackLimrEot1Data0 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Data1(void)
{
    extern __PST__UINT8 HwTq1Meas_Pim_RackLimrEot1Data1;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_RackLimrEot1Data1 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Data2(void)
{
    extern __PST__UINT8 HwTq1Meas_Pim_RackLimrEot1Data2;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_RackLimrEot1Data2 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Id2DataReadCmpl(void)
{
    extern __PST__UINT8 HwTq1Meas_Pim_RackLimrEot1Id2DataReadCmpl;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_RackLimrEot1Id2DataReadCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Id3DataReadCmpl(void)
{
    extern __PST__UINT8 HwTq1Meas_Pim_RackLimrEot1Id3DataReadCmpl;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_RackLimrEot1Id3DataReadCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Id4DataReadCmpl(void)
{
    extern __PST__UINT8 HwTq1Meas_Pim_RackLimrEot1Id4DataReadCmpl;
    
    /* initialization with random value */
    {
        HwTq1Meas_Pim_RackLimrEot1Id4DataReadCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RSENT1(void)
{
    extern __PST__g__37 RSENT1;
    
    /* initialization with random value */
    {
        RSENT1 = _main_gen_init_g37();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 HwTq1Meas_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        HwTq1Meas_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 HwTq1Meas_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        HwTq1Meas_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 HwTq1Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        HwTq1Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 HwTq1Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        HwTq1Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Srv_HwTq1Offs_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 HwTq1Meas_Srv_HwTq1Offs_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        HwTq1Meas_Srv_HwTq1Offs_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Srv_IoHwAb_SetFctPrphlHwTq1_Return(void)
{
    extern __PST__UINT8 HwTq1Meas_Srv_IoHwAb_SetFctPrphlHwTq1_Return;
    
    /* initialization with random value */
    {
        HwTq1Meas_Srv_IoHwAb_SetFctPrphlHwTq1_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 HwTq1Meas_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        HwTq1Meas_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Cli_HwTq1MeasHwTq1ReadTrim_HwTqReadTrimData(void)
{
    extern __PST__FLOAT32 HwTq1Meas_Cli_HwTq1MeasHwTq1ReadTrim_HwTqReadTrimData;
    
    /* initialization with random value */
    {
        HwTq1Meas_Cli_HwTq1MeasHwTq1ReadTrim_HwTqReadTrimData = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Cli_HwTq1MeasHwTq1TrimPrfmdSts_HwTqOffsTrimPrfmdStsData(void)
{
    extern __PST__UINT8 HwTq1Meas_Cli_HwTq1MeasHwTq1TrimPrfmdSts_HwTqOffsTrimPrfmdStsData;
    
    /* initialization with random value */
    {
        HwTq1Meas_Cli_HwTq1MeasHwTq1TrimPrfmdSts_HwTqOffsTrimPrfmdStsData = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwTq1Meas_Cli_HwTq1MeasHwTq1WrTrim_HwTqWrOffsTrimData(void)
{
    extern __PST__FLOAT32 HwTq1Meas_Cli_HwTq1MeasHwTq1WrTrim_HwTqWrOffsTrimData;
    
    /* initialization with random value */
    {
        HwTq1Meas_Cli_HwTq1MeasHwTq1WrTrim_HwTqWrOffsTrimData = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable HwTq1Meas_Ip_HwTq1Polarity */
    _main_gen_init_sym_HwTq1Meas_Ip_HwTq1Polarity();
    
    /* init for variable HwTq1Meas_Op_HwTq1 : useless (never read) */

    /* init for variable HwTq1Meas_Op_HwTq1Qlfr : useless (never read) */

    /* init for variable HwTq1Meas_Op_HwTq1RollgCntr : useless (never read) */

    /* init for variable HwTq1Meas_Op_RackLimrCcwEotSig1 : useless (never read) */

    /* init for variable HwTq1Meas_Op_RackLimrCwEotSig1 : useless (never read) */

    /* init for variable HwTq1Meas_Op_RackLimrEotSig1Avl : useless (never read) */

    /* init for variable HwTq1Meas_Cal_HwTq1MeasHwTq1PrtclFltFailStep */
    _main_gen_init_sym_HwTq1Meas_Cal_HwTq1MeasHwTq1PrtclFltFailStep();
    
    /* init for variable HwTq1Meas_Cal_HwTq1MeasHwTq1PrtclFltPassStep */
    _main_gen_init_sym_HwTq1Meas_Cal_HwTq1MeasHwTq1PrtclFltPassStep();
    
    /* init for variable HwTq1Meas_Pim_HwTq1Offs */
    _main_gen_init_sym_HwTq1Meas_Pim_HwTq1Offs();
    
    /* init for variable HwTq1Meas_Pim_HwTq1ComStsErrCntr */
    _main_gen_init_sym_HwTq1Meas_Pim_HwTq1ComStsErrCntr();
    
    /* init for variable HwTq1Meas_Pim_HwTq1IntSnsrErrCntr */
    _main_gen_init_sym_HwTq1Meas_Pim_HwTq1IntSnsrErrCntr();
    
    /* init for variable HwTq1Meas_Pim_HwTq1MeasPrevHwTq1 */
    _main_gen_init_sym_HwTq1Meas_Pim_HwTq1MeasPrevHwTq1();
    
    /* init for variable HwTq1Meas_Pim_HwTq1MsgMissRxCnt */
    _main_gen_init_sym_HwTq1Meas_Pim_HwTq1MsgMissRxCnt();
    
    /* init for variable HwTq1Meas_Pim_HwTq1MeasPrevRollgCntr */
    _main_gen_init_sym_HwTq1Meas_Pim_HwTq1MeasPrevRollgCntr();
    
    /* init for variable HwTq1Meas_Pim_RackLimrCcwEot1 */
    _main_gen_init_sym_HwTq1Meas_Pim_RackLimrCcwEot1();
    
    /* init for variable HwTq1Meas_Pim_RackLimrCwEot1 */
    _main_gen_init_sym_HwTq1Meas_Pim_RackLimrCwEot1();
    
    /* init for variable HwTq1Meas_Pim_RackLimrEot1Avl */
    _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Avl();
    
    /* init for variable HwTq1Meas_Pim_RackLimrEot1Data0 */
    _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Data0();
    
    /* init for variable HwTq1Meas_Pim_RackLimrEot1Data1 */
    _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Data1();
    
    /* init for variable HwTq1Meas_Pim_RackLimrEot1Data2 */
    _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Data2();
    
    /* init for variable HwTq1Meas_Pim_RackLimrEot1Id2DataReadCmpl */
    _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Id2DataReadCmpl();
    
    /* init for variable HwTq1Meas_Pim_RackLimrEot1Id3DataReadCmpl */
    _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Id3DataReadCmpl();
    
    /* init for variable HwTq1Meas_Pim_RackLimrEot1Id4DataReadCmpl */
    _main_gen_init_sym_HwTq1Meas_Pim_RackLimrEot1Id4DataReadCmpl();
    
    /* init for variable RSENT1 */
    _main_gen_init_sym_RSENT1();
    
    /* init for variable HwTq1Meas_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable HwTq1Meas_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_HwTq1Meas_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable HwTq1Meas_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_HwTq1Meas_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable HwTq1Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr */
    _main_gen_init_sym_HwTq1Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr();
    
    /* init for variable HwTq1Meas_Srv_GetTiSpan1MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable HwTq1Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan */
    _main_gen_init_sym_HwTq1Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan();
    
    /* init for variable HwTq1Meas_Srv_HwTq1Offs_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable HwTq1Meas_Srv_HwTq1Offs_SetRamBlockStatus_Return */
    _main_gen_init_sym_HwTq1Meas_Srv_HwTq1Offs_SetRamBlockStatus_Return();
    
    /* init for variable HwTq1Meas_Srv_IoHwAb_SetFctPrphlHwTq1_Return */
    _main_gen_init_sym_HwTq1Meas_Srv_IoHwAb_SetFctPrphlHwTq1_Return();
    
    /* init for variable HwTq1Meas_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable HwTq1Meas_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable HwTq1Meas_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable HwTq1Meas_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable HwTq1Meas_Srv_SetNtcSts_Return */
    _main_gen_init_sym_HwTq1Meas_Srv_SetNtcSts_Return();
    
    /* init for variable HwTq1Meas_Cli_HwTq1MeasHwTq1ReadTrim_HwTqReadTrimData */
    _main_gen_init_sym_HwTq1Meas_Cli_HwTq1MeasHwTq1ReadTrim_HwTqReadTrimData();
    
    /* init for variable HwTq1Meas_Cli_HwTq1MeasHwTq1TrimPrfmdSts_HwTqOffsTrimPrfmdStsData */
    _main_gen_init_sym_HwTq1Meas_Cli_HwTq1MeasHwTq1TrimPrfmdSts_HwTqOffsTrimPrfmdStsData();
    
    /* init for variable HwTq1Meas_Cli_HwTq1MeasHwTq1WrTrim_HwTqWrOffsTrimData */
    _main_gen_init_sym_HwTq1Meas_Cli_HwTq1MeasHwTq1WrTrim_HwTqWrOffsTrimData();
    
}
