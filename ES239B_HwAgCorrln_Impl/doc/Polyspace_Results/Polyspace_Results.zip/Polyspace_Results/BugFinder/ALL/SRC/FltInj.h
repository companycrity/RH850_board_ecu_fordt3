
#ifndef FLTINJ_H
#define FLTINJ_H

/* Fault Injection Command */
#define FLTINJ_HWAGCORRLN_HWAGIDPTSIG           (35U)

#endif
