typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT64 __PST__g__16(void);
typedef __PST__g__11 *__PST__g__18;
typedef volatile __PST__FLOAT64 __PST__g__19;
typedef __PST__SINT8 *__PST__g__21;
typedef volatile __PST__g__21 __PST__g__20;
typedef __PST__VOID __PST__g__22(__PST__SINT32);
typedef __PST__SINT32 __PST__g__130[1];
union __PST__g__25
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__25 __PST__g__24;
typedef volatile __PST__g__24 __PST__g__23;
struct __PST__g__27
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
  };
typedef const struct __PST__g__27 __PST__g__26;
union __PST__g__33
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__33 __PST__g__32;
typedef volatile __PST__g__32 __PST__g__31;
struct __PST__g__35
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
  };
typedef const struct __PST__g__35 __PST__g__34;
union __PST__g__38
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__38 __PST__g__37;
typedef volatile __PST__g__37 __PST__g__36;
struct __PST__g__40
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
  };
typedef const struct __PST__g__40 __PST__g__39;
union __PST__g__43
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__43 __PST__g__42;
typedef volatile __PST__g__42 __PST__g__41;
struct __PST__g__45
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
  };
typedef const struct __PST__g__45 __PST__g__44;
union __PST__g__48
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__48 __PST__g__47;
typedef volatile __PST__g__47 __PST__g__46;
struct __PST__g__50
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
  };
typedef const struct __PST__g__50 __PST__g__49;
union __PST__g__53
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__53 __PST__g__52;
typedef volatile __PST__g__52 __PST__g__51;
struct __PST__g__55
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
  };
typedef const struct __PST__g__55 __PST__g__54;
union __PST__g__58
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__58 __PST__g__57;
typedef volatile __PST__g__57 __PST__g__56;
struct __PST__g__60
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
  };
typedef const struct __PST__g__60 __PST__g__59;
union __PST__g__63
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__63 __PST__g__62;
typedef volatile __PST__g__62 __PST__g__61;
struct __PST__g__65
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
  };
typedef const struct __PST__g__65 __PST__g__64;
union __PST__g__68
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__68 __PST__g__67;
typedef volatile __PST__g__67 __PST__g__66;
struct __PST__g__70
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__70 __PST__g__69;
typedef const __PST__UINT32 __PST__g__71;
union __PST__g__74
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__74 __PST__g__73;
typedef volatile __PST__g__73 __PST__g__72;
struct __PST__g__76
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__76 __PST__g__75;
union __PST__g__80
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__80 __PST__g__79;
typedef volatile __PST__g__79 __PST__g__78;
struct __PST__g__82
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_24 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
    __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__82 __PST__g__81;
union __PST__g__85
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__85 __PST__g__84;
typedef volatile __PST__g__84 __PST__g__83;
struct __PST__g__87
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    const __PST__UINT32 __pst_unused_field_12 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
    const __PST__UINT32 __pst_unused_field_15 : 1;
    const __PST__UINT32 __pst_unused_field_16 : 1;
    const __PST__UINT32 __pst_unused_field_17 : 1;
    const __PST__UINT32 __pst_unused_field_18 : 1;
    const __PST__UINT32 __pst_unused_field_19 : 1;
    const __PST__UINT32 __pst_unused_field_20 : 1;
    const __PST__UINT32 __pst_unused_field_21 : 1;
    const __PST__UINT32 __pst_unused_field_22 : 1;
    const __PST__UINT32 __pst_unused_field_23 : 1;
    const __PST__UINT32 __pst_unused_field_24 : 1;
    const __PST__UINT32 __pst_unused_field_25 : 1;
    const __PST__UINT32 __pst_unused_field_26 : 1;
    const __PST__UINT32 __pst_unused_field_27 : 1;
    const __PST__UINT32 __pst_unused_field_28 : 1;
    const __PST__UINT32 __pst_unused_field_29 : 1;
    const __PST__UINT32 __pst_unused_field_30 : 1;
    const __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__87 __PST__g__86;
union __PST__g__90
  {
    __PST__g__130 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__90 __PST__g__89;
typedef volatile __PST__g__89 __PST__g__88;
struct __PST__g__92
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    const __PST__UINT32 __pst_unused_field_12 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
    const __PST__UINT32 __pst_unused_field_15 : 1;
    const __PST__UINT32 __pst_unused_field_16 : 1;
    const __PST__UINT32 __pst_unused_field_17 : 1;
    const __PST__UINT32 __pst_unused_field_18 : 1;
    const __PST__UINT32 __pst_unused_field_19 : 1;
    const __PST__UINT32 __pst_unused_field_20 : 1;
    const __PST__UINT32 __pst_unused_field_21 : 1;
    const __PST__UINT32 __pst_unused_field_22 : 1;
    const __PST__UINT32 __pst_unused_field_23 : 1;
    const __PST__UINT32 __pst_unused_field_24 : 1;
    const __PST__UINT32 __pst_unused_field_25 : 1;
    const __PST__UINT32 __pst_unused_field_26 : 1;
    const __PST__UINT32 __pst_unused_field_27 : 1;
    const __PST__UINT32 __pst_unused_field_28 : 1;
    const __PST__UINT32 __pst_unused_field_29 : 1;
    const __PST__UINT32 __pst_unused_field_30 : 1;
    const __PST__UINT32 __pst_unused_field_31 : 1;
  };
typedef const struct __PST__g__92 __PST__g__91;
typedef __PST__VOID __PST__g__93(__PST__UINT32, __PST__UINT32);
typedef __PST__UINT32 *__PST__g__95;
typedef __PST__VOID __PST__g__94(__PST__g__95);
typedef __PST__g__94 *__PST__g__96;
typedef __PST__g__72 *__PST__g__97;
typedef volatile __PST__g__71 __PST__g__98;
typedef __PST__g__98 *__PST__g__99;
typedef __PST__g__78 *__PST__g__100;
typedef __PST__g__66 *__PST__g__101;
typedef __PST__g__22 *__PST__g__102;
typedef __PST__g__93 *__PST__g__103;
typedef __PST__g__23 *__PST__g__104;
typedef __PST__g__46 *__PST__g__105;
typedef __PST__g__31 *__PST__g__106;
typedef __PST__g__51 *__PST__g__107;
typedef __PST__g__36 *__PST__g__108;
typedef __PST__g__56 *__PST__g__109;
typedef __PST__g__41 *__PST__g__110;
typedef __PST__g__61 *__PST__g__111;
typedef __PST__g__83 *__PST__g__112;
typedef __PST__g__88 *__PST__g__113;
typedef __PST__SINT32 __PST__g__114();
typedef __PST__g__114 *__PST__g__115;
typedef __PST__g__15 *__PST__g__116;
typedef volatile __PST__SINT32 __PST__g__117;
typedef __PST__SINT8 __PST__g__123(void);
typedef volatile __PST__SINT8 __PST__g__124;
typedef __PST__UINT8 __PST__g__125(void);
typedef volatile __PST__UINT8 __PST__g__126;
typedef __PST__SINT32 __PST__g__127(void);
typedef __PST__UINT32 __PST__g__128(void);
typedef volatile __PST__UINT32 __PST__g__129;
