#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__88 _main_gen_init_g88(void);

extern __PST__g__83 _main_gen_init_g83(void);

extern __PST__g__78 _main_gen_init_g78(void);

extern __PST__g__72 _main_gen_init_g72(void);

extern __PST__g__66 _main_gen_init_g66(void);

extern __PST__g__61 _main_gen_init_g61(void);

extern __PST__g__56 _main_gen_init_g56(void);

extern __PST__g__51 _main_gen_init_g51(void);

extern __PST__g__46 _main_gen_init_g46(void);

extern __PST__g__41 _main_gen_init_g41(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__g__31 _main_gen_init_g31(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__23 _main_gen_init_g23(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__31 _main_gen_init_g31(void)
{
    __PST__g__31 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__41 _main_gen_init_g41(void)
{
    __PST__g__41 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__46 _main_gen_init_g46(void)
{
    __PST__g__46 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__51 _main_gen_init_g51(void)
{
    __PST__g__51 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__56 _main_gen_init_g56(void)
{
    __PST__g__56 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__61 _main_gen_init_g61(void)
{
    __PST__g__61 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__66 _main_gen_init_g66(void)
{
    __PST__g__66 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__72 _main_gen_init_g72(void)
{
    __PST__g__72 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__78 _main_gen_init_g78(void)
{
    __PST__g__78 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__83 _main_gen_init_g83(void)
{
    __PST__g__83 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__88 _main_gen_init_g88(void)
{
    __PST__g__88 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_LBISTREF1_BASE(void)
{
    extern __PST__g__23 LBISTREF1_BASE;
    
    /* initialization with random value */
    {
        LBISTREF1_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_LBISTREF2_BASE(void)
{
    extern __PST__g__31 LBISTREF2_BASE;
    
    /* initialization with random value */
    {
        LBISTREF2_BASE = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_MBISTREF1_BASE(void)
{
    extern __PST__g__36 MBISTREF1_BASE;
    
    /* initialization with random value */
    {
        MBISTREF1_BASE = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_MBISTREF2_BASE(void)
{
    extern __PST__g__41 MBISTREF2_BASE;
    
    /* initialization with random value */
    {
        MBISTREF2_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_LBISTSIG1_BASE(void)
{
    extern __PST__g__46 LBISTSIG1_BASE;
    
    /* initialization with random value */
    {
        LBISTSIG1_BASE = _main_gen_init_g46();
    }
}

static void _main_gen_init_sym_LBISTSIG2_BASE(void)
{
    extern __PST__g__51 LBISTSIG2_BASE;
    
    /* initialization with random value */
    {
        LBISTSIG2_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_MBISTSIG1_BASE(void)
{
    extern __PST__g__56 MBISTSIG1_BASE;
    
    /* initialization with random value */
    {
        MBISTSIG1_BASE = _main_gen_init_g56();
    }
}

static void _main_gen_init_sym_MBISTSIG2_BASE(void)
{
    extern __PST__g__61 MBISTSIG2_BASE;
    
    /* initialization with random value */
    {
        MBISTSIG2_BASE = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_MBISTFTAGL1_BASE(void)
{
    extern __PST__g__66 MBISTFTAGL1_BASE;
    
    /* initialization with random value */
    {
        MBISTFTAGL1_BASE = _main_gen_init_g66();
    }
}

static void _main_gen_init_sym_BSEQ0ST_BASE(void)
{
    extern __PST__g__72 BSEQ0ST_BASE;
    
    /* initialization with random value */
    {
        BSEQ0ST_BASE = _main_gen_init_g72();
    }
}

static void _main_gen_init_sym_BSEQ0STB_BASE(void)
{
    extern __PST__g__78 BSEQ0STB_BASE;
    
    /* initialization with random value */
    {
        BSEQ0STB_BASE = _main_gen_init_g78();
    }
}

static void _main_gen_init_sym_ECMM0ESSTR2_BASE(void)
{
    extern __PST__g__83 ECMM0ESSTR2_BASE;
    
    /* initialization with random value */
    {
        ECMM0ESSTR2_BASE = _main_gen_init_g83();
    }
}

static void _main_gen_init_sym_ECMC0ESSTR2_BASE(void)
{
    extern __PST__g__88 ECMC0ESSTR2_BASE;
    
    /* initialization with random value */
    {
        ECMC0ESSTR2_BASE = _main_gen_init_g88();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable McuCoreCfgAndDiagc_Pim_dMcuCoreCfgAndDiagcBistRunCmpl : useless (never read) */

    /* init for variable LBISTREF1_BASE */
    _main_gen_init_sym_LBISTREF1_BASE();
    
    /* init for variable LBISTREF2_BASE */
    _main_gen_init_sym_LBISTREF2_BASE();
    
    /* init for variable MBISTREF1_BASE */
    _main_gen_init_sym_MBISTREF1_BASE();
    
    /* init for variable MBISTREF2_BASE */
    _main_gen_init_sym_MBISTREF2_BASE();
    
    /* init for variable LBISTSIG1_BASE */
    _main_gen_init_sym_LBISTSIG1_BASE();
    
    /* init for variable LBISTSIG2_BASE */
    _main_gen_init_sym_LBISTSIG2_BASE();
    
    /* init for variable MBISTSIG1_BASE */
    _main_gen_init_sym_MBISTSIG1_BASE();
    
    /* init for variable MBISTSIG2_BASE */
    _main_gen_init_sym_MBISTSIG2_BASE();
    
    /* init for variable MBISTFTAGL1_BASE */
    _main_gen_init_sym_MBISTFTAGL1_BASE();
    
    /* init for variable BSEQ0ST_BASE */
    _main_gen_init_sym_BSEQ0ST_BASE();
    
    /* init for variable BSEQ0STB_BASE */
    _main_gen_init_sym_BSEQ0STB_BASE();
    
    /* init for variable ECMM0ESSTR2_BASE */
    _main_gen_init_sym_ECMM0ESSTR2_BASE();
    
    /* init for variable ECMC0ESSTR2_BASE */
    _main_gen_init_sym_ECMC0ESSTR2_BASE();
    
}
