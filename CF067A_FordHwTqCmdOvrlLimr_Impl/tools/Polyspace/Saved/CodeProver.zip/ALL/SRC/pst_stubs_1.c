#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct Rte_CDS_FordHwTqCmdOvrlLimr _main_gen_init_g25(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct Rte_CDS_FordHwTqCmdOvrlLimr _main_gen_init_g25(void)
{
    static struct Rte_CDS_FordHwTqCmdOvrlLimr x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g10();
        }
        x.Pim_LkaTqReqPrev = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_4[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g10();
        }
        x.Pim_PrevVehSpd = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g10();
        }
        x.Pim_TqReqPrev = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_FordHwTqCmdOvrlLimr(void)
{
    extern __PST__g__22 Rte_Inst_FordHwTqCmdOvrlLimr;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_FordHwTqCmdOvrlLimr _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_FordHwTqCmdOvrlLimr)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_FordHwTqCmdOvrlLimr); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g25();
            }
            Rte_Inst_FordHwTqCmdOvrlLimr = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_FordHwTqCmdOvrlLimr) / 2];
        }
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_EcuId(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Ip_EcuId;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_EcuId = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FildVehSpd(void)
{
    extern __PST__FLOAT32 FordHwTqCmdOvrlLimr_Ip_FildVehSpd;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_FildVehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnArbnCmd(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnArbnCmd;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnArbnCmd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnFctCallSts(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnFctCallSts;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnFctCallSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnTqReq(void)
{
    extern __PST__FLOAT32 FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnTqReq;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnTqReq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiArbnCmd(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiArbnCmd;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiArbnCmd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiFctCallSts(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiFctCallSts;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiFctCallSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiTqReq(void)
{
    extern __PST__FLOAT32 FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiTqReq;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiTqReq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiArbnCmd(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiArbnCmd;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiArbnCmd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiFctCallSts(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiFctCallSts;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiFctCallSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiTqReq(void)
{
    extern __PST__FLOAT32 FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiTqReq;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiTqReq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_VehSpdVld(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Ip_VehSpdVld;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Ip_VehSpdVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdBwY(void)
{
    extern __PST__g__28 FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdBwY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 8; _main_gen_tmp_8_0++)
            {
                /* base type */
                FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdBwY[_main_gen_tmp_8_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdTqRateY(void)
{
    extern __PST__g__28 FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdTqRateY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 8; _main_gen_tmp_9_0++)
            {
                /* base type */
                FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdTqRateY[_main_gen_tmp_9_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdTqSatnY(void)
{
    extern __PST__g__28 FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdTqSatnY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 8; _main_gen_tmp_10_0++)
            {
                /* base type */
                FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdTqSatnY[_main_gen_tmp_10_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdVehSpdBreakPtX(void)
{
    extern __PST__g__28 FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdVehSpdBreakPtX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 8; _main_gen_tmp_11_0++)
            {
                /* base type */
                FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdVehSpdBreakPtX[_main_gen_tmp_11_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrDftSpdRate(void)
{
    extern __PST__g__30 FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrDftSpdRate;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrDftSpdRate = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrDftSpdRcvrRate(void)
{
    extern __PST__g__30 FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrDftSpdRcvrRate;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrDftSpdRcvrRate = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaBwY(void)
{
    extern __PST__g__28 FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaBwY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 8; _main_gen_tmp_12_0++)
            {
                /* base type */
                FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaBwY[_main_gen_tmp_12_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaTqRateY(void)
{
    extern __PST__g__28 FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaTqRateY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 8; _main_gen_tmp_13_0++)
            {
                /* base type */
                FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaTqRateY[_main_gen_tmp_13_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaTqSatnY(void)
{
    extern __PST__g__28 FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaTqSatnY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_14_0;
            
            for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 8; _main_gen_tmp_14_0++)
            {
                /* base type */
                FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaTqSatnY[_main_gen_tmp_14_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrVehSpdBreakPtX(void)
{
    extern __PST__g__28 FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrVehSpdBreakPtX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 8; _main_gen_tmp_15_0++)
            {
                /* base type */
                FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrVehSpdBreakPtX[_main_gen_tmp_15_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Pim_LimrDftVehSpd(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Pim_LimrDftVehSpd;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Pim_LimrDftVehSpd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Pim_LimrVehSpdPrev(void)
{
    extern __PST__FLOAT32 FordHwTqCmdOvrlLimr_Pim_LimrVehSpdPrev;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Pim_LimrVehSpdPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Pim_PrevDftVehSpd(void)
{
    extern __PST__FLOAT32 FordHwTqCmdOvrlLimr_Pim_PrevDftVehSpd;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Pim_PrevDftVehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_DrvrSteerRcmdnFctCallSts(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Irv_DrvrSteerRcmdnFctCallSts;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Irv_DrvrSteerRcmdnFctCallSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_DrvrSteerRcmdnTqReq(void)
{
    extern __PST__FLOAT32 FordHwTqCmdOvrlLimr_Irv_DrvrSteerRcmdnTqReq;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Irv_DrvrSteerRcmdnTqReq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_EvasSteerAssiFctCallSts(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Irv_EvasSteerAssiFctCallSts;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Irv_EvasSteerAssiFctCallSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_EvasSteerAssiTqReq(void)
{
    extern __PST__FLOAT32 FordHwTqCmdOvrlLimr_Irv_EvasSteerAssiTqReq;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Irv_EvasSteerAssiTqReq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_FildVehSpdVal(void)
{
    extern __PST__FLOAT32 FordHwTqCmdOvrlLimr_Irv_FildVehSpdVal;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Irv_FildVehSpdVal = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_LaneKeepAssiFctCallSts(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Irv_LaneKeepAssiFctCallSts;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Irv_LaneKeepAssiFctCallSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_LaneKeepAssiTqReq(void)
{
    extern __PST__FLOAT32 FordHwTqCmdOvrlLimr_Irv_LaneKeepAssiTqReq;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Irv_LaneKeepAssiTqReq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_VehSpdVldVal(void)
{
    extern __PST__UINT8 FordHwTqCmdOvrlLimr_Irv_VehSpdVldVal;
    
    /* initialization with random value */
    {
        FordHwTqCmdOvrlLimr_Irv_VehSpdVldVal = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_FordHwTqCmdOvrlLimr */
    _main_gen_init_sym_Rte_Inst_FordHwTqCmdOvrlLimr();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_EcuId */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_EcuId();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_FildVehSpd */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FildVehSpd();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnArbnCmd */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnArbnCmd();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnFctCallSts */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnFctCallSts();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnTqReq */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordDrvrSteerRcmdnTqReq();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiArbnCmd */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiArbnCmd();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiFctCallSts */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiFctCallSts();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiTqReq */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordEvasSteerAssiTqReq();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiArbnCmd */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiArbnCmd();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiFctCallSts */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiFctCallSts();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiTqReq */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_FordLaneKeepAssiTqReq();
    
    /* init for variable FordHwTqCmdOvrlLimr_Ip_VehSpdVld */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Ip_VehSpdVld();
    
    /* init for variable FordHwTqCmdOvrlLimr_Op_FordColTqOvrl : useless (never read) */

    /* init for variable FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdBwY */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdBwY();
    
    /* init for variable FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdTqRateY */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdTqRateY();
    
    /* init for variable FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdTqSatnY */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdTqSatnY();
    
    /* init for variable FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdVehSpdBreakPtX */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrCombdVehSpdBreakPtX();
    
    /* init for variable FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrDftSpdRate */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrDftSpdRate();
    
    /* init for variable FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrDftSpdRcvrRate */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrDftSpdRcvrRate();
    
    /* init for variable FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaBwY */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaBwY();
    
    /* init for variable FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaTqRateY */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaTqRateY();
    
    /* init for variable FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaTqSatnY */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrLkaTqSatnY();
    
    /* init for variable FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrVehSpdBreakPtX */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Cal_FordHwTqCmdOvrlLimrVehSpdBreakPtX();
    
    /* init for variable FordHwTqCmdOvrlLimr_Pim_LimrDftVehSpd */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Pim_LimrDftVehSpd();
    
    /* init for variable FordHwTqCmdOvrlLimr_Pim_LimrVehSpdPrev */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Pim_LimrVehSpdPrev();
    
    /* init for variable FordHwTqCmdOvrlLimr_Pim_PrevDftVehSpd */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Pim_PrevDftVehSpd();
    
    /* init for variable FordHwTqCmdOvrlLimr_Irv_DrvrSteerRcmdnFctCallSts */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_DrvrSteerRcmdnFctCallSts();
    
    /* init for variable FordHwTqCmdOvrlLimr_Irv_DrvrSteerRcmdnTqReq */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_DrvrSteerRcmdnTqReq();
    
    /* init for variable FordHwTqCmdOvrlLimr_Irv_EvasSteerAssiFctCallSts */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_EvasSteerAssiFctCallSts();
    
    /* init for variable FordHwTqCmdOvrlLimr_Irv_EvasSteerAssiTqReq */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_EvasSteerAssiTqReq();
    
    /* init for variable FordHwTqCmdOvrlLimr_Irv_FildVehSpdVal */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_FildVehSpdVal();
    
    /* init for variable FordHwTqCmdOvrlLimr_Irv_LaneKeepAssiFctCallSts */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_LaneKeepAssiFctCallSts();
    
    /* init for variable FordHwTqCmdOvrlLimr_Irv_LaneKeepAssiTqReq */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_LaneKeepAssiTqReq();
    
    /* init for variable FordHwTqCmdOvrlLimr_Irv_VehSpdVldVal */
    _main_gen_init_sym_FordHwTqCmdOvrlLimr_Irv_VehSpdVldVal();
    
}
