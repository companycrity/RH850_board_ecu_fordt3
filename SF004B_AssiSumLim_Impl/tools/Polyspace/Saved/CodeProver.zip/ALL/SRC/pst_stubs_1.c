#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__31 _main_gen_init_g31(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

struct __PST__g__31 _main_gen_init_g31(void)
{
    static struct __PST__g__31 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_AssiSumLim_Ip_AssiCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_AssiCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_AssiCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_DampgCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_DampgCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_DampgCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_EotActvCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_EotActvCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_EotActvCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_EotAssiSca(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_EotAssiSca;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_EotAssiSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_EotDampgCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_EotDampgCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_EotDampgCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_EotMotTqLim(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_EotMotTqLim;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_EotMotTqLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_HwTqLoaMtgtnEna(void)
{
    extern __PST__UINT8 AssiSumLim_Ip_HwTqLoaMtgtnEna;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_HwTqLoaMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_MotTqCmdLimDi(void)
{
    extern __PST__UINT8 AssiSumLim_Ip_MotTqCmdLimDi;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_MotTqCmdLimDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_MotTqCmdOvrl(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_MotTqCmdOvrl;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_MotTqCmdOvrl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_MotVelMrf(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_MotVelMrf;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_MotVelMrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_PinionCentrLrnCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_PinionCentrLrnCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_PinionCentrLrnCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_PinionCentrLrnEna(void)
{
    extern __PST__UINT8 AssiSumLim_Ip_PinionCentrLrnEna;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_PinionCentrLrnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_PullCmpCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_PullCmpCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_PullCmpCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_PwrLimrRednFac(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_PwrLimrRednFac;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_PwrLimrRednFac = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_RtnCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_RtnCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_RtnCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_StallMotTqLim(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_StallMotTqLim;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_StallMotTqLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_SysMotTqCmdSca(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_SysMotTqCmdSca;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_SysMotTqCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_ThermMotTqLim(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_ThermMotTqLim;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_ThermMotTqLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_ThermRednFac(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_ThermRednFac;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_ThermRednFac = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_TqLoaCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_TqLoaCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_TqLoaCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_TqSteerMtgtnCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_TqSteerMtgtnCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_TqSteerMtgtnCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_VehSpd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_VehSpdMotTqLim(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_VehSpdMotTqLim;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_VehSpdMotTqLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Ip_WhlImbRejctnCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Ip_WhlImbRejctnCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Ip_WhlImbRejctnCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimBlndCmdSumFrqLimX(void)
{
    extern __PST__g__26 AssiSumLim_Cal_AssiSumLimBlndCmdSumFrqLimX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 2; _main_gen_tmp_2_0++)
            {
                /* base type */
                AssiSumLim_Cal_AssiSumLimBlndCmdSumFrqLimX[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimBlndCmdSumFrqLimY(void)
{
    extern __PST__g__26 AssiSumLim_Cal_AssiSumLimBlndCmdSumFrqLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 2; _main_gen_tmp_3_0++)
            {
                /* base type */
                AssiSumLim_Cal_AssiSumLimBlndCmdSumFrqLimY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimCmdSumFilActv(void)
{
    extern __PST__g__28 AssiSumLim_Cal_AssiSumLimCmdSumFilActv;
    
    /* initialization with random value */
    {
        AssiSumLim_Cal_AssiSumLimCmdSumFilActv = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimHiSpdCmdSumFrqLimX(void)
{
    extern __PST__g__29 AssiSumLim_Cal_AssiSumLimHiSpdCmdSumFrqLimX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 8; _main_gen_tmp_4_0++)
            {
                /* base type */
                AssiSumLim_Cal_AssiSumLimHiSpdCmdSumFrqLimX[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimHiSpdCmdSumFrqLimY(void)
{
    extern __PST__g__29 AssiSumLim_Cal_AssiSumLimHiSpdCmdSumFrqLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 8; _main_gen_tmp_5_0++)
            {
                /* base type */
                AssiSumLim_Cal_AssiSumLimHiSpdCmdSumFrqLimY[_main_gen_tmp_5_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimLoSpdCmdSumFrqLimX(void)
{
    extern __PST__g__29 AssiSumLim_Cal_AssiSumLimLoSpdCmdSumFrqLimX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 8; _main_gen_tmp_6_0++)
            {
                /* base type */
                AssiSumLim_Cal_AssiSumLimLoSpdCmdSumFrqLimX[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimLoSpdCmdSumFrqLimY(void)
{
    extern __PST__g__29 AssiSumLim_Cal_AssiSumLimLoSpdCmdSumFrqLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 8; _main_gen_tmp_7_0++)
            {
                /* base type */
                AssiSumLim_Cal_AssiSumLimLoSpdCmdSumFrqLimY[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimMotVelLpFilFrq(void)
{
    extern __PST__g__30 AssiSumLim_Cal_AssiSumLimMotVelLpFilFrq;
    
    /* initialization with random value */
    {
        AssiSumLim_Cal_AssiSumLimMotVelLpFilFrq = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimNtc0x0C4FailStep(void)
{
    extern __PST__g__27 AssiSumLim_Cal_AssiSumLimNtc0x0C4FailStep;
    
    /* initialization with random value */
    {
        AssiSumLim_Cal_AssiSumLimNtc0x0C4FailStep = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimNtc0x0C4PassStep(void)
{
    extern __PST__g__27 AssiSumLim_Cal_AssiSumLimNtc0x0C4PassStep;
    
    /* initialization with random value */
    {
        AssiSumLim_Cal_AssiSumLimNtc0x0C4PassStep = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimPullCmpLim(void)
{
    extern __PST__g__30 AssiSumLim_Cal_AssiSumLimPullCmpLim;
    
    /* initialization with random value */
    {
        AssiSumLim_Cal_AssiSumLimPullCmpLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_AssiSumLim_Pim_CmdSumInpPrev(void)
{
    extern __PST__FLOAT32 AssiSumLim_Pim_CmdSumInpPrev;
    
    /* initialization with random value */
    {
        AssiSumLim_Pim_CmdSumInpPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Pim_CmdSumOutpPrev(void)
{
    extern __PST__FLOAT32 AssiSumLim_Pim_CmdSumOutpPrev;
    
    /* initialization with random value */
    {
        AssiSumLim_Pim_CmdSumOutpPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Pim_MotVelFilLp(void)
{
    extern struct __PST__g__31 AssiSumLim_Pim_MotVelFilLp;
    
    /* initialization with random value */
    {
        AssiSumLim_Pim_MotVelFilLp = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_AssiSumLim_Irv_ProcdManTqCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Irv_ProcdManTqCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Irv_ProcdManTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Irv_ProcdManTqCmdEna(void)
{
    extern __PST__UINT8 AssiSumLim_Irv_ProcdManTqCmdEna;
    
    /* initialization with random value */
    {
        AssiSumLim_Irv_ProcdManTqCmdEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AssiSumLim_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 AssiSumLim_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        AssiSumLim_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AssiSumLim_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 AssiSumLim_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        AssiSumLim_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AssiSumLim_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 AssiSumLim_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        AssiSumLim_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_AssiSumLim_Cli_SetManTqCmd_ManTqCmd(void)
{
    extern __PST__FLOAT32 AssiSumLim_Cli_SetManTqCmd_ManTqCmd;
    
    /* initialization with random value */
    {
        AssiSumLim_Cli_SetManTqCmd_ManTqCmd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_AssiSumLim_Cli_SetManTqCmd_ManTqCmdEna(void)
{
    extern __PST__UINT8 AssiSumLim_Cli_SetManTqCmd_ManTqCmdEna;
    
    /* initialization with random value */
    {
        AssiSumLim_Cli_SetManTqCmd_ManTqCmdEna = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable AssiSumLim_Ip_AssiCmd */
    _main_gen_init_sym_AssiSumLim_Ip_AssiCmd();
    
    /* init for variable AssiSumLim_Ip_DampgCmd */
    _main_gen_init_sym_AssiSumLim_Ip_DampgCmd();
    
    /* init for variable AssiSumLim_Ip_EotActvCmd */
    _main_gen_init_sym_AssiSumLim_Ip_EotActvCmd();
    
    /* init for variable AssiSumLim_Ip_EotAssiSca */
    _main_gen_init_sym_AssiSumLim_Ip_EotAssiSca();
    
    /* init for variable AssiSumLim_Ip_EotDampgCmd */
    _main_gen_init_sym_AssiSumLim_Ip_EotDampgCmd();
    
    /* init for variable AssiSumLim_Ip_EotMotTqLim */
    _main_gen_init_sym_AssiSumLim_Ip_EotMotTqLim();
    
    /* init for variable AssiSumLim_Ip_HwTqLoaMtgtnEna */
    _main_gen_init_sym_AssiSumLim_Ip_HwTqLoaMtgtnEna();
    
    /* init for variable AssiSumLim_Ip_MotTqCmdLimDi */
    _main_gen_init_sym_AssiSumLim_Ip_MotTqCmdLimDi();
    
    /* init for variable AssiSumLim_Ip_MotTqCmdOvrl */
    _main_gen_init_sym_AssiSumLim_Ip_MotTqCmdOvrl();
    
    /* init for variable AssiSumLim_Ip_MotVelMrf */
    _main_gen_init_sym_AssiSumLim_Ip_MotVelMrf();
    
    /* init for variable AssiSumLim_Ip_PinionCentrLrnCmd */
    _main_gen_init_sym_AssiSumLim_Ip_PinionCentrLrnCmd();
    
    /* init for variable AssiSumLim_Ip_PinionCentrLrnEna */
    _main_gen_init_sym_AssiSumLim_Ip_PinionCentrLrnEna();
    
    /* init for variable AssiSumLim_Ip_PullCmpCmd */
    _main_gen_init_sym_AssiSumLim_Ip_PullCmpCmd();
    
    /* init for variable AssiSumLim_Ip_PwrLimrRednFac */
    _main_gen_init_sym_AssiSumLim_Ip_PwrLimrRednFac();
    
    /* init for variable AssiSumLim_Ip_RtnCmd */
    _main_gen_init_sym_AssiSumLim_Ip_RtnCmd();
    
    /* init for variable AssiSumLim_Ip_StallMotTqLim */
    _main_gen_init_sym_AssiSumLim_Ip_StallMotTqLim();
    
    /* init for variable AssiSumLim_Ip_SysMotTqCmdSca */
    _main_gen_init_sym_AssiSumLim_Ip_SysMotTqCmdSca();
    
    /* init for variable AssiSumLim_Ip_ThermMotTqLim */
    _main_gen_init_sym_AssiSumLim_Ip_ThermMotTqLim();
    
    /* init for variable AssiSumLim_Ip_ThermRednFac */
    _main_gen_init_sym_AssiSumLim_Ip_ThermRednFac();
    
    /* init for variable AssiSumLim_Ip_TqLoaCmd */
    _main_gen_init_sym_AssiSumLim_Ip_TqLoaCmd();
    
    /* init for variable AssiSumLim_Ip_TqSteerMtgtnCmd */
    _main_gen_init_sym_AssiSumLim_Ip_TqSteerMtgtnCmd();
    
    /* init for variable AssiSumLim_Ip_VehSpd */
    _main_gen_init_sym_AssiSumLim_Ip_VehSpd();
    
    /* init for variable AssiSumLim_Ip_VehSpdMotTqLim */
    _main_gen_init_sym_AssiSumLim_Ip_VehSpdMotTqLim();
    
    /* init for variable AssiSumLim_Ip_WhlImbRejctnCmd */
    _main_gen_init_sym_AssiSumLim_Ip_WhlImbRejctnCmd();
    
    /* init for variable AssiSumLim_Op_MotTqCmd : useless (never read) */

    /* init for variable AssiSumLim_Op_MotTqCmdLimdPreStall : useless (never read) */

    /* init for variable AssiSumLim_Op_MotTqCmdLimrMin : useless (never read) */

    /* init for variable AssiSumLim_Op_MotTqCmdPreLim : useless (never read) */

    /* init for variable AssiSumLim_Op_SysProtnRednFac : useless (never read) */

    /* init for variable AssiSumLim_Cal_AssiSumLimBlndCmdSumFrqLimX */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimBlndCmdSumFrqLimX();
    
    /* init for variable AssiSumLim_Cal_AssiSumLimBlndCmdSumFrqLimY */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimBlndCmdSumFrqLimY();
    
    /* init for variable AssiSumLim_Cal_AssiSumLimCmdSumFilActv */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimCmdSumFilActv();
    
    /* init for variable AssiSumLim_Cal_AssiSumLimHiSpdCmdSumFrqLimX */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimHiSpdCmdSumFrqLimX();
    
    /* init for variable AssiSumLim_Cal_AssiSumLimHiSpdCmdSumFrqLimY */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimHiSpdCmdSumFrqLimY();
    
    /* init for variable AssiSumLim_Cal_AssiSumLimLoSpdCmdSumFrqLimX */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimLoSpdCmdSumFrqLimX();
    
    /* init for variable AssiSumLim_Cal_AssiSumLimLoSpdCmdSumFrqLimY */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimLoSpdCmdSumFrqLimY();
    
    /* init for variable AssiSumLim_Cal_AssiSumLimMotVelLpFilFrq */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimMotVelLpFilFrq();
    
    /* init for variable AssiSumLim_Cal_AssiSumLimNtc0x0C4FailStep */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimNtc0x0C4FailStep();
    
    /* init for variable AssiSumLim_Cal_AssiSumLimNtc0x0C4PassStep */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimNtc0x0C4PassStep();
    
    /* init for variable AssiSumLim_Cal_AssiSumLimPullCmpLim */
    _main_gen_init_sym_AssiSumLim_Cal_AssiSumLimPullCmpLim();
    
    /* init for variable AssiSumLim_Pim_CmdSumInpPrev */
    _main_gen_init_sym_AssiSumLim_Pim_CmdSumInpPrev();
    
    /* init for variable AssiSumLim_Pim_CmdSumOutpPrev */
    _main_gen_init_sym_AssiSumLim_Pim_CmdSumOutpPrev();
    
    /* init for variable AssiSumLim_Pim_MotVelFilLp */
    _main_gen_init_sym_AssiSumLim_Pim_MotVelFilLp();
    
    /* init for variable AssiSumLim_Irv_ProcdManTqCmd */
    _main_gen_init_sym_AssiSumLim_Irv_ProcdManTqCmd();
    
    /* init for variable AssiSumLim_Irv_ProcdManTqCmdEna */
    _main_gen_init_sym_AssiSumLim_Irv_ProcdManTqCmdEna();
    
    /* init for variable AssiSumLim_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable AssiSumLim_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_AssiSumLim_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable AssiSumLim_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_AssiSumLim_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable AssiSumLim_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable AssiSumLim_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable AssiSumLim_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable AssiSumLim_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable AssiSumLim_Srv_SetNtcSts_Return */
    _main_gen_init_sym_AssiSumLim_Srv_SetNtcSts_Return();
    
    /* init for variable AssiSumLim_Cli_SetManTqCmd_ManTqCmd */
    _main_gen_init_sym_AssiSumLim_Cli_SetManTqCmd_ManTqCmd();
    
    /* init for variable AssiSumLim_Cli_SetManTqCmd_ManTqCmdEna */
    _main_gen_init_sym_AssiSumLim_Cli_SetManTqCmd_ManTqCmdEna();
    
    /* init for variable AssiSumLim_Cli_SetManTqCmd_Return : useless (never read) */

}
