#ifndef ELECGLBPRM_H
#define ELECGLBPRM_H

/* Extern for config parameter */
extern VAR(uint8, AUTOMATIC)    ELECGLBPRM_IVTRCNT_CNT_U08;

#endif
