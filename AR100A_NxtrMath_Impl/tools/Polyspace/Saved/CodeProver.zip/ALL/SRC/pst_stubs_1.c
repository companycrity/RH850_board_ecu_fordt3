#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_NxtrMath_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 NxtrMath_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        NxtrMath_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Blnd_Inp1(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Blnd_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Blnd_Inp1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Blnd_Inp2(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Blnd_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Blnd_Inp2 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Blnd_Fac(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Blnd_Fac;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Blnd_Fac = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Abslt_s08_Inp(void)
{
    extern __PST__SINT8 NxtrMath_Test_Abslt_s08_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Abslt_s08_Inp = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Abslt_s16_Inp(void)
{
    extern __PST__SINT16 NxtrMath_Test_Abslt_s16_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Abslt_s16_Inp = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Abslt_s32_Inp(void)
{
    extern __PST__SINT32 NxtrMath_Test_Abslt_s32_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Abslt_s32_Inp = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Abslt_f32_Inp(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Abslt_f32_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Abslt_f32_Inp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Sign_s08_Inp(void)
{
    extern __PST__SINT8 NxtrMath_Test_Sign_s08_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Sign_s08_Inp = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Sign_s16_Inp(void)
{
    extern __PST__SINT16 NxtrMath_Test_Sign_s16_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Sign_s16_Inp = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Sign_s32_Inp(void)
{
    extern __PST__SINT32 NxtrMath_Test_Sign_s32_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Sign_s32_Inp = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Sign_f32_Inp(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Sign_f32_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Sign_f32_Inp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_s08_Inp1(void)
{
    extern __PST__SINT8 NxtrMath_Test_Min_s08_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_s08_Inp1 = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_s08_Inp2(void)
{
    extern __PST__SINT8 NxtrMath_Test_Min_s08_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_s08_Inp2 = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_u08_Inp1(void)
{
    extern __PST__UINT8 NxtrMath_Test_Min_u08_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_u08_Inp1 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_u08_Inp2(void)
{
    extern __PST__UINT8 NxtrMath_Test_Min_u08_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_u08_Inp2 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_s16_Inp1(void)
{
    extern __PST__SINT16 NxtrMath_Test_Min_s16_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_s16_Inp1 = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_s16_Inp2(void)
{
    extern __PST__SINT16 NxtrMath_Test_Min_s16_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_s16_Inp2 = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_u16_Inp1(void)
{
    extern __PST__UINT16 NxtrMath_Test_Min_u16_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_u16_Inp1 = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_u16_Inp2(void)
{
    extern __PST__UINT16 NxtrMath_Test_Min_u16_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_u16_Inp2 = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_s32_Inp1(void)
{
    extern __PST__SINT32 NxtrMath_Test_Min_s32_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_s32_Inp1 = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_s32_Inp2(void)
{
    extern __PST__SINT32 NxtrMath_Test_Min_s32_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_s32_Inp2 = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_u32_Inp1(void)
{
    extern __PST__UINT32 NxtrMath_Test_Min_u32_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_u32_Inp1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_u32_Inp2(void)
{
    extern __PST__UINT32 NxtrMath_Test_Min_u32_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_u32_Inp2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_f32_Inp1(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Min_f32_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_f32_Inp1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Min_f32_Inp2(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Min_f32_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Min_f32_Inp2 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_s08_Inp1(void)
{
    extern __PST__SINT8 NxtrMath_Test_Max_s08_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_s08_Inp1 = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_s08_Inp2(void)
{
    extern __PST__SINT8 NxtrMath_Test_Max_s08_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_s08_Inp2 = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_u08_Inp1(void)
{
    extern __PST__UINT8 NxtrMath_Test_Max_u08_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_u08_Inp1 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_u08_Inp2(void)
{
    extern __PST__UINT8 NxtrMath_Test_Max_u08_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_u08_Inp2 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_s16_Inp1(void)
{
    extern __PST__SINT16 NxtrMath_Test_Max_s16_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_s16_Inp1 = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_s16_Inp2(void)
{
    extern __PST__SINT16 NxtrMath_Test_Max_s16_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_s16_Inp2 = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_u16_Inp1(void)
{
    extern __PST__UINT16 NxtrMath_Test_Max_u16_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_u16_Inp1 = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_u16_Inp2(void)
{
    extern __PST__UINT16 NxtrMath_Test_Max_u16_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_u16_Inp2 = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_s32_Inp1(void)
{
    extern __PST__SINT32 NxtrMath_Test_Max_s32_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_s32_Inp1 = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_s32_Inp2(void)
{
    extern __PST__SINT32 NxtrMath_Test_Max_s32_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_s32_Inp2 = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_u32_Inp1(void)
{
    extern __PST__UINT32 NxtrMath_Test_Max_u32_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_u32_Inp1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_u32_Inp2(void)
{
    extern __PST__UINT32 NxtrMath_Test_Max_u32_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_u32_Inp2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_f32_Inp1(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Max_f32_Inp1;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_f32_Inp1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Max_f32_Inp2(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Max_f32_Inp2;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Max_f32_Inp2 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_s08_Inp(void)
{
    extern __PST__SINT8 NxtrMath_Test_Lim_s08_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_s08_Inp = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_s08_RngLo(void)
{
    extern __PST__SINT8 NxtrMath_Test_Lim_s08_RngLo;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_s08_RngLo = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_s08_RngHi(void)
{
    extern __PST__SINT8 NxtrMath_Test_Lim_s08_RngHi;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_s08_RngHi = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_u08_Inp(void)
{
    extern __PST__UINT8 NxtrMath_Test_Lim_u08_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_u08_Inp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_u08_RngLo(void)
{
    extern __PST__UINT8 NxtrMath_Test_Lim_u08_RngLo;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_u08_RngLo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_u08_RngHi(void)
{
    extern __PST__UINT8 NxtrMath_Test_Lim_u08_RngHi;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_u08_RngHi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_s16_Inp(void)
{
    extern __PST__SINT16 NxtrMath_Test_Lim_s16_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_s16_Inp = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_s16_RngLo(void)
{
    extern __PST__SINT16 NxtrMath_Test_Lim_s16_RngLo;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_s16_RngLo = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_s16_RngHi(void)
{
    extern __PST__SINT16 NxtrMath_Test_Lim_s16_RngHi;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_s16_RngHi = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_u16_Inp(void)
{
    extern __PST__UINT16 NxtrMath_Test_Lim_u16_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_u16_Inp = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_u16_RngLo(void)
{
    extern __PST__UINT16 NxtrMath_Test_Lim_u16_RngLo;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_u16_RngLo = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_u16_RngHi(void)
{
    extern __PST__UINT16 NxtrMath_Test_Lim_u16_RngHi;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_u16_RngHi = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_s32_Inp(void)
{
    extern __PST__SINT32 NxtrMath_Test_Lim_s32_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_s32_Inp = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_s32_RngLo(void)
{
    extern __PST__SINT32 NxtrMath_Test_Lim_s32_RngLo;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_s32_RngLo = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_s32_RngHi(void)
{
    extern __PST__SINT32 NxtrMath_Test_Lim_s32_RngHi;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_s32_RngHi = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_u32_Inp(void)
{
    extern __PST__UINT32 NxtrMath_Test_Lim_u32_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_u32_Inp = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_u32_RngLo(void)
{
    extern __PST__UINT32 NxtrMath_Test_Lim_u32_RngLo;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_u32_RngLo = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_u32_RngHi(void)
{
    extern __PST__UINT32 NxtrMath_Test_Lim_u32_RngHi;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_u32_RngHi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_f32_Inp(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Lim_f32_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_f32_Inp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_f32_RngLo(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Lim_f32_RngLo;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_f32_RngLo = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Lim_f32_RngHi(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Lim_f32_RngHi;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Lim_f32_RngHi = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Arctan2_Numer(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Arctan2_Numer;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Arctan2_Numer = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Arctan2_Denom(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Arctan2_Denom;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Arctan2_Denom = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Sin_Inp(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Sin_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Sin_Inp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Cos_Inp(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Cos_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Cos_Inp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Exp_Inp(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Exp_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Exp_Inp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Sqrt_Inp(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Sqrt_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Sqrt_Inp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Mod_Numer(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Mod_Numer;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Mod_Numer = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_Test_Mod_Denom(void)
{
    extern __PST__FLOAT32 NxtrMath_Test_Mod_Denom;
    
    /* initialization with random value */
    {
        NxtrMath_Test_Mod_Denom = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_NxtrMath_errno_Inp(void)
{
    extern __PST__SINT32 NxtrMath_errno_Inp;
    
    /* initialization with random value */
    {
        NxtrMath_errno_Inp = _main_gen_init_g4();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable NxtrMath_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable NxtrMath_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable NxtrMath_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable NxtrMath_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable NxtrMath_Srv_SetNtcSts_Return */
    _main_gen_init_sym_NxtrMath_Srv_SetNtcSts_Return();
    
    /* init for variable NxtrMath_Test_Blnd_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Blnd_Inp1();
    
    /* init for variable NxtrMath_Test_Blnd_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Blnd_Inp2();
    
    /* init for variable NxtrMath_Test_Blnd_Fac */
    _main_gen_init_sym_NxtrMath_Test_Blnd_Fac();
    
    /* init for variable NxtrMath_Test_Abslt_s08_Inp */
    _main_gen_init_sym_NxtrMath_Test_Abslt_s08_Inp();
    
    /* init for variable NxtrMath_Test_Abslt_s16_Inp */
    _main_gen_init_sym_NxtrMath_Test_Abslt_s16_Inp();
    
    /* init for variable NxtrMath_Test_Abslt_s32_Inp */
    _main_gen_init_sym_NxtrMath_Test_Abslt_s32_Inp();
    
    /* init for variable NxtrMath_Test_Abslt_f32_Inp */
    _main_gen_init_sym_NxtrMath_Test_Abslt_f32_Inp();
    
    /* init for variable NxtrMath_Test_Sign_s08_Inp */
    _main_gen_init_sym_NxtrMath_Test_Sign_s08_Inp();
    
    /* init for variable NxtrMath_Test_Sign_s16_Inp */
    _main_gen_init_sym_NxtrMath_Test_Sign_s16_Inp();
    
    /* init for variable NxtrMath_Test_Sign_s32_Inp */
    _main_gen_init_sym_NxtrMath_Test_Sign_s32_Inp();
    
    /* init for variable NxtrMath_Test_Sign_f32_Inp */
    _main_gen_init_sym_NxtrMath_Test_Sign_f32_Inp();
    
    /* init for variable NxtrMath_Test_Min_s08_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Min_s08_Inp1();
    
    /* init for variable NxtrMath_Test_Min_s08_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Min_s08_Inp2();
    
    /* init for variable NxtrMath_Test_Min_u08_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Min_u08_Inp1();
    
    /* init for variable NxtrMath_Test_Min_u08_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Min_u08_Inp2();
    
    /* init for variable NxtrMath_Test_Min_s16_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Min_s16_Inp1();
    
    /* init for variable NxtrMath_Test_Min_s16_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Min_s16_Inp2();
    
    /* init for variable NxtrMath_Test_Min_u16_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Min_u16_Inp1();
    
    /* init for variable NxtrMath_Test_Min_u16_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Min_u16_Inp2();
    
    /* init for variable NxtrMath_Test_Min_s32_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Min_s32_Inp1();
    
    /* init for variable NxtrMath_Test_Min_s32_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Min_s32_Inp2();
    
    /* init for variable NxtrMath_Test_Min_u32_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Min_u32_Inp1();
    
    /* init for variable NxtrMath_Test_Min_u32_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Min_u32_Inp2();
    
    /* init for variable NxtrMath_Test_Min_f32_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Min_f32_Inp1();
    
    /* init for variable NxtrMath_Test_Min_f32_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Min_f32_Inp2();
    
    /* init for variable NxtrMath_Test_Max_s08_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Max_s08_Inp1();
    
    /* init for variable NxtrMath_Test_Max_s08_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Max_s08_Inp2();
    
    /* init for variable NxtrMath_Test_Max_u08_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Max_u08_Inp1();
    
    /* init for variable NxtrMath_Test_Max_u08_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Max_u08_Inp2();
    
    /* init for variable NxtrMath_Test_Max_s16_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Max_s16_Inp1();
    
    /* init for variable NxtrMath_Test_Max_s16_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Max_s16_Inp2();
    
    /* init for variable NxtrMath_Test_Max_u16_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Max_u16_Inp1();
    
    /* init for variable NxtrMath_Test_Max_u16_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Max_u16_Inp2();
    
    /* init for variable NxtrMath_Test_Max_s32_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Max_s32_Inp1();
    
    /* init for variable NxtrMath_Test_Max_s32_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Max_s32_Inp2();
    
    /* init for variable NxtrMath_Test_Max_u32_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Max_u32_Inp1();
    
    /* init for variable NxtrMath_Test_Max_u32_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Max_u32_Inp2();
    
    /* init for variable NxtrMath_Test_Max_f32_Inp1 */
    _main_gen_init_sym_NxtrMath_Test_Max_f32_Inp1();
    
    /* init for variable NxtrMath_Test_Max_f32_Inp2 */
    _main_gen_init_sym_NxtrMath_Test_Max_f32_Inp2();
    
    /* init for variable NxtrMath_Test_Lim_s08_Inp */
    _main_gen_init_sym_NxtrMath_Test_Lim_s08_Inp();
    
    /* init for variable NxtrMath_Test_Lim_s08_RngLo */
    _main_gen_init_sym_NxtrMath_Test_Lim_s08_RngLo();
    
    /* init for variable NxtrMath_Test_Lim_s08_RngHi */
    _main_gen_init_sym_NxtrMath_Test_Lim_s08_RngHi();
    
    /* init for variable NxtrMath_Test_Lim_u08_Inp */
    _main_gen_init_sym_NxtrMath_Test_Lim_u08_Inp();
    
    /* init for variable NxtrMath_Test_Lim_u08_RngLo */
    _main_gen_init_sym_NxtrMath_Test_Lim_u08_RngLo();
    
    /* init for variable NxtrMath_Test_Lim_u08_RngHi */
    _main_gen_init_sym_NxtrMath_Test_Lim_u08_RngHi();
    
    /* init for variable NxtrMath_Test_Lim_s16_Inp */
    _main_gen_init_sym_NxtrMath_Test_Lim_s16_Inp();
    
    /* init for variable NxtrMath_Test_Lim_s16_RngLo */
    _main_gen_init_sym_NxtrMath_Test_Lim_s16_RngLo();
    
    /* init for variable NxtrMath_Test_Lim_s16_RngHi */
    _main_gen_init_sym_NxtrMath_Test_Lim_s16_RngHi();
    
    /* init for variable NxtrMath_Test_Lim_u16_Inp */
    _main_gen_init_sym_NxtrMath_Test_Lim_u16_Inp();
    
    /* init for variable NxtrMath_Test_Lim_u16_RngLo */
    _main_gen_init_sym_NxtrMath_Test_Lim_u16_RngLo();
    
    /* init for variable NxtrMath_Test_Lim_u16_RngHi */
    _main_gen_init_sym_NxtrMath_Test_Lim_u16_RngHi();
    
    /* init for variable NxtrMath_Test_Lim_s32_Inp */
    _main_gen_init_sym_NxtrMath_Test_Lim_s32_Inp();
    
    /* init for variable NxtrMath_Test_Lim_s32_RngLo */
    _main_gen_init_sym_NxtrMath_Test_Lim_s32_RngLo();
    
    /* init for variable NxtrMath_Test_Lim_s32_RngHi */
    _main_gen_init_sym_NxtrMath_Test_Lim_s32_RngHi();
    
    /* init for variable NxtrMath_Test_Lim_u32_Inp */
    _main_gen_init_sym_NxtrMath_Test_Lim_u32_Inp();
    
    /* init for variable NxtrMath_Test_Lim_u32_RngLo */
    _main_gen_init_sym_NxtrMath_Test_Lim_u32_RngLo();
    
    /* init for variable NxtrMath_Test_Lim_u32_RngHi */
    _main_gen_init_sym_NxtrMath_Test_Lim_u32_RngHi();
    
    /* init for variable NxtrMath_Test_Lim_f32_Inp */
    _main_gen_init_sym_NxtrMath_Test_Lim_f32_Inp();
    
    /* init for variable NxtrMath_Test_Lim_f32_RngLo */
    _main_gen_init_sym_NxtrMath_Test_Lim_f32_RngLo();
    
    /* init for variable NxtrMath_Test_Lim_f32_RngHi */
    _main_gen_init_sym_NxtrMath_Test_Lim_f32_RngHi();
    
    /* init for variable NxtrMath_Test_Arctan2_Numer */
    _main_gen_init_sym_NxtrMath_Test_Arctan2_Numer();
    
    /* init for variable NxtrMath_Test_Arctan2_Denom */
    _main_gen_init_sym_NxtrMath_Test_Arctan2_Denom();
    
    /* init for variable NxtrMath_Test_Sin_Inp */
    _main_gen_init_sym_NxtrMath_Test_Sin_Inp();
    
    /* init for variable NxtrMath_Test_Cos_Inp */
    _main_gen_init_sym_NxtrMath_Test_Cos_Inp();
    
    /* init for variable NxtrMath_Test_Exp_Inp */
    _main_gen_init_sym_NxtrMath_Test_Exp_Inp();
    
    /* init for variable NxtrMath_Test_Sqrt_Inp */
    _main_gen_init_sym_NxtrMath_Test_Sqrt_Inp();
    
    /* init for variable NxtrMath_Test_Mod_Numer */
    _main_gen_init_sym_NxtrMath_Test_Mod_Numer();
    
    /* init for variable NxtrMath_Test_Mod_Denom */
    _main_gen_init_sym_NxtrMath_Test_Mod_Denom();
    
    /* init for variable NxtrMath_errno_Inp */
    _main_gen_init_sym_NxtrMath_errno_Inp();
    
}
