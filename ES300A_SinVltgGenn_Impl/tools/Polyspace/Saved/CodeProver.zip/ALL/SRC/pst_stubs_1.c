#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__g__21 _main_gen_init_g21(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__SINT8 _main_gen_init_g2(void);

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__21 _main_gen_init_g21(void)
{
    __PST__g__21 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_SinVltgGenn_Ip_MotElecMeclPolarity(void)
{
    extern __PST__SINT8 SinVltgGenn_Ip_MotElecMeclPolarity;
    
    /* initialization with random value */
    {
        SinVltgGenn_Ip_MotElecMeclPolarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Pim_PhaDptOffsA(void)
{
    extern __PST__FLOAT32 SinVltgGenn_Pim_PhaDptOffsA;
    
    /* initialization with random value */
    {
        SinVltgGenn_Pim_PhaDptOffsA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Pim_PhaDptOffsB(void)
{
    extern __PST__FLOAT32 SinVltgGenn_Pim_PhaDptOffsB;
    
    /* initialization with random value */
    {
        SinVltgGenn_Pim_PhaDptOffsB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Pim_PhaDptOffsC(void)
{
    extern __PST__FLOAT32 SinVltgGenn_Pim_PhaDptOffsC;
    
    /* initialization with random value */
    {
        SinVltgGenn_Pim_PhaDptOffsC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Pim_PwmPerdRng(void)
{
    extern __PST__UINT32 SinVltgGenn_Pim_PwmPerdRng;
    
    /* initialization with random value */
    {
        SinVltgGenn_Pim_PwmPerdRng = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Pim_RndNrPrev(void)
{
    extern __PST__FLOAT32 SinVltgGenn_Pim_RndNrPrev;
    
    /* initialization with random value */
    {
        SinVltgGenn_Pim_RndNrPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Cal_SinVltgGennDthrEna(void)
{
    extern __PST__g__28 SinVltgGenn_Cal_SinVltgGennDthrEna;
    
    /* initialization with random value */
    {
        SinVltgGenn_Cal_SinVltgGennDthrEna = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Cal_SinVltgGennDthrLpFilCoeff(void)
{
    extern __PST__g__21 SinVltgGenn_Cal_SinVltgGennDthrLpFilCoeff;
    
    /* initialization with random value */
    {
        SinVltgGenn_Cal_SinVltgGennDthrLpFilCoeff = _main_gen_init_g21();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Cal_MotAgSwCalVehSpdThd(void)
{
    extern __PST__g__21 SinVltgGenn_Cal_MotAgSwCalVehSpdThd;
    
    /* initialization with random value */
    {
        SinVltgGenn_Cal_MotAgSwCalVehSpdThd = _main_gen_init_g21();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Pim_Fil1OutpPrev(void)
{
    extern __PST__FLOAT32 SinVltgGenn_Pim_Fil1OutpPrev;
    
    /* initialization with random value */
    {
        SinVltgGenn_Pim_Fil1OutpPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Pim_Fil2OutpPrev(void)
{
    extern __PST__FLOAT32 SinVltgGenn_Pim_Fil2OutpPrev;
    
    /* initialization with random value */
    {
        SinVltgGenn_Pim_Fil2OutpPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Pim_PhaOnTiSumAPrev(void)
{
    extern __PST__UINT32 SinVltgGenn_Pim_PhaOnTiSumAPrev;
    
    /* initialization with random value */
    {
        SinVltgGenn_Pim_PhaOnTiSumAPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Pim_PhaOnTiSumBPrev(void)
{
    extern __PST__UINT32 SinVltgGenn_Pim_PhaOnTiSumBPrev;
    
    /* initialization with random value */
    {
        SinVltgGenn_Pim_PhaOnTiSumBPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_SinVltgGenn_Pim_PhaOnTiSumCPrev(void)
{
    extern __PST__UINT32 SinVltgGenn_Pim_PhaOnTiSumCPrev;
    
    /* initialization with random value */
    {
        SinVltgGenn_Pim_PhaOnTiSumCPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElec(void)
{
    extern __PST__UINT16 MOTCTRLMGR_MotCtrlMotAgElec;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgElec = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotModlnIdx(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotModlnIdx;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotPhaAdv(void)
{
    extern __PST__UINT16 MOTCTRLMGR_MotCtrlMotPhaAdv;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotPhaAdv = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlSwCalPosnIdx(void)
{
    extern __PST__UINT16 MOTCTRLMGR_MotCtrlSwCalPosnIdx;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlSwCalPosnIdx = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlSwCalModlnIdx(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlSwCalModlnIdx;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlSwCalModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiA = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiB;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiB = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiC;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiC = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlSwCalEna(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlSwCalEna;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlSwCalEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlVehSpd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlVehSpd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlVehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlIvtrFetFltPha(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlIvtrFetFltPha;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlIvtrFetFltPha = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlIvtrFetFltTyp(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlIvtrFetFltTyp;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlIvtrFetFltTyp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMfgEnaSt(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMfgEnaSt;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMfgEnaSt = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable SinVltgGenn_Ip_MotElecMeclPolarity */
    _main_gen_init_sym_SinVltgGenn_Ip_MotElecMeclPolarity();
    
    /* init for variable SinVltgGenn_Pim_PhaDptOffsA */
    _main_gen_init_sym_SinVltgGenn_Pim_PhaDptOffsA();
    
    /* init for variable SinVltgGenn_Pim_PhaDptOffsB */
    _main_gen_init_sym_SinVltgGenn_Pim_PhaDptOffsB();
    
    /* init for variable SinVltgGenn_Pim_PhaDptOffsC */
    _main_gen_init_sym_SinVltgGenn_Pim_PhaDptOffsC();
    
    /* init for variable SinVltgGenn_Pim_PwmPerdRng */
    _main_gen_init_sym_SinVltgGenn_Pim_PwmPerdRng();
    
    /* init for variable SinVltgGenn_Pim_RndNrPrev */
    _main_gen_init_sym_SinVltgGenn_Pim_RndNrPrev();
    
    /* init for variable SinVltgGenn_Cal_SinVltgGennDthrEna */
    _main_gen_init_sym_SinVltgGenn_Cal_SinVltgGennDthrEna();
    
    /* init for variable SinVltgGenn_Cal_SinVltgGennDthrLpFilCoeff */
    _main_gen_init_sym_SinVltgGenn_Cal_SinVltgGennDthrLpFilCoeff();
    
    /* init for variable SinVltgGenn_Cal_MotAgSwCalVehSpdThd */
    _main_gen_init_sym_SinVltgGenn_Cal_MotAgSwCalVehSpdThd();
    
    /* init for variable SinVltgGenn_Pim_Fil1OutpPrev */
    _main_gen_init_sym_SinVltgGenn_Pim_Fil1OutpPrev();
    
    /* init for variable SinVltgGenn_Pim_Fil2OutpPrev */
    _main_gen_init_sym_SinVltgGenn_Pim_Fil2OutpPrev();
    
    /* init for variable SinVltgGenn_Pim_PhaOnTiSumAPrev */
    _main_gen_init_sym_SinVltgGenn_Pim_PhaOnTiSumAPrev();
    
    /* init for variable SinVltgGenn_Pim_PhaOnTiSumBPrev */
    _main_gen_init_sym_SinVltgGenn_Pim_PhaOnTiSumBPrev();
    
    /* init for variable SinVltgGenn_Pim_PhaOnTiSumCPrev */
    _main_gen_init_sym_SinVltgGenn_Pim_PhaOnTiSumCPrev();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgElec */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElec();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotModlnIdx */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotModlnIdx();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotPhaAdv */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotPhaAdv();
    
    /* init for variable MOTCTRLMGR_MotCtrlSwCalPosnIdx */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlSwCalPosnIdx();
    
    /* init for variable MOTCTRLMGR_MotCtrlSwCalModlnIdx */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlSwCalModlnIdx();
    
    /* init for variable MOTCTRLMGR_MotCtrlCmuOffs : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiB */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiC */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiSumA : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiSumB : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiSumC : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlPwmPerd : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlSwCalEna */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlSwCalEna();
    
    /* init for variable MOTCTRLMGR_MotCtrlVehSpd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlVehSpd();
    
    /* init for variable MOTCTRLMGR_MotCtrlIvtrFetFltPha */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlIvtrFetFltPha();
    
    /* init for variable MOTCTRLMGR_MotCtrlIvtrFetFltTyp */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlIvtrFetFltTyp();
    
    /* init for variable MOTCTRLMGR_MotCtrlMfgEnaSt */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMfgEnaSt();
    
}
