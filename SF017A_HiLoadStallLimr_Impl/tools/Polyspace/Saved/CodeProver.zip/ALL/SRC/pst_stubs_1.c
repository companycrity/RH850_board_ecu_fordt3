#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__26 _main_gen_init_g26(void);

extern __PST__g__22 _main_gen_init_g22(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__22 _main_gen_init_g22(void)
{
    __PST__g__22 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__26 _main_gen_init_g26(void)
{
    static struct __PST__g__26 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_HiLoadStallLimr_Ip_DualEcuFltMtgtnEna(void)
{
    extern __PST__UINT8 HiLoadStallLimr_Ip_DualEcuFltMtgtnEna;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Ip_DualEcuFltMtgtnEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Ip_MotAndThermProtnLoaMod(void)
{
    extern __PST__UINT8 HiLoadStallLimr_Ip_MotAndThermProtnLoaMod;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Ip_MotAndThermProtnLoaMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Ip_MotTqCmdLimdPreStall(void)
{
    extern __PST__FLOAT32 HiLoadStallLimr_Ip_MotTqCmdLimdPreStall;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Ip_MotTqCmdLimdPreStall = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 HiLoadStallLimr_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Ip_StallMotTqLimDi(void)
{
    extern __PST__UINT8 HiLoadStallLimr_Ip_StallMotTqLimDi;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Ip_StallMotTqLimDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrMotTqCmdFetMtgtnEnaFilFrq(void)
{
    extern __PST__g__22 HiLoadStallLimr_Cal_HiLoadStallLimrMotTqCmdFetMtgtnEnaFilFrq;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Cal_HiLoadStallLimrMotTqCmdFetMtgtnEnaFilFrq = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrMotTqCmdFilFrq(void)
{
    extern __PST__g__22 HiLoadStallLimr_Cal_HiLoadStallLimrMotTqCmdFilFrq;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Cal_HiLoadStallLimrMotTqCmdFilFrq = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrMotVelMgnThd(void)
{
    extern __PST__g__23 HiLoadStallLimr_Cal_HiLoadStallLimrMotVelMgnThd;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 2; _main_gen_tmp_1_0++)
            {
                /* base type */
                HiLoadStallLimr_Cal_HiLoadStallLimrMotVelMgnThd[_main_gen_tmp_1_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdFetMtgtnLimX(void)
{
    extern __PST__g__24 HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdFetMtgtnLimX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 6; _main_gen_tmp_2_0++)
            {
                /* base type */
                HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdFetMtgtnLimX[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdFetMtgtnLimY(void)
{
    extern __PST__g__24 HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdFetMtgtnLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 6; _main_gen_tmp_3_0++)
            {
                /* base type */
                HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdFetMtgtnLimY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdLimX(void)
{
    extern __PST__g__24 HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdLimX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 6; _main_gen_tmp_4_0++)
            {
                /* base type */
                HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdLimX[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdLimY(void)
{
    extern __PST__g__24 HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdLimY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 6; _main_gen_tmp_5_0++)
            {
                /* base type */
                HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdLimY[_main_gen_tmp_5_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqLimSlewRate(void)
{
    extern __PST__g__23 HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqLimSlewRate;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 2; _main_gen_tmp_6_0++)
            {
                /* base type */
                HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqLimSlewRate[_main_gen_tmp_6_0] = pst_random_g_10;
            }
        }
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallThermLimSca(void)
{
    extern __PST__g__22 HiLoadStallLimr_Cal_HiLoadStallLimrStallThermLimSca;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Cal_HiLoadStallLimrStallThermLimSca = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Pim_FetLoaMtgtnCalIdx(void)
{
    extern __PST__UINT8 HiLoadStallLimr_Pim_FetLoaMtgtnCalIdx;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Pim_FetLoaMtgtnCalIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Pim_StallMotTqCmdFetMtgtnFil(void)
{
    extern struct __PST__g__26 HiLoadStallLimr_Pim_StallMotTqCmdFetMtgtnFil;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Pim_StallMotTqCmdFetMtgtnFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Pim_StallMotTqCmdFil(void)
{
    extern struct __PST__g__26 HiLoadStallLimr_Pim_StallMotTqCmdFil;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Pim_StallMotTqCmdFil = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Pim_StallMotTqLimFetMtgtnPrev(void)
{
    extern __PST__FLOAT32 HiLoadStallLimr_Pim_StallMotTqLimFetMtgtnPrev;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Pim_StallMotTqLimFetMtgtnPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HiLoadStallLimr_Pim_StallMotTqLimPrev(void)
{
    extern __PST__FLOAT32 HiLoadStallLimr_Pim_StallMotTqLimPrev;
    
    /* initialization with random value */
    {
        HiLoadStallLimr_Pim_StallMotTqLimPrev = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable HiLoadStallLimr_Ip_DualEcuFltMtgtnEna */
    _main_gen_init_sym_HiLoadStallLimr_Ip_DualEcuFltMtgtnEna();
    
    /* init for variable HiLoadStallLimr_Ip_MotAndThermProtnLoaMod */
    _main_gen_init_sym_HiLoadStallLimr_Ip_MotAndThermProtnLoaMod();
    
    /* init for variable HiLoadStallLimr_Ip_MotTqCmdLimdPreStall */
    _main_gen_init_sym_HiLoadStallLimr_Ip_MotTqCmdLimdPreStall();
    
    /* init for variable HiLoadStallLimr_Ip_MotVelCrf */
    _main_gen_init_sym_HiLoadStallLimr_Ip_MotVelCrf();
    
    /* init for variable HiLoadStallLimr_Ip_StallMotTqLimDi */
    _main_gen_init_sym_HiLoadStallLimr_Ip_StallMotTqLimDi();
    
    /* init for variable HiLoadStallLimr_Op_StallMotTqLim : useless (never read) */

    /* init for variable HiLoadStallLimr_Cal_HiLoadStallLimrMotTqCmdFetMtgtnEnaFilFrq */
    _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrMotTqCmdFetMtgtnEnaFilFrq();
    
    /* init for variable HiLoadStallLimr_Cal_HiLoadStallLimrMotTqCmdFilFrq */
    _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrMotTqCmdFilFrq();
    
    /* init for variable HiLoadStallLimr_Cal_HiLoadStallLimrMotVelMgnThd */
    _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrMotVelMgnThd();
    
    /* init for variable HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdFetMtgtnLimX */
    _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdFetMtgtnLimX();
    
    /* init for variable HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdFetMtgtnLimY */
    _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdFetMtgtnLimY();
    
    /* init for variable HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdLimX */
    _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdLimX();
    
    /* init for variable HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdLimY */
    _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqCmdLimY();
    
    /* init for variable HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqLimSlewRate */
    _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallMotTqLimSlewRate();
    
    /* init for variable HiLoadStallLimr_Cal_HiLoadStallLimrStallThermLimSca */
    _main_gen_init_sym_HiLoadStallLimr_Cal_HiLoadStallLimrStallThermLimSca();
    
    /* init for variable HiLoadStallLimr_Pim_dHiLoadStallLimrStallMotTqCmd : useless (never read) */

    /* init for variable HiLoadStallLimr_Pim_dHiLoadStallLimrStallMotTqCmdFild : useless (never read) */

    /* init for variable HiLoadStallLimr_Pim_dHiLoadStallLimrStallMotTqLim : useless (never read) */

    /* init for variable HiLoadStallLimr_Pim_FetLoaMtgtnCalIdx */
    _main_gen_init_sym_HiLoadStallLimr_Pim_FetLoaMtgtnCalIdx();
    
    /* init for variable HiLoadStallLimr_Pim_StallMotTqCmdFetMtgtnFil */
    _main_gen_init_sym_HiLoadStallLimr_Pim_StallMotTqCmdFetMtgtnFil();
    
    /* init for variable HiLoadStallLimr_Pim_StallMotTqCmdFil */
    _main_gen_init_sym_HiLoadStallLimr_Pim_StallMotTqCmdFil();
    
    /* init for variable HiLoadStallLimr_Pim_StallMotTqLimFetMtgtnPrev */
    _main_gen_init_sym_HiLoadStallLimr_Pim_StallMotTqLimFetMtgtnPrev();
    
    /* init for variable HiLoadStallLimr_Pim_StallMotTqLimPrev */
    _main_gen_init_sym_HiLoadStallLimr_Pim_StallMotTqLimPrev();
    
}
