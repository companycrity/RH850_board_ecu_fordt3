#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__g__48 _main_gen_init_g48(void);

extern struct __PST__g__43 _main_gen_init_g43(void);

extern struct __PST__g__42 _main_gen_init_g42(void);

extern struct __PST__g__41 _main_gen_init_g41(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern struct __PST__g__17 _main_gen_init_g17(void);

extern __PST__g__40 _main_gen_init_g40(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__40 _main_gen_init_g40(void)
{
    __PST__g__40 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

struct __PST__g__17 _main_gen_init_g17(void)
{
    static struct __PST__g__17 x;
    /* struct/union type */
    { /* array type */
        __PST__UINT32 _main_gen_tmp_3_0;
        
        for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 144; _main_gen_tmp_3_0++)
        {
            /* base type */
            x.SinHrmncTbl[_main_gen_tmp_3_0] = pst_random_g_2;
        }
    }
    { /* array type */
        __PST__UINT32 _main_gen_tmp_4_0;
        
        for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 144; _main_gen_tmp_4_0++)
        {
            /* base type */
            x.CosHrmncTbl[_main_gen_tmp_4_0] = pst_random_g_2;
        }
    }
    x.SinOffs = _main_gen_init_g7();
    x.CosOffs = _main_gen_init_g7();
    x.SinAmpRecpr = _main_gen_init_g7();
    x.CosAmpRecpr = _main_gen_init_g7();
    x.SinDelta = _main_gen_init_g3();
    x.SinGainCorrd = _main_gen_init_g7();
    x.CosGainCorrd = _main_gen_init_g7();
    x.SinOffsCorrd = _main_gen_init_g3();
    x.CosOffsCorrd = _main_gen_init_g3();
    x.CosDeltaRecpr = _main_gen_init_g7();
    return x;
}

struct __PST__g__41 _main_gen_init_g41(void)
{
    static struct __PST__g__41 x;
    /* struct/union type */
    x.MotAgSinMax = _main_gen_init_g10();
    x.MotAgSinMin = _main_gen_init_g10();
    x.MotAgCosMax = _main_gen_init_g10();
    x.MotAgCosMin = _main_gen_init_g10();
    return x;
}

struct __PST__g__42 _main_gen_init_g42(void)
{
    static struct __PST__g__42 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

struct __PST__g__43 _main_gen_init_g43(void)
{
    static struct __PST__g__43 x;
    /* struct/union type */
    x.SinRtOffs = _main_gen_init_g10();
    x.SinRtAmpRecpr = _main_gen_init_g10();
    x.CosRtOffs = _main_gen_init_g10();
    x.CosRtAmpRecpr = _main_gen_init_g10();
    x.SinGainCorrd = _main_gen_init_g10();
    x.CosGainCorrd = _main_gen_init_g10();
    x.SinOffsCorrd = _main_gen_init_g10();
    x.CosOffsCorrd = _main_gen_init_g10();
    x.CosSinNomRatio = _main_gen_init_g10();
    x.SinCosNomRatio = _main_gen_init_g10();
    x.RtToNomRatioLoLim = _main_gen_init_g10();
    x.RtToNomRatioHiLim = _main_gen_init_g10();
    x.PrevSinRtOffs = _main_gen_init_g10();
    x.PrevCosRtOffs = _main_gen_init_g10();
    return x;
}

__PST__g__48 _main_gen_init_g48(void)
{
    __PST__g__48 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotAg5Meas_Ip_MotAg5Cos(void)
{
    extern __PST__FLOAT32 MotAg5Meas_Ip_MotAg5Cos;
    
    /* initialization with random value */
    {
        MotAg5Meas_Ip_MotAg5Cos = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Ip_MotAg5CosAdcFaild(void)
{
    extern __PST__UINT8 MotAg5Meas_Ip_MotAg5CosAdcFaild;
    
    /* initialization with random value */
    {
        MotAg5Meas_Ip_MotAg5CosAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Ip_MotAg5RawMecl(void)
{
    extern __PST__UINT16 MotAg5Meas_Ip_MotAg5RawMecl;
    
    /* initialization with random value */
    {
        MotAg5Meas_Ip_MotAg5RawMecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Ip_MotAg5Sin(void)
{
    extern __PST__FLOAT32 MotAg5Meas_Ip_MotAg5Sin;
    
    /* initialization with random value */
    {
        MotAg5Meas_Ip_MotAg5Sin = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Ip_MotAg5SinAdcFaild(void)
{
    extern __PST__UINT8 MotAg5Meas_Ip_MotAg5SinAdcFaild;
    
    /* initialization with random value */
    {
        MotAg5Meas_Ip_MotAg5SinAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Ip_MotVelMrf(void)
{
    extern __PST__FLOAT32 MotAg5Meas_Ip_MotVelMrf;
    
    /* initialization with random value */
    {
        MotAg5Meas_Ip_MotVelMrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasAmpSqdMaxThd(void)
{
    extern __PST__g__40 MotAg5Meas_Cal_MotAg5MeasAmpSqdMaxThd;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cal_MotAg5MeasAmpSqdMaxThd = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasAmpSqdMinThd(void)
{
    extern __PST__g__40 MotAg5Meas_Cal_MotAg5MeasAmpSqdMinThd;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cal_MotAg5MeasAmpSqdMinThd = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasLpFilFrq(void)
{
    extern __PST__g__40 MotAg5Meas_Cal_MotAg5MeasLpFilFrq;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cal_MotAg5MeasLpFilFrq = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasRtAmpRecprLim(void)
{
    extern __PST__g__40 MotAg5Meas_Cal_MotAg5MeasRtAmpRecprLim;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cal_MotAg5MeasRtAmpRecprLim = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasRtFilEnaThd(void)
{
    extern __PST__g__40 MotAg5Meas_Cal_MotAg5MeasRtFilEnaThd;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cal_MotAg5MeasRtFilEnaThd = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasRtMotVelFilEnaThd(void)
{
    extern __PST__g__40 MotAg5Meas_Cal_MotAg5MeasRtMotVelFilEnaThd;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cal_MotAg5MeasRtMotVelFilEnaThd = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasRtOffsLim(void)
{
    extern __PST__g__40 MotAg5Meas_Cal_MotAg5MeasRtOffsLim;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cal_MotAg5MeasRtOffsLim = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasRtToNomRatLim(void)
{
    extern __PST__g__40 MotAg5Meas_Cal_MotAg5MeasRtToNomRatLim;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cal_MotAg5MeasRtToNomRatLim = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Pim_MotAg5EolPrm(void)
{
    extern struct __PST__g__17 MotAg5Meas_Pim_MotAg5EolPrm;
    
    /* initialization with random value */
    {
        MotAg5Meas_Pim_MotAg5EolPrm = _main_gen_init_g17();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Pim_MotAg5StVari(void)
{
    extern struct __PST__g__41 MotAg5Meas_Pim_MotAg5StVari;
    
    /* initialization with random value */
    {
        MotAg5Meas_Pim_MotAg5StVari = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Pim_MotAg5CosMaxLpFil(void)
{
    extern struct __PST__g__42 MotAg5Meas_Pim_MotAg5CosMaxLpFil;
    
    /* initialization with random value */
    {
        MotAg5Meas_Pim_MotAg5CosMaxLpFil = _main_gen_init_g42();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Pim_MotAg5CosMinLpFil(void)
{
    extern struct __PST__g__42 MotAg5Meas_Pim_MotAg5CosMinLpFil;
    
    /* initialization with random value */
    {
        MotAg5Meas_Pim_MotAg5CosMinLpFil = _main_gen_init_g42();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Pim_MotAg5NvmFltEna(void)
{
    extern __PST__UINT8 MotAg5Meas_Pim_MotAg5NvmFltEna;
    
    /* initialization with random value */
    {
        MotAg5Meas_Pim_MotAg5NvmFltEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Pim_MotAg5PrevRollgCntr(void)
{
    extern __PST__UINT8 MotAg5Meas_Pim_MotAg5PrevRollgCntr;
    
    /* initialization with random value */
    {
        MotAg5Meas_Pim_MotAg5PrevRollgCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Pim_MotAg5RtPrm(void)
{
    extern struct __PST__g__43 MotAg5Meas_Pim_MotAg5RtPrm;
    
    /* initialization with random value */
    {
        MotAg5Meas_Pim_MotAg5RtPrm = _main_gen_init_g43();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Pim_MotAg5SinMaxLpFil(void)
{
    extern struct __PST__g__42 MotAg5Meas_Pim_MotAg5SinMaxLpFil;
    
    /* initialization with random value */
    {
        MotAg5Meas_Pim_MotAg5SinMaxLpFil = _main_gen_init_g42();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Pim_MotAg5SinMinLpFil(void)
{
    extern struct __PST__g__42 MotAg5Meas_Pim_MotAg5SinMinLpFil;
    
    /* initialization with random value */
    {
        MotAg5Meas_Pim_MotAg5SinMinLpFil = _main_gen_init_g42();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Irv_MotAg5PrtclOk(void)
{
    extern __PST__UINT8 MotAg5Meas_Irv_MotAg5PrtclOk;
    
    /* initialization with random value */
    {
        MotAg5Meas_Irv_MotAg5PrtclOk = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Irv_MotAg5RtVari(void)
{
    extern __PST__g__44 MotAg5Meas_Irv_MotAg5RtVari;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 1; _main_gen_tmp_5_0++)
            {
                /* struct/union type */
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].SinRtOffs = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].SinRtAmpRecpr = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].CosRtOffs = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].CosRtAmpRecpr = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].SinGainCorrd = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].CosGainCorrd = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].SinOffsCorrd = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].CosOffsCorrd = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].CosSinNomRatio = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].SinCosNomRatio = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].RtToNomRatioLoLim = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].RtToNomRatioHiLim = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].PrevSinRtOffs = _main_gen_init_g10();
                MotAg5Meas_Irv_MotAg5RtVari[_main_gen_tmp_5_0].PrevCosRtOffs = _main_gen_init_g10();
            }
        }
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasOffs(void)
{
    extern __PST__g__48 MotAg5Meas_Cal_MotAg5MeasOffs;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cal_MotAg5MeasOffs = _main_gen_init_g48();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Pim_PrevMotAg5Mecl(void)
{
    extern __PST__UINT16 MotAg5Meas_Pim_PrevMotAg5Mecl;
    
    /* initialization with random value */
    {
        MotAg5Meas_Pim_PrevMotAg5Mecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5Cos(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg5Cos;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5Cos = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5CosRtAmpRecpr(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg5CosRtAmpRecpr;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5CosRtAmpRecpr = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5CosRtOffs(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg5CosRtOffs;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5CosRtOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5Polarity(void)
{
    extern __PST__SINT8 MOTCTRLMGR_MotCtrlMotAg5Polarity;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5Polarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5Sin(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg5Sin;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5Sin = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5SinRtAmpRecpr(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg5SinRtAmpRecpr;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5SinRtAmpRecpr = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5SinRtOffs(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg5SinRtOffs;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5SinRtOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMeasTi(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlMotAgMeasTi;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgMeasTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_CnvSnpshtData_f32_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 MotAg5Meas_Srv_CnvSnpshtData_f32_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_CnvSnpshtData_f32_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_CnvSnpshtData_logl_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 MotAg5Meas_Srv_CnvSnpshtData_logl_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_CnvSnpshtData_logl_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 MotAg5Meas_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 MotAg5Meas_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_MotAg5EolPrm_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 MotAg5Meas_Srv_MotAg5EolPrm_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_MotAg5EolPrm_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_MotAg5EolPrm_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 MotAg5Meas_Srv_MotAg5EolPrm_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_MotAg5EolPrm_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_MotAg5EolPrm_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 MotAg5Meas_Srv_MotAg5EolPrm_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_MotAg5EolPrm_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_MotAg5StVari_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 MotAg5Meas_Srv_MotAg5StVari_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_MotAg5StVari_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_MotAg5StVari_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 MotAg5Meas_Srv_MotAg5StVari_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_MotAg5StVari_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_MotAg5StVari_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 MotAg5Meas_Srv_MotAg5StVari_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_MotAg5StVari_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Srv_SetNtcStsAndSnpshtData_Return(void)
{
    extern __PST__UINT8 MotAg5Meas_Srv_SetNtcStsAndSnpshtData_Return;
    
    /* initialization with random value */
    {
        MotAg5Meas_Srv_SetNtcStsAndSnpshtData_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cli_MotAg5EolPrmRead_MotAg5EolPrmData(void)
{
    extern struct __PST__g__17 MotAg5Meas_Cli_MotAg5EolPrmRead_MotAg5EolPrmData;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cli_MotAg5EolPrmRead_MotAg5EolPrmData = _main_gen_init_g17();
    }
}

static void _main_gen_init_sym_MotAg5Meas_Cli_MotAg5EolPrmWr_MotAg5EolPrmData(void)
{
    extern struct __PST__g__17 MotAg5Meas_Cli_MotAg5EolPrmWr_MotAg5EolPrmData;
    
    /* initialization with random value */
    {
        MotAg5Meas_Cli_MotAg5EolPrmWr_MotAg5EolPrmData = _main_gen_init_g17();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotAg5Meas_Ip_MotAg5Cos */
    _main_gen_init_sym_MotAg5Meas_Ip_MotAg5Cos();
    
    /* init for variable MotAg5Meas_Ip_MotAg5CosAdcFaild */
    _main_gen_init_sym_MotAg5Meas_Ip_MotAg5CosAdcFaild();
    
    /* init for variable MotAg5Meas_Ip_MotAg5RawMecl */
    _main_gen_init_sym_MotAg5Meas_Ip_MotAg5RawMecl();
    
    /* init for variable MotAg5Meas_Ip_MotAg5Sin */
    _main_gen_init_sym_MotAg5Meas_Ip_MotAg5Sin();
    
    /* init for variable MotAg5Meas_Ip_MotAg5SinAdcFaild */
    _main_gen_init_sym_MotAg5Meas_Ip_MotAg5SinAdcFaild();
    
    /* init for variable MotAg5Meas_Ip_MotVelMrf */
    _main_gen_init_sym_MotAg5Meas_Ip_MotVelMrf();
    
    /* init for variable MotAg5Meas_Op_MotAg5CosRtAmpRecpr : useless (never read) */

    /* init for variable MotAg5Meas_Op_MotAg5CosRtOffs : useless (never read) */

    /* init for variable MotAg5Meas_Op_MotAg5MeclQlfr : useless (never read) */

    /* init for variable MotAg5Meas_Op_MotAg5MeclRollgCntr : useless (never read) */

    /* init for variable MotAg5Meas_Op_MotAg5SinRtAmpRecpr : useless (never read) */

    /* init for variable MotAg5Meas_Op_MotAg5SinRtOffs : useless (never read) */

    /* init for variable MotAg5Meas_Cal_MotAg5MeasAmpSqdMaxThd */
    _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasAmpSqdMaxThd();
    
    /* init for variable MotAg5Meas_Cal_MotAg5MeasAmpSqdMinThd */
    _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasAmpSqdMinThd();
    
    /* init for variable MotAg5Meas_Cal_MotAg5MeasLpFilFrq */
    _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasLpFilFrq();
    
    /* init for variable MotAg5Meas_Cal_MotAg5MeasRtAmpRecprLim */
    _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasRtAmpRecprLim();
    
    /* init for variable MotAg5Meas_Cal_MotAg5MeasRtFilEnaThd */
    _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasRtFilEnaThd();
    
    /* init for variable MotAg5Meas_Cal_MotAg5MeasRtMotVelFilEnaThd */
    _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasRtMotVelFilEnaThd();
    
    /* init for variable MotAg5Meas_Cal_MotAg5MeasRtOffsLim */
    _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasRtOffsLim();
    
    /* init for variable MotAg5Meas_Cal_MotAg5MeasRtToNomRatLim */
    _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasRtToNomRatLim();
    
    /* init for variable MotAg5Meas_Pim_MotAg5EolPrm */
    _main_gen_init_sym_MotAg5Meas_Pim_MotAg5EolPrm();
    
    /* init for variable MotAg5Meas_Pim_MotAg5StVari */
    _main_gen_init_sym_MotAg5Meas_Pim_MotAg5StVari();
    
    /* init for variable MotAg5Meas_Pim_dMotAg5MeasAmpVal : useless (never read) */

    /* init for variable MotAg5Meas_Pim_MotAg5CosMaxLpFil */
    _main_gen_init_sym_MotAg5Meas_Pim_MotAg5CosMaxLpFil();
    
    /* init for variable MotAg5Meas_Pim_MotAg5CosMinLpFil */
    _main_gen_init_sym_MotAg5Meas_Pim_MotAg5CosMinLpFil();
    
    /* init for variable MotAg5Meas_Pim_MotAg5NvmFltEna */
    _main_gen_init_sym_MotAg5Meas_Pim_MotAg5NvmFltEna();
    
    /* init for variable MotAg5Meas_Pim_MotAg5PrevRollgCntr */
    _main_gen_init_sym_MotAg5Meas_Pim_MotAg5PrevRollgCntr();
    
    /* init for variable MotAg5Meas_Pim_MotAg5RtPrm */
    _main_gen_init_sym_MotAg5Meas_Pim_MotAg5RtPrm();
    
    /* init for variable MotAg5Meas_Pim_MotAg5SinMaxLpFil */
    _main_gen_init_sym_MotAg5Meas_Pim_MotAg5SinMaxLpFil();
    
    /* init for variable MotAg5Meas_Pim_MotAg5SinMinLpFil */
    _main_gen_init_sym_MotAg5Meas_Pim_MotAg5SinMinLpFil();
    
    /* init for variable MotAg5Meas_Irv_MotAg5PrtclOk */
    _main_gen_init_sym_MotAg5Meas_Irv_MotAg5PrtclOk();
    
    /* init for variable MotAg5Meas_Irv_MotAg5RtVari */
    _main_gen_init_sym_MotAg5Meas_Irv_MotAg5RtVari();
    
    /* init for variable MotAg5Meas_Cal_MotAg5MeasOffs */
    _main_gen_init_sym_MotAg5Meas_Cal_MotAg5MeasOffs();
    
    /* init for variable MotAg5Meas_Pim_PrevMotAg5Mecl */
    _main_gen_init_sym_MotAg5Meas_Pim_PrevMotAg5Mecl();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5Cos */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5Cos();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5CosRtAmpRecpr */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5CosRtAmpRecpr();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5CosRtOffs */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5CosRtOffs();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5Polarity */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5Polarity();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5Sin */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5Sin();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5SinRtAmpRecpr */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5SinRtAmpRecpr();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5SinRtOffs */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5SinRtOffs();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgMeasTi */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMeasTi();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5Mecl : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg5RawMecl : useless (never read) */

    /* init for variable MotAg5Meas_Srv_CnvSnpshtData_f32_SnpshtDataCnvd */
    _main_gen_init_sym_MotAg5Meas_Srv_CnvSnpshtData_f32_SnpshtDataCnvd();
    
    /* init for variable MotAg5Meas_Srv_CnvSnpshtData_f32_SnpshtData : useless (never read) */

    /* init for variable MotAg5Meas_Srv_CnvSnpshtData_logl_SnpshtDataCnvd */
    _main_gen_init_sym_MotAg5Meas_Srv_CnvSnpshtData_logl_SnpshtDataCnvd();
    
    /* init for variable MotAg5Meas_Srv_CnvSnpshtData_logl_SnpshtData : useless (never read) */

    /* init for variable MotAg5Meas_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable MotAg5Meas_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_MotAg5Meas_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable MotAg5Meas_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_MotAg5Meas_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable MotAg5Meas_Srv_MotAg5EolPrm_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_MotAg5Meas_Srv_MotAg5EolPrm_GetErrorStatus_RequestResultPtr();
    
    /* init for variable MotAg5Meas_Srv_MotAg5EolPrm_GetErrorStatus_Return */
    _main_gen_init_sym_MotAg5Meas_Srv_MotAg5EolPrm_GetErrorStatus_Return();
    
    /* init for variable MotAg5Meas_Srv_MotAg5EolPrm_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable MotAg5Meas_Srv_MotAg5EolPrm_SetRamBlockStatus_Return */
    _main_gen_init_sym_MotAg5Meas_Srv_MotAg5EolPrm_SetRamBlockStatus_Return();
    
    /* init for variable MotAg5Meas_Srv_MotAg5StVari_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_MotAg5Meas_Srv_MotAg5StVari_GetErrorStatus_RequestResultPtr();
    
    /* init for variable MotAg5Meas_Srv_MotAg5StVari_GetErrorStatus_Return */
    _main_gen_init_sym_MotAg5Meas_Srv_MotAg5StVari_GetErrorStatus_Return();
    
    /* init for variable MotAg5Meas_Srv_MotAg5StVari_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable MotAg5Meas_Srv_MotAg5StVari_SetRamBlockStatus_Return */
    _main_gen_init_sym_MotAg5Meas_Srv_MotAg5StVari_SetRamBlockStatus_Return();
    
    /* init for variable MotAg5Meas_Srv_SetNtcStsAndSnpshtData_NtcNr : useless (never read) */

    /* init for variable MotAg5Meas_Srv_SetNtcStsAndSnpshtData_NtcStInfo : useless (never read) */

    /* init for variable MotAg5Meas_Srv_SetNtcStsAndSnpshtData_NtcSts : useless (never read) */

    /* init for variable MotAg5Meas_Srv_SetNtcStsAndSnpshtData_DebStep : useless (never read) */

    /* init for variable MotAg5Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData0 : useless (never read) */

    /* init for variable MotAg5Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData1 : useless (never read) */

    /* init for variable MotAg5Meas_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData2 : useless (never read) */

    /* init for variable MotAg5Meas_Srv_SetNtcStsAndSnpshtData_Return */
    _main_gen_init_sym_MotAg5Meas_Srv_SetNtcStsAndSnpshtData_Return();
    
    /* init for variable MotAg5Meas_Cli_MotAg5EolPrmRead_MotAg5EolPrmData */
    _main_gen_init_sym_MotAg5Meas_Cli_MotAg5EolPrmRead_MotAg5EolPrmData();
    
    /* init for variable MotAg5Meas_Cli_MotAg5EolPrmWr_MotAg5EolPrmData */
    _main_gen_init_sym_MotAg5Meas_Cli_MotAg5EolPrmWr_MotAg5EolPrmData();
    
}
