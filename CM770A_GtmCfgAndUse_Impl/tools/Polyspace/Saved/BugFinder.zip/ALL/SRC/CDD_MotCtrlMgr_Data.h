/* header file for contract folder of CM770A */

#ifndef CDD_MOTCTRLMGR_DATA_H
#define CDD_MOTCTRLMGR_DATA_H

extern MotCurrEolCalSt2 MOTCTRLMGR_MotCtrlMotCurrEolCalSt;
extern uint32 MOTCTRLMGR_MotCtrlPwmPerd;
extern uint32 MOTCTRLMGR_MotCtrlPhaOnTiA;
extern uint32 MOTCTRLMGR_MotCtrlPhaOnTiB;
extern uint32 MOTCTRLMGR_MotCtrlPhaOnTiC;

#endif

