#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_PwrUpSeq_Ip_CodFlsCrcChkCmpl(void)
{
    extern __PST__UINT8 PwrUpSeq_Ip_CodFlsCrcChkCmpl;
    
    /* initialization with random value */
    {
        PwrUpSeq_Ip_CodFlsCrcChkCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrUpSeq_Ip_CurrMeasWrmIninTestCmpl(void)
{
    extern __PST__UINT8 PwrUpSeq_Ip_CurrMeasWrmIninTestCmpl;
    
    /* initialization with random value */
    {
        PwrUpSeq_Ip_CurrMeasWrmIninTestCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrUpSeq_Ip_MotDrvr0IninTestCmpl(void)
{
    extern __PST__UINT8 PwrUpSeq_Ip_MotDrvr0IninTestCmpl;
    
    /* initialization with random value */
    {
        PwrUpSeq_Ip_MotDrvr0IninTestCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrUpSeq_Ip_MotDrvr1IninTestCmpl(void)
{
    extern __PST__UINT8 PwrUpSeq_Ip_MotDrvr1IninTestCmpl;
    
    /* initialization with random value */
    {
        PwrUpSeq_Ip_MotDrvr1IninTestCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrUpSeq_Ip_PwrDiscnctATestCmpl(void)
{
    extern __PST__UINT8 PwrUpSeq_Ip_PwrDiscnctATestCmpl;
    
    /* initialization with random value */
    {
        PwrUpSeq_Ip_PwrDiscnctATestCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrUpSeq_Ip_PwrDiscnctBTestCmpl(void)
{
    extern __PST__UINT8 PwrUpSeq_Ip_PwrDiscnctBTestCmpl;
    
    /* initialization with random value */
    {
        PwrUpSeq_Ip_PwrDiscnctBTestCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrUpSeq_Ip_SysSt(void)
{
    extern __PST__UINT8 PwrUpSeq_Ip_SysSt;
    
    /* initialization with random value */
    {
        PwrUpSeq_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrUpSeq_Ip_TmplMonIninTestCmpl(void)
{
    extern __PST__UINT8 PwrUpSeq_Ip_TmplMonIninTestCmpl;
    
    /* initialization with random value */
    {
        PwrUpSeq_Ip_TmplMonIninTestCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrUpSeq_Pim_PwrTurnOffCtrlPrev(void)
{
    extern __PST__UINT8 PwrUpSeq_Pim_PwrTurnOffCtrlPrev;
    
    /* initialization with random value */
    {
        PwrUpSeq_Pim_PwrTurnOffCtrlPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrUpSeq_Srv_IoHwAb_SetGpioPwrTurnOffCtrl_Return(void)
{
    extern __PST__UINT8 PwrUpSeq_Srv_IoHwAb_SetGpioPwrTurnOffCtrl_Return;
    
    /* initialization with random value */
    {
        PwrUpSeq_Srv_IoHwAb_SetGpioPwrTurnOffCtrl_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrUpSeq_Cli_PwrTurnOffCtrl_PinSt(void)
{
    extern __PST__UINT8 PwrUpSeq_Cli_PwrTurnOffCtrl_PinSt;
    
    /* initialization with random value */
    {
        PwrUpSeq_Cli_PwrTurnOffCtrl_PinSt = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable PwrUpSeq_Ip_CodFlsCrcChkCmpl */
    _main_gen_init_sym_PwrUpSeq_Ip_CodFlsCrcChkCmpl();
    
    /* init for variable PwrUpSeq_Ip_CurrMeasWrmIninTestCmpl */
    _main_gen_init_sym_PwrUpSeq_Ip_CurrMeasWrmIninTestCmpl();
    
    /* init for variable PwrUpSeq_Ip_MotDrvr0IninTestCmpl */
    _main_gen_init_sym_PwrUpSeq_Ip_MotDrvr0IninTestCmpl();
    
    /* init for variable PwrUpSeq_Ip_MotDrvr1IninTestCmpl */
    _main_gen_init_sym_PwrUpSeq_Ip_MotDrvr1IninTestCmpl();
    
    /* init for variable PwrUpSeq_Ip_PwrDiscnctATestCmpl */
    _main_gen_init_sym_PwrUpSeq_Ip_PwrDiscnctATestCmpl();
    
    /* init for variable PwrUpSeq_Ip_PwrDiscnctBTestCmpl */
    _main_gen_init_sym_PwrUpSeq_Ip_PwrDiscnctBTestCmpl();
    
    /* init for variable PwrUpSeq_Ip_SysSt */
    _main_gen_init_sym_PwrUpSeq_Ip_SysSt();
    
    /* init for variable PwrUpSeq_Ip_TmplMonIninTestCmpl */
    _main_gen_init_sym_PwrUpSeq_Ip_TmplMonIninTestCmpl();
    
    /* init for variable PwrUpSeq_Op_StrtUpSt : useless (never read) */

    /* init for variable PwrUpSeq_Op_SysStWrmIninCmpl : useless (never read) */

    /* init for variable PwrUpSeq_Pim_PwrTurnOffCtrlPrev */
    _main_gen_init_sym_PwrUpSeq_Pim_PwrTurnOffCtrlPrev();
    
    /* init for variable PwrUpSeq_Srv_IoHwAb_SetGpioPwrTurnOffCtrl_PinSt : useless (never read) */

    /* init for variable PwrUpSeq_Srv_IoHwAb_SetGpioPwrTurnOffCtrl_Return */
    _main_gen_init_sym_PwrUpSeq_Srv_IoHwAb_SetGpioPwrTurnOffCtrl_Return();
    
    /* init for variable PwrUpSeq_Cli_PwrTurnOffCtrl_PinSt */
    _main_gen_init_sym_PwrUpSeq_Cli_PwrTurnOffCtrl_PinSt();
    
}
