#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsf32(void)
{
    extern __PST__FLOAT32 MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsf32;
    
    /* initialization with random value */
    {
        MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsf32 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu32(void)
{
    extern __PST__UINT32 MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu32;
    
    /* initialization with random value */
    {
        MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu32 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss32(void)
{
    extern __PST__SINT32 MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss32;
    
    /* initialization with random value */
    {
        MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss32 = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu16(void)
{
    extern __PST__UINT16 MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu16;
    
    /* initialization with random value */
    {
        MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu16 = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss16(void)
{
    extern __PST__SINT16 MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss16;
    
    /* initialization with random value */
    {
        MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss16 = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu08(void)
{
    extern __PST__UINT8 MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu08;
    
    /* initialization with random value */
    {
        MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu08 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss08(void)
{
    extern __PST__SINT8 MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss08;
    
    /* initialization with random value */
    {
        MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss08 = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsbool(void)
{
    extern __PST__UINT8 MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsbool;
    
    /* initialization with random value */
    {
        MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsbool = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsEnum(void)
{
    extern __PST__UINT32 MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsEnum;
    
    /* initialization with random value */
    {
        MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsEnum = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_Srv_DmaWaitForMotCtrlTo2MilliSecTrf_Return(void)
{
    extern __PST__UINT8 MotCtrlMgr_Srv_DmaWaitForMotCtrlTo2MilliSecTrf_Return;
    
    /* initialization with random value */
    {
        MotCtrlMgr_Srv_DmaWaitForMotCtrlTo2MilliSecTrf_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsf32 */
    _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsf32();
    
    /* init for variable MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu32 */
    _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu32();
    
    /* init for variable MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss32 */
    _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss32();
    
    /* init for variable MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu16 */
    _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu16();
    
    /* init for variable MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss16 */
    _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss16();
    
    /* init for variable MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu08 */
    _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsu08();
    
    /* init for variable MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss08 */
    _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMss08();
    
    /* init for variable MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsbool */
    _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsbool();
    
    /* init for variable MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsEnum */
    _main_gen_init_sym_MotCtrlMgr_Ip_ReadMotCtrlWriteTwoMsEnum();
    
    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadMotCtrlReadTwoMsf32 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadTwoMsf32 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadMotCtrlReadTwoMsu32 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadTwoMsu32 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadMotCtrlReadTwoMss32 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadTwoMss32 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadMotCtrlReadTwoMsu16 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadTwoMsu16 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadMotCtrlReadTwoMss16 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadTwoMss16 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadMotCtrlReadTwoMsu08 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadTwoMsu08 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_Signal3 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadMotCtrlReadTwoMss08 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadTwoMss08 : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadMotCtrlReadTwoMsbool : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadTwoMsbool : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadMotCtrlReadTwoMsEnum : useless (never read) */

    /* init for variable MotCtrlMgr_Op_WriteMotCtrlReadTwoMsEnum : useless (never read) */

    /* init for variable MotCtrlMgr_Srv_DmaWaitForMotCtrlTo2MilliSecTrf_Return */
    _main_gen_init_sym_MotCtrlMgr_Srv_DmaWaitForMotCtrlTo2MilliSecTrf_Return();
    
}
