#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BattVltgCorrln_Ip_BattVltg(void)
{
    extern __PST__FLOAT32 BattVltgCorrln_Ip_BattVltg;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Ip_BattVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Ip_BattVltgAdcFaild(void)
{
    extern __PST__UINT8 BattVltgCorrln_Ip_BattVltgAdcFaild;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Ip_BattVltgAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Ip_BattVltgSwd1(void)
{
    extern __PST__FLOAT32 BattVltgCorrln_Ip_BattVltgSwd1;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Ip_BattVltgSwd1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Ip_BattVltgSwd1AdcFaild(void)
{
    extern __PST__UINT8 BattVltgCorrln_Ip_BattVltgSwd1AdcFaild;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Ip_BattVltgSwd1AdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Ip_DiagcStsIvtr1Inactv(void)
{
    extern __PST__UINT8 BattVltgCorrln_Ip_DiagcStsIvtr1Inactv;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Ip_DiagcStsIvtr1Inactv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Ip_InhbBattVltgDiagc(void)
{
    extern __PST__UINT8 BattVltgCorrln_Ip_InhbBattVltgDiagc;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Ip_InhbBattVltgDiagc = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Ip_StrtUpSt(void)
{
    extern __PST__UINT8 BattVltgCorrln_Ip_StrtUpSt;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Ip_StrtUpSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Ip_SysSt(void)
{
    extern __PST__UINT8 BattVltgCorrln_Ip_SysSt;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnAllwdVltgDif(void)
{
    extern __PST__g__25 BattVltgCorrln_Cal_BattVltgCorrlnAllwdVltgDif;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnAllwdVltgDif = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnBattLoVltg(void)
{
    extern __PST__g__25 BattVltgCorrln_Cal_BattVltgCorrlnBattLoVltg;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnBattLoVltg = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnBattOverVltg(void)
{
    extern __PST__g__25 BattVltgCorrln_Cal_BattVltgCorrlnBattOverVltg;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnBattOverVltg = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnBattUnderVltg(void)
{
    extern __PST__g__25 BattVltgCorrln_Cal_BattVltgCorrlnBattUnderVltg;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnBattUnderVltg = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x03C0x044FailStep(void)
{
    extern __PST__g__26 BattVltgCorrln_Cal_BattVltgCorrlnNtc0x03C0x044FailStep;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnNtc0x03C0x044FailStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x03C0x044PassStep(void)
{
    extern __PST__g__26 BattVltgCorrln_Cal_BattVltgCorrlnNtc0x03C0x044PassStep;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnNtc0x03C0x044PassStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B0FailStep(void)
{
    extern __PST__g__26 BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B0FailStep;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B0FailStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B0PassStep(void)
{
    extern __PST__g__26 BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B0PassStep;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B0PassStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B1FailStep(void)
{
    extern __PST__g__26 BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B1FailStep;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B1FailStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B1PassStep(void)
{
    extern __PST__g__26 BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B1PassStep;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B1PassStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B5FailStep(void)
{
    extern __PST__g__26 BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B5FailStep;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B5FailStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B5PassStep(void)
{
    extern __PST__g__26 BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B5PassStep;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B5PassStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattLoVltg(void)
{
    extern __PST__g__25 BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattLoVltg;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattLoVltg = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattOverVltg(void)
{
    extern __PST__g__25 BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattOverVltg;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattOverVltg = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattUnderVltg(void)
{
    extern __PST__g__25 BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattUnderVltg;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattUnderVltg = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnSwdMax(void)
{
    extern __PST__g__25 BattVltgCorrln_Cal_BattVltgCorrlnSwdMax;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnSwdMax = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnSysMinVltg(void)
{
    extern __PST__g__25 BattVltgCorrln_Cal_BattVltgCorrlnSysMinVltg;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Cal_BattVltgCorrlnSysMinVltg = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 BattVltgCorrln_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 BattVltgCorrln_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_BattVltgCorrln_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 BattVltgCorrln_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        BattVltgCorrln_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BattVltgCorrln_Ip_BattVltg */
    _main_gen_init_sym_BattVltgCorrln_Ip_BattVltg();
    
    /* init for variable BattVltgCorrln_Ip_BattVltgAdcFaild */
    _main_gen_init_sym_BattVltgCorrln_Ip_BattVltgAdcFaild();
    
    /* init for variable BattVltgCorrln_Ip_BattVltgSwd1 */
    _main_gen_init_sym_BattVltgCorrln_Ip_BattVltgSwd1();
    
    /* init for variable BattVltgCorrln_Ip_BattVltgSwd1AdcFaild */
    _main_gen_init_sym_BattVltgCorrln_Ip_BattVltgSwd1AdcFaild();
    
    /* init for variable BattVltgCorrln_Ip_DiagcStsIvtr1Inactv */
    _main_gen_init_sym_BattVltgCorrln_Ip_DiagcStsIvtr1Inactv();
    
    /* init for variable BattVltgCorrln_Ip_InhbBattVltgDiagc */
    _main_gen_init_sym_BattVltgCorrln_Ip_InhbBattVltgDiagc();
    
    /* init for variable BattVltgCorrln_Ip_StrtUpSt */
    _main_gen_init_sym_BattVltgCorrln_Ip_StrtUpSt();
    
    /* init for variable BattVltgCorrln_Ip_SysSt */
    _main_gen_init_sym_BattVltgCorrln_Ip_SysSt();
    
    /* init for variable BattVltgCorrln_Op_BattSwdVltgCorrlnSts : useless (never read) */

    /* init for variable BattVltgCorrln_Op_BattVltgCorrlnIdptSig : useless (never read) */

    /* init for variable BattVltgCorrln_Op_DftBrdgVltgActv : useless (never read) */

    /* init for variable BattVltgCorrln_Op_SwdVltgLimd : useless (never read) */

    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnAllwdVltgDif */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnAllwdVltgDif();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnBattLoVltg */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnBattLoVltg();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnBattOverVltg */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnBattOverVltg();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnBattUnderVltg */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnBattUnderVltg();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnNtc0x03C0x044FailStep */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x03C0x044FailStep();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnNtc0x03C0x044PassStep */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x03C0x044PassStep();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B0FailStep */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B0FailStep();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B0PassStep */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B0PassStep();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B1FailStep */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B1FailStep();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B1PassStep */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B1PassStep();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B5FailStep */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B5FailStep();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B5PassStep */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnNtc0x0B5PassStep();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattLoVltg */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattLoVltg();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattOverVltg */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattOverVltg();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattUnderVltg */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnRcvrlBattUnderVltg();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnSwdMax */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnSwdMax();
    
    /* init for variable BattVltgCorrln_Cal_BattVltgCorrlnSysMinVltg */
    _main_gen_init_sym_BattVltgCorrln_Cal_BattVltgCorrlnSysMinVltg();
    
    /* init for variable BattVltgCorrln_Pim_dBattVltgCorrlnBattVltgAndSwd1Ok : useless (never read) */

    /* init for variable BattVltgCorrln_Pim_dBattVltgCorrlnBattVltgRngOk : useless (never read) */

    /* init for variable BattVltgCorrln_Pim_dBattVltgCorrlnBattVltgSwd1RngOk : useless (never read) */

    /* init for variable BattVltgCorrln_Pim_dBattVltgCorrlnNtc0x03CQlfrSts : useless (never read) */

    /* init for variable BattVltgCorrln_Pim_dBattVltgCorrlnNtc0x044QlfrSts : useless (never read) */

    /* init for variable BattVltgCorrln_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable BattVltgCorrln_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_BattVltgCorrln_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable BattVltgCorrln_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_BattVltgCorrln_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable BattVltgCorrln_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable BattVltgCorrln_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable BattVltgCorrln_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable BattVltgCorrln_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable BattVltgCorrln_Srv_SetNtcSts_Return */
    _main_gen_init_sym_BattVltgCorrln_Srv_SetNtcSts_Return();
    
}
