#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__32 _main_gen_init_g32(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__32 _main_gen_init_g32(void)
{
    static struct __PST__g__32 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Dampg_Ip_AssiCmdBas(void)
{
    extern __PST__FLOAT32 Dampg_Ip_AssiCmdBas;
    
    /* initialization with random value */
    {
        Dampg_Ip_AssiCmdBas = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Dampg_Ip_AssiMechT(void)
{
    extern __PST__FLOAT32 Dampg_Ip_AssiMechT;
    
    /* initialization with random value */
    {
        Dampg_Ip_AssiMechT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Dampg_Ip_DampgCmdBasDi(void)
{
    extern __PST__UINT8 Dampg_Ip_DampgCmdBasDi;
    
    /* initialization with random value */
    {
        Dampg_Ip_DampgCmdBasDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Dampg_Ip_DampgCmdOvrl(void)
{
    extern __PST__FLOAT32 Dampg_Ip_DampgCmdOvrl;
    
    /* initialization with random value */
    {
        Dampg_Ip_DampgCmdOvrl = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Dampg_Ip_DampgCmdSca(void)
{
    extern __PST__FLOAT32 Dampg_Ip_DampgCmdSca;
    
    /* initialization with random value */
    {
        Dampg_Ip_DampgCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Dampg_Ip_HwTq(void)
{
    extern __PST__FLOAT32 Dampg_Ip_HwTq;
    
    /* initialization with random value */
    {
        Dampg_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Dampg_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 Dampg_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        Dampg_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Dampg_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 Dampg_Ip_VehSpd;
    
    /* initialization with random value */
    {
        Dampg_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHwTqX(void)
{
    extern __PST__g__24 Dampg_Cal_DampgHwTqX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 2; _main_gen_tmp_2_0++)
            {
                /* base type */
                Dampg_Cal_DampgHwTqX[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHwTqY(void)
{
    extern __PST__g__24 Dampg_Cal_DampgHwTqY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 2; _main_gen_tmp_3_0++)
            {
                /* base type */
                Dampg_Cal_DampgHwTqY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHydAssiLim(void)
{
    extern __PST__g__25 Dampg_Cal_DampgHydAssiLim;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 12; _main_gen_tmp_4_0++)
            {
                /* base type */
                Dampg_Cal_DampgHydAssiLim[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHydBasCoeff1(void)
{
    extern __PST__g__26 Dampg_Cal_DampgHydBasCoeff1;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgHydBasCoeff1 = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHydBasCoeff2(void)
{
    extern __PST__g__26 Dampg_Cal_DampgHydBasCoeff2;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgHydBasCoeff2 = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHydBasCoeff3(void)
{
    extern __PST__g__26 Dampg_Cal_DampgHydBasCoeff3;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgHydBasCoeff3 = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHydBasCoeff4(void)
{
    extern __PST__g__26 Dampg_Cal_DampgHydBasCoeff4;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgHydBasCoeff4 = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHydCoeff1ScaY(void)
{
    extern __PST__g__25 Dampg_Cal_DampgHydCoeff1ScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 12; _main_gen_tmp_5_0++)
            {
                /* base type */
                Dampg_Cal_DampgHydCoeff1ScaY[_main_gen_tmp_5_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHydCoeff2ScaY(void)
{
    extern __PST__g__25 Dampg_Cal_DampgHydCoeff2ScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 12; _main_gen_tmp_6_0++)
            {
                /* base type */
                Dampg_Cal_DampgHydCoeff2ScaY[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHydCoeff3ScaY(void)
{
    extern __PST__g__25 Dampg_Cal_DampgHydCoeff3ScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 12; _main_gen_tmp_7_0++)
            {
                /* base type */
                Dampg_Cal_DampgHydCoeff3ScaY[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHydCoeff4ScaY(void)
{
    extern __PST__g__25 Dampg_Cal_DampgHydCoeff4ScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 12; _main_gen_tmp_8_0++)
            {
                /* base type */
                Dampg_Cal_DampgHydCoeff4ScaY[_main_gen_tmp_8_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgHydOutpLim(void)
{
    extern __PST__g__26 Dampg_Cal_DampgHydOutpLim;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgHydOutpLim = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgMotVelLpFilFrq(void)
{
    extern __PST__g__26 Dampg_Cal_DampgMotVelLpFilFrq;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgMotVelLpFilFrq = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgMotVelX(void)
{
    extern __PST__g__27 Dampg_Cal_DampgMotVelX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 12; _main_gen_tmp_9_0++)
            {
                __PST__UINT32 _main_gen_tmp_9_1;
                
                for (_main_gen_tmp_9_1 = 0; _main_gen_tmp_9_1 < 13; _main_gen_tmp_9_1++)
                {
                    /* base type */
                    Dampg_Cal_DampgMotVelX[_main_gen_tmp_9_0][_main_gen_tmp_9_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgMotVelY(void)
{
    extern __PST__g__27 Dampg_Cal_DampgMotVelY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 12; _main_gen_tmp_10_0++)
            {
                __PST__UINT32 _main_gen_tmp_10_1;
                
                for (_main_gen_tmp_10_1 = 0; _main_gen_tmp_10_1 < 13; _main_gen_tmp_10_1++)
                {
                    /* base type */
                    Dampg_Cal_DampgMotVelY[_main_gen_tmp_10_0][_main_gen_tmp_10_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgQuad13Mplr(void)
{
    extern __PST__g__26 Dampg_Cal_DampgQuad13Mplr;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgQuad13Mplr = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgQuad24Mplr(void)
{
    extern __PST__g__26 Dampg_Cal_DampgQuad24Mplr;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgQuad24Mplr = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgQuadHwTqBacklsh(void)
{
    extern __PST__g__26 Dampg_Cal_DampgQuadHwTqBacklsh;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgQuadHwTqBacklsh = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgQuadHwTqLpFilFrq(void)
{
    extern __PST__g__26 Dampg_Cal_DampgQuadHwTqLpFilFrq;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgQuadHwTqLpFilFrq = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgQuadMotVelBacklsh(void)
{
    extern __PST__g__26 Dampg_Cal_DampgQuadMotVelBacklsh;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgQuadMotVelBacklsh = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgQuadMotVelLpFilFrq(void)
{
    extern __PST__g__26 Dampg_Cal_DampgQuadMotVelLpFilFrq;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgQuadMotVelLpFilFrq = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgQuadScaLpFilFrq(void)
{
    extern __PST__g__26 Dampg_Cal_DampgQuadScaLpFilFrq;
    
    /* initialization with random value */
    {
        Dampg_Cal_DampgQuadScaLpFilFrq = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgTScaX(void)
{
    extern __PST__g__29 Dampg_Cal_DampgTScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 14; _main_gen_tmp_11_0++)
            {
                /* base type */
                Dampg_Cal_DampgTScaX[_main_gen_tmp_11_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_DampgTScaY(void)
{
    extern __PST__g__31 Dampg_Cal_DampgTScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 14; _main_gen_tmp_12_0++)
            {
                /* base type */
                Dampg_Cal_DampgTScaY[_main_gen_tmp_12_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Cal_SysGlbPrmVehSpdBilnrSeln(void)
{
    extern __PST__g__25 Dampg_Cal_SysGlbPrmVehSpdBilnrSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 12; _main_gen_tmp_13_0++)
            {
                /* base type */
                Dampg_Cal_SysGlbPrmVehSpdBilnrSeln[_main_gen_tmp_13_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Dampg_Pim_MotVelDampgLpFil(void)
{
    extern struct __PST__g__32 Dampg_Pim_MotVelDampgLpFil;
    
    /* initialization with random value */
    {
        Dampg_Pim_MotVelDampgLpFil = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_Dampg_Pim_PrevHwTqBacklshOutp(void)
{
    extern __PST__FLOAT32 Dampg_Pim_PrevHwTqBacklshOutp;
    
    /* initialization with random value */
    {
        Dampg_Pim_PrevHwTqBacklshOutp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Dampg_Pim_PrevMotVelBacklshOutp(void)
{
    extern __PST__FLOAT32 Dampg_Pim_PrevMotVelBacklshOutp;
    
    /* initialization with random value */
    {
        Dampg_Pim_PrevMotVelBacklshOutp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Dampg_Pim_QuadDampgHwTqLpFil(void)
{
    extern struct __PST__g__32 Dampg_Pim_QuadDampgHwTqLpFil;
    
    /* initialization with random value */
    {
        Dampg_Pim_QuadDampgHwTqLpFil = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_Dampg_Pim_QuadDampgMotVelLpFil(void)
{
    extern struct __PST__g__32 Dampg_Pim_QuadDampgMotVelLpFil;
    
    /* initialization with random value */
    {
        Dampg_Pim_QuadDampgMotVelLpFil = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_Dampg_Pim_QuadDampgScaLpFil(void)
{
    extern struct __PST__g__32 Dampg_Pim_QuadDampgScaLpFil;
    
    /* initialization with random value */
    {
        Dampg_Pim_QuadDampgScaLpFil = _main_gen_init_g32();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Dampg_Ip_AssiCmdBas */
    _main_gen_init_sym_Dampg_Ip_AssiCmdBas();
    
    /* init for variable Dampg_Ip_AssiMechT */
    _main_gen_init_sym_Dampg_Ip_AssiMechT();
    
    /* init for variable Dampg_Ip_DampgCmdBasDi */
    _main_gen_init_sym_Dampg_Ip_DampgCmdBasDi();
    
    /* init for variable Dampg_Ip_DampgCmdOvrl */
    _main_gen_init_sym_Dampg_Ip_DampgCmdOvrl();
    
    /* init for variable Dampg_Ip_DampgCmdSca */
    _main_gen_init_sym_Dampg_Ip_DampgCmdSca();
    
    /* init for variable Dampg_Ip_HwTq */
    _main_gen_init_sym_Dampg_Ip_HwTq();
    
    /* init for variable Dampg_Ip_MotVelCrf */
    _main_gen_init_sym_Dampg_Ip_MotVelCrf();
    
    /* init for variable Dampg_Ip_VehSpd */
    _main_gen_init_sym_Dampg_Ip_VehSpd();
    
    /* init for variable Dampg_Op_DampgCmdBas : useless (never read) */

    /* init for variable Dampg_Cal_DampgHwTqX */
    _main_gen_init_sym_Dampg_Cal_DampgHwTqX();
    
    /* init for variable Dampg_Cal_DampgHwTqY */
    _main_gen_init_sym_Dampg_Cal_DampgHwTqY();
    
    /* init for variable Dampg_Cal_DampgHydAssiLim */
    _main_gen_init_sym_Dampg_Cal_DampgHydAssiLim();
    
    /* init for variable Dampg_Cal_DampgHydBasCoeff1 */
    _main_gen_init_sym_Dampg_Cal_DampgHydBasCoeff1();
    
    /* init for variable Dampg_Cal_DampgHydBasCoeff2 */
    _main_gen_init_sym_Dampg_Cal_DampgHydBasCoeff2();
    
    /* init for variable Dampg_Cal_DampgHydBasCoeff3 */
    _main_gen_init_sym_Dampg_Cal_DampgHydBasCoeff3();
    
    /* init for variable Dampg_Cal_DampgHydBasCoeff4 */
    _main_gen_init_sym_Dampg_Cal_DampgHydBasCoeff4();
    
    /* init for variable Dampg_Cal_DampgHydCoeff1ScaY */
    _main_gen_init_sym_Dampg_Cal_DampgHydCoeff1ScaY();
    
    /* init for variable Dampg_Cal_DampgHydCoeff2ScaY */
    _main_gen_init_sym_Dampg_Cal_DampgHydCoeff2ScaY();
    
    /* init for variable Dampg_Cal_DampgHydCoeff3ScaY */
    _main_gen_init_sym_Dampg_Cal_DampgHydCoeff3ScaY();
    
    /* init for variable Dampg_Cal_DampgHydCoeff4ScaY */
    _main_gen_init_sym_Dampg_Cal_DampgHydCoeff4ScaY();
    
    /* init for variable Dampg_Cal_DampgHydOutpLim */
    _main_gen_init_sym_Dampg_Cal_DampgHydOutpLim();
    
    /* init for variable Dampg_Cal_DampgMotVelLpFilFrq */
    _main_gen_init_sym_Dampg_Cal_DampgMotVelLpFilFrq();
    
    /* init for variable Dampg_Cal_DampgMotVelX */
    _main_gen_init_sym_Dampg_Cal_DampgMotVelX();
    
    /* init for variable Dampg_Cal_DampgMotVelY */
    _main_gen_init_sym_Dampg_Cal_DampgMotVelY();
    
    /* init for variable Dampg_Cal_DampgQuad13Mplr */
    _main_gen_init_sym_Dampg_Cal_DampgQuad13Mplr();
    
    /* init for variable Dampg_Cal_DampgQuad24Mplr */
    _main_gen_init_sym_Dampg_Cal_DampgQuad24Mplr();
    
    /* init for variable Dampg_Cal_DampgQuadHwTqBacklsh */
    _main_gen_init_sym_Dampg_Cal_DampgQuadHwTqBacklsh();
    
    /* init for variable Dampg_Cal_DampgQuadHwTqLpFilFrq */
    _main_gen_init_sym_Dampg_Cal_DampgQuadHwTqLpFilFrq();
    
    /* init for variable Dampg_Cal_DampgQuadMotVelBacklsh */
    _main_gen_init_sym_Dampg_Cal_DampgQuadMotVelBacklsh();
    
    /* init for variable Dampg_Cal_DampgQuadMotVelLpFilFrq */
    _main_gen_init_sym_Dampg_Cal_DampgQuadMotVelLpFilFrq();
    
    /* init for variable Dampg_Cal_DampgQuadScaLpFilFrq */
    _main_gen_init_sym_Dampg_Cal_DampgQuadScaLpFilFrq();
    
    /* init for variable Dampg_Cal_DampgTScaX */
    _main_gen_init_sym_Dampg_Cal_DampgTScaX();
    
    /* init for variable Dampg_Cal_DampgTScaY */
    _main_gen_init_sym_Dampg_Cal_DampgTScaY();
    
    /* init for variable Dampg_Cal_SysGlbPrmVehSpdBilnrSeln */
    _main_gen_init_sym_Dampg_Cal_SysGlbPrmVehSpdBilnrSeln();
    
    /* init for variable Dampg_Pim_dDampgAssiMechTSca : useless (never read) */

    /* init for variable Dampg_Pim_dDampgCoeff1Term : useless (never read) */

    /* init for variable Dampg_Pim_dDampgCoeff2Term : useless (never read) */

    /* init for variable Dampg_Pim_dDampgCoeff3Term : useless (never read) */

    /* init for variable Dampg_Pim_dDampgCoeff4Term : useless (never read) */

    /* init for variable Dampg_Pim_dDampgHwTqSca : useless (never read) */

    /* init for variable Dampg_Pim_dDampgMotVelDampgCmd : useless (never read) */

    /* init for variable Dampg_Pim_dDampgQuadHwTqBacklsh : useless (never read) */

    /* init for variable Dampg_Pim_dDampgQuadMotVelBacklsh : useless (never read) */

    /* init for variable Dampg_Pim_MotVelDampgLpFil */
    _main_gen_init_sym_Dampg_Pim_MotVelDampgLpFil();
    
    /* init for variable Dampg_Pim_PrevHwTqBacklshOutp */
    _main_gen_init_sym_Dampg_Pim_PrevHwTqBacklshOutp();
    
    /* init for variable Dampg_Pim_PrevMotVelBacklshOutp */
    _main_gen_init_sym_Dampg_Pim_PrevMotVelBacklshOutp();
    
    /* init for variable Dampg_Pim_QuadDampgHwTqLpFil */
    _main_gen_init_sym_Dampg_Pim_QuadDampgHwTqLpFil();
    
    /* init for variable Dampg_Pim_QuadDampgMotVelLpFil */
    _main_gen_init_sym_Dampg_Pim_QuadDampgMotVelLpFil();
    
    /* init for variable Dampg_Pim_QuadDampgScaLpFil */
    _main_gen_init_sym_Dampg_Pim_QuadDampgScaLpFil();
    
}
