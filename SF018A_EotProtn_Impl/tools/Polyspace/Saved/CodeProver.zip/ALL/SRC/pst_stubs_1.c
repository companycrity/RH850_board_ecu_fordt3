#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__31 _main_gen_init_g31(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__31 _main_gen_init_g31(void)
{
    static struct __PST__g__31 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_EotProtn_Ip_EotProtnDi(void)
{
    extern __PST__UINT8 EotProtn_Ip_EotProtnDi;
    
    /* initialization with random value */
    {
        EotProtn_Ip_EotProtnDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotProtn_Ip_HwAg(void)
{
    extern __PST__FLOAT32 EotProtn_Ip_HwAg;
    
    /* initialization with random value */
    {
        EotProtn_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Ip_HwAgAuthy(void)
{
    extern __PST__FLOAT32 EotProtn_Ip_HwAgAuthy;
    
    /* initialization with random value */
    {
        EotProtn_Ip_HwAgAuthy = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Ip_HwAgCcwDetd(void)
{
    extern __PST__UINT8 EotProtn_Ip_HwAgCcwDetd;
    
    /* initialization with random value */
    {
        EotProtn_Ip_HwAgCcwDetd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotProtn_Ip_HwAgCwDetd(void)
{
    extern __PST__UINT8 EotProtn_Ip_HwAgCwDetd;
    
    /* initialization with random value */
    {
        EotProtn_Ip_HwAgCwDetd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotProtn_Ip_HwAgEotCcw(void)
{
    extern __PST__FLOAT32 EotProtn_Ip_HwAgEotCcw;
    
    /* initialization with random value */
    {
        EotProtn_Ip_HwAgEotCcw = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Ip_HwAgEotCw(void)
{
    extern __PST__FLOAT32 EotProtn_Ip_HwAgEotCw;
    
    /* initialization with random value */
    {
        EotProtn_Ip_HwAgEotCw = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Ip_HwTq(void)
{
    extern __PST__FLOAT32 EotProtn_Ip_HwTq;
    
    /* initialization with random value */
    {
        EotProtn_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 EotProtn_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        EotProtn_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Ip_SysMotTqCmdSca(void)
{
    extern __PST__FLOAT32 EotProtn_Ip_SysMotTqCmdSca;
    
    /* initialization with random value */
    {
        EotProtn_Ip_SysMotTqCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 EotProtn_Ip_VehSpd;
    
    /* initialization with random value */
    {
        EotProtn_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnActvRegnBypMaxThd(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnActvRegnBypMaxThd;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnActvRegnBypMaxThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnDampgSlew(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnDampgSlew;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnDampgSlew = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnDampgVehSpdTbl(void)
{
    extern __PST__g__26 EotProtn_Cal_EotProtnDampgVehSpdTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 4; _main_gen_tmp_2_0++)
            {
                /* base type */
                EotProtn_Cal_EotProtnDampgVehSpdTbl[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnDeltaTqThd(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnDeltaTqThd;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnDeltaTqThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnDftPosn(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnDftPosn;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnDftPosn = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnEntrGainAuthyThd(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnEntrGainAuthyThd;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnEntrGainAuthyThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnEntrGainVehSpdTbl(void)
{
    extern __PST__g__27 EotProtn_Cal_EotProtnEntrGainVehSpdTbl;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 5; _main_gen_tmp_3_0++)
            {
                /* base type */
                EotProtn_Cal_EotProtnEntrGainVehSpdTbl[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnEntrGainX(void)
{
    extern __PST__g__28 EotProtn_Cal_EotProtnEntrGainX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 4; _main_gen_tmp_4_0++)
            {
                __PST__UINT32 _main_gen_tmp_4_1;
                
                for (_main_gen_tmp_4_1 = 0; _main_gen_tmp_4_1 < 5; _main_gen_tmp_4_1++)
                {
                    /* base type */
                    EotProtn_Cal_EotProtnEntrGainX[_main_gen_tmp_4_0][_main_gen_tmp_4_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnEntrGainY(void)
{
    extern __PST__g__28 EotProtn_Cal_EotProtnEntrGainY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 4; _main_gen_tmp_5_0++)
            {
                __PST__UINT32 _main_gen_tmp_5_1;
                
                for (_main_gen_tmp_5_1 = 0; _main_gen_tmp_5_1 < 5; _main_gen_tmp_5_1++)
                {
                    /* base type */
                    EotProtn_Cal_EotProtnEntrGainY[_main_gen_tmp_5_0][_main_gen_tmp_5_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnEntrStLpFilFrq(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnEntrStLpFilFrq;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnEntrStLpFilFrq = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnExitDampgY(void)
{
    extern __PST__g__29 EotProtn_Cal_EotProtnExitDampgY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 2; _main_gen_tmp_6_0++)
            {
                __PST__UINT32 _main_gen_tmp_6_1;
                
                for (_main_gen_tmp_6_1 = 0; _main_gen_tmp_6_1 < 4; _main_gen_tmp_6_1++)
                {
                    /* base type */
                    EotProtn_Cal_EotProtnExitDampgY[_main_gen_tmp_6_0][_main_gen_tmp_6_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnExitStLpFilFrq(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnExitStLpFilFrq;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnExitStLpFilFrq = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnHwAgGain(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnHwAgGain;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnHwAgGain = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnHwAgMax(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnHwAgMax;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnHwAgMax = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnHwAgMin(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnHwAgMin;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnHwAgMin = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnHwDegDampgX(void)
{
    extern __PST__g__29 EotProtn_Cal_EotProtnHwDegDampgX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 2; _main_gen_tmp_7_0++)
            {
                __PST__UINT32 _main_gen_tmp_7_1;
                
                for (_main_gen_tmp_7_1 = 0; _main_gen_tmp_7_1 < 4; _main_gen_tmp_7_1++)
                {
                    /* base type */
                    EotProtn_Cal_EotProtnHwDegDampgX[_main_gen_tmp_7_0][_main_gen_tmp_7_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnHwTqLpFilFrq(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnHwTqLpFilFrq;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnHwTqLpFilFrq = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnHwTqScaX(void)
{
    extern __PST__g__19 EotProtn_Cal_EotProtnHwTqScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 2; _main_gen_tmp_8_0++)
            {
                /* base type */
                EotProtn_Cal_EotProtnHwTqScaX[_main_gen_tmp_8_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnLoAuthyEntrGainY(void)
{
    extern __PST__g__28 EotProtn_Cal_EotProtnLoAuthyEntrGainY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 4; _main_gen_tmp_9_0++)
            {
                __PST__UINT32 _main_gen_tmp_9_1;
                
                for (_main_gen_tmp_9_1 = 0; _main_gen_tmp_9_1 < 5; _main_gen_tmp_9_1++)
                {
                    /* base type */
                    EotProtn_Cal_EotProtnLoAuthyEntrGainY[_main_gen_tmp_9_0][_main_gen_tmp_9_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnMotSpdIncptSca(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnMotSpdIncptSca;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnMotSpdIncptSca = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnMotSpdIncptX(void)
{
    extern __PST__g__19 EotProtn_Cal_EotProtnMotSpdIncptX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 2; _main_gen_tmp_10_0++)
            {
                /* base type */
                EotProtn_Cal_EotProtnMotSpdIncptX[_main_gen_tmp_10_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnMotSpdIncptY(void)
{
    extern __PST__g__19 EotProtn_Cal_EotProtnMotSpdIncptY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 2; _main_gen_tmp_11_0++)
            {
                /* base type */
                EotProtn_Cal_EotProtnMotSpdIncptY[_main_gen_tmp_11_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnMotVelGain(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnMotVelGain;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnMotVelGain = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnNormDampgY(void)
{
    extern __PST__g__29 EotProtn_Cal_EotProtnNormDampgY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 2; _main_gen_tmp_12_0++)
            {
                __PST__UINT32 _main_gen_tmp_12_1;
                
                for (_main_gen_tmp_12_1 = 0; _main_gen_tmp_12_1 < 4; _main_gen_tmp_12_1++)
                {
                    /* base type */
                    EotProtn_Cal_EotProtnNormDampgY[_main_gen_tmp_12_0][_main_gen_tmp_12_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnPosnRampStep(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnPosnRampStep;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnPosnRampStep = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrAuthyThd(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnRackTrvlLimrAuthyThd;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnRackTrvlLimrAuthyThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrAuthyThdLimd(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnRackTrvlLimrAuthyThdLimd;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnRackTrvlLimrAuthyThdLimd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrEna(void)
{
    extern __PST__g__30 EotProtn_Cal_EotProtnRackTrvlLimrEna;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnRackTrvlLimrEna = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrRng(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnRackTrvlLimrRng;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnRackTrvlLimrRng = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrRngLimd(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnRackTrvlLimrRngLimd;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnRackTrvlLimrRngLimd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrVehSpdThd(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnRackTrvlLimrVehSpdThd;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnRackTrvlLimrVehSpdThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnRunEotVelImpctAndSoftEndStop(void)
{
    extern __PST__g__30 EotProtn_Cal_EotProtnRunEotVelImpctAndSoftEndStop;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnRunEotVelImpctAndSoftEndStop = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnSoftEndStopAuthyThd(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnSoftEndStopAuthyThd;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnSoftEndStopAuthyThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnSoftEndStopEna(void)
{
    extern __PST__g__30 EotProtn_Cal_EotProtnSoftEndStopEna;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnSoftEndStopEna = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_EotProtn_Cal_EotProtnSoftEndStopVehSpdThd(void)
{
    extern __PST__g__25 EotProtn_Cal_EotProtnSoftEndStopVehSpdThd;
    
    /* initialization with random value */
    {
        EotProtn_Cal_EotProtnSoftEndStopVehSpdThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_EotProtn_Pim_EotAssiScaLpFil(void)
{
    extern struct __PST__g__31 EotProtn_Pim_EotAssiScaLpFil;
    
    /* initialization with random value */
    {
        EotProtn_Pim_EotAssiScaLpFil = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_EotProtn_Pim_HwTqLpFil(void)
{
    extern struct __PST__g__31 EotProtn_Pim_HwTqLpFil;
    
    /* initialization with random value */
    {
        EotProtn_Pim_HwTqLpFil = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_EotProtn_Pim_NewSoftEndStopSt(void)
{
    extern __PST__UINT8 EotProtn_Pim_NewSoftEndStopSt;
    
    /* initialization with random value */
    {
        EotProtn_Pim_NewSoftEndStopSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotProtn_Pim_PrevEotAssiSca(void)
{
    extern __PST__FLOAT32 EotProtn_Pim_PrevEotAssiSca;
    
    /* initialization with random value */
    {
        EotProtn_Pim_PrevEotAssiSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Pim_PrevEotDampg(void)
{
    extern __PST__FLOAT32 EotProtn_Pim_PrevEotDampg;
    
    /* initialization with random value */
    {
        EotProtn_Pim_PrevEotDampg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Pim_PrevImpctPosn(void)
{
    extern __PST__FLOAT32 EotProtn_Pim_PrevImpctPosn;
    
    /* initialization with random value */
    {
        EotProtn_Pim_PrevImpctPosn = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_EotProtn_Pim_PrevRackTrvlLimrEna(void)
{
    extern __PST__UINT8 EotProtn_Pim_PrevRackTrvlLimrEna;
    
    /* initialization with random value */
    {
        EotProtn_Pim_PrevRackTrvlLimrEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotProtn_Pim_PrevRackTrvlLimrInin(void)
{
    extern __PST__UINT8 EotProtn_Pim_PrevRackTrvlLimrInin;
    
    /* initialization with random value */
    {
        EotProtn_Pim_PrevRackTrvlLimrInin = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EotProtn_Pim_PrevSoftEndStopSt(void)
{
    extern __PST__UINT8 EotProtn_Pim_PrevSoftEndStopSt;
    
    /* initialization with random value */
    {
        EotProtn_Pim_PrevSoftEndStopSt = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable EotProtn_Ip_EotProtnDi */
    _main_gen_init_sym_EotProtn_Ip_EotProtnDi();
    
    /* init for variable EotProtn_Ip_HwAg */
    _main_gen_init_sym_EotProtn_Ip_HwAg();
    
    /* init for variable EotProtn_Ip_HwAgAuthy */
    _main_gen_init_sym_EotProtn_Ip_HwAgAuthy();
    
    /* init for variable EotProtn_Ip_HwAgCcwDetd */
    _main_gen_init_sym_EotProtn_Ip_HwAgCcwDetd();
    
    /* init for variable EotProtn_Ip_HwAgCwDetd */
    _main_gen_init_sym_EotProtn_Ip_HwAgCwDetd();
    
    /* init for variable EotProtn_Ip_HwAgEotCcw */
    _main_gen_init_sym_EotProtn_Ip_HwAgEotCcw();
    
    /* init for variable EotProtn_Ip_HwAgEotCw */
    _main_gen_init_sym_EotProtn_Ip_HwAgEotCw();
    
    /* init for variable EotProtn_Ip_HwTq */
    _main_gen_init_sym_EotProtn_Ip_HwTq();
    
    /* init for variable EotProtn_Ip_MotVelCrf */
    _main_gen_init_sym_EotProtn_Ip_MotVelCrf();
    
    /* init for variable EotProtn_Ip_SysMotTqCmdSca */
    _main_gen_init_sym_EotProtn_Ip_SysMotTqCmdSca();
    
    /* init for variable EotProtn_Ip_VehSpd */
    _main_gen_init_sym_EotProtn_Ip_VehSpd();
    
    /* init for variable EotProtn_Op_EotActvCmd : useless (never read) */

    /* init for variable EotProtn_Op_EotAssiSca : useless (never read) */

    /* init for variable EotProtn_Op_EotDampgCmd : useless (never read) */

    /* init for variable EotProtn_Op_EotMotTqLim : useless (never read) */

    /* init for variable EotProtn_Cal_EotProtnActvRegnBypMaxThd */
    _main_gen_init_sym_EotProtn_Cal_EotProtnActvRegnBypMaxThd();
    
    /* init for variable EotProtn_Cal_EotProtnDampgSlew */
    _main_gen_init_sym_EotProtn_Cal_EotProtnDampgSlew();
    
    /* init for variable EotProtn_Cal_EotProtnDampgVehSpdTbl */
    _main_gen_init_sym_EotProtn_Cal_EotProtnDampgVehSpdTbl();
    
    /* init for variable EotProtn_Cal_EotProtnDeltaTqThd */
    _main_gen_init_sym_EotProtn_Cal_EotProtnDeltaTqThd();
    
    /* init for variable EotProtn_Cal_EotProtnDftPosn */
    _main_gen_init_sym_EotProtn_Cal_EotProtnDftPosn();
    
    /* init for variable EotProtn_Cal_EotProtnEntrGainAuthyThd */
    _main_gen_init_sym_EotProtn_Cal_EotProtnEntrGainAuthyThd();
    
    /* init for variable EotProtn_Cal_EotProtnEntrGainVehSpdTbl */
    _main_gen_init_sym_EotProtn_Cal_EotProtnEntrGainVehSpdTbl();
    
    /* init for variable EotProtn_Cal_EotProtnEntrGainX */
    _main_gen_init_sym_EotProtn_Cal_EotProtnEntrGainX();
    
    /* init for variable EotProtn_Cal_EotProtnEntrGainY */
    _main_gen_init_sym_EotProtn_Cal_EotProtnEntrGainY();
    
    /* init for variable EotProtn_Cal_EotProtnEntrStLpFilFrq */
    _main_gen_init_sym_EotProtn_Cal_EotProtnEntrStLpFilFrq();
    
    /* init for variable EotProtn_Cal_EotProtnExitDampgY */
    _main_gen_init_sym_EotProtn_Cal_EotProtnExitDampgY();
    
    /* init for variable EotProtn_Cal_EotProtnExitStLpFilFrq */
    _main_gen_init_sym_EotProtn_Cal_EotProtnExitStLpFilFrq();
    
    /* init for variable EotProtn_Cal_EotProtnHwAgGain */
    _main_gen_init_sym_EotProtn_Cal_EotProtnHwAgGain();
    
    /* init for variable EotProtn_Cal_EotProtnHwAgMax */
    _main_gen_init_sym_EotProtn_Cal_EotProtnHwAgMax();
    
    /* init for variable EotProtn_Cal_EotProtnHwAgMin */
    _main_gen_init_sym_EotProtn_Cal_EotProtnHwAgMin();
    
    /* init for variable EotProtn_Cal_EotProtnHwDegDampgX */
    _main_gen_init_sym_EotProtn_Cal_EotProtnHwDegDampgX();
    
    /* init for variable EotProtn_Cal_EotProtnHwTqLpFilFrq */
    _main_gen_init_sym_EotProtn_Cal_EotProtnHwTqLpFilFrq();
    
    /* init for variable EotProtn_Cal_EotProtnHwTqScaX */
    _main_gen_init_sym_EotProtn_Cal_EotProtnHwTqScaX();
    
    /* init for variable EotProtn_Cal_EotProtnLoAuthyEntrGainY */
    _main_gen_init_sym_EotProtn_Cal_EotProtnLoAuthyEntrGainY();
    
    /* init for variable EotProtn_Cal_EotProtnMotSpdIncptSca */
    _main_gen_init_sym_EotProtn_Cal_EotProtnMotSpdIncptSca();
    
    /* init for variable EotProtn_Cal_EotProtnMotSpdIncptX */
    _main_gen_init_sym_EotProtn_Cal_EotProtnMotSpdIncptX();
    
    /* init for variable EotProtn_Cal_EotProtnMotSpdIncptY */
    _main_gen_init_sym_EotProtn_Cal_EotProtnMotSpdIncptY();
    
    /* init for variable EotProtn_Cal_EotProtnMotVelGain */
    _main_gen_init_sym_EotProtn_Cal_EotProtnMotVelGain();
    
    /* init for variable EotProtn_Cal_EotProtnNormDampgY */
    _main_gen_init_sym_EotProtn_Cal_EotProtnNormDampgY();
    
    /* init for variable EotProtn_Cal_EotProtnPosnRampStep */
    _main_gen_init_sym_EotProtn_Cal_EotProtnPosnRampStep();
    
    /* init for variable EotProtn_Cal_EotProtnRackTrvlLimrAuthyThd */
    _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrAuthyThd();
    
    /* init for variable EotProtn_Cal_EotProtnRackTrvlLimrAuthyThdLimd */
    _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrAuthyThdLimd();
    
    /* init for variable EotProtn_Cal_EotProtnRackTrvlLimrEna */
    _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrEna();
    
    /* init for variable EotProtn_Cal_EotProtnRackTrvlLimrRng */
    _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrRng();
    
    /* init for variable EotProtn_Cal_EotProtnRackTrvlLimrRngLimd */
    _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrRngLimd();
    
    /* init for variable EotProtn_Cal_EotProtnRackTrvlLimrVehSpdThd */
    _main_gen_init_sym_EotProtn_Cal_EotProtnRackTrvlLimrVehSpdThd();
    
    /* init for variable EotProtn_Cal_EotProtnRunEotVelImpctAndSoftEndStop */
    _main_gen_init_sym_EotProtn_Cal_EotProtnRunEotVelImpctAndSoftEndStop();
    
    /* init for variable EotProtn_Cal_EotProtnSoftEndStopAuthyThd */
    _main_gen_init_sym_EotProtn_Cal_EotProtnSoftEndStopAuthyThd();
    
    /* init for variable EotProtn_Cal_EotProtnSoftEndStopEna */
    _main_gen_init_sym_EotProtn_Cal_EotProtnSoftEndStopEna();
    
    /* init for variable EotProtn_Cal_EotProtnSoftEndStopVehSpdThd */
    _main_gen_init_sym_EotProtn_Cal_EotProtnSoftEndStopVehSpdThd();
    
    /* init for variable EotProtn_Pim_dEotProtnDampg : useless (never read) */

    /* init for variable EotProtn_Pim_dEotProtnDetd : useless (never read) */

    /* init for variable EotProtn_Pim_dEotProtnEntrGain : useless (never read) */

    /* init for variable EotProtn_Pim_dEotProtnEotAssiSca : useless (never read) */

    /* init for variable EotProtn_Pim_dEotProtnEotGain : useless (never read) */

    /* init for variable EotProtn_Pim_dEotProtnExitGain : useless (never read) */

    /* init for variable EotProtn_Pim_dEotProtnLimPosn : useless (never read) */

    /* init for variable EotProtn_Pim_dEotProtnRackTrvlLimrDi : useless (never read) */

    /* init for variable EotProtn_Pim_EotAssiScaLpFil */
    _main_gen_init_sym_EotProtn_Pim_EotAssiScaLpFil();
    
    /* init for variable EotProtn_Pim_HwTqLpFil */
    _main_gen_init_sym_EotProtn_Pim_HwTqLpFil();
    
    /* init for variable EotProtn_Pim_NewSoftEndStopSt */
    _main_gen_init_sym_EotProtn_Pim_NewSoftEndStopSt();
    
    /* init for variable EotProtn_Pim_PrevEotAssiSca */
    _main_gen_init_sym_EotProtn_Pim_PrevEotAssiSca();
    
    /* init for variable EotProtn_Pim_PrevEotDampg */
    _main_gen_init_sym_EotProtn_Pim_PrevEotDampg();
    
    /* init for variable EotProtn_Pim_PrevImpctPosn */
    _main_gen_init_sym_EotProtn_Pim_PrevImpctPosn();
    
    /* init for variable EotProtn_Pim_PrevRackTrvlLimrEna */
    _main_gen_init_sym_EotProtn_Pim_PrevRackTrvlLimrEna();
    
    /* init for variable EotProtn_Pim_PrevRackTrvlLimrInin */
    _main_gen_init_sym_EotProtn_Pim_PrevRackTrvlLimrInin();
    
    /* init for variable EotProtn_Pim_PrevSoftEndStopSt */
    _main_gen_init_sym_EotProtn_Pim_PrevSoftEndStopSt();
    
}
