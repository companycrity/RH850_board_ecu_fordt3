/* Stub File for sandbox compile and unit testing : Based on Mcu.h in Mcu component */
void Mcu_EcmReleaseErrorOutPin(void);
