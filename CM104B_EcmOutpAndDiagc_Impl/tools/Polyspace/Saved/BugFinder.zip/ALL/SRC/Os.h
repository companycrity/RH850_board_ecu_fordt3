#ifndef _OS_H
# define _OS_H

extern void SuspendAllInterrupts(void);
extern void ResumeAllInterrupts(void);

#endif /*_OS_H */
