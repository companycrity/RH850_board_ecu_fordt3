#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__g__120 _main_gen_init_g120(void);

extern __PST__g__115 _main_gen_init_g115(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__g__112 _main_gen_init_g112(void);

extern __PST__g__109 _main_gen_init_g109(void);

extern __PST__g__106 _main_gen_init_g106(void);

extern __PST__g__101 _main_gen_init_g101(void);

extern __PST__g__96 _main_gen_init_g96(void);

extern __PST__g__91 _main_gen_init_g91(void);

extern __PST__g__86 _main_gen_init_g86(void);

extern __PST__g__81 _main_gen_init_g81(void);

extern __PST__g__76 _main_gen_init_g76(void);

extern __PST__g__71 _main_gen_init_g71(void);

extern __PST__g__67 _main_gen_init_g67(void);

extern __PST__g__64 _main_gen_init_g64(void);

extern __PST__g__61 _main_gen_init_g61(void);

extern __PST__g__58 _main_gen_init_g58(void);

extern __PST__g__55 _main_gen_init_g55(void);

extern __PST__g__52 _main_gen_init_g52(void);

extern __PST__g__49 _main_gen_init_g49(void);

extern __PST__g__46 _main_gen_init_g46(void);

extern __PST__g__43 _main_gen_init_g43(void);

extern __PST__g__40 _main_gen_init_g40(void);

extern __PST__g__33 _main_gen_init_g33(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__23 _main_gen_init_g23(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__33 _main_gen_init_g33(void)
{
    __PST__g__33 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__40 _main_gen_init_g40(void)
{
    __PST__g__40 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__43 _main_gen_init_g43(void)
{
    __PST__g__43 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__46 _main_gen_init_g46(void)
{
    __PST__g__46 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__49 _main_gen_init_g49(void)
{
    __PST__g__49 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__52 _main_gen_init_g52(void)
{
    __PST__g__52 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__55 _main_gen_init_g55(void)
{
    __PST__g__55 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__58 _main_gen_init_g58(void)
{
    __PST__g__58 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__61 _main_gen_init_g61(void)
{
    __PST__g__61 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__64 _main_gen_init_g64(void)
{
    __PST__g__64 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__67 _main_gen_init_g67(void)
{
    __PST__g__67 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__71 _main_gen_init_g71(void)
{
    __PST__g__71 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__76 _main_gen_init_g76(void)
{
    __PST__g__76 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__81 _main_gen_init_g81(void)
{
    __PST__g__81 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__86 _main_gen_init_g86(void)
{
    __PST__g__86 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__91 _main_gen_init_g91(void)
{
    __PST__g__91 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__96 _main_gen_init_g96(void)
{
    __PST__g__96 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__101 _main_gen_init_g101(void)
{
    __PST__g__101 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__106 _main_gen_init_g106(void)
{
    __PST__g__106 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__109 _main_gen_init_g109(void)
{
    __PST__g__109 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__112 _main_gen_init_g112(void)
{
    __PST__g__112 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__115 _main_gen_init_g115(void)
{
    __PST__g__115 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__120 _main_gen_init_g120(void)
{
    __PST__g__120 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ECM0ESSTC2_BASE(void)
{
    extern __PST__g__23 ECM0ESSTC2_BASE;
    
    /* initialization with random value */
    {
        ECM0ESSTC2_BASE = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_ECM0PEM_BASE(void)
{
    extern __PST__g__27 ECM0PEM_BASE;
    
    /* initialization with random value */
    {
        ECM0PEM_BASE = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_ECMM0ESET_BASE(void)
{
    extern __PST__g__30 ECMM0ESET_BASE;
    
    /* initialization with random value */
    {
        ECMM0ESET_BASE = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_ECMC0ESET_BASE(void)
{
    extern __PST__g__33 ECMC0ESET_BASE;
    
    /* initialization with random value */
    {
        ECMC0ESET_BASE = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_ECM0EPCFG_BASE(void)
{
    extern __PST__g__40 ECM0EPCFG_BASE;
    
    /* initialization with random value */
    {
        ECM0EPCFG_BASE = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_ECM0MICFG2_BASE(void)
{
    extern __PST__g__43 ECM0MICFG2_BASE;
    
    /* initialization with random value */
    {
        ECM0MICFG2_BASE = _main_gen_init_g43();
    }
}

static void _main_gen_init_sym_ECM0NMICFG0_BASE(void)
{
    extern __PST__g__46 ECM0NMICFG0_BASE;
    
    /* initialization with random value */
    {
        ECM0NMICFG0_BASE = _main_gen_init_g46();
    }
}

static void _main_gen_init_sym_ECM0NMICFG2_BASE(void)
{
    extern __PST__g__49 ECM0NMICFG2_BASE;
    
    /* initialization with random value */
    {
        ECM0NMICFG2_BASE = _main_gen_init_g49();
    }
}

static void _main_gen_init_sym_ECM0IRCFG2_BASE(void)
{
    extern __PST__g__52 ECM0IRCFG2_BASE;
    
    /* initialization with random value */
    {
        ECM0IRCFG2_BASE = _main_gen_init_g52();
    }
}

static void _main_gen_init_sym_ECM0EMK0_BASE(void)
{
    extern __PST__g__55 ECM0EMK0_BASE;
    
    /* initialization with random value */
    {
        ECM0EMK0_BASE = _main_gen_init_g55();
    }
}

static void _main_gen_init_sym_ECM0EMK1_BASE(void)
{
    extern __PST__g__58 ECM0EMK1_BASE;
    
    /* initialization with random value */
    {
        ECM0EMK1_BASE = _main_gen_init_g58();
    }
}

static void _main_gen_init_sym_ECM0EMK2_BASE(void)
{
    extern __PST__g__61 ECM0EMK2_BASE;
    
    /* initialization with random value */
    {
        ECM0EMK2_BASE = _main_gen_init_g61();
    }
}

static void _main_gen_init_sym_ECM0PE2_BASE(void)
{
    extern __PST__g__64 ECM0PE2_BASE;
    
    /* initialization with random value */
    {
        ECM0PE2_BASE = _main_gen_init_g64();
    }
}

static void _main_gen_init_sym_ECM0EOCCFG_BASE(void)
{
    extern __PST__g__67 ECM0EOCCFG_BASE;
    
    /* initialization with random value */
    {
        ECM0EOCCFG_BASE = _main_gen_init_g67();
    }
}

static void _main_gen_init_sym_ECMM0ESSTR0_BASE(void)
{
    extern __PST__g__71 ECMM0ESSTR0_BASE;
    
    /* initialization with random value */
    {
        ECMM0ESSTR0_BASE = _main_gen_init_g71();
    }
}

static void _main_gen_init_sym_ECMM0ESSTR1_BASE(void)
{
    extern __PST__g__76 ECMM0ESSTR1_BASE;
    
    /* initialization with random value */
    {
        ECMM0ESSTR1_BASE = _main_gen_init_g76();
    }
}

static void _main_gen_init_sym_ECMM0ESSTR2_BASE(void)
{
    extern __PST__g__81 ECMM0ESSTR2_BASE;
    
    /* initialization with random value */
    {
        ECMM0ESSTR2_BASE = _main_gen_init_g81();
    }
}

static void _main_gen_init_sym_ECMC0ESSTR0_BASE(void)
{
    extern __PST__g__86 ECMC0ESSTR0_BASE;
    
    /* initialization with random value */
    {
        ECMC0ESSTR0_BASE = _main_gen_init_g86();
    }
}

static void _main_gen_init_sym_ECMC0ESSTR1_BASE(void)
{
    extern __PST__g__91 ECMC0ESSTR1_BASE;
    
    /* initialization with random value */
    {
        ECMC0ESSTR1_BASE = _main_gen_init_g91();
    }
}

static void _main_gen_init_sym_ECMC0ESSTR2_BASE(void)
{
    extern __PST__g__96 ECMC0ESSTR2_BASE;
    
    /* initialization with random value */
    {
        ECMC0ESSTR2_BASE = _main_gen_init_g96();
    }
}

static void _main_gen_init_sym_FEINTF0_BASE(void)
{
    extern __PST__g__101 FEINTF0_BASE;
    
    /* initialization with random value */
    {
        FEINTF0_BASE = _main_gen_init_g101();
    }
}

static void _main_gen_init_sym_FEINTFMSK0_BASE(void)
{
    extern __PST__g__106 FEINTFMSK0_BASE;
    
    /* initialization with random value */
    {
        FEINTFMSK0_BASE = _main_gen_init_g106();
    }
}

static void _main_gen_init_sym_FEINTFC0_BASE(void)
{
    extern __PST__g__109 FEINTFC0_BASE;
    
    /* initialization with random value */
    {
        FEINTFC0_BASE = _main_gen_init_g109();
    }
}

static void _main_gen_init_sym_EIC0_BASE(void)
{
    extern __PST__g__112 EIC0_BASE;
    
    /* initialization with random value */
    {
        EIC0_BASE = _main_gen_init_g112();
    }
}

static void _main_gen_init_sym_FIC_BASE(void)
{
    extern __PST__g__115 FIC_BASE;
    
    /* initialization with random value */
    {
        FIC_BASE = _main_gen_init_g115();
    }
}

static void _main_gen_init_sym_IMR0_BASE(void)
{
    extern __PST__g__120 IMR0_BASE;
    
    /* initialization with random value */
    {
        IMR0_BASE = _main_gen_init_g120();
    }
}

static void _main_gen_init_sym_EcmOutpAndDiagc_Cli_CtrlErrOut_PinSt(void)
{
    extern __PST__UINT8 EcmOutpAndDiagc_Cli_CtrlErrOut_PinSt;
    
    /* initialization with random value */
    {
        EcmOutpAndDiagc_Cli_CtrlErrOut_PinSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_EcmOutpAndDiagc_Cli_CtrlErrOut_TrigReg(void)
{
    extern __PST__UINT8 EcmOutpAndDiagc_Cli_CtrlErrOut_TrigReg;
    
    /* initialization with random value */
    {
        EcmOutpAndDiagc_Cli_CtrlErrOut_TrigReg = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ECM0ESSTC2_BASE */
    _main_gen_init_sym_ECM0ESSTC2_BASE();
    
    /* init for variable ECM0PEM_BASE */
    _main_gen_init_sym_ECM0PEM_BASE();
    
    /* init for variable ECMM0ESET_BASE */
    _main_gen_init_sym_ECMM0ESET_BASE();
    
    /* init for variable ECMC0ESET_BASE */
    _main_gen_init_sym_ECMC0ESET_BASE();
    
    /* init for variable EcmOutpAndDiagc_Pim_dEcmVrfyErrOutpCtrlCmpl : useless (never read) */

    /* init for variable EcmOutpAndDiagc_Pim_dEcmVrfyIntrptGennCmpl : useless (never read) */

    /* init for variable ECM0EPCFG_BASE */
    _main_gen_init_sym_ECM0EPCFG_BASE();
    
    /* init for variable ECM0MICFG2_BASE */
    _main_gen_init_sym_ECM0MICFG2_BASE();
    
    /* init for variable ECM0NMICFG0_BASE */
    _main_gen_init_sym_ECM0NMICFG0_BASE();
    
    /* init for variable ECM0NMICFG2_BASE */
    _main_gen_init_sym_ECM0NMICFG2_BASE();
    
    /* init for variable ECM0IRCFG2_BASE */
    _main_gen_init_sym_ECM0IRCFG2_BASE();
    
    /* init for variable ECM0EMK0_BASE */
    _main_gen_init_sym_ECM0EMK0_BASE();
    
    /* init for variable ECM0EMK1_BASE */
    _main_gen_init_sym_ECM0EMK1_BASE();
    
    /* init for variable ECM0EMK2_BASE */
    _main_gen_init_sym_ECM0EMK2_BASE();
    
    /* init for variable ECM0PE2_BASE */
    _main_gen_init_sym_ECM0PE2_BASE();
    
    /* init for variable ECM0EOCCFG_BASE */
    _main_gen_init_sym_ECM0EOCCFG_BASE();
    
    /* init for variable ECMM0ESSTR0_BASE */
    _main_gen_init_sym_ECMM0ESSTR0_BASE();
    
    /* init for variable ECMM0ESSTR1_BASE */
    _main_gen_init_sym_ECMM0ESSTR1_BASE();
    
    /* init for variable ECMM0ESSTR2_BASE */
    _main_gen_init_sym_ECMM0ESSTR2_BASE();
    
    /* init for variable ECMC0ESSTR0_BASE */
    _main_gen_init_sym_ECMC0ESSTR0_BASE();
    
    /* init for variable ECMC0ESSTR1_BASE */
    _main_gen_init_sym_ECMC0ESSTR1_BASE();
    
    /* init for variable ECMC0ESSTR2_BASE */
    _main_gen_init_sym_ECMC0ESSTR2_BASE();
    
    /* init for variable FEINTF0_BASE */
    _main_gen_init_sym_FEINTF0_BASE();
    
    /* init for variable FEINTFMSK0_BASE */
    _main_gen_init_sym_FEINTFMSK0_BASE();
    
    /* init for variable FEINTFC0_BASE */
    _main_gen_init_sym_FEINTFC0_BASE();
    
    /* init for variable EIC0_BASE */
    _main_gen_init_sym_EIC0_BASE();
    
    /* init for variable FIC_BASE */
    _main_gen_init_sym_FIC_BASE();
    
    /* init for variable IMR0_BASE */
    _main_gen_init_sym_IMR0_BASE();
    
    /* init for variable EcmOutpAndDiagc_Cli_CtrlErrOut_PinSt */
    _main_gen_init_sym_EcmOutpAndDiagc_Cli_CtrlErrOut_PinSt();
    
    /* init for variable EcmOutpAndDiagc_Cli_CtrlErrOut_TrigReg */
    _main_gen_init_sym_EcmOutpAndDiagc_Cli_CtrlErrOut_TrigReg();
    
}
