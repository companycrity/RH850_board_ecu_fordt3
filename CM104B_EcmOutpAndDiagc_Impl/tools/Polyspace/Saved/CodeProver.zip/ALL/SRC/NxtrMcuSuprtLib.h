/* Stub File for Unit Testing and Sandbox Compiles */
extern FUNC(void, NxtrMcuSuprtLib_CODE) WrProtdRegEcmm0_u32(uint32 WrVal_Arg, P2VAR(volatile uint32, AUTOMATIC, NxtrMcuSuprtLib_APPL_VAR) WrAddr_Arg);
extern FUNC(void, NxtrMcuSuprtLib_CODE) WrProtdRegEcmc0_u32(uint32 WrVal_Arg, P2VAR(volatile uint32, AUTOMATIC, NxtrMcuSuprtLib_APPL_VAR) WrAddr_Arg);
extern FUNC(void, NxtrMcuSuprtLib_CODE) WrProtdRegEcm0_u32( uint32 WrVal_Arg, P2VAR(volatile uint32, AUTOMATIC, NxtrMcuSuprtLib_APPL_VAR) WrAddr_Arg);
