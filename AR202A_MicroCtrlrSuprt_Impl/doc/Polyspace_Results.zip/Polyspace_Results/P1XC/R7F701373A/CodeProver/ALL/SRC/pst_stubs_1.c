#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__65 _main_gen_init_g65(void);

extern __PST__g__60 _main_gen_init_g60(void);

extern __PST__g__56 _main_gen_init_g56(void);

extern __PST__g__53 _main_gen_init_g53(void);

extern __PST__g__50 _main_gen_init_g50(void);

extern __PST__g__47 _main_gen_init_g47(void);

extern __PST__g__44 _main_gen_init_g44(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__g__38 _main_gen_init_g38(void);

extern __PST__g__35 _main_gen_init_g35(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__25 _main_gen_init_g25(void);

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__35 _main_gen_init_g35(void)
{
    __PST__g__35 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__38 _main_gen_init_g38(void)
{
    __PST__g__38 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__44 _main_gen_init_g44(void)
{
    __PST__g__44 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__47 _main_gen_init_g47(void)
{
    __PST__g__47 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__50 _main_gen_init_g50(void)
{
    __PST__g__50 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__53 _main_gen_init_g53(void)
{
    __PST__g__53 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__56 _main_gen_init_g56(void)
{
    __PST__g__56 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__60 _main_gen_init_g60(void)
{
    __PST__g__60 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__65 _main_gen_init_g65(void)
{
    __PST__g__65 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ECM0ESSTC0_BASE(void)
{
    extern __PST__g__25 ECM0ESSTC0_BASE;
    
    /* initialization with random value */
    {
        ECM0ESSTC0_BASE = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_ECM0ESSTC1_BASE(void)
{
    extern __PST__g__29 ECM0ESSTC1_BASE;
    
    /* initialization with random value */
    {
        ECM0ESSTC1_BASE = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_ECM0ESSTC2_BASE(void)
{
    extern __PST__g__32 ECM0ESSTC2_BASE;
    
    /* initialization with random value */
    {
        ECM0ESSTC2_BASE = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_ECM0PCMD1_BASE(void)
{
    extern __PST__g__35 ECM0PCMD1_BASE;
    
    /* initialization with random value */
    {
        ECM0PCMD1_BASE = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_ECM0PS_BASE(void)
{
    extern __PST__g__38 ECM0PS_BASE;
    
    /* initialization with random value */
    {
        ECM0PS_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_ECMM0ESET_BASE(void)
{
    extern __PST__g__44 ECMM0ESET_BASE;
    
    /* initialization with random value */
    {
        ECMM0ESET_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ECMM0PCMD0_BASE(void)
{
    extern __PST__g__47 ECMM0PCMD0_BASE;
    
    /* initialization with random value */
    {
        ECMM0PCMD0_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ECMC0ESET_BASE(void)
{
    extern __PST__g__50 ECMC0ESET_BASE;
    
    /* initialization with random value */
    {
        ECMC0ESET_BASE = _main_gen_init_g50();
    }
}

static void _main_gen_init_sym_ECMC0PCMD0_BASE(void)
{
    extern __PST__g__53 ECMC0PCMD0_BASE;
    
    /* initialization with random value */
    {
        ECMC0PCMD0_BASE = _main_gen_init_g53();
    }
}

static void _main_gen_init_sym_FLMDPCMD_BASE(void)
{
    extern __PST__g__56 FLMDPCMD_BASE;
    
    /* initialization with random value */
    {
        FLMDPCMD_BASE = _main_gen_init_g56();
    }
}

static void _main_gen_init_sym_FLMDPS_BASE(void)
{
    extern __PST__g__60 FLMDPS_BASE;
    
    /* initialization with random value */
    {
        FLMDPS_BASE = _main_gen_init_g60();
    }
}

static void _main_gen_init_sym_RESFC_BASE(void)
{
    extern __PST__g__65 RESFC_BASE;
    
    /* initialization with random value */
    {
        RESFC_BASE = _main_gen_init_g65();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ECM0ESSTC0_BASE */
    _main_gen_init_sym_ECM0ESSTC0_BASE();
    
    /* init for variable ECM0ESSTC1_BASE */
    _main_gen_init_sym_ECM0ESSTC1_BASE();
    
    /* init for variable ECM0ESSTC2_BASE */
    _main_gen_init_sym_ECM0ESSTC2_BASE();
    
    /* init for variable ECM0PCMD1_BASE */
    _main_gen_init_sym_ECM0PCMD1_BASE();
    
    /* init for variable ECM0PS_BASE */
    _main_gen_init_sym_ECM0PS_BASE();
    
    /* init for variable ECMM0ESET_BASE */
    _main_gen_init_sym_ECMM0ESET_BASE();
    
    /* init for variable ECMM0PCMD0_BASE */
    _main_gen_init_sym_ECMM0PCMD0_BASE();
    
    /* init for variable ECMC0ESET_BASE */
    _main_gen_init_sym_ECMC0ESET_BASE();
    
    /* init for variable ECMC0PCMD0_BASE */
    _main_gen_init_sym_ECMC0PCMD0_BASE();
    
    /* init for variable FLMDPCMD_BASE */
    _main_gen_init_sym_FLMDPCMD_BASE();
    
    /* init for variable FLMDPS_BASE */
    _main_gen_init_sym_FLMDPS_BASE();
    
    /* init for variable RESFC_BASE */
    _main_gen_init_sym_RESFC_BASE();
    
}
