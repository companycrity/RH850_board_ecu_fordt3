#!/bin/sh
polyspace-code-prover-nodesktop -options-file server-options.opt
