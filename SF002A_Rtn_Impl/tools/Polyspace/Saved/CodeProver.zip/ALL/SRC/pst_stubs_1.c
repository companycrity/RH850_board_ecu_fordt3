#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__27 _main_gen_init_g27(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__27 _main_gen_init_g27(void)
{
    __PST__g__27 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rtn_Ip_AssiMechT(void)
{
    extern __PST__FLOAT32 Rtn_Ip_AssiMechT;
    
    /* initialization with random value */
    {
        Rtn_Ip_AssiMechT = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Rtn_Ip_HwAg(void)
{
    extern __PST__FLOAT32 Rtn_Ip_HwAg;
    
    /* initialization with random value */
    {
        Rtn_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Rtn_Ip_HwAgAuthySca(void)
{
    extern __PST__FLOAT32 Rtn_Ip_HwAgAuthySca;
    
    /* initialization with random value */
    {
        Rtn_Ip_HwAgAuthySca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Rtn_Ip_HwAgRtnOffs(void)
{
    extern __PST__FLOAT32 Rtn_Ip_HwAgRtnOffs;
    
    /* initialization with random value */
    {
        Rtn_Ip_HwAgRtnOffs = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Rtn_Ip_HwTq(void)
{
    extern __PST__FLOAT32 Rtn_Ip_HwTq;
    
    /* initialization with random value */
    {
        Rtn_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Rtn_Ip_HwVel(void)
{
    extern __PST__FLOAT32 Rtn_Ip_HwVel;
    
    /* initialization with random value */
    {
        Rtn_Ip_HwVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Rtn_Ip_RtnCmdDi(void)
{
    extern __PST__UINT8 Rtn_Ip_RtnCmdDi;
    
    /* initialization with random value */
    {
        Rtn_Ip_RtnCmdDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Rtn_Ip_RtnCmdDiagcDi(void)
{
    extern __PST__UINT8 Rtn_Ip_RtnCmdDiagcDi;
    
    /* initialization with random value */
    {
        Rtn_Ip_RtnCmdDiagcDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Rtn_Ip_RtnCmdSca(void)
{
    extern __PST__FLOAT32 Rtn_Ip_RtnCmdSca;
    
    /* initialization with random value */
    {
        Rtn_Ip_RtnCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Rtn_Ip_RtnCmdScaServo(void)
{
    extern __PST__FLOAT32 Rtn_Ip_RtnCmdScaServo;
    
    /* initialization with random value */
    {
        Rtn_Ip_RtnCmdScaServo = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Rtn_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 Rtn_Ip_VehSpd;
    
    /* initialization with random value */
    {
        Rtn_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Rtn_Ip_VehSpdVld(void)
{
    extern __PST__UINT8 Rtn_Ip_VehSpdVld;
    
    /* initialization with random value */
    {
        Rtn_Ip_VehSpdVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnHwAgOffsCalcdX(void)
{
    extern __PST__g__23 Rtn_Cal_RtnHwAgOffsCalcdX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 9; _main_gen_tmp_0_0++)
            {
                __PST__UINT32 _main_gen_tmp_0_1;
                
                for (_main_gen_tmp_0_1 = 0; _main_gen_tmp_0_1 < 16; _main_gen_tmp_0_1++)
                {
                    /* base type */
                    Rtn_Cal_RtnHwAgOffsCalcdX[_main_gen_tmp_0_0][_main_gen_tmp_0_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnHwAgOffsCalcdY(void)
{
    extern __PST__g__23 Rtn_Cal_RtnHwAgOffsCalcdY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 9; _main_gen_tmp_1_0++)
            {
                __PST__UINT32 _main_gen_tmp_1_1;
                
                for (_main_gen_tmp_1_1 = 0; _main_gen_tmp_1_1 < 16; _main_gen_tmp_1_1++)
                {
                    /* base type */
                    Rtn_Cal_RtnHwAgOffsCalcdY[_main_gen_tmp_1_0][_main_gen_tmp_1_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnHwAuthyScaX(void)
{
    extern __PST__g__26 Rtn_Cal_RtnHwAuthyScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 4; _main_gen_tmp_2_0++)
            {
                /* base type */
                Rtn_Cal_RtnHwAuthyScaX[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnHwAuthyScaY(void)
{
    extern __PST__g__26 Rtn_Cal_RtnHwAuthyScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 4; _main_gen_tmp_3_0++)
            {
                /* base type */
                Rtn_Cal_RtnHwAuthyScaY[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnHwAuthySlew(void)
{
    extern __PST__g__27 Rtn_Cal_RtnHwAuthySlew;
    
    /* initialization with random value */
    {
        Rtn_Cal_RtnHwAuthySlew = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnOffsRng(void)
{
    extern __PST__g__27 Rtn_Cal_RtnOffsRng;
    
    /* initialization with random value */
    {
        Rtn_Cal_RtnOffsRng = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnOffsSlew(void)
{
    extern __PST__g__27 Rtn_Cal_RtnOffsSlew;
    
    /* initialization with random value */
    {
        Rtn_Cal_RtnOffsSlew = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnScaTqX(void)
{
    extern __PST__g__28 Rtn_Cal_RtnScaTqX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 9; _main_gen_tmp_4_0++)
            {
                __PST__UINT32 _main_gen_tmp_4_1;
                
                for (_main_gen_tmp_4_1 = 0; _main_gen_tmp_4_1 < 8; _main_gen_tmp_4_1++)
                {
                    /* base type */
                    Rtn_Cal_RtnScaTqX[_main_gen_tmp_4_0][_main_gen_tmp_4_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnScaTqY(void)
{
    extern __PST__g__28 Rtn_Cal_RtnScaTqY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 9; _main_gen_tmp_5_0++)
            {
                __PST__UINT32 _main_gen_tmp_5_1;
                
                for (_main_gen_tmp_5_1 = 0; _main_gen_tmp_5_1 < 8; _main_gen_tmp_5_1++)
                {
                    /* base type */
                    Rtn_Cal_RtnScaTqY[_main_gen_tmp_5_0][_main_gen_tmp_5_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnScaVelX(void)
{
    extern __PST__g__30 Rtn_Cal_RtnScaVelX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 9; _main_gen_tmp_6_0++)
            {
                __PST__UINT32 _main_gen_tmp_6_1;
                
                for (_main_gen_tmp_6_1 = 0; _main_gen_tmp_6_1 < 4; _main_gen_tmp_6_1++)
                {
                    /* base type */
                    Rtn_Cal_RtnScaVelX[_main_gen_tmp_6_0][_main_gen_tmp_6_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnScaVelY(void)
{
    extern __PST__g__30 Rtn_Cal_RtnScaVelY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 9; _main_gen_tmp_7_0++)
            {
                __PST__UINT32 _main_gen_tmp_7_1;
                
                for (_main_gen_tmp_7_1 = 0; _main_gen_tmp_7_1 < 4; _main_gen_tmp_7_1++)
                {
                    /* base type */
                    Rtn_Cal_RtnScaVelY[_main_gen_tmp_7_0][_main_gen_tmp_7_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnTScaX(void)
{
    extern __PST__g__31 Rtn_Cal_RtnTScaX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 14; _main_gen_tmp_8_0++)
            {
                /* base type */
                Rtn_Cal_RtnTScaX[_main_gen_tmp_8_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnTScaY(void)
{
    extern __PST__g__33 Rtn_Cal_RtnTScaY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 14; _main_gen_tmp_9_0++)
            {
                /* base type */
                Rtn_Cal_RtnTScaY[_main_gen_tmp_9_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Cal_RtnVehSpdSeln(void)
{
    extern __PST__g__34 Rtn_Cal_RtnVehSpdSeln;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 9; _main_gen_tmp_10_0++)
            {
                /* base type */
                Rtn_Cal_RtnVehSpdSeln[_main_gen_tmp_10_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_Rtn_Pim_PrevHwAgAuthy(void)
{
    extern __PST__FLOAT32 Rtn_Pim_PrevHwAgAuthy;
    
    /* initialization with random value */
    {
        Rtn_Pim_PrevHwAgAuthy = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_Rtn_Pim_PrevHwAgOffsLimd(void)
{
    extern __PST__FLOAT32 Rtn_Pim_PrevHwAgOffsLimd;
    
    /* initialization with random value */
    {
        Rtn_Pim_PrevHwAgOffsLimd = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rtn_Ip_AssiMechT */
    _main_gen_init_sym_Rtn_Ip_AssiMechT();
    
    /* init for variable Rtn_Ip_HwAg */
    _main_gen_init_sym_Rtn_Ip_HwAg();
    
    /* init for variable Rtn_Ip_HwAgAuthySca */
    _main_gen_init_sym_Rtn_Ip_HwAgAuthySca();
    
    /* init for variable Rtn_Ip_HwAgRtnOffs */
    _main_gen_init_sym_Rtn_Ip_HwAgRtnOffs();
    
    /* init for variable Rtn_Ip_HwTq */
    _main_gen_init_sym_Rtn_Ip_HwTq();
    
    /* init for variable Rtn_Ip_HwVel */
    _main_gen_init_sym_Rtn_Ip_HwVel();
    
    /* init for variable Rtn_Ip_RtnCmdDi */
    _main_gen_init_sym_Rtn_Ip_RtnCmdDi();
    
    /* init for variable Rtn_Ip_RtnCmdDiagcDi */
    _main_gen_init_sym_Rtn_Ip_RtnCmdDiagcDi();
    
    /* init for variable Rtn_Ip_RtnCmdSca */
    _main_gen_init_sym_Rtn_Ip_RtnCmdSca();
    
    /* init for variable Rtn_Ip_RtnCmdScaServo */
    _main_gen_init_sym_Rtn_Ip_RtnCmdScaServo();
    
    /* init for variable Rtn_Ip_VehSpd */
    _main_gen_init_sym_Rtn_Ip_VehSpd();
    
    /* init for variable Rtn_Ip_VehSpdVld */
    _main_gen_init_sym_Rtn_Ip_VehSpdVld();
    
    /* init for variable Rtn_Op_RtnCmd : useless (never read) */

    /* init for variable Rtn_Cal_RtnHwAgOffsCalcdX */
    _main_gen_init_sym_Rtn_Cal_RtnHwAgOffsCalcdX();
    
    /* init for variable Rtn_Cal_RtnHwAgOffsCalcdY */
    _main_gen_init_sym_Rtn_Cal_RtnHwAgOffsCalcdY();
    
    /* init for variable Rtn_Cal_RtnHwAuthyScaX */
    _main_gen_init_sym_Rtn_Cal_RtnHwAuthyScaX();
    
    /* init for variable Rtn_Cal_RtnHwAuthyScaY */
    _main_gen_init_sym_Rtn_Cal_RtnHwAuthyScaY();
    
    /* init for variable Rtn_Cal_RtnHwAuthySlew */
    _main_gen_init_sym_Rtn_Cal_RtnHwAuthySlew();
    
    /* init for variable Rtn_Cal_RtnOffsRng */
    _main_gen_init_sym_Rtn_Cal_RtnOffsRng();
    
    /* init for variable Rtn_Cal_RtnOffsSlew */
    _main_gen_init_sym_Rtn_Cal_RtnOffsSlew();
    
    /* init for variable Rtn_Cal_RtnScaTqX */
    _main_gen_init_sym_Rtn_Cal_RtnScaTqX();
    
    /* init for variable Rtn_Cal_RtnScaTqY */
    _main_gen_init_sym_Rtn_Cal_RtnScaTqY();
    
    /* init for variable Rtn_Cal_RtnScaVelX */
    _main_gen_init_sym_Rtn_Cal_RtnScaVelX();
    
    /* init for variable Rtn_Cal_RtnScaVelY */
    _main_gen_init_sym_Rtn_Cal_RtnScaVelY();
    
    /* init for variable Rtn_Cal_RtnTScaX */
    _main_gen_init_sym_Rtn_Cal_RtnTScaX();
    
    /* init for variable Rtn_Cal_RtnTScaY */
    _main_gen_init_sym_Rtn_Cal_RtnTScaY();
    
    /* init for variable Rtn_Cal_RtnVehSpdSeln */
    _main_gen_init_sym_Rtn_Cal_RtnVehSpdSeln();
    
    /* init for variable Rtn_Pim_dRtnAbsltHwAg : useless (never read) */

    /* init for variable Rtn_Pim_dRtnAssiMechTRtnSca : useless (never read) */

    /* init for variable Rtn_Pim_dRtnBascRtn : useless (never read) */

    /* init for variable Rtn_Pim_dRtnHwAgAuthySca : useless (never read) */

    /* init for variable Rtn_Pim_dRtnHwAgRtnCmd : useless (never read) */

    /* init for variable Rtn_Pim_dRtnHwTqRtnSca : useless (never read) */

    /* init for variable Rtn_Pim_dRtnHwVelRtnSca : useless (never read) */

    /* init for variable Rtn_Pim_PrevHwAgAuthy */
    _main_gen_init_sym_Rtn_Pim_PrevHwAgAuthy();
    
    /* init for variable Rtn_Pim_PrevHwAgOffsLimd */
    _main_gen_init_sym_Rtn_Pim_PrevHwAgOffsLimd();
    
}
