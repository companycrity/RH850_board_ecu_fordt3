#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_StOutpCtrl_Ip_DiagcStsCtrldShtDwnFltPrsnt(void)
{
    extern __PST__UINT8 StOutpCtrl_Ip_DiagcStsCtrldShtDwnFltPrsnt;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_DiagcStsCtrldShtDwnFltPrsnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_LoaRateLim(void)
{
    extern __PST__FLOAT32 StOutpCtrl_Ip_LoaRateLim;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_LoaRateLim = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_LoaSca(void)
{
    extern __PST__FLOAT32 StOutpCtrl_Ip_LoaSca;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_LoaSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_MotTqTranlDampgCmpl(void)
{
    extern __PST__UINT8 StOutpCtrl_Ip_MotTqTranlDampgCmpl;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_MotTqTranlDampgCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_SysDiMotTqCmdSca(void)
{
    extern __PST__FLOAT32 StOutpCtrl_Ip_SysDiMotTqCmdSca;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_SysDiMotTqCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_SysDiRampRate(void)
{
    extern __PST__FLOAT32 StOutpCtrl_Ip_SysDiRampRate;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_SysDiRampRate = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_SysMotTqCmdRampRateDi(void)
{
    extern __PST__UINT8 StOutpCtrl_Ip_SysMotTqCmdRampRateDi;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_SysMotTqCmdRampRateDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_SysOperMotTqCmdSca(void)
{
    extern __PST__FLOAT32 StOutpCtrl_Ip_SysOperMotTqCmdSca;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_SysOperMotTqCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_SysOperRampRate(void)
{
    extern __PST__FLOAT32 StOutpCtrl_Ip_SysOperRampRate;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_SysOperRampRate = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_SysStFltOutpReqDi(void)
{
    extern __PST__UINT8 StOutpCtrl_Ip_SysStFltOutpReqDi;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_SysStFltOutpReqDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_VehStrtStopMotTqCmdSca(void)
{
    extern __PST__FLOAT32 StOutpCtrl_Ip_VehStrtStopMotTqCmdSca;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_VehStrtStopMotTqCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Ip_VehStrtStopRampRate(void)
{
    extern __PST__FLOAT32 StOutpCtrl_Ip_VehStrtStopRampRate;
    
    /* initialization with random value */
    {
        StOutpCtrl_Ip_VehStrtStopRampRate = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Pim_StOutpCtrlPrevCmdSca(void)
{
    extern __PST__FLOAT32 StOutpCtrl_Pim_StOutpCtrlPrevCmdSca;
    
    /* initialization with random value */
    {
        StOutpCtrl_Pim_StOutpCtrlPrevCmdSca = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_StOutpCtrl_Pim_StOutpCtrlPrevSrc(void)
{
    extern __PST__UINT8 StOutpCtrl_Pim_StOutpCtrlPrevSrc;
    
    /* initialization with random value */
    {
        StOutpCtrl_Pim_StOutpCtrlPrevSrc = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable StOutpCtrl_Ip_DiagcStsCtrldShtDwnFltPrsnt */
    _main_gen_init_sym_StOutpCtrl_Ip_DiagcStsCtrldShtDwnFltPrsnt();
    
    /* init for variable StOutpCtrl_Ip_LoaRateLim */
    _main_gen_init_sym_StOutpCtrl_Ip_LoaRateLim();
    
    /* init for variable StOutpCtrl_Ip_LoaSca */
    _main_gen_init_sym_StOutpCtrl_Ip_LoaSca();
    
    /* init for variable StOutpCtrl_Ip_MotTqTranlDampgCmpl */
    _main_gen_init_sym_StOutpCtrl_Ip_MotTqTranlDampgCmpl();
    
    /* init for variable StOutpCtrl_Ip_SysDiMotTqCmdSca */
    _main_gen_init_sym_StOutpCtrl_Ip_SysDiMotTqCmdSca();
    
    /* init for variable StOutpCtrl_Ip_SysDiRampRate */
    _main_gen_init_sym_StOutpCtrl_Ip_SysDiRampRate();
    
    /* init for variable StOutpCtrl_Ip_SysMotTqCmdRampRateDi */
    _main_gen_init_sym_StOutpCtrl_Ip_SysMotTqCmdRampRateDi();
    
    /* init for variable StOutpCtrl_Ip_SysOperMotTqCmdSca */
    _main_gen_init_sym_StOutpCtrl_Ip_SysOperMotTqCmdSca();
    
    /* init for variable StOutpCtrl_Ip_SysOperRampRate */
    _main_gen_init_sym_StOutpCtrl_Ip_SysOperRampRate();
    
    /* init for variable StOutpCtrl_Ip_SysStFltOutpReqDi */
    _main_gen_init_sym_StOutpCtrl_Ip_SysStFltOutpReqDi();
    
    /* init for variable StOutpCtrl_Ip_VehStrtStopMotTqCmdSca */
    _main_gen_init_sym_StOutpCtrl_Ip_VehStrtStopMotTqCmdSca();
    
    /* init for variable StOutpCtrl_Ip_VehStrtStopRampRate */
    _main_gen_init_sym_StOutpCtrl_Ip_VehStrtStopRampRate();
    
    /* init for variable StOutpCtrl_Op_SysMotTqCmdSca : useless (never read) */

    /* init for variable StOutpCtrl_Op_SysStReqDi : useless (never read) */

    /* init for variable StOutpCtrl_Pim_dStOutpCtrlRateLim : useless (never read) */

    /* init for variable StOutpCtrl_Pim_dStOutpCtrlTarSca : useless (never read) */

    /* init for variable StOutpCtrl_Pim_StOutpCtrlPrevCmdSca */
    _main_gen_init_sym_StOutpCtrl_Pim_StOutpCtrlPrevCmdSca();
    
    /* init for variable StOutpCtrl_Pim_StOutpCtrlPrevSrc */
    _main_gen_init_sym_StOutpCtrl_Pim_StOutpCtrlPrevSrc();
    
}
