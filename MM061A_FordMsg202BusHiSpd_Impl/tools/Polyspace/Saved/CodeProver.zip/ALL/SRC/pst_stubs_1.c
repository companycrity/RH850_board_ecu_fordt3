#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FordMsg202BusHiSpd_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordAbsPrsnt(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Ip_FordAbsPrsnt;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Ip_FordAbsPrsnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordBrkOscnRednEnad(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Ip_FordBrkOscnRednEnad;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Ip_FordBrkOscnRednEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordCanDtcInhb(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Ip_FordCanDtcInhb;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Ip_FordCanDtcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordEpsLifeCycMod(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Ip_FordEpsLifeCycMod;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Ip_FordEpsLifeCycMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordInvldMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Ip_FordInvldMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Ip_FordInvldMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordMfgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Ip_FordMfgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Ip_FordMfgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordMissMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Ip_FordMissMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Ip_FordMissMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordTqSteerCmpEnad(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Ip_FordTqSteerCmpEnad;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Ip_FordTqSteerCmpEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordTrlrBackupAssiEnad(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Ip_FordTrlrBackupAssiEnad;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Ip_FordTrlrBackupAssiEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldFaildThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldMissThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldPassdThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModlVldFaildThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModlVldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModlVldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModlVldMissThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModlVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModlVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsInvldFaildThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsInvldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsInvldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsInvldPassdThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsInvldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsInvldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldFaildThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldMissThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldPassdThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgFaildAbsPrsntDisadThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgFaildAbsPrsntDisadThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgFaildAbsPrsntDisadThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgFaildAbsPrsntEnadThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgFaildAbsPrsntEnadThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgFaildAbsPrsntEnadThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgPassdThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgPassdThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdQlyFacEngModInvldFaildThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdQlyFacEngModInvldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdQlyFacEngModInvldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdQlyFacEngModInvldPassdThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdQlyFacEngModInvldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdQlyFacEngModInvldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdTrlrBackupAssiAvlVldMissThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdTrlrBackupAssiAvlVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdTrlrBackupAssiAvlVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdTrlrBackupAssiAvlVldPassdThd(void)
{
    extern __PST__g__32 FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdTrlrBackupAssiAvlVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdTrlrBackupAssiAvlVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_ClrDiagcFlgProxyPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_ClrDiagcFlgProxyPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_ClrDiagcFlgProxyPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FirstTranVldFlg(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FirstTranVldFlg;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FirstTranVldFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsInvldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehGearRvsStsInvldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehGearRvsStsInvldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsInvldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehGearRvsStsInvldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehGearRvsStsInvldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehGearRvsStsPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehGearRvsStsPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsRawPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehGearRvsStsRawPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehGearRvsStsRawPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehMsg202Miss(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehMsg202Miss;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehMsg202Miss = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehMsg202Rxd(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehMsg202Rxd;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehMsg202Rxd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdChksEngModlPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehSpdChksEngModlPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdChksEngModlPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdCntrEngModlPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehSpdCntrEngModlPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdCntrEngModlPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModlPrev(void)
{
    extern __PST__FLOAT32 FordMsg202BusHiSpd_Pim_FordVehSpdEngModlPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdEngModlPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModlRawPrev(void)
{
    extern __PST__UINT16 FordMsg202BusHiSpd_Pim_FordVehSpdEngModlRawPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdEngModlRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlInvldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlInvldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlInvldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlInvldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlInvldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlInvldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehTrlrAidAvlPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehTrlrAidAvlPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehTrlrAidAvlPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehTrlrAidAvlRawPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehTrlrAidAvlRawPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehTrlrAidAvlRawPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldPrev(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldPrev;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_MissMsgFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_MissMsgFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_MissMsgFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Pim_MissMsgPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Pim_MissMsgPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Pim_MissMsgPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 FordMsg202BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg202BusHiSpd_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 FordMsg202BusHiSpd_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        FordMsg202BusHiSpd_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FordMsg202BusHiSpd_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_FordMsg202BusHiSpd_Ip_ClrDiagcFlgProxy();
    
    /* init for variable FordMsg202BusHiSpd_Ip_FordAbsPrsnt */
    _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordAbsPrsnt();
    
    /* init for variable FordMsg202BusHiSpd_Ip_FordBrkOscnRednEnad */
    _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordBrkOscnRednEnad();
    
    /* init for variable FordMsg202BusHiSpd_Ip_FordCanDtcInhb */
    _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordCanDtcInhb();
    
    /* init for variable FordMsg202BusHiSpd_Ip_FordEpsLifeCycMod */
    _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordEpsLifeCycMod();
    
    /* init for variable FordMsg202BusHiSpd_Ip_FordInvldMsgDiagcInhb */
    _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordInvldMsgDiagcInhb();
    
    /* init for variable FordMsg202BusHiSpd_Ip_FordMfgDiagcInhb */
    _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordMfgDiagcInhb();
    
    /* init for variable FordMsg202BusHiSpd_Ip_FordMissMsgDiagcInhb */
    _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordMissMsgDiagcInhb();
    
    /* init for variable FordMsg202BusHiSpd_Ip_FordTqSteerCmpEnad */
    _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordTqSteerCmpEnad();
    
    /* init for variable FordMsg202BusHiSpd_Ip_FordTrlrBackupAssiEnad */
    _main_gen_init_sym_FordMsg202BusHiSpd_Ip_FordTrlrBackupAssiEnad();
    
    /* init for variable FordMsg202BusHiSpd_Op_FordVehGearRvsStsRaw : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Op_FordVehGearRvsStsVld : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Op_FordVehSpdChksEngModl : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Op_FordVehSpdCntrEngModl : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Op_FordVehSpdEngModLoQlyVld : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Op_FordVehSpdEngModl : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Op_FordVehSpdEngModlRaw : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Op_FordVehSpdEngModlVld : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Op_FordVehTrlrAidAvlRaw : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Op_FordVehTrlrBackupAssiAvlVld : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldFaildThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldFaildThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldMissThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldMissThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldPassdThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModLoQlyVldPassdThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModlVldFaildThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModlVldFaildThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModlVldMissThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdEngModlVldMissThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsInvldFaildThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsInvldFaildThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsInvldPassdThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsInvldPassdThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldFaildThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldFaildThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldMissThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldMissThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldPassdThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdGearRvsStsVldPassdThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgFaildAbsPrsntDisadThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgFaildAbsPrsntDisadThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgFaildAbsPrsntEnadThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgFaildAbsPrsntEnadThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgPassdThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdMissMsgPassdThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdQlyFacEngModInvldFaildThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdQlyFacEngModInvldFaildThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdQlyFacEngModInvldPassdThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdQlyFacEngModInvldPassdThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdTrlrBackupAssiAvlVldMissThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdTrlrBackupAssiAvlVldMissThd();
    
    /* init for variable FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdTrlrBackupAssiAvlVldPassdThd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Cal_FordMsg202BusHiSpdTrlrBackupAssiAvlVldPassdThd();
    
    /* init for variable FordMsg202BusHiSpd_Pim_ClrDiagcFlgProxyPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_ClrDiagcFlgProxyPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FirstTranVldFlg */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FirstTranVldFlg();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehGearRvsStsInvldFaildRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsInvldFaildRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehGearRvsStsInvldPassdRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsInvldPassdRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehGearRvsStsPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehGearRvsStsRawPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsRawPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldFaildRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldFaildRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldMissRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldMissRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldPassdRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldPassdRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehGearRvsStsVldPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehMsg202Miss */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehMsg202Miss();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehMsg202Rxd */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehMsg202Rxd();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdChksEngModlPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdChksEngModlPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdCntrEngModlPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdCntrEngModlPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldFaildRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldFaildRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldMissRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldMissRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldPassdRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldPassdRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModLoQlyVldPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdEngModlPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModlPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdEngModlRawPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModlRawPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldFaildRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldFaildRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldMissRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldMissRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdEngModlVldPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlInvldFaildRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlInvldFaildRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlInvldPassdRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlInvldPassdRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehSpdQlyFacEngModlPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehTrlrAidAvlPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehTrlrAidAvlPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehTrlrAidAvlRawPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehTrlrAidAvlRawPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldMissRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldMissRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldPassdRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldPassdRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldPrev */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_FordVehTrlrBackupAssiAvlVldPrev();
    
    /* init for variable FordMsg202BusHiSpd_Pim_MissMsgFaildRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_MissMsgFaildRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Pim_MissMsgPassdRefTi */
    _main_gen_init_sym_FordMsg202BusHiSpd_Pim_MissMsgPassdRefTi();
    
    /* init for variable FordMsg202BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_FordMsg202BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable FordMsg202BusHiSpd_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_FordMsg202BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable FordMsg202BusHiSpd_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable FordMsg202BusHiSpd_Srv_SetNtcSts_Return */
    _main_gen_init_sym_FordMsg202BusHiSpd_Srv_SetNtcSts_Return();
    
}
