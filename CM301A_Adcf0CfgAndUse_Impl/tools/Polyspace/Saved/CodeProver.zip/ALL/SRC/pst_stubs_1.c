#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__61 _main_gen_init_g61(void);

extern __PST__g__57 _main_gen_init_g57(void);

extern __PST__g__54 _main_gen_init_g54(void);

extern __PST__g__51 _main_gen_init_g51(void);

extern __PST__g__47 _main_gen_init_g47(void);

extern __PST__g__44 _main_gen_init_g44(void);

extern __PST__g__41 _main_gen_init_g41(void);

extern __PST__g__38 _main_gen_init_g38(void);

extern struct __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__35 _main_gen_init_g35(void);

extern struct __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern struct __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__22 _main_gen_init_g22(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__22 _main_gen_init_g22(void)
{
    __PST__g__22 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__30 _main_gen_init_g30(void)
{
    static struct __PST__g__30 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 3);
        x._SUSMTD = bitf;
    }
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g30();
    return x;
}

struct __PST__g__34 _main_gen_init_g34(void)
{
    static struct __PST__g__34 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._ADDNT = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._DFMT = bitf;
    }
    return x;
}

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g34();
    return x;
}

struct __PST__g__37 _main_gen_init_g37(void)
{
    static struct __PST__g__37 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._IDEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._PEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._OWEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._ULEIE = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x._RDCLRE = bitf;
    }
    return x;
}

__PST__g__35 _main_gen_init_g35(void)
{
    __PST__g__35 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g37();
    return x;
}

__PST__g__38 _main_gen_init_g38(void)
{
    __PST__g__38 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__41 _main_gen_init_g41(void)
{
    __PST__g__41 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__44 _main_gen_init_g44(void)
{
    __PST__g__44 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__47 _main_gen_init_g47(void)
{
    __PST__g__47 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__51 _main_gen_init_g51(void)
{
    __PST__g__51 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__54 _main_gen_init_g54(void)
{
    __PST__g__54 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__57 _main_gen_init_g57(void)
{
    __PST__g__57 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__61 _main_gen_init_g61(void)
{
    __PST__g__61 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Adcf0CfgAndUse_Pim_Adcf0DiagcEndPtr(void)
{
    extern __PST__UINT8 Adcf0CfgAndUse_Pim_Adcf0DiagcEndPtr;
    
    /* initialization with random value */
    {
        Adcf0CfgAndUse_Pim_Adcf0DiagcEndPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_Adcf0CfgAndUse_Pim_Adcf0DiagcStrtPtr(void)
{
    extern __PST__UINT8 Adcf0CfgAndUse_Pim_Adcf0DiagcStrtPtr;
    
    /* initialization with random value */
    {
        Adcf0CfgAndUse_Pim_Adcf0DiagcStrtPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ADCF0VCR0_BASE(void)
{
    extern __PST__g__22 ADCF0VCR0_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR0_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR1_BASE(void)
{
    extern __PST__g__22 ADCF0VCR1_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR1_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR2_BASE(void)
{
    extern __PST__g__22 ADCF0VCR2_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR2_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR3_BASE(void)
{
    extern __PST__g__22 ADCF0VCR3_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR3_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR4_BASE(void)
{
    extern __PST__g__22 ADCF0VCR4_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR4_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR5_BASE(void)
{
    extern __PST__g__22 ADCF0VCR5_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR5_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR6_BASE(void)
{
    extern __PST__g__22 ADCF0VCR6_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR6_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR7_BASE(void)
{
    extern __PST__g__22 ADCF0VCR7_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR7_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR8_BASE(void)
{
    extern __PST__g__22 ADCF0VCR8_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR8_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR9_BASE(void)
{
    extern __PST__g__22 ADCF0VCR9_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR9_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR10_BASE(void)
{
    extern __PST__g__22 ADCF0VCR10_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR10_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR11_BASE(void)
{
    extern __PST__g__22 ADCF0VCR11_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR11_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR12_BASE(void)
{
    extern __PST__g__22 ADCF0VCR12_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR12_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR13_BASE(void)
{
    extern __PST__g__22 ADCF0VCR13_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR13_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR14_BASE(void)
{
    extern __PST__g__22 ADCF0VCR14_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR14_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR15_BASE(void)
{
    extern __PST__g__22 ADCF0VCR15_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR15_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR16_BASE(void)
{
    extern __PST__g__22 ADCF0VCR16_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR16_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR17_BASE(void)
{
    extern __PST__g__22 ADCF0VCR17_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR17_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR18_BASE(void)
{
    extern __PST__g__22 ADCF0VCR18_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR18_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR19_BASE(void)
{
    extern __PST__g__22 ADCF0VCR19_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR19_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR20_BASE(void)
{
    extern __PST__g__22 ADCF0VCR20_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR20_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR21_BASE(void)
{
    extern __PST__g__22 ADCF0VCR21_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR21_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR22_BASE(void)
{
    extern __PST__g__22 ADCF0VCR22_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR22_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0VCR23_BASE(void)
{
    extern __PST__g__22 ADCF0VCR23_BASE;
    
    /* initialization with random value */
    {
        ADCF0VCR23_BASE = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_ADCF0ADCR1_BASE(void)
{
    extern __PST__g__28 ADCF0ADCR1_BASE;
    
    /* initialization with random value */
    {
        ADCF0ADCR1_BASE = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_ADCF0ADCR2_BASE(void)
{
    extern __PST__g__32 ADCF0ADCR2_BASE;
    
    /* initialization with random value */
    {
        ADCF0ADCR2_BASE = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_ADCF0SFTCR_BASE(void)
{
    extern __PST__g__35 ADCF0SFTCR_BASE;
    
    /* initialization with random value */
    {
        ADCF0SFTCR_BASE = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_ADCF0ULLMTBR0_BASE(void)
{
    extern __PST__g__38 ADCF0ULLMTBR0_BASE;
    
    /* initialization with random value */
    {
        ADCF0ULLMTBR0_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_ADCF0ULLMTBR1_BASE(void)
{
    extern __PST__g__38 ADCF0ULLMTBR1_BASE;
    
    /* initialization with random value */
    {
        ADCF0ULLMTBR1_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_ADCF0ULLMTBR2_BASE(void)
{
    extern __PST__g__38 ADCF0ULLMTBR2_BASE;
    
    /* initialization with random value */
    {
        ADCF0ULLMTBR2_BASE = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_ADCF0SGSTCR0_BASE(void)
{
    extern __PST__g__41 ADCF0SGSTCR0_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGSTCR0_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_ADCF0SGCR0_BASE(void)
{
    extern __PST__g__44 ADCF0SGCR0_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGCR0_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ADCF0SGVCSP0_BASE(void)
{
    extern __PST__g__47 ADCF0SGVCSP0_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGVCSP0_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ADCF0SGVCEP0_BASE(void)
{
    extern __PST__g__51 ADCF0SGVCEP0_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGVCEP0_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ADCF0SGMCYCR0_BASE(void)
{
    extern __PST__g__54 ADCF0SGMCYCR0_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGMCYCR0_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_ADCF0ULLMSR0_BASE(void)
{
    extern __PST__g__57 ADCF0ULLMSR0_BASE;
    
    /* initialization with random value */
    {
        ADCF0ULLMSR0_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_ADCF0SGSTCR1_BASE(void)
{
    extern __PST__g__41 ADCF0SGSTCR1_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGSTCR1_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_ADCF0SGCR1_BASE(void)
{
    extern __PST__g__44 ADCF0SGCR1_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGCR1_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ADCF0SGVCSP1_BASE(void)
{
    extern __PST__g__47 ADCF0SGVCSP1_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGVCSP1_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ADCF0SGVCEP1_BASE(void)
{
    extern __PST__g__51 ADCF0SGVCEP1_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGVCEP1_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ADCF0SGMCYCR1_BASE(void)
{
    extern __PST__g__54 ADCF0SGMCYCR1_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGMCYCR1_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_ADCF0ULLMSR1_BASE(void)
{
    extern __PST__g__57 ADCF0ULLMSR1_BASE;
    
    /* initialization with random value */
    {
        ADCF0ULLMSR1_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_ADCF0SGSTCR2_BASE(void)
{
    extern __PST__g__41 ADCF0SGSTCR2_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGSTCR2_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_ADCF0SGCR2_BASE(void)
{
    extern __PST__g__44 ADCF0SGCR2_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGCR2_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ADCF0SGVCSP2_BASE(void)
{
    extern __PST__g__47 ADCF0SGVCSP2_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGVCSP2_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ADCF0SGVCEP2_BASE(void)
{
    extern __PST__g__51 ADCF0SGVCEP2_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGVCEP2_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ADCF0SGMCYCR2_BASE(void)
{
    extern __PST__g__54 ADCF0SGMCYCR2_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGMCYCR2_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_ADCF0ULLMSR2_BASE(void)
{
    extern __PST__g__57 ADCF0ULLMSR2_BASE;
    
    /* initialization with random value */
    {
        ADCF0ULLMSR2_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_ADCF0SGSTCR3_BASE(void)
{
    extern __PST__g__41 ADCF0SGSTCR3_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGSTCR3_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_ADCF0SGCR3_BASE(void)
{
    extern __PST__g__44 ADCF0SGCR3_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGCR3_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ADCF0SGVCSP3_BASE(void)
{
    extern __PST__g__47 ADCF0SGVCSP3_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGVCSP3_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ADCF0SGVCEP3_BASE(void)
{
    extern __PST__g__51 ADCF0SGVCEP3_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGVCEP3_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ADCF0SGMCYCR3_BASE(void)
{
    extern __PST__g__54 ADCF0SGMCYCR3_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGMCYCR3_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_ADCF0ULLMSR3_BASE(void)
{
    extern __PST__g__57 ADCF0ULLMSR3_BASE;
    
    /* initialization with random value */
    {
        ADCF0ULLMSR3_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_ADCF0SGSTCR4_BASE(void)
{
    extern __PST__g__41 ADCF0SGSTCR4_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGSTCR4_BASE = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_ADCF0SGCR4_BASE(void)
{
    extern __PST__g__44 ADCF0SGCR4_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGCR4_BASE = _main_gen_init_g44();
    }
}

static void _main_gen_init_sym_ADCF0SGVCSP4_BASE(void)
{
    extern __PST__g__47 ADCF0SGVCSP4_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGVCSP4_BASE = _main_gen_init_g47();
    }
}

static void _main_gen_init_sym_ADCF0SGVCEP4_BASE(void)
{
    extern __PST__g__51 ADCF0SGVCEP4_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGVCEP4_BASE = _main_gen_init_g51();
    }
}

static void _main_gen_init_sym_ADCF0SGMCYCR4_BASE(void)
{
    extern __PST__g__54 ADCF0SGMCYCR4_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGMCYCR4_BASE = _main_gen_init_g54();
    }
}

static void _main_gen_init_sym_ADCF0ULLMSR4_BASE(void)
{
    extern __PST__g__57 ADCF0ULLMSR4_BASE;
    
    /* initialization with random value */
    {
        ADCF0ULLMSR4_BASE = _main_gen_init_g57();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdcDiagcEndPtrOutp(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlAdcDiagcEndPtrOutp;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlAdcDiagcEndPtrOutp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdcDiagcStrtPtrOutp(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlAdcDiagcStrtPtrOutp;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlAdcDiagcStrtPtrOutp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ADCF0SGSR1_BASE(void)
{
    extern __PST__g__61 ADCF0SGSR1_BASE;
    
    /* initialization with random value */
    {
        ADCF0SGSR1_BASE = _main_gen_init_g61();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Adcf0CfgAndUse_Pim_Adcf0DiagcEndPtr */
    _main_gen_init_sym_Adcf0CfgAndUse_Pim_Adcf0DiagcEndPtr();
    
    /* init for variable Adcf0CfgAndUse_Pim_Adcf0DiagcStrtPtr */
    _main_gen_init_sym_Adcf0CfgAndUse_Pim_Adcf0DiagcStrtPtr();
    
    /* init for variable ADCF0VCR0_BASE */
    _main_gen_init_sym_ADCF0VCR0_BASE();
    
    /* init for variable ADCF0VCR1_BASE */
    _main_gen_init_sym_ADCF0VCR1_BASE();
    
    /* init for variable ADCF0VCR2_BASE */
    _main_gen_init_sym_ADCF0VCR2_BASE();
    
    /* init for variable ADCF0VCR3_BASE */
    _main_gen_init_sym_ADCF0VCR3_BASE();
    
    /* init for variable ADCF0VCR4_BASE */
    _main_gen_init_sym_ADCF0VCR4_BASE();
    
    /* init for variable ADCF0VCR5_BASE */
    _main_gen_init_sym_ADCF0VCR5_BASE();
    
    /* init for variable ADCF0VCR6_BASE */
    _main_gen_init_sym_ADCF0VCR6_BASE();
    
    /* init for variable ADCF0VCR7_BASE */
    _main_gen_init_sym_ADCF0VCR7_BASE();
    
    /* init for variable ADCF0VCR8_BASE */
    _main_gen_init_sym_ADCF0VCR8_BASE();
    
    /* init for variable ADCF0VCR9_BASE */
    _main_gen_init_sym_ADCF0VCR9_BASE();
    
    /* init for variable ADCF0VCR10_BASE */
    _main_gen_init_sym_ADCF0VCR10_BASE();
    
    /* init for variable ADCF0VCR11_BASE */
    _main_gen_init_sym_ADCF0VCR11_BASE();
    
    /* init for variable ADCF0VCR12_BASE */
    _main_gen_init_sym_ADCF0VCR12_BASE();
    
    /* init for variable ADCF0VCR13_BASE */
    _main_gen_init_sym_ADCF0VCR13_BASE();
    
    /* init for variable ADCF0VCR14_BASE */
    _main_gen_init_sym_ADCF0VCR14_BASE();
    
    /* init for variable ADCF0VCR15_BASE */
    _main_gen_init_sym_ADCF0VCR15_BASE();
    
    /* init for variable ADCF0VCR16_BASE */
    _main_gen_init_sym_ADCF0VCR16_BASE();
    
    /* init for variable ADCF0VCR17_BASE */
    _main_gen_init_sym_ADCF0VCR17_BASE();
    
    /* init for variable ADCF0VCR18_BASE */
    _main_gen_init_sym_ADCF0VCR18_BASE();
    
    /* init for variable ADCF0VCR19_BASE */
    _main_gen_init_sym_ADCF0VCR19_BASE();
    
    /* init for variable ADCF0VCR20_BASE */
    _main_gen_init_sym_ADCF0VCR20_BASE();
    
    /* init for variable ADCF0VCR21_BASE */
    _main_gen_init_sym_ADCF0VCR21_BASE();
    
    /* init for variable ADCF0VCR22_BASE */
    _main_gen_init_sym_ADCF0VCR22_BASE();
    
    /* init for variable ADCF0VCR23_BASE */
    _main_gen_init_sym_ADCF0VCR23_BASE();
    
    /* init for variable ADCF0ADCR1_BASE */
    _main_gen_init_sym_ADCF0ADCR1_BASE();
    
    /* init for variable ADCF0ADCR2_BASE */
    _main_gen_init_sym_ADCF0ADCR2_BASE();
    
    /* init for variable ADCF0SFTCR_BASE */
    _main_gen_init_sym_ADCF0SFTCR_BASE();
    
    /* init for variable ADCF0ULLMTBR0_BASE */
    _main_gen_init_sym_ADCF0ULLMTBR0_BASE();
    
    /* init for variable ADCF0ULLMTBR1_BASE */
    _main_gen_init_sym_ADCF0ULLMTBR1_BASE();
    
    /* init for variable ADCF0ULLMTBR2_BASE */
    _main_gen_init_sym_ADCF0ULLMTBR2_BASE();
    
    /* init for variable ADCF0SGSTCR0_BASE */
    _main_gen_init_sym_ADCF0SGSTCR0_BASE();
    
    /* init for variable ADCF0SGCR0_BASE */
    _main_gen_init_sym_ADCF0SGCR0_BASE();
    
    /* init for variable ADCF0SGVCSP0_BASE */
    _main_gen_init_sym_ADCF0SGVCSP0_BASE();
    
    /* init for variable ADCF0SGVCEP0_BASE */
    _main_gen_init_sym_ADCF0SGVCEP0_BASE();
    
    /* init for variable ADCF0SGMCYCR0_BASE */
    _main_gen_init_sym_ADCF0SGMCYCR0_BASE();
    
    /* init for variable ADCF0ULLMSR0_BASE */
    _main_gen_init_sym_ADCF0ULLMSR0_BASE();
    
    /* init for variable ADCF0SGSTCR1_BASE */
    _main_gen_init_sym_ADCF0SGSTCR1_BASE();
    
    /* init for variable ADCF0SGCR1_BASE */
    _main_gen_init_sym_ADCF0SGCR1_BASE();
    
    /* init for variable ADCF0SGVCSP1_BASE */
    _main_gen_init_sym_ADCF0SGVCSP1_BASE();
    
    /* init for variable ADCF0SGVCEP1_BASE */
    _main_gen_init_sym_ADCF0SGVCEP1_BASE();
    
    /* init for variable ADCF0SGMCYCR1_BASE */
    _main_gen_init_sym_ADCF0SGMCYCR1_BASE();
    
    /* init for variable ADCF0ULLMSR1_BASE */
    _main_gen_init_sym_ADCF0ULLMSR1_BASE();
    
    /* init for variable ADCF0SGSTCR2_BASE */
    _main_gen_init_sym_ADCF0SGSTCR2_BASE();
    
    /* init for variable ADCF0SGCR2_BASE */
    _main_gen_init_sym_ADCF0SGCR2_BASE();
    
    /* init for variable ADCF0SGVCSP2_BASE */
    _main_gen_init_sym_ADCF0SGVCSP2_BASE();
    
    /* init for variable ADCF0SGVCEP2_BASE */
    _main_gen_init_sym_ADCF0SGVCEP2_BASE();
    
    /* init for variable ADCF0SGMCYCR2_BASE */
    _main_gen_init_sym_ADCF0SGMCYCR2_BASE();
    
    /* init for variable ADCF0ULLMSR2_BASE */
    _main_gen_init_sym_ADCF0ULLMSR2_BASE();
    
    /* init for variable ADCF0SGSTCR3_BASE */
    _main_gen_init_sym_ADCF0SGSTCR3_BASE();
    
    /* init for variable ADCF0SGCR3_BASE */
    _main_gen_init_sym_ADCF0SGCR3_BASE();
    
    /* init for variable ADCF0SGVCSP3_BASE */
    _main_gen_init_sym_ADCF0SGVCSP3_BASE();
    
    /* init for variable ADCF0SGVCEP3_BASE */
    _main_gen_init_sym_ADCF0SGVCEP3_BASE();
    
    /* init for variable ADCF0SGMCYCR3_BASE */
    _main_gen_init_sym_ADCF0SGMCYCR3_BASE();
    
    /* init for variable ADCF0ULLMSR3_BASE */
    _main_gen_init_sym_ADCF0ULLMSR3_BASE();
    
    /* init for variable ADCF0SGSTCR4_BASE */
    _main_gen_init_sym_ADCF0SGSTCR4_BASE();
    
    /* init for variable ADCF0SGCR4_BASE */
    _main_gen_init_sym_ADCF0SGCR4_BASE();
    
    /* init for variable ADCF0SGVCSP4_BASE */
    _main_gen_init_sym_ADCF0SGVCSP4_BASE();
    
    /* init for variable ADCF0SGVCEP4_BASE */
    _main_gen_init_sym_ADCF0SGVCEP4_BASE();
    
    /* init for variable ADCF0SGMCYCR4_BASE */
    _main_gen_init_sym_ADCF0SGMCYCR4_BASE();
    
    /* init for variable ADCF0ULLMSR4_BASE */
    _main_gen_init_sym_ADCF0ULLMSR4_BASE();
    
    /* init for variable MOTCTRLMGR_MotCtrlAdcDiagcEndPtrOutp */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdcDiagcEndPtrOutp();
    
    /* init for variable MOTCTRLMGR_MotCtrlAdcDiagcStrtPtrOutp */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdcDiagcStrtPtrOutp();
    
    /* init for variable ADCF0SGSR1_BASE */
    _main_gen_init_sym_ADCF0SGSR1_BASE();
    
}
