/**********************************************************************************************************************
* Copyright 2015 Nexteer 
* Nexteer Confidential
*
* Module File Name: TunSelnAuthy.h
* Module Description: Header for TunSelnAuthy
* Project           : CBD 
* Author            : Nick Saxton
***********************************************************************************************************************
* Version Control:
* %version:           1 %
* %derived_by:        mzjphh %
*----------------------------------------------------------------------------------------------------------------------
* Date      Rev      Author         Change Description                                                           SCR #
* -------   -------  --------  ---------------------------------------------------------------------------     --------
* 10/09/15  1        NS        Initial Version                                                                 EA4#1782
**********************************************************************************************************************/

#ifndef TUNSELNAUTHY_H
#define TUNSELNAUTHY_H

#define TUNSELNAUTHY_XCPVEHSPDTHD_KPH_F32 (0.05F)

#endif
