#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_TunSelnAuthy_Ip_HwTq(void)
{
    extern __PST__FLOAT32 TunSelnAuthy_Ip_HwTq;
    
    /* initialization with random value */
    {
        TunSelnAuthy_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TunSelnAuthy_Ip_HwVel(void)
{
    extern __PST__FLOAT32 TunSelnAuthy_Ip_HwVel;
    
    /* initialization with random value */
    {
        TunSelnAuthy_Ip_HwVel = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TunSelnAuthy_Ip_TunSelnRtDi(void)
{
    extern __PST__UINT8 TunSelnAuthy_Ip_TunSelnRtDi;
    
    /* initialization with random value */
    {
        TunSelnAuthy_Ip_TunSelnRtDi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TunSelnAuthy_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 TunSelnAuthy_Ip_VehSpd;
    
    /* initialization with random value */
    {
        TunSelnAuthy_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_TunSelnAuthy_Cal_TunSelnAuthyHwTqY(void)
{
    extern __PST__g__24 TunSelnAuthy_Cal_TunSelnAuthyHwTqY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 6; _main_gen_tmp_1_0++)
            {
                /* base type */
                TunSelnAuthy_Cal_TunSelnAuthyHwTqY[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_TunSelnAuthy_Cal_TunSelnAuthyHwVelY(void)
{
    extern __PST__g__24 TunSelnAuthy_Cal_TunSelnAuthyHwVelY;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 6; _main_gen_tmp_2_0++)
            {
                /* base type */
                TunSelnAuthy_Cal_TunSelnAuthyHwVelY[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_TunSelnAuthy_Cal_TunSelnAuthyTunSelnRtDiCmd(void)
{
    extern __PST__g__26 TunSelnAuthy_Cal_TunSelnAuthyTunSelnRtDiCmd;
    
    /* initialization with random value */
    {
        TunSelnAuthy_Cal_TunSelnAuthyTunSelnRtDiCmd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_TunSelnAuthy_Cal_TunSelnAuthyVehSpdX(void)
{
    extern __PST__g__24 TunSelnAuthy_Cal_TunSelnAuthyVehSpdX;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 6; _main_gen_tmp_3_0++)
            {
                /* base type */
                TunSelnAuthy_Cal_TunSelnAuthyVehSpdX[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable TunSelnAuthy_Cli_RtCalChgReq_Return : useless (never read) */

    /* init for variable TunSelnAuthy_Cli_XcpCalChgReq_Return : useless (never read) */

    /* init for variable TunSelnAuthy_Ip_HwTq */
    _main_gen_init_sym_TunSelnAuthy_Ip_HwTq();
    
    /* init for variable TunSelnAuthy_Ip_HwVel */
    _main_gen_init_sym_TunSelnAuthy_Ip_HwVel();
    
    /* init for variable TunSelnAuthy_Ip_TunSelnRtDi */
    _main_gen_init_sym_TunSelnAuthy_Ip_TunSelnRtDi();
    
    /* init for variable TunSelnAuthy_Ip_VehSpd */
    _main_gen_init_sym_TunSelnAuthy_Ip_VehSpd();
    
    /* init for variable TunSelnAuthy_Cal_TunSelnAuthyHwTqY */
    _main_gen_init_sym_TunSelnAuthy_Cal_TunSelnAuthyHwTqY();
    
    /* init for variable TunSelnAuthy_Cal_TunSelnAuthyHwVelY */
    _main_gen_init_sym_TunSelnAuthy_Cal_TunSelnAuthyHwVelY();
    
    /* init for variable TunSelnAuthy_Cal_TunSelnAuthyTunSelnRtDiCmd */
    _main_gen_init_sym_TunSelnAuthy_Cal_TunSelnAuthyTunSelnRtDiCmd();
    
    /* init for variable TunSelnAuthy_Cal_TunSelnAuthyVehSpdX */
    _main_gen_init_sym_TunSelnAuthy_Cal_TunSelnAuthyVehSpdX();
    
}
