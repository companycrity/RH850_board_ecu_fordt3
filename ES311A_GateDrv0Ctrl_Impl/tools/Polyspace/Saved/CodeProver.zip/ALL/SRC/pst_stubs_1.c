#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__31 _main_gen_init_g31(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__31 _main_gen_init_g31(void)
{
    static struct __PST__g__31 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_GateDrv0Ctrl_Ip_Ivtr1PwrDiscnctFltSts(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Ip_Ivtr1PwrDiscnctFltSts;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Ip_Ivtr1PwrDiscnctFltSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiMeasdA(void)
{
    extern __PST__UINT32 GateDrv0Ctrl_Ip_PhaOnTiMeasdA;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Ip_PhaOnTiMeasdA = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiMeasdB(void)
{
    extern __PST__UINT32 GateDrv0Ctrl_Ip_PhaOnTiMeasdB;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Ip_PhaOnTiMeasdB = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiMeasdC(void)
{
    extern __PST__UINT32 GateDrv0Ctrl_Ip_PhaOnTiMeasdC;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Ip_PhaOnTiMeasdC = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiSumA(void)
{
    extern __PST__UINT32 GateDrv0Ctrl_Ip_PhaOnTiSumA;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Ip_PhaOnTiSumA = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiSumB(void)
{
    extern __PST__UINT32 GateDrv0Ctrl_Ip_PhaOnTiSumB;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Ip_PhaOnTiSumB = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiSumC(void)
{
    extern __PST__UINT32 GateDrv0Ctrl_Ip_PhaOnTiSumC;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Ip_PhaOnTiSumC = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Ip_StrtUpSt(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Ip_StrtUpSt;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Ip_StrtUpSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Ip_SysSt(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Ip_SysSt;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlErrFilFrq(void)
{
    extern __PST__g__28 GateDrv0Ctrl_Cal_GateDrv0CtrlErrFilFrq;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlErrFilFrq = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlErrOffs(void)
{
    extern __PST__g__29 GateDrv0Ctrl_Cal_GateDrv0CtrlErrOffs;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlErrOffs = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlErrThd(void)
{
    extern __PST__g__29 GateDrv0Ctrl_Cal_GateDrv0CtrlErrThd;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlErrThd = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x050FailStep(void)
{
    extern __PST__g__30 GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x050FailStep;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x050FailStep = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x050PassStep(void)
{
    extern __PST__g__30 GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x050PassStep;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x050PassStep = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x051FailStep(void)
{
    extern __PST__g__30 GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x051FailStep;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x051FailStep = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x051PassStep(void)
{
    extern __PST__g__30 GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x051PassStep;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x051PassStep = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x055FailStep(void)
{
    extern __PST__g__30 GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x055FailStep;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x055FailStep = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x055PassStep(void)
{
    extern __PST__g__30 GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x055PassStep;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x055PassStep = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg2WrVal(void)
{
    extern __PST__g__30 GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg2WrVal;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg2WrVal = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg3WrVal(void)
{
    extern __PST__g__30 GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg3WrVal;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg3WrVal = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg4WrVal(void)
{
    extern __PST__g__30 GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg4WrVal;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg4WrVal = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg7WrVal(void)
{
    extern __PST__g__30 GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg7WrVal;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg7WrVal = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0CfgCnt(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_GateDrv0CfgCnt;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0CfgCnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0CfgSecAtmpt(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_GateDrv0CfgSecAtmpt;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0CfgSecAtmpt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0Diag0Val(void)
{
    extern __PST__UINT16 GateDrv0Ctrl_Pim_GateDrv0Diag0Val;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0Diag0Val = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0Diag1Val(void)
{
    extern __PST__UINT16 GateDrv0Ctrl_Pim_GateDrv0Diag1Val;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0Diag1Val = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0Diag2Val(void)
{
    extern __PST__UINT16 GateDrv0Ctrl_Pim_GateDrv0Diag2Val;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0Diag2Val = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0OffStChkIdx(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_GateDrv0OffStChkIdx;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0OffStChkIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0OffStChkSecAtmpt(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_GateDrv0OffStChkSecAtmpt;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0OffStChkSecAtmpt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0OffStCnt(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_GateDrv0OffStCnt;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0OffStCnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaAFilLp(void)
{
    extern struct __PST__g__31 GateDrv0Ctrl_Pim_GateDrv0PhaAFilLp;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0PhaAFilLp = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaBFilLp(void)
{
    extern struct __PST__g__31 GateDrv0Ctrl_Pim_GateDrv0PhaBFilLp;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0PhaBFilLp = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaCFilLp(void)
{
    extern struct __PST__g__31 GateDrv0Ctrl_Pim_GateDrv0PhaCFilLp;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0PhaCFilLp = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumAPrev(void)
{
    extern __PST__UINT32 GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumAPrev;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumAPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumBPrev(void)
{
    extern __PST__UINT32 GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumBPrev;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumBPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumCPrev(void)
{
    extern __PST__UINT32 GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumCPrev;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumCPrev = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0SpiErrSecAtmpt(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_GateDrv0SpiErrSecAtmpt;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0SpiErrSecAtmpt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0SpiTrsmErrCntr(void)
{
    extern __PST__UINT32 GateDrv0Ctrl_Pim_GateDrv0SpiTrsmErrCntr;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0SpiTrsmErrCntr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0St(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_GateDrv0St;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0St = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0StsVal(void)
{
    extern __PST__UINT16 GateDrv0Ctrl_Pim_GateDrv0StsVal;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0StsVal = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0VrfyRes0Val(void)
{
    extern __PST__UINT16 GateDrv0Ctrl_Pim_GateDrv0VrfyRes0Val;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0VrfyRes0Val = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0VrfyRes1Val(void)
{
    extern __PST__UINT16 GateDrv0Ctrl_Pim_GateDrv0VrfyRes1Val;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_GateDrv0VrfyRes1Val = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_Ivtr0BootstrpSplyFltPrmVal(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_Ivtr0BootstrpSplyFltPrmVal;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_Ivtr0BootstrpSplyFltPrmVal = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_Ivtr0GenericFltPrmVal(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_Ivtr0GenericFltPrmVal;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_Ivtr0GenericFltPrmVal = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_Ivtr0InactvSts(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_Ivtr0InactvSts;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_Ivtr0InactvSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_Ivtr0OffStChkCmpl(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_Ivtr0OffStChkCmpl;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_Ivtr0OffStChkCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_IvtrFetFltPhaDataStore(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_IvtrFetFltPhaDataStore;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_IvtrFetFltPhaDataStore = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Pim_IvtrFetFltTypDataStore(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Pim_IvtrFetFltTypDataStore;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Pim_IvtrFetFltTypDataStore = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Irv_GateDrv0Ena(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Irv_GateDrv0Ena;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Irv_GateDrv0Ena = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Irv_GateDrv0PhaReasbnDiagcEna(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Irv_GateDrv0PhaReasbnDiagcEna;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Irv_GateDrv0PhaReasbnDiagcEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Irv_Ivtr0PhyFltInpActv(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Irv_Ivtr0PhyFltInpActv;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Irv_Ivtr0PhyFltInpActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ELECGLBPRM_GATEDRVOFFSTCHKDATA_CNT_U16(void)
{
    extern __PST__g__32 ELECGLBPRM_GATEDRVOFFSTCHKDATA_CNT_U16;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 20; _main_gen_tmp_1_0++)
            {
                __PST__UINT32 _main_gen_tmp_1_1;
                
                for (_main_gen_tmp_1_1 = 0; _main_gen_tmp_1_1 < 8; _main_gen_tmp_1_1++)
                {
                    /* base type */
                    ELECGLBPRM_GATEDRVOFFSTCHKDATA_CNT_U16[_main_gen_tmp_1_0][_main_gen_tmp_1_1] = pst_random_g_7;
                }
            }
        }
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Srv_IoHwAb_GetGpioMotDrvr0Diag_PinSt(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Srv_IoHwAb_GetGpioMotDrvr0Diag_PinSt;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Srv_IoHwAb_GetGpioMotDrvr0Diag_PinSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Srv_IoHwAb_GetGpioMotDrvr0Diag_Return(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Srv_IoHwAb_GetGpioMotDrvr0Diag_Return;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Srv_IoHwAb_GetGpioMotDrvr0Diag_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Srv_IoHwAb_SetGpioSysFlt2A_Return(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Srv_IoHwAb_SetGpioSysFlt2A_Return;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Srv_IoHwAb_SetGpioSysFlt2A_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_Return(void)
{
    extern __PST__UINT8 GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_Return;
    
    /* initialization with random value */
    {
        GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable GateDrv0Ctrl_Ip_Ivtr1PwrDiscnctFltSts */
    _main_gen_init_sym_GateDrv0Ctrl_Ip_Ivtr1PwrDiscnctFltSts();
    
    /* init for variable GateDrv0Ctrl_Ip_PhaOnTiMeasdA */
    _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiMeasdA();
    
    /* init for variable GateDrv0Ctrl_Ip_PhaOnTiMeasdB */
    _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiMeasdB();
    
    /* init for variable GateDrv0Ctrl_Ip_PhaOnTiMeasdC */
    _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiMeasdC();
    
    /* init for variable GateDrv0Ctrl_Ip_PhaOnTiSumA */
    _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiSumA();
    
    /* init for variable GateDrv0Ctrl_Ip_PhaOnTiSumB */
    _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiSumB();
    
    /* init for variable GateDrv0Ctrl_Ip_PhaOnTiSumC */
    _main_gen_init_sym_GateDrv0Ctrl_Ip_PhaOnTiSumC();
    
    /* init for variable GateDrv0Ctrl_Ip_StrtUpSt */
    _main_gen_init_sym_GateDrv0Ctrl_Ip_StrtUpSt();
    
    /* init for variable GateDrv0Ctrl_Ip_SysSt */
    _main_gen_init_sym_GateDrv0Ctrl_Ip_SysSt();
    
    /* init for variable GateDrv0Ctrl_Op_DiagcStsIvtr1Inactv : useless (never read) */

    /* init for variable GateDrv0Ctrl_Op_IvtrFetFltPha : useless (never read) */

    /* init for variable GateDrv0Ctrl_Op_IvtrFetFltTyp : useless (never read) */

    /* init for variable GateDrv0Ctrl_Op_MotDrvErrA : useless (never read) */

    /* init for variable GateDrv0Ctrl_Op_MotDrvErrB : useless (never read) */

    /* init for variable GateDrv0Ctrl_Op_MotDrvErrC : useless (never read) */

    /* init for variable GateDrv0Ctrl_Op_MotDrvr0IninTestCmpl : useless (never read) */

    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlErrFilFrq */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlErrFilFrq();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlErrOffs */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlErrOffs();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlErrThd */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlErrThd();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x050FailStep */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x050FailStep();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x050PassStep */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x050PassStep();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x051FailStep */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x051FailStep();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x051PassStep */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x051PassStep();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x055FailStep */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x055FailStep();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x055PassStep */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlNtcNr0x055PassStep();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg2WrVal */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg2WrVal();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg3WrVal */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg3WrVal();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg4WrVal */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg4WrVal();
    
    /* init for variable GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg7WrVal */
    _main_gen_init_sym_GateDrv0Ctrl_Cal_GateDrv0CtrlUnit0Cfg7WrVal();
    
    /* init for variable GateDrv0Ctrl_Pim_dGateDrv0CtrlGateDrv0Diag0Val : useless (never read) */

    /* init for variable GateDrv0Ctrl_Pim_dGateDrv0CtrlGateDrv0Diag1Val : useless (never read) */

    /* init for variable GateDrv0Ctrl_Pim_dGateDrv0CtrlGateDrv0Diag2Val : useless (never read) */

    /* init for variable GateDrv0Ctrl_Pim_dGateDrv0CtrlGateDrv0OffsStVrfyPrmBitIdx : useless (never read) */

    /* init for variable GateDrv0Ctrl_Pim_dGateDrv0CtrlGateDrv0PhaOnTiSumAExp : useless (never read) */

    /* init for variable GateDrv0Ctrl_Pim_dGateDrv0CtrlGateDrv0PhaOnTiSumBExp : useless (never read) */

    /* init for variable GateDrv0Ctrl_Pim_dGateDrv0CtrlGateDrv0PhaOnTiSumCExp : useless (never read) */

    /* init for variable GateDrv0Ctrl_Pim_dGateDrv0CtrlGateDrv0StsVal : useless (never read) */

    /* init for variable GateDrv0Ctrl_Pim_dGateDrv0CtrlGateDrv0VrfyRes0Val : useless (never read) */

    /* init for variable GateDrv0Ctrl_Pim_dGateDrv0CtrlGateDrv0VrfyRes1Val : useless (never read) */

    /* init for variable GateDrv0Ctrl_Pim_GateDrv0CfgCnt */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0CfgCnt();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0CfgSecAtmpt */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0CfgSecAtmpt();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0Diag0Val */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0Diag0Val();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0Diag1Val */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0Diag1Val();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0Diag2Val */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0Diag2Val();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0OffStChkIdx */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0OffStChkIdx();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0OffStChkSecAtmpt */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0OffStChkSecAtmpt();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0OffStCnt */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0OffStCnt();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0PhaAFilLp */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaAFilLp();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0PhaBFilLp */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaBFilLp();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0PhaCFilLp */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaCFilLp();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumAPrev */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumAPrev();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumBPrev */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumBPrev();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumCPrev */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0PhaOnTiSumCPrev();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0SpiErrSecAtmpt */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0SpiErrSecAtmpt();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0SpiTrsmErrCntr */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0SpiTrsmErrCntr();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0St */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0St();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0StsVal */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0StsVal();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0VrfyRes0Val */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0VrfyRes0Val();
    
    /* init for variable GateDrv0Ctrl_Pim_GateDrv0VrfyRes1Val */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_GateDrv0VrfyRes1Val();
    
    /* init for variable GateDrv0Ctrl_Pim_Ivtr0BootstrpSplyFltPrmVal */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_Ivtr0BootstrpSplyFltPrmVal();
    
    /* init for variable GateDrv0Ctrl_Pim_Ivtr0GenericFltPrmVal */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_Ivtr0GenericFltPrmVal();
    
    /* init for variable GateDrv0Ctrl_Pim_Ivtr0InactvSts */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_Ivtr0InactvSts();
    
    /* init for variable GateDrv0Ctrl_Pim_Ivtr0OffStChkCmpl */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_Ivtr0OffStChkCmpl();
    
    /* init for variable GateDrv0Ctrl_Pim_IvtrFetFltPhaDataStore */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_IvtrFetFltPhaDataStore();
    
    /* init for variable GateDrv0Ctrl_Pim_IvtrFetFltTypDataStore */
    _main_gen_init_sym_GateDrv0Ctrl_Pim_IvtrFetFltTypDataStore();
    
    /* init for variable GateDrv0Ctrl_Irv_GateDrv0Ena */
    _main_gen_init_sym_GateDrv0Ctrl_Irv_GateDrv0Ena();
    
    /* init for variable GateDrv0Ctrl_Irv_GateDrv0PhaReasbnDiagcEna */
    _main_gen_init_sym_GateDrv0Ctrl_Irv_GateDrv0PhaReasbnDiagcEna();
    
    /* init for variable GateDrv0Ctrl_Irv_Ivtr0PhyFltInpActv */
    _main_gen_init_sym_GateDrv0Ctrl_Irv_Ivtr0PhyFltInpActv();
    
    /* init for variable ELECGLBPRM_GATEDRVOFFSTCHKDATA_CNT_U16 */
    _main_gen_init_sym_ELECGLBPRM_GATEDRVOFFSTCHKDATA_CNT_U16();
    
    /* init for variable GateDrv0Ctrl_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_GateDrv0Ctrl_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable GateDrv0Ctrl_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_GateDrv0Ctrl_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable GateDrv0Ctrl_Srv_IoHwAb_GetGpioMotDrvr0Diag_PinSt */
    _main_gen_init_sym_GateDrv0Ctrl_Srv_IoHwAb_GetGpioMotDrvr0Diag_PinSt();
    
    /* init for variable GateDrv0Ctrl_Srv_IoHwAb_GetGpioMotDrvr0Diag_Return */
    _main_gen_init_sym_GateDrv0Ctrl_Srv_IoHwAb_GetGpioMotDrvr0Diag_Return();
    
    /* init for variable GateDrv0Ctrl_Srv_IoHwAb_SetGpioGateDrv0Rst_PinSt : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_IoHwAb_SetGpioSysFlt2A_PinSt : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_IoHwAb_SetGpioSysFlt2A_Return */
    _main_gen_init_sym_GateDrv0Ctrl_Srv_IoHwAb_SetGpioSysFlt2A_Return();
    
    /* init for variable GateDrv0Ctrl_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcSts_Return */
    _main_gen_init_sym_GateDrv0Ctrl_Srv_SetNtcSts_Return();
    
    /* init for variable GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_NtcNr : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_NtcStInfo : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_NtcSts : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_DebStep : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData0 : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData1 : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData2 : useless (never read) */

    /* init for variable GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_Return */
    _main_gen_init_sym_GateDrv0Ctrl_Srv_SetNtcStsAndSnpshtData_Return();
    
}
