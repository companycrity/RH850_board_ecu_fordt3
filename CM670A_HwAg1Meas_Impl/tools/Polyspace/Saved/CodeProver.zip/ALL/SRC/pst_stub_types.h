typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT32 *__PST__g__17;
typedef __PST__VOID __PST__g__16(__PST__g__17);
typedef __PST__UINT8 *__PST__g__19;
typedef __PST__VOID __PST__g__18(__PST__g__19);
typedef __PST__VOID __PST__g__20(__PST__FLOAT32);
typedef __PST__UINT8 __PST__g__21(__PST__UINT16, __PST__g__19);
typedef __PST__UINT32 *__PST__g__23;
typedef __PST__UINT8 __PST__g__22(__PST__g__23);
typedef __PST__UINT8 __PST__g__24(__PST__UINT32, __PST__g__23);
typedef __PST__UINT8 __PST__g__25(__PST__g__19);
typedef __PST__UINT8 __PST__g__26(__PST__UINT8);
typedef __PST__UINT8 __PST__g__27(void);
typedef __PST__UINT8 __PST__g__28(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);
typedef __PST__FLOAT64 __PST__g__29(void);
typedef __PST__g__11 *__PST__g__31;
typedef volatile __PST__FLOAT64 __PST__g__32;
typedef __PST__SINT8 *__PST__g__34;
typedef volatile __PST__g__34 __PST__g__33;
typedef const __PST__UINT16 __PST__g__35;
typedef const __PST__UINT8 __PST__g__37;
typedef __PST__g__37 __PST__g__36[22];
typedef const __PST__SINT16 __PST__g__39;
typedef __PST__g__39 __PST__g__38[22];
typedef __PST__SINT8 __PST__g__41[3];
struct __PST__g__40
  {
    __PST__FLOAT32 OffsTrim;
    __PST__UINT8 OffsTrimPrfmdSts;
    __PST__g__41 __pst_unused_field___pstfiller;
  };
typedef __PST__SINT32 __PST__g__205[1];
union __PST__g__44
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT8 __PST__g__203[4];
typedef __PST__SINT8 __PST__g__204[8];
union __PST__g__52
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__57
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__61
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
struct __PST__g__65
  {
    __PST__UINT32 OMC : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
union __PST__g__64
  {
    struct __PST__g__65 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
union __PST__g__67
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
struct __PST__g__73
  {
    const __PST__UINT32 OMS : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 29;
  };
typedef const struct __PST__g__73 __PST__g__72;
union __PST__g__71
  {
    __PST__g__72 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__71 __PST__g__70;
struct __PST__g__78
  {
    const __PST__UINT32 FRS : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 NRS : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 21;
  };
typedef const struct __PST__g__78 __PST__g__77;
union __PST__g__76
  {
    __PST__g__77 BIT;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__76 __PST__g__75;
struct __PST__g__81
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 NRC : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__80
  {
    struct __PST__g__81 BIT;
    __PST__UINT32 UINT32;
  };
struct __PST__g__114
  {
    const __PST__UINT32 __pst_unused_field_0 : 24;
    const __PST__UINT32 __pst_unused_field_1 : 4;
    const __PST__UINT32 __pst_unused_field_2 : 2;
    const __PST__UINT32 FND : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
  };
typedef const struct __PST__g__114 __PST__g__113;
union __PST__g__112
  {
    __PST__g__113 BIT;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__112 __PST__g__111;
struct __PST__g__43
  {
    union __PST__g__44 TSPC;
    __PST__g__203 __pst_unused_field_1;
    __PST__g__204 __pst_unused_field_2;
    union __PST__g__52 _CC;
    union __PST__g__57 BRP;
    union __PST__g__61 IDE;
    union __PST__g__64 MDC;
    union __PST__g__67 SPCT;
    __PST__g__70 MST;
    __PST__g__75 CS;
    union __PST__g__80 CSC;
    __PST__g__203 __pst_unused_field_11;
    __PST__g__203 __pst_unused_field_12;
    __PST__g__203 __pst_unused_field_13;
    __PST__g__203 __pst_unused_field_14;
    __PST__g__203 __pst_unused_field_15;
    __PST__g__111 FRXD;
  };
typedef volatile struct __PST__g__43 __PST__g__42;
struct __PST__g__45
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 15;
  };
union __PST__g__49
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__50
  {
    __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef __PST__UINT8 __PST__g__51[8];
struct __PST__g__53
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 3;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 19;
  };
struct __PST__g__58
  {
    __PST__UINT32 __pst_unused_field_0 : 5;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 3;
    __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_4 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_6 : 4;
    __PST__UINT32 __pst_unused_field_pstnonamef4 : 4;
  };
struct __PST__g__62
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 21;
  };
struct __PST__g__68
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 25;
  };
union __PST__g__83
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__83 __PST__g__82;
struct __PST__g__85
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__85 __PST__g__84;
typedef const __PST__UINT32 __PST__g__86;
union __PST__g__88
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__88 __PST__g__87;
struct __PST__g__90
  {
    const __PST__UINT32 __pst_unused_field_0 : 20;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 3;
    const __PST__UINT32 __pst_unused_field_3 : 6;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
  };
typedef const struct __PST__g__90 __PST__g__89;
union __PST__g__96
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__96 __PST__g__95;
struct __PST__g__98
  {
    const __PST__UINT32 __pst_unused_field_0 : 17;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 15;
  };
typedef const struct __PST__g__98 __PST__g__97;
union __PST__g__102
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__102 __PST__g__101;
struct __PST__g__104
  {
    const __PST__UINT32 __pst_unused_field_0 : 21;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 11;
  };
typedef const struct __PST__g__104 __PST__g__103;
union __PST__g__108
  {
    __PST__g__205 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__108 __PST__g__107;
struct __PST__g__110
  {
    const __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef const struct __PST__g__110 __PST__g__109;
typedef __PST__VOID __PST__g__119(__PST__SINT32);
typedef __PST__FLOAT32 __PST__g__120(__PST__FLOAT32);
typedef __PST__UINT8 __PST__g__121(__PST__FLOAT32);
typedef __PST__g__37 *__PST__g__122;
typedef __PST__g__39 *__PST__g__123;
typedef __PST__VOID __PST__g__124(__PST__UINT8);
typedef __PST__FLOAT32 __PST__g__125(__PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32);
typedef struct __PST__g__40 *__PST__g__126;
typedef __PST__UINT8 __PST__g__127(__PST__SINT8);
typedef __PST__g__120 *__PST__g__128;
typedef __PST__g__26 *__PST__g__129;
typedef __PST__g__42 *__PST__g__130;
typedef volatile union __PST__g__64 __PST__g__131;
typedef __PST__g__131 *__PST__g__132;
typedef volatile struct __PST__g__65 __PST__g__133;
typedef __PST__g__133 *__PST__g__134;
typedef __PST__g__22 *__PST__g__137;
typedef volatile __PST__g__70 __PST__g__138;
typedef __PST__g__138 *__PST__g__139;
typedef volatile __PST__g__72 __PST__g__140;
typedef __PST__g__140 *__PST__g__141;
typedef __PST__g__24 *__PST__g__144;
typedef volatile union __PST__g__44 __PST__g__145;
typedef __PST__g__145 *__PST__g__146;
typedef volatile __PST__UINT32 __PST__g__147;
typedef __PST__g__147 *__PST__g__148;
typedef volatile union __PST__g__52 __PST__g__149;
typedef __PST__g__149 *__PST__g__150;
typedef volatile union __PST__g__57 __PST__g__151;
typedef __PST__g__151 *__PST__g__152;
typedef volatile union __PST__g__61 __PST__g__153;
typedef __PST__g__153 *__PST__g__154;
typedef __PST__g__27 *__PST__g__155;
typedef __PST__g__25 *__PST__g__156;
typedef __PST__g__119 *__PST__g__157;
typedef __PST__g__28 *__PST__g__158;
typedef volatile union __PST__g__80 __PST__g__159;
typedef __PST__g__159 *__PST__g__160;
typedef volatile union __PST__g__67 __PST__g__161;
typedef __PST__g__161 *__PST__g__162;
typedef __PST__g__15 *__PST__g__163;
typedef volatile struct __PST__g__81 __PST__g__164;
typedef __PST__g__164 *__PST__g__165;
typedef volatile __PST__g__75 __PST__g__168;
typedef __PST__g__168 *__PST__g__169;
typedef volatile __PST__g__77 __PST__g__170;
typedef __PST__g__170 *__PST__g__171;
typedef volatile __PST__g__86 __PST__g__174;
typedef __PST__g__174 *__PST__g__175;
typedef volatile __PST__g__111 __PST__g__176;
typedef __PST__g__176 *__PST__g__177;
typedef __PST__UINT32 __PST__g__178(__PST__g__147);
typedef __PST__g__178 *__PST__g__179;
typedef volatile __PST__g__113 __PST__g__180;
typedef __PST__g__180 *__PST__g__181;
typedef __PST__g__121 *__PST__g__182;
typedef __PST__g__36 *__PST__g__183;
typedef __PST__g__127 *__PST__g__184;
typedef __PST__g__125 *__PST__g__185;
typedef __PST__g__21 *__PST__g__186;
typedef __PST__g__124 *__PST__g__187;
typedef __PST__g__38 *__PST__g__188;
typedef __PST__g__16 *__PST__g__189;
typedef __PST__g__18 *__PST__g__190;
typedef __PST__g__20 *__PST__g__191;
typedef volatile __PST__SINT32 __PST__g__192;
typedef __PST__SINT8 __PST__g__198(void);
typedef volatile __PST__SINT8 __PST__g__199;
typedef volatile __PST__UINT8 __PST__g__200;
typedef __PST__SINT32 __PST__g__201(void);
typedef __PST__UINT32 __PST__g__202(void);
typedef __PST__SINT16 *__PST__g__206;
typedef volatile __PST__SINT16 __PST__g__207;
typedef volatile __PST__FLOAT32 __PST__g__208;
