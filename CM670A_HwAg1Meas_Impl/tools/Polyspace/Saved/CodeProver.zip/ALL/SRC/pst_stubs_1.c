#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__114 _main_gen_init_g114(void);

extern union __PST__g__112 _main_gen_init_g112(void);

extern struct __PST__g__81 _main_gen_init_g81(void);

extern union __PST__g__80 _main_gen_init_g80(void);

extern struct __PST__g__78 _main_gen_init_g78(void);

extern union __PST__g__76 _main_gen_init_g76(void);

extern struct __PST__g__73 _main_gen_init_g73(void);

extern union __PST__g__71 _main_gen_init_g71(void);

extern union __PST__g__67 _main_gen_init_g67(void);

extern struct __PST__g__65 _main_gen_init_g65(void);

extern union __PST__g__64 _main_gen_init_g64(void);

extern union __PST__g__61 _main_gen_init_g61(void);

extern union __PST__g__57 _main_gen_init_g57(void);

extern union __PST__g__52 _main_gen_init_g52(void);

extern union __PST__g__44 _main_gen_init_g44(void);

extern __PST__g__42 _main_gen_init_g42(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__40 _main_gen_init_g40(void);

extern __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__35 _main_gen_init_g35(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__SINT8 _main_gen_init_g2(void);

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__35 _main_gen_init_g35(void)
{
    __PST__g__35 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__37 _main_gen_init_g37(void)
{
    __PST__g__37 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__40 _main_gen_init_g40(void)
{
    static struct __PST__g__40 x;
    /* struct/union type */
    x.OffsTrim = _main_gen_init_g10();
    x.OffsTrimPrfmdSts = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__44 _main_gen_init_g44(void)
{
    static union __PST__g__44 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__52 _main_gen_init_g52(void)
{
    static union __PST__g__52 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__57 _main_gen_init_g57(void)
{
    static union __PST__g__57 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__61 _main_gen_init_g61(void)
{
    static union __PST__g__61 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__65 _main_gen_init_g65(void)
{
    static struct __PST__g__65 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 7);
        x.OMC = bitf;
    }
    return x;
}

union __PST__g__64 _main_gen_init_g64(void)
{
    static union __PST__g__64 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g65();
    return x;
}

union __PST__g__67 _main_gen_init_g67(void)
{
    static union __PST__g__67 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__73 _main_gen_init_g73(void)
{
    static struct __PST__g__73 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 7);
        x.OMS = bitf;
    }
    return x;
}

union __PST__g__71 _main_gen_init_g71(void)
{
    static union __PST__g__71 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g73();
    return x;
}

struct __PST__g__78 _main_gen_init_g78(void)
{
    static struct __PST__g__78 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FRS = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRS = bitf;
    }
    return x;
}

union __PST__g__76 _main_gen_init_g76(void)
{
    static union __PST__g__76 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g78();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__81 _main_gen_init_g81(void)
{
    static struct __PST__g__81 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.NRC = bitf;
    }
    return x;
}

union __PST__g__80 _main_gen_init_g80(void)
{
    static union __PST__g__80 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g81();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__114 _main_gen_init_g114(void)
{
    static struct __PST__g__114 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.FND = bitf;
    }
    return x;
}

union __PST__g__112 _main_gen_init_g112(void)
{
    static union __PST__g__112 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g114();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__42 _main_gen_init_g42(void)
{
    __PST__g__42 x;
    /* struct/union type */
    x.TSPC = _main_gen_init_g44();
    x._CC = _main_gen_init_g52();
    x.BRP = _main_gen_init_g57();
    x.IDE = _main_gen_init_g61();
    x.MDC = _main_gen_init_g64();
    x.SPCT = _main_gen_init_g67();
    x.MST = _main_gen_init_g71();
    x.CS = _main_gen_init_g76();
    x.CSC = _main_gen_init_g80();
    x.FRXD = _main_gen_init_g112();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_HwAg1Meas_Ip_HwAg1Polarity(void)
{
    extern __PST__SINT8 HwAg1Meas_Ip_HwAg1Polarity;
    
    /* initialization with random value */
    {
        HwAg1Meas_Ip_HwAg1Polarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Ip_HwAg1SnsrTyp(void)
{
    extern __PST__UINT8 HwAg1Meas_Ip_HwAg1SnsrTyp;
    
    /* initialization with random value */
    {
        HwAg1Meas_Ip_HwAg1SnsrTyp = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1IfFltFailStep(void)
{
    extern __PST__g__35 HwAg1Meas_Cal_HwAg1MeasHwAg1IfFltFailStep;
    
    /* initialization with random value */
    {
        HwAg1Meas_Cal_HwAg1MeasHwAg1IfFltFailStep = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1IfFltPassStep(void)
{
    extern __PST__g__35 HwAg1Meas_Cal_HwAg1MeasHwAg1IfFltPassStep;
    
    /* initialization with random value */
    {
        HwAg1Meas_Cal_HwAg1MeasHwAg1IfFltPassStep = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr0PrtclFltFailStep(void)
{
    extern __PST__g__35 HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr0PrtclFltFailStep;
    
    /* initialization with random value */
    {
        HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr0PrtclFltFailStep = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr0PrtclFltPassStep(void)
{
    extern __PST__g__35 HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr0PrtclFltPassStep;
    
    /* initialization with random value */
    {
        HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr0PrtclFltPassStep = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr1PrtclFltFailStep(void)
{
    extern __PST__g__35 HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr1PrtclFltFailStep;
    
    /* initialization with random value */
    {
        HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr1PrtclFltFailStep = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr1PrtclFltPassStep(void)
{
    extern __PST__g__35 HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr1PrtclFltPassStep;
    
    /* initialization with random value */
    {
        HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr1PrtclFltPassStep = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasSnsr0Rev(void)
{
    extern __PST__g__36 HwAg1Meas_Cal_HwAg1MeasSnsr0Rev;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 22; _main_gen_tmp_1_0++)
            {
                /* base type */
                HwAg1Meas_Cal_HwAg1MeasSnsr0Rev[_main_gen_tmp_1_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasSnsr1Rev(void)
{
    extern __PST__g__36 HwAg1Meas_Cal_HwAg1MeasSnsr1Rev;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 22; _main_gen_tmp_2_0++)
            {
                /* base type */
                HwAg1Meas_Cal_HwAg1MeasSnsr1Rev[_main_gen_tmp_2_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasStep(void)
{
    extern __PST__g__38 HwAg1Meas_Cal_HwAg1MeasStep;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 22; _main_gen_tmp_3_0++)
            {
                /* base type */
                HwAg1Meas_Cal_HwAg1MeasStep[_main_gen_tmp_3_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasVrnrErrThd(void)
{
    extern __PST__g__37 HwAg1Meas_Cal_HwAg1MeasVrnrErrThd;
    
    /* initialization with random value */
    {
        HwAg1Meas_Cal_HwAg1MeasVrnrErrThd = _main_gen_init_g37();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1IfFltLtch(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1IfFltLtch;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1IfFltLtch = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Offs(void)
{
    extern struct __PST__g__40 HwAg1Meas_Pim_HwAg1Offs;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1Offs = _main_gen_init_g40();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1InitStepSeqNrCmpl(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1InitStepSeqNrCmpl;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1InitStepSeqNrCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1LtchClr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1LtchClr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1LtchClr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1PrevHwAg1(void)
{
    extern __PST__FLOAT32 HwAg1Meas_Pim_HwAg1PrevHwAg1;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1PrevHwAg1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1PrevRollCnt(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1PrevRollCnt;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1PrevRollCnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1PrevStepSeqNr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1PrevStepSeqNr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1PrevStepSeqNr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1RawDataAvlStrtTi(void)
{
    extern __PST__UINT32 HwAg1Meas_Pim_HwAg1RawDataAvlStrtTi;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1RawDataAvlStrtTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr0ComStsErrCntr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1Snsr0ComStsErrCntr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1Snsr0ComStsErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr0IdErrCntr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1Snsr0IdErrCntr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1Snsr0IdErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr0IntSnsrErrCntr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1Snsr0IntSnsrErrCntr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1Snsr0IntSnsrErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr0NoMsgErrCntr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1Snsr0NoMsgErrCntr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1Snsr0NoMsgErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr1ComStsErrCntr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1Snsr1ComStsErrCntr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1Snsr1ComStsErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr1IdErrCntr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1Snsr1IdErrCntr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1Snsr1IdErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr1IntSnsrErrCntr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1Snsr1IntSnsrErrCntr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1Snsr1IntSnsrErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr1NoMsgErrCntr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1Snsr1NoMsgErrCntr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1Snsr1NoMsgErrCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_HwAg1SnsrTrigNr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_HwAg1SnsrTrigNr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_HwAg1SnsrTrigNr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1(void)
{
    extern __PST__FLOAT32 HwAg1Meas_Pim_PrevHwAg1;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_PrevHwAg1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1Qlfr(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_PrevHwAg1Qlfr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_PrevHwAg1Qlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1Snsr0Raw(void)
{
    extern __PST__UINT16 HwAg1Meas_Pim_PrevHwAg1Snsr0Raw;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_PrevHwAg1Snsr0Raw = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1Snsr0TestOk(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_PrevHwAg1Snsr0TestOk;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_PrevHwAg1Snsr0TestOk = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1Snsr1Raw(void)
{
    extern __PST__UINT16 HwAg1Meas_Pim_PrevHwAg1Snsr1Raw;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_PrevHwAg1Snsr1Raw = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1Snsr1TestOk(void)
{
    extern __PST__UINT8 HwAg1Meas_Pim_PrevHwAg1Snsr1TestOk;
    
    /* initialization with random value */
    {
        HwAg1Meas_Pim_PrevHwAg1Snsr1TestOk = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Irv_HwAg1Snsr0Raw(void)
{
    extern __PST__UINT16 HwAg1Meas_Irv_HwAg1Snsr0Raw;
    
    /* initialization with random value */
    {
        HwAg1Meas_Irv_HwAg1Snsr0Raw = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Irv_HwAg1Snsr0TestOk(void)
{
    extern __PST__UINT8 HwAg1Meas_Irv_HwAg1Snsr0TestOk;
    
    /* initialization with random value */
    {
        HwAg1Meas_Irv_HwAg1Snsr0TestOk = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Irv_HwAg1Snsr1Raw(void)
{
    extern __PST__UINT16 HwAg1Meas_Irv_HwAg1Snsr1Raw;
    
    /* initialization with random value */
    {
        HwAg1Meas_Irv_HwAg1Snsr1Raw = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Irv_HwAg1Snsr1TestOk(void)
{
    extern __PST__UINT8 HwAg1Meas_Irv_HwAg1Snsr1TestOk;
    
    /* initialization with random value */
    {
        HwAg1Meas_Irv_HwAg1Snsr1TestOk = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ELECGLBPRM_HWAGIFFLTLTCHENA_CNT_LGC(void)
{
    extern __PST__UINT8 ELECGLBPRM_HWAGIFFLTLTCHENA_CNT_LGC;
    
    /* initialization with random value */
    {
        ELECGLBPRM_HWAGIFFLTLTCHENA_CNT_LGC = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_RSENT2(void)
{
    extern __PST__g__42 RSENT2;
    
    /* initialization with random value */
    {
        RSENT2 = _main_gen_init_g42();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 HwAg1Meas_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 HwAg1Meas_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 HwAg1Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 HwAg1Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_HwAg1IfFltLtch_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 HwAg1Meas_Srv_HwAg1IfFltLtch_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_HwAg1IfFltLtch_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_HwAg1IfFltLtch_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 HwAg1Meas_Srv_HwAg1IfFltLtch_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_HwAg1IfFltLtch_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_HwAg1IfFltLtch_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 HwAg1Meas_Srv_HwAg1IfFltLtch_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_HwAg1IfFltLtch_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_HwAg1Offs_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 HwAg1Meas_Srv_HwAg1Offs_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_HwAg1Offs_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_HwAg1Offs_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 HwAg1Meas_Srv_HwAg1Offs_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_HwAg1Offs_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_HwAg1Offs_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 HwAg1Meas_Srv_HwAg1Offs_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_HwAg1Offs_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_IoHwAb_SetFctPrphlHwAg1_Return(void)
{
    extern __PST__UINT8 HwAg1Meas_Srv_IoHwAb_SetFctPrphlHwAg1_Return;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_IoHwAb_SetFctPrphlHwAg1_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 HwAg1Meas_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        HwAg1Meas_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cli_HwAg1ReadTrim_HwAgReadTrimData(void)
{
    extern __PST__FLOAT32 HwAg1Meas_Cli_HwAg1ReadTrim_HwAgReadTrimData;
    
    /* initialization with random value */
    {
        HwAg1Meas_Cli_HwAg1ReadTrim_HwAgReadTrimData = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cli_HwAg1TrimPrfmdSts_HwAgOffsTrimPrfmdStsData(void)
{
    extern __PST__UINT8 HwAg1Meas_Cli_HwAg1TrimPrfmdSts_HwAgOffsTrimPrfmdStsData;
    
    /* initialization with random value */
    {
        HwAg1Meas_Cli_HwAg1TrimPrfmdSts_HwAgOffsTrimPrfmdStsData = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAg1Meas_Cli_HwAg1WrTrim_HwAgWrOffsTrimData(void)
{
    extern __PST__FLOAT32 HwAg1Meas_Cli_HwAg1WrTrim_HwAgWrOffsTrimData;
    
    /* initialization with random value */
    {
        HwAg1Meas_Cli_HwAg1WrTrim_HwAgWrOffsTrimData = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable HwAg1Meas_Ip_HwAg1Polarity */
    _main_gen_init_sym_HwAg1Meas_Ip_HwAg1Polarity();
    
    /* init for variable HwAg1Meas_Ip_HwAg1SnsrTyp */
    _main_gen_init_sym_HwAg1Meas_Ip_HwAg1SnsrTyp();
    
    /* init for variable HwAg1Meas_Op_HwAg1 : useless (never read) */

    /* init for variable HwAg1Meas_Op_HwAg1Qlfr : useless (never read) */

    /* init for variable HwAg1Meas_Op_HwAg1RollgCntr : useless (never read) */

    /* init for variable HwAg1Meas_Cal_HwAg1MeasHwAg1IfFltFailStep */
    _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1IfFltFailStep();
    
    /* init for variable HwAg1Meas_Cal_HwAg1MeasHwAg1IfFltPassStep */
    _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1IfFltPassStep();
    
    /* init for variable HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr0PrtclFltFailStep */
    _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr0PrtclFltFailStep();
    
    /* init for variable HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr0PrtclFltPassStep */
    _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr0PrtclFltPassStep();
    
    /* init for variable HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr1PrtclFltFailStep */
    _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr1PrtclFltFailStep();
    
    /* init for variable HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr1PrtclFltPassStep */
    _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasHwAg1Snsr1PrtclFltPassStep();
    
    /* init for variable HwAg1Meas_Cal_HwAg1MeasSnsr0Rev */
    _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasSnsr0Rev();
    
    /* init for variable HwAg1Meas_Cal_HwAg1MeasSnsr1Rev */
    _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasSnsr1Rev();
    
    /* init for variable HwAg1Meas_Cal_HwAg1MeasStep */
    _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasStep();
    
    /* init for variable HwAg1Meas_Cal_HwAg1MeasVrnrErrThd */
    _main_gen_init_sym_HwAg1Meas_Cal_HwAg1MeasVrnrErrThd();
    
    /* init for variable HwAg1Meas_Pim_HwAg1IfFltLtch */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1IfFltLtch();
    
    /* init for variable HwAg1Meas_Pim_HwAg1Offs */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Offs();
    
    /* init for variable HwAg1Meas_Pim_dHwAg1MeasSnsr0Abs : useless (never read) */

    /* init for variable HwAg1Meas_Pim_dHwAg1MeasSnsr0CS : useless (never read) */

    /* init for variable HwAg1Meas_Pim_dHwAg1MeasSnsr0FRXD : useless (never read) */

    /* init for variable HwAg1Meas_Pim_dHwAg1MeasSnsr0Rel : useless (never read) */

    /* init for variable HwAg1Meas_Pim_dHwAg1MeasSnsr1Abs : useless (never read) */

    /* init for variable HwAg1Meas_Pim_dHwAg1MeasSnsr1CS : useless (never read) */

    /* init for variable HwAg1Meas_Pim_dHwAg1MeasSnsr1FRXD : useless (never read) */

    /* init for variable HwAg1Meas_Pim_dHwAg1MeasSnsr1Rel : useless (never read) */

    /* init for variable HwAg1Meas_Pim_HwAg1InitStepSeqNrCmpl */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1InitStepSeqNrCmpl();
    
    /* init for variable HwAg1Meas_Pim_HwAg1LtchClr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1LtchClr();
    
    /* init for variable HwAg1Meas_Pim_HwAg1PrevHwAg1 */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1PrevHwAg1();
    
    /* init for variable HwAg1Meas_Pim_HwAg1PrevRollCnt */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1PrevRollCnt();
    
    /* init for variable HwAg1Meas_Pim_HwAg1PrevStepSeqNr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1PrevStepSeqNr();
    
    /* init for variable HwAg1Meas_Pim_HwAg1RawDataAvlStrtTi */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1RawDataAvlStrtTi();
    
    /* init for variable HwAg1Meas_Pim_HwAg1Snsr0ComStsErrCntr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr0ComStsErrCntr();
    
    /* init for variable HwAg1Meas_Pim_HwAg1Snsr0IdErrCntr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr0IdErrCntr();
    
    /* init for variable HwAg1Meas_Pim_HwAg1Snsr0IntSnsrErrCntr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr0IntSnsrErrCntr();
    
    /* init for variable HwAg1Meas_Pim_HwAg1Snsr0NoMsgErrCntr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr0NoMsgErrCntr();
    
    /* init for variable HwAg1Meas_Pim_HwAg1Snsr1ComStsErrCntr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr1ComStsErrCntr();
    
    /* init for variable HwAg1Meas_Pim_HwAg1Snsr1IdErrCntr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr1IdErrCntr();
    
    /* init for variable HwAg1Meas_Pim_HwAg1Snsr1IntSnsrErrCntr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr1IntSnsrErrCntr();
    
    /* init for variable HwAg1Meas_Pim_HwAg1Snsr1NoMsgErrCntr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1Snsr1NoMsgErrCntr();
    
    /* init for variable HwAg1Meas_Pim_HwAg1SnsrTrigNr */
    _main_gen_init_sym_HwAg1Meas_Pim_HwAg1SnsrTrigNr();
    
    /* init for variable HwAg1Meas_Pim_PrevHwAg1 */
    _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1();
    
    /* init for variable HwAg1Meas_Pim_PrevHwAg1Qlfr */
    _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1Qlfr();
    
    /* init for variable HwAg1Meas_Pim_PrevHwAg1Snsr0Raw */
    _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1Snsr0Raw();
    
    /* init for variable HwAg1Meas_Pim_PrevHwAg1Snsr0TestOk */
    _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1Snsr0TestOk();
    
    /* init for variable HwAg1Meas_Pim_PrevHwAg1Snsr1Raw */
    _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1Snsr1Raw();
    
    /* init for variable HwAg1Meas_Pim_PrevHwAg1Snsr1TestOk */
    _main_gen_init_sym_HwAg1Meas_Pim_PrevHwAg1Snsr1TestOk();
    
    /* init for variable HwAg1Meas_Irv_HwAg1Snsr0Raw */
    _main_gen_init_sym_HwAg1Meas_Irv_HwAg1Snsr0Raw();
    
    /* init for variable HwAg1Meas_Irv_HwAg1Snsr0TestOk */
    _main_gen_init_sym_HwAg1Meas_Irv_HwAg1Snsr0TestOk();
    
    /* init for variable HwAg1Meas_Irv_HwAg1Snsr1Raw */
    _main_gen_init_sym_HwAg1Meas_Irv_HwAg1Snsr1Raw();
    
    /* init for variable HwAg1Meas_Irv_HwAg1Snsr1TestOk */
    _main_gen_init_sym_HwAg1Meas_Irv_HwAg1Snsr1TestOk();
    
    /* init for variable ELECGLBPRM_HWAGIFFLTLTCHENA_CNT_LGC */
    _main_gen_init_sym_ELECGLBPRM_HWAGIFFLTLTCHENA_CNT_LGC();
    
    /* init for variable RSENT2 */
    _main_gen_init_sym_RSENT2();
    
    /* init for variable HwAg1Meas_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable HwAg1Meas_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_HwAg1Meas_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable HwAg1Meas_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_HwAg1Meas_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable HwAg1Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr */
    _main_gen_init_sym_HwAg1Meas_Srv_GetRefTmr1MicroSec32bit_RefTmr();
    
    /* init for variable HwAg1Meas_Srv_GetTiSpan1MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable HwAg1Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan */
    _main_gen_init_sym_HwAg1Meas_Srv_GetTiSpan1MicroSec32bit_TiSpan();
    
    /* init for variable HwAg1Meas_Srv_HwAg1IfFltLtch_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_HwAg1Meas_Srv_HwAg1IfFltLtch_GetErrorStatus_RequestResultPtr();
    
    /* init for variable HwAg1Meas_Srv_HwAg1IfFltLtch_GetErrorStatus_Return */
    _main_gen_init_sym_HwAg1Meas_Srv_HwAg1IfFltLtch_GetErrorStatus_Return();
    
    /* init for variable HwAg1Meas_Srv_HwAg1IfFltLtch_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable HwAg1Meas_Srv_HwAg1IfFltLtch_SetRamBlockStatus_Return */
    _main_gen_init_sym_HwAg1Meas_Srv_HwAg1IfFltLtch_SetRamBlockStatus_Return();
    
    /* init for variable HwAg1Meas_Srv_HwAg1Offs_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_HwAg1Meas_Srv_HwAg1Offs_GetErrorStatus_RequestResultPtr();
    
    /* init for variable HwAg1Meas_Srv_HwAg1Offs_GetErrorStatus_Return */
    _main_gen_init_sym_HwAg1Meas_Srv_HwAg1Offs_GetErrorStatus_Return();
    
    /* init for variable HwAg1Meas_Srv_HwAg1Offs_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable HwAg1Meas_Srv_HwAg1Offs_SetRamBlockStatus_Return */
    _main_gen_init_sym_HwAg1Meas_Srv_HwAg1Offs_SetRamBlockStatus_Return();
    
    /* init for variable HwAg1Meas_Srv_IoHwAb_SetFctPrphlHwAg1_Return */
    _main_gen_init_sym_HwAg1Meas_Srv_IoHwAb_SetFctPrphlHwAg1_Return();
    
    /* init for variable HwAg1Meas_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable HwAg1Meas_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable HwAg1Meas_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable HwAg1Meas_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable HwAg1Meas_Srv_SetNtcSts_Return */
    _main_gen_init_sym_HwAg1Meas_Srv_SetNtcSts_Return();
    
    /* init for variable HwAg1Meas_Cli_HwAg1ReadTrim_HwAgReadTrimData */
    _main_gen_init_sym_HwAg1Meas_Cli_HwAg1ReadTrim_HwAgReadTrimData();
    
    /* init for variable HwAg1Meas_Cli_HwAg1TrimPrfmdSts_HwAgOffsTrimPrfmdStsData */
    _main_gen_init_sym_HwAg1Meas_Cli_HwAg1TrimPrfmdSts_HwAgOffsTrimPrfmdStsData();
    
    /* init for variable HwAg1Meas_Cli_HwAg1WrTrim_HwAgWrOffsTrimData */
    _main_gen_init_sym_HwAg1Meas_Cli_HwAg1WrTrim_HwAgWrOffsTrimData();
    
}
