#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__33 _main_gen_init_g33(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__33 _main_gen_init_g33(void)
{
    __PST__g__33 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_MotAgSwCal_Pim_BoostModlnIdx(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Pim_BoostModlnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_BoostModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_BoostSlew(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Pim_BoostSlew;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_BoostSlew = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_BoostTi(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_BoostTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_BoostTi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_BoostTiOut(void)
{
    extern __PST__UINT32 MotAgSwCal_Pim_BoostTiOut;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_BoostTiOut = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_CoolDwnModlnIdx(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Pim_CoolDwnModlnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_CoolDwnModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_CoolDwnSlew(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Pim_CoolDwnSlew;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_CoolDwnSlew = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_CoolDwnTi(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_CoolDwnTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_CoolDwnTi = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_CoolDwnTiOut(void)
{
    extern __PST__UINT32 MotAgSwCal_Pim_CoolDwnTiOut;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_CoolDwnTiOut = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_ElecRevCnt(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_ElecRevCnt;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_ElecRevCnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_HldModlnIdx(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Pim_HldModlnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_HldModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_HldSlew(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Pim_HldSlew;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_HldSlew = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_HldTi(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_HldTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_HldTi = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_HldTiOut(void)
{
    extern __PST__UINT32 MotAgSwCal_Pim_HldTiOut;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_HldTiOut = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg2CosMeasAvrg(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg2CosMeasAvrg;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg2CosMeasAvrg = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg2SinMeasAvrg(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg2SinMeasAvrg;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg2SinMeasAvrg = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg5CosMeasAvrg(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg5CosMeasAvrg;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg5CosMeasAvrg = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg5SinMeasAvrg(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg5SinMeasAvrg;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg5SinMeasAvrg = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg6CosMeasAvrg(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg6CosMeasAvrg;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg6CosMeasAvrg = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg6SinMeasAvrg(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg6SinMeasAvrg;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg6SinMeasAvrg = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_PosnStepSize(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_PosnStepSize;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_PosnStepSize = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_Ramp1Ti(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_Ramp1Ti;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_Ramp1Ti = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_Ramp2Ti(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_Ramp2Ti;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_Ramp2Ti = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_Ramp3Ti(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_Ramp3Ti;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_Ramp3Ti = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_SamplePosnIdx(void)
{
    extern __PST__UINT32 MotAgSwCal_Pim_SamplePosnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_SamplePosnIdx = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_SampleRdyFlg(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_SampleRdyFlg;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_SampleRdyFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_SampleStopTi(void)
{
    extern __PST__UINT32 MotAgSwCal_Pim_SampleStopTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_SampleStopTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_SampleStrtTi(void)
{
    extern __PST__UINT32 MotAgSwCal_Pim_SampleStrtTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_SampleStrtTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_SwCalEna(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_SwCalEna;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_SwCalEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cal_MotAgSwCalVehSpdThd(void)
{
    extern __PST__g__33 MotAgSwCal_Cal_MotAgSwCalVehSpdThd;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cal_MotAgSwCalVehSpdThd = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg2CosAdcFaildCntr(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_MotAg2CosAdcFaildCntr;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg2CosAdcFaildCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg2CosMeasRaw(void)
{
    extern __PST__g__34 MotAgSwCal_Pim_MotAg2CosMeasRaw;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 50; _main_gen_tmp_1_0++)
            {
                /* base type */
                MotAgSwCal_Pim_MotAg2CosMeasRaw[_main_gen_tmp_1_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg2CosMeasRawCumv(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg2CosMeasRawCumv;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg2CosMeasRawCumv = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg2CosMeasRawPrev(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg2CosMeasRawPrev;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg2CosMeasRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg2SinAdcFaildCntr(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_MotAg2SinAdcFaildCntr;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg2SinAdcFaildCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg2SinMeasRaw(void)
{
    extern __PST__g__34 MotAgSwCal_Pim_MotAg2SinMeasRaw;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 50; _main_gen_tmp_2_0++)
            {
                /* base type */
                MotAgSwCal_Pim_MotAg2SinMeasRaw[_main_gen_tmp_2_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg2SinMeasRawCumv(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg2SinMeasRawCumv;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg2SinMeasRawCumv = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg2SinMeasRawPrev(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg2SinMeasRawPrev;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg2SinMeasRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg5CosAdcFaildCntr(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_MotAg5CosAdcFaildCntr;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg5CosAdcFaildCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg5CosMeasRaw(void)
{
    extern __PST__g__34 MotAgSwCal_Pim_MotAg5CosMeasRaw;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 50; _main_gen_tmp_3_0++)
            {
                /* base type */
                MotAgSwCal_Pim_MotAg5CosMeasRaw[_main_gen_tmp_3_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg5CosMeasRawCumv(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg5CosMeasRawCumv;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg5CosMeasRawCumv = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg5CosMeasRawPrev(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg5CosMeasRawPrev;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg5CosMeasRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg5SinAdcFaildCntr(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_MotAg5SinAdcFaildCntr;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg5SinAdcFaildCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg5SinMeasRaw(void)
{
    extern __PST__g__34 MotAgSwCal_Pim_MotAg5SinMeasRaw;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 50; _main_gen_tmp_4_0++)
            {
                /* base type */
                MotAgSwCal_Pim_MotAg5SinMeasRaw[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg5SinMeasRawCumv(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg5SinMeasRawCumv;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg5SinMeasRawCumv = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg5SinMeasRawPrev(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg5SinMeasRawPrev;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg5SinMeasRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg6CosAdcFaildCntr(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_MotAg6CosAdcFaildCntr;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg6CosAdcFaildCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg6CosMeasRaw(void)
{
    extern __PST__g__34 MotAgSwCal_Pim_MotAg6CosMeasRaw;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 50; _main_gen_tmp_5_0++)
            {
                /* base type */
                MotAgSwCal_Pim_MotAg6CosMeasRaw[_main_gen_tmp_5_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg6CosMeasRawCumv(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg6CosMeasRawCumv;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg6CosMeasRawCumv = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg6CosMeasRawPrev(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg6CosMeasRawPrev;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg6CosMeasRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg6SinAdcFaildCntr(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_MotAg6SinAdcFaildCntr;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg6SinAdcFaildCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg6SinMeasRaw(void)
{
    extern __PST__g__34 MotAgSwCal_Pim_MotAg6SinMeasRaw;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 50; _main_gen_tmp_6_0++)
            {
                /* base type */
                MotAgSwCal_Pim_MotAg6SinMeasRaw[_main_gen_tmp_6_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg6SinMeasRawCumv(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg6SinMeasRawCumv;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg6SinMeasRawCumv = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_MotAg6SinMeasRawPrev(void)
{
    extern __PST__UINT16 MotAgSwCal_Pim_MotAg6SinMeasRawPrev;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_MotAg6SinMeasRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_PosnIdx(void)
{
    extern __PST__UINT32 MotAgSwCal_Pim_PosnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_PosnIdx = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_SampleIdx(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_SampleIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_SampleIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_SwCalCycTi(void)
{
    extern __PST__UINT32 MotAgSwCal_Pim_SwCalCycTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_SwCalCycTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_SwCalMotModlnIdx(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Pim_SwCalMotModlnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_SwCalMotModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Pim_SwCalStepDir(void)
{
    extern __PST__UINT8 MotAgSwCal_Pim_SwCalStepDir;
    
    /* initialization with random value */
    {
        MotAgSwCal_Pim_SwCalStepDir = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5Sin(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg5Sin;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5Sin = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5Cos(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg5Cos;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5Cos = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg6Sin(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg6Sin;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg6Sin = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg6Cos(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg6Cos;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg6Cos = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg2Sin(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg2Sin;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg2Sin = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg2Cos(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotAg2Cos;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg2Cos = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlVehSpd(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlVehSpd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlVehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMfgEnaSt(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMfgEnaSt;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMfgEnaSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5SinAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotAg5SinAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5SinAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5CosAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotAg5CosAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg5CosAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg6SinAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotAg6SinAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg6SinAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg6CosAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotAg6CosAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg6CosAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg2SinAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotAg2SinAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg2SinAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg2CosAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotAg2CosAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg2CosAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Srv_SwCalStsCallBack_SnsrData(void)
{
    extern __PST__g__25 MotAgSwCal_Srv_SwCalStsCallBack_SnsrData;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 12; _main_gen_tmp_7_0++)
            {
                /* base type */
                MotAgSwCal_Srv_SwCalStsCallBack_SnsrData[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_BoostModlnIdx(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Cli_SwCalGetPrm_BoostModlnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_BoostModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_HldModlnIdx(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Cli_SwCalGetPrm_HldModlnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_HldModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_CoolDwnModlnIdx(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Cli_SwCalGetPrm_CoolDwnModlnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_CoolDwnModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_Ramp1Ti(void)
{
    extern __PST__UINT8 MotAgSwCal_Cli_SwCalGetPrm_Ramp1Ti;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_Ramp1Ti = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_Ramp2Ti(void)
{
    extern __PST__UINT8 MotAgSwCal_Cli_SwCalGetPrm_Ramp2Ti;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_Ramp2Ti = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_Ramp3Ti(void)
{
    extern __PST__UINT8 MotAgSwCal_Cli_SwCalGetPrm_Ramp3Ti;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_Ramp3Ti = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_BoostTi(void)
{
    extern __PST__UINT8 MotAgSwCal_Cli_SwCalGetPrm_BoostTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_BoostTi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_HldTi(void)
{
    extern __PST__UINT16 MotAgSwCal_Cli_SwCalGetPrm_HldTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_HldTi = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_CoolDwnTi(void)
{
    extern __PST__UINT16 MotAgSwCal_Cli_SwCalGetPrm_CoolDwnTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_CoolDwnTi = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_PosnStepSize(void)
{
    extern __PST__UINT16 MotAgSwCal_Cli_SwCalGetPrm_PosnStepSize;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_PosnStepSize = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_ElecRevCnt(void)
{
    extern __PST__UINT8 MotAgSwCal_Cli_SwCalGetPrm_ElecRevCnt;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalGetPrm_ElecRevCnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_BoostModlnIdx(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Cli_SwCalSetPrm_BoostModlnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_BoostModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_HldModlnIdx(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Cli_SwCalSetPrm_HldModlnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_HldModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_CoolDwnModlnIdx(void)
{
    extern __PST__FLOAT32 MotAgSwCal_Cli_SwCalSetPrm_CoolDwnModlnIdx;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_CoolDwnModlnIdx = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_Ramp1Ti(void)
{
    extern __PST__UINT8 MotAgSwCal_Cli_SwCalSetPrm_Ramp1Ti;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_Ramp1Ti = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_Ramp2Ti(void)
{
    extern __PST__UINT8 MotAgSwCal_Cli_SwCalSetPrm_Ramp2Ti;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_Ramp2Ti = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_Ramp3Ti(void)
{
    extern __PST__UINT8 MotAgSwCal_Cli_SwCalSetPrm_Ramp3Ti;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_Ramp3Ti = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_BoostTi(void)
{
    extern __PST__UINT8 MotAgSwCal_Cli_SwCalSetPrm_BoostTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_BoostTi = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_HldTi(void)
{
    extern __PST__UINT16 MotAgSwCal_Cli_SwCalSetPrm_HldTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_HldTi = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_CoolDwnTi(void)
{
    extern __PST__UINT16 MotAgSwCal_Cli_SwCalSetPrm_CoolDwnTi;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_CoolDwnTi = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_PosnStepSize(void)
{
    extern __PST__UINT16 MotAgSwCal_Cli_SwCalSetPrm_PosnStepSize;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_PosnStepSize = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_ElecRevCnt(void)
{
    extern __PST__UINT8 MotAgSwCal_Cli_SwCalSetPrm_ElecRevCnt;
    
    /* initialization with random value */
    {
        MotAgSwCal_Cli_SwCalSetPrm_ElecRevCnt = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable MotAgSwCal_Pim_BoostModlnIdx */
    _main_gen_init_sym_MotAgSwCal_Pim_BoostModlnIdx();
    
    /* init for variable MotAgSwCal_Pim_BoostSlew */
    _main_gen_init_sym_MotAgSwCal_Pim_BoostSlew();
    
    /* init for variable MotAgSwCal_Pim_BoostTi */
    _main_gen_init_sym_MotAgSwCal_Pim_BoostTi();
    
    /* init for variable MotAgSwCal_Pim_BoostTiOut */
    _main_gen_init_sym_MotAgSwCal_Pim_BoostTiOut();
    
    /* init for variable MotAgSwCal_Pim_CoolDwnModlnIdx */
    _main_gen_init_sym_MotAgSwCal_Pim_CoolDwnModlnIdx();
    
    /* init for variable MotAgSwCal_Pim_CoolDwnSlew */
    _main_gen_init_sym_MotAgSwCal_Pim_CoolDwnSlew();
    
    /* init for variable MotAgSwCal_Pim_CoolDwnTi */
    _main_gen_init_sym_MotAgSwCal_Pim_CoolDwnTi();
    
    /* init for variable MotAgSwCal_Pim_CoolDwnTiOut */
    _main_gen_init_sym_MotAgSwCal_Pim_CoolDwnTiOut();
    
    /* init for variable MotAgSwCal_Pim_ElecRevCnt */
    _main_gen_init_sym_MotAgSwCal_Pim_ElecRevCnt();
    
    /* init for variable MotAgSwCal_Pim_HldModlnIdx */
    _main_gen_init_sym_MotAgSwCal_Pim_HldModlnIdx();
    
    /* init for variable MotAgSwCal_Pim_HldSlew */
    _main_gen_init_sym_MotAgSwCal_Pim_HldSlew();
    
    /* init for variable MotAgSwCal_Pim_HldTi */
    _main_gen_init_sym_MotAgSwCal_Pim_HldTi();
    
    /* init for variable MotAgSwCal_Pim_HldTiOut */
    _main_gen_init_sym_MotAgSwCal_Pim_HldTiOut();
    
    /* init for variable MotAgSwCal_Pim_MotAg2CosMeasAvrg */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg2CosMeasAvrg();
    
    /* init for variable MotAgSwCal_Pim_MotAg2SinMeasAvrg */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg2SinMeasAvrg();
    
    /* init for variable MotAgSwCal_Pim_MotAg5CosMeasAvrg */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg5CosMeasAvrg();
    
    /* init for variable MotAgSwCal_Pim_MotAg5SinMeasAvrg */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg5SinMeasAvrg();
    
    /* init for variable MotAgSwCal_Pim_MotAg6CosMeasAvrg */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg6CosMeasAvrg();
    
    /* init for variable MotAgSwCal_Pim_MotAg6SinMeasAvrg */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg6SinMeasAvrg();
    
    /* init for variable MotAgSwCal_Pim_PosnStepSize */
    _main_gen_init_sym_MotAgSwCal_Pim_PosnStepSize();
    
    /* init for variable MotAgSwCal_Pim_Ramp1Ti */
    _main_gen_init_sym_MotAgSwCal_Pim_Ramp1Ti();
    
    /* init for variable MotAgSwCal_Pim_Ramp2Ti */
    _main_gen_init_sym_MotAgSwCal_Pim_Ramp2Ti();
    
    /* init for variable MotAgSwCal_Pim_Ramp3Ti */
    _main_gen_init_sym_MotAgSwCal_Pim_Ramp3Ti();
    
    /* init for variable MotAgSwCal_Pim_SamplePosnIdx */
    _main_gen_init_sym_MotAgSwCal_Pim_SamplePosnIdx();
    
    /* init for variable MotAgSwCal_Pim_SampleRdyFlg */
    _main_gen_init_sym_MotAgSwCal_Pim_SampleRdyFlg();
    
    /* init for variable MotAgSwCal_Pim_SampleStopTi */
    _main_gen_init_sym_MotAgSwCal_Pim_SampleStopTi();
    
    /* init for variable MotAgSwCal_Pim_SampleStrtTi */
    _main_gen_init_sym_MotAgSwCal_Pim_SampleStrtTi();
    
    /* init for variable MotAgSwCal_Pim_SwCalEna */
    _main_gen_init_sym_MotAgSwCal_Pim_SwCalEna();
    
    /* init for variable MotAgSwCal_Cal_MotAgSwCalVehSpdThd */
    _main_gen_init_sym_MotAgSwCal_Cal_MotAgSwCalVehSpdThd();
    
    /* init for variable MotAgSwCal_Pim_MotAg2CosAdcFaildCntr */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg2CosAdcFaildCntr();
    
    /* init for variable MotAgSwCal_Pim_MotAg2CosMeasRaw */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg2CosMeasRaw();
    
    /* init for variable MotAgSwCal_Pim_MotAg2CosMeasRawCumv */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg2CosMeasRawCumv();
    
    /* init for variable MotAgSwCal_Pim_MotAg2CosMeasRawPrev */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg2CosMeasRawPrev();
    
    /* init for variable MotAgSwCal_Pim_MotAg2SinAdcFaildCntr */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg2SinAdcFaildCntr();
    
    /* init for variable MotAgSwCal_Pim_MotAg2SinMeasRaw */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg2SinMeasRaw();
    
    /* init for variable MotAgSwCal_Pim_MotAg2SinMeasRawCumv */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg2SinMeasRawCumv();
    
    /* init for variable MotAgSwCal_Pim_MotAg2SinMeasRawPrev */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg2SinMeasRawPrev();
    
    /* init for variable MotAgSwCal_Pim_MotAg5CosAdcFaildCntr */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg5CosAdcFaildCntr();
    
    /* init for variable MotAgSwCal_Pim_MotAg5CosMeasRaw */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg5CosMeasRaw();
    
    /* init for variable MotAgSwCal_Pim_MotAg5CosMeasRawCumv */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg5CosMeasRawCumv();
    
    /* init for variable MotAgSwCal_Pim_MotAg5CosMeasRawPrev */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg5CosMeasRawPrev();
    
    /* init for variable MotAgSwCal_Pim_MotAg5SinAdcFaildCntr */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg5SinAdcFaildCntr();
    
    /* init for variable MotAgSwCal_Pim_MotAg5SinMeasRaw */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg5SinMeasRaw();
    
    /* init for variable MotAgSwCal_Pim_MotAg5SinMeasRawCumv */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg5SinMeasRawCumv();
    
    /* init for variable MotAgSwCal_Pim_MotAg5SinMeasRawPrev */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg5SinMeasRawPrev();
    
    /* init for variable MotAgSwCal_Pim_MotAg6CosAdcFaildCntr */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg6CosAdcFaildCntr();
    
    /* init for variable MotAgSwCal_Pim_MotAg6CosMeasRaw */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg6CosMeasRaw();
    
    /* init for variable MotAgSwCal_Pim_MotAg6CosMeasRawCumv */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg6CosMeasRawCumv();
    
    /* init for variable MotAgSwCal_Pim_MotAg6CosMeasRawPrev */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg6CosMeasRawPrev();
    
    /* init for variable MotAgSwCal_Pim_MotAg6SinAdcFaildCntr */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg6SinAdcFaildCntr();
    
    /* init for variable MotAgSwCal_Pim_MotAg6SinMeasRaw */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg6SinMeasRaw();
    
    /* init for variable MotAgSwCal_Pim_MotAg6SinMeasRawCumv */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg6SinMeasRawCumv();
    
    /* init for variable MotAgSwCal_Pim_MotAg6SinMeasRawPrev */
    _main_gen_init_sym_MotAgSwCal_Pim_MotAg6SinMeasRawPrev();
    
    /* init for variable MotAgSwCal_Pim_PosnIdx */
    _main_gen_init_sym_MotAgSwCal_Pim_PosnIdx();
    
    /* init for variable MotAgSwCal_Pim_SampleIdx */
    _main_gen_init_sym_MotAgSwCal_Pim_SampleIdx();
    
    /* init for variable MotAgSwCal_Pim_SwCalCycTi */
    _main_gen_init_sym_MotAgSwCal_Pim_SwCalCycTi();
    
    /* init for variable MotAgSwCal_Pim_SwCalMotModlnIdx */
    _main_gen_init_sym_MotAgSwCal_Pim_SwCalMotModlnIdx();
    
    /* init for variable MotAgSwCal_Pim_SwCalStepDir */
    _main_gen_init_sym_MotAgSwCal_Pim_SwCalStepDir();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5Sin */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5Sin();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5Cos */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5Cos();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg6Sin */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg6Sin();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg6Cos */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg6Cos();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg2Sin */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg2Sin();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg2Cos */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg2Cos();
    
    /* init for variable MOTCTRLMGR_MotCtrlVehSpd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlVehSpd();
    
    /* init for variable MOTCTRLMGR_MotCtrlMfgEnaSt */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMfgEnaSt();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5SinAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5SinAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg5CosAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg5CosAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg6SinAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg6SinAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg6CosAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg6CosAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg2SinAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg2SinAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg2CosAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg2CosAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlSwCalEna : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlSwCalModlnIdx : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlSwCalPosnIdx : useless (never read) */

    /* init for variable MotAgSwCal_Srv_SwCalStsCallBack_ElecRev : useless (never read) */

    /* init for variable MotAgSwCal_Srv_SwCalStsCallBack_PosIdx : useless (never read) */

    /* init for variable MotAgSwCal_Srv_SwCalStsCallBack_SnsrData */
    _main_gen_init_sym_MotAgSwCal_Srv_SwCalStsCallBack_SnsrData();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_BoostModlnIdx */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_BoostModlnIdx();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_HldModlnIdx */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_HldModlnIdx();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_CoolDwnModlnIdx */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_CoolDwnModlnIdx();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_Ramp1Ti */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_Ramp1Ti();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_Ramp2Ti */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_Ramp2Ti();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_Ramp3Ti */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_Ramp3Ti();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_BoostTi */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_BoostTi();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_HldTi */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_HldTi();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_CoolDwnTi */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_CoolDwnTi();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_PosnStepSize */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_PosnStepSize();
    
    /* init for variable MotAgSwCal_Cli_SwCalGetPrm_ElecRevCnt */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalGetPrm_ElecRevCnt();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_BoostModlnIdx */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_BoostModlnIdx();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_HldModlnIdx */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_HldModlnIdx();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_CoolDwnModlnIdx */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_CoolDwnModlnIdx();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_Ramp1Ti */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_Ramp1Ti();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_Ramp2Ti */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_Ramp2Ti();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_Ramp3Ti */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_Ramp3Ti();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_BoostTi */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_BoostTi();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_HldTi */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_HldTi();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_CoolDwnTi */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_CoolDwnTi();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_PosnStepSize */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_PosnStepSize();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_ElecRevCnt */
    _main_gen_init_sym_MotAgSwCal_Cli_SwCalSetPrm_ElecRevCnt();
    
    /* init for variable MotAgSwCal_Cli_SwCalSetPrm_Return : useless (never read) */

}
