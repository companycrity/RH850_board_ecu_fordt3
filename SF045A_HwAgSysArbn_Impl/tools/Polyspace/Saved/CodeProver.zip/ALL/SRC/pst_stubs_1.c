#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__32 _main_gen_init_g32(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__31 _main_gen_init_g31(void);

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__29 _main_gen_init_g29(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__29 _main_gen_init_g29(void)
{
    __PST__g__29 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__31 _main_gen_init_g31(void)
{
    __PST__g__31 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

struct __PST__g__32 _main_gen_init_g32(void)
{
    static struct __PST__g__32 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_HwAgSysArbn_Ip_CmplncErrPinionToHw(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Ip_CmplncErrPinionToHw;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Ip_CmplncErrPinionToHw = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Ip_HwAg(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Ip_HwAg;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Ip_HwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Ip_HwAgCorrd(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Ip_HwAgCorrd;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Ip_HwAgCorrd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Ip_HwAgIdptSig(void)
{
    extern __PST__UINT8 HwAgSysArbn_Ip_HwAgIdptSig;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Ip_HwAgIdptSig = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Ip_HwAgSnsrls(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Ip_HwAgSnsrls;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Ip_HwAgSnsrls = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Ip_HwAgSnsrlsConf(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Ip_HwAgSnsrlsConf;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Ip_HwAgSnsrlsConf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Ip_HwTq(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Ip_HwTq;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Ip_MotVelCrf(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Ip_MotVelCrf;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Ip_MotVelCrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Ip_MotVelVld(void)
{
    extern __PST__UINT8 HwAgSysArbn_Ip_MotVelVld;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Ip_MotVelVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgConf1Snsr(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnHwAgConf1Snsr;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgConf1Snsr = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgConf2Snsr(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnHwAgConf2Snsr;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgConf2Snsr = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgConfNoSnsr(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnHwAgConfNoSnsr;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgConfNoSnsr = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrdCorrlnThd(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrdCorrlnThd;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrdCorrlnThd = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnFailDebStep(void)
{
    extern __PST__g__29 HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnFailDebStep;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnFailDebStep = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnPassDebStep(void)
{
    extern __PST__g__29 HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnPassDebStep;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnPassDebStep = _main_gen_init_g29();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnRng(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnRng;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnRng = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgIdptSigLim(void)
{
    extern __PST__g__30 HwAgSysArbn_Cal_HwAgSysArbnHwAgIdptSigLim;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgIdptSigLim = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgSlewRate(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnHwAgSlewRate;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgSlewRate = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgSnsrlsCorrlnThd(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnHwAgSnsrlsCorrlnThd;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgSnsrlsCorrlnThd = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgSnsrlsKineThd(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnHwAgSnsrlsKineThd;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgSnsrlsKineThd = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgToMotAgCorrlnElpdTiLim(void)
{
    extern __PST__g__31 HwAgSysArbn_Cal_HwAgSysArbnHwAgToMotAgCorrlnElpdTiLim;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnHwAgToMotAgCorrlnElpdTiLim = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnSerlComHwAgCorrdConf(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnSerlComHwAgCorrdConf;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnSerlComHwAgCorrdConf = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnSerlComHwAgSnsrlsConf(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnSerlComHwAgSnsrlsConf;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnSerlComHwAgSnsrlsConf = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnSlewRateTmr(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnSlewRateTmr;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnSlewRateTmr = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnTqSnsrVelFilFrq(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_HwAgSysArbnTqSnsrVelFilFrq;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_HwAgSysArbnTqSnsrVelFilFrq = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_SysGlbPrmSysKineRat(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_SysGlbPrmSysKineRat;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_SysGlbPrmSysKineRat = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Cal_SysGlbPrmTorsBarStfn(void)
{
    extern __PST__g__28 HwAgSysArbn_Cal_SysGlbPrmTorsBarStfn;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Cal_SysGlbPrmTorsBarStfn = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_HwAgKineFlt(void)
{
    extern __PST__UINT8 HwAgSysArbn_Pim_HwAgKineFlt;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_HwAgKineFlt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_HwAgLtch(void)
{
    extern __PST__UINT8 HwAgSysArbn_Pim_HwAgLtch;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_HwAgLtch = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_HwAgPrev(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Pim_HwAgPrev;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_HwAgPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_HwAgToMotAgCorrln(void)
{
    extern __PST__UINT8 HwAgSysArbn_Pim_HwAgToMotAgCorrln;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_HwAgToMotAgCorrln = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_HwAgToMotAgCorrlnDurnRefTmr(void)
{
    extern __PST__UINT32 HwAgSysArbn_Pim_HwAgToMotAgCorrlnDurnRefTmr;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_HwAgToMotAgCorrlnDurnRefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_PrevHwAgNotCorrd(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Pim_PrevHwAgNotCorrd;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_PrevHwAgNotCorrd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_PrevPinionAgConf(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Pim_PrevPinionAgConf;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_PrevPinionAgConf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_PrevSeldHwAg(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Pim_PrevSeldHwAg;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_PrevSeldHwAg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_PrevSrcSeln(void)
{
    extern __PST__SINT8 HwAgSysArbn_Pim_PrevSrcSeln;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_PrevSrcSeln = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_SeldHwAgConf(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Pim_SeldHwAgConf;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_SeldHwAgConf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_SlewElpdRefTmr(void)
{
    extern __PST__UINT32 HwAgSysArbn_Pim_SlewElpdRefTmr;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_SlewElpdRefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_SlewSts(void)
{
    extern __PST__UINT8 HwAgSysArbn_Pim_SlewSts;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_SlewSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_TqSnsrAgPrev(void)
{
    extern __PST__FLOAT32 HwAgSysArbn_Pim_TqSnsrAgPrev;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_TqSnsrAgPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Pim_TqSnsrVelFil(void)
{
    extern struct __PST__g__32 HwAgSysArbn_Pim_TqSnsrVelFil;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Pim_TqSnsrVelFil = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 HwAgSysArbn_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 HwAgSysArbn_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 HwAgSysArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 HwAgSysArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_HwAgSysArbn_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 HwAgSysArbn_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        HwAgSysArbn_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable HwAgSysArbn_Ip_CmplncErrPinionToHw */
    _main_gen_init_sym_HwAgSysArbn_Ip_CmplncErrPinionToHw();
    
    /* init for variable HwAgSysArbn_Ip_HwAg */
    _main_gen_init_sym_HwAgSysArbn_Ip_HwAg();
    
    /* init for variable HwAgSysArbn_Ip_HwAgCorrd */
    _main_gen_init_sym_HwAgSysArbn_Ip_HwAgCorrd();
    
    /* init for variable HwAgSysArbn_Ip_HwAgIdptSig */
    _main_gen_init_sym_HwAgSysArbn_Ip_HwAgIdptSig();
    
    /* init for variable HwAgSysArbn_Ip_HwAgSnsrls */
    _main_gen_init_sym_HwAgSysArbn_Ip_HwAgSnsrls();
    
    /* init for variable HwAgSysArbn_Ip_HwAgSnsrlsConf */
    _main_gen_init_sym_HwAgSysArbn_Ip_HwAgSnsrlsConf();
    
    /* init for variable HwAgSysArbn_Ip_HwTq */
    _main_gen_init_sym_HwAgSysArbn_Ip_HwTq();
    
    /* init for variable HwAgSysArbn_Ip_MotVelCrf */
    _main_gen_init_sym_HwAgSysArbn_Ip_MotVelCrf();
    
    /* init for variable HwAgSysArbn_Ip_MotVelVld */
    _main_gen_init_sym_HwAgSysArbn_Ip_MotVelVld();
    
    /* init for variable HwAgSysArbn_Op_HwAgFinal : useless (never read) */

    /* init for variable HwAgSysArbn_Op_HwAgNotCorrd : useless (never read) */

    /* init for variable HwAgSysArbn_Op_HwAgToSerlCom : useless (never read) */

    /* init for variable HwAgSysArbn_Op_HwAgVldToSerlCom : useless (never read) */

    /* init for variable HwAgSysArbn_Op_HwVel : useless (never read) */

    /* init for variable HwAgSysArbn_Op_HwVelToSerlCom : useless (never read) */

    /* init for variable HwAgSysArbn_Op_PinionAg : useless (never read) */

    /* init for variable HwAgSysArbn_Op_PinionAgConf : useless (never read) */

    /* init for variable HwAgSysArbn_Op_PinionVel : useless (never read) */

    /* init for variable HwAgSysArbn_Op_PinionVelConf : useless (never read) */

    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgConf1Snsr */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgConf1Snsr();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgConf2Snsr */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgConf2Snsr();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgConfNoSnsr */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgConfNoSnsr();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrdCorrlnThd */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrdCorrlnThd();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnFailDebStep */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnFailDebStep();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnPassDebStep */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnPassDebStep();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnRng */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgCorrlnRng();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgIdptSigLim */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgIdptSigLim();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgSlewRate */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgSlewRate();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgSnsrlsCorrlnThd */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgSnsrlsCorrlnThd();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgSnsrlsKineThd */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgSnsrlsKineThd();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnHwAgToMotAgCorrlnElpdTiLim */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnHwAgToMotAgCorrlnElpdTiLim();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnSerlComHwAgCorrdConf */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnSerlComHwAgCorrdConf();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnSerlComHwAgSnsrlsConf */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnSerlComHwAgSnsrlsConf();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnSlewRateTmr */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnSlewRateTmr();
    
    /* init for variable HwAgSysArbn_Cal_HwAgSysArbnTqSnsrVelFilFrq */
    _main_gen_init_sym_HwAgSysArbn_Cal_HwAgSysArbnTqSnsrVelFilFrq();
    
    /* init for variable HwAgSysArbn_Cal_SysGlbPrmSysKineRat */
    _main_gen_init_sym_HwAgSysArbn_Cal_SysGlbPrmSysKineRat();
    
    /* init for variable HwAgSysArbn_Cal_SysGlbPrmTorsBarStfn */
    _main_gen_init_sym_HwAgSysArbn_Cal_SysGlbPrmTorsBarStfn();
    
    /* init for variable HwAgSysArbn_Pim_HwAgKineFlt */
    _main_gen_init_sym_HwAgSysArbn_Pim_HwAgKineFlt();
    
    /* init for variable HwAgSysArbn_Pim_HwAgLtch */
    _main_gen_init_sym_HwAgSysArbn_Pim_HwAgLtch();
    
    /* init for variable HwAgSysArbn_Pim_HwAgPrev */
    _main_gen_init_sym_HwAgSysArbn_Pim_HwAgPrev();
    
    /* init for variable HwAgSysArbn_Pim_HwAgToMotAgCorrln */
    _main_gen_init_sym_HwAgSysArbn_Pim_HwAgToMotAgCorrln();
    
    /* init for variable HwAgSysArbn_Pim_HwAgToMotAgCorrlnDurnRefTmr */
    _main_gen_init_sym_HwAgSysArbn_Pim_HwAgToMotAgCorrlnDurnRefTmr();
    
    /* init for variable HwAgSysArbn_Pim_PrevHwAgNotCorrd */
    _main_gen_init_sym_HwAgSysArbn_Pim_PrevHwAgNotCorrd();
    
    /* init for variable HwAgSysArbn_Pim_PrevPinionAgConf */
    _main_gen_init_sym_HwAgSysArbn_Pim_PrevPinionAgConf();
    
    /* init for variable HwAgSysArbn_Pim_PrevSeldHwAg */
    _main_gen_init_sym_HwAgSysArbn_Pim_PrevSeldHwAg();
    
    /* init for variable HwAgSysArbn_Pim_PrevSrcSeln */
    _main_gen_init_sym_HwAgSysArbn_Pim_PrevSrcSeln();
    
    /* init for variable HwAgSysArbn_Pim_SeldHwAgConf */
    _main_gen_init_sym_HwAgSysArbn_Pim_SeldHwAgConf();
    
    /* init for variable HwAgSysArbn_Pim_SlewElpdRefTmr */
    _main_gen_init_sym_HwAgSysArbn_Pim_SlewElpdRefTmr();
    
    /* init for variable HwAgSysArbn_Pim_SlewSts */
    _main_gen_init_sym_HwAgSysArbn_Pim_SlewSts();
    
    /* init for variable HwAgSysArbn_Pim_TqSnsrAgPrev */
    _main_gen_init_sym_HwAgSysArbn_Pim_TqSnsrAgPrev();
    
    /* init for variable HwAgSysArbn_Pim_TqSnsrVelFil */
    _main_gen_init_sym_HwAgSysArbn_Pim_TqSnsrVelFil();
    
    /* init for variable HwAgSysArbn_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable HwAgSysArbn_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_HwAgSysArbn_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable HwAgSysArbn_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_HwAgSysArbn_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable HwAgSysArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_HwAgSysArbn_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable HwAgSysArbn_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable HwAgSysArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_HwAgSysArbn_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable HwAgSysArbn_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable HwAgSysArbn_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable HwAgSysArbn_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable HwAgSysArbn_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable HwAgSysArbn_Srv_SetNtcSts_Return */
    _main_gen_init_sym_HwAgSysArbn_Srv_SetNtcSts_Return();
    
}
