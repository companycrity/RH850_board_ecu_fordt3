#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 FordMsg41EBusHiSpd_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Ip_FordCanDtcInhb(void)
{
    extern __PST__UINT8 FordMsg41EBusHiSpd_Ip_FordCanDtcInhb;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Ip_FordCanDtcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Ip_FordEpsLifeCycMod(void)
{
    extern __PST__UINT8 FordMsg41EBusHiSpd_Ip_FordEpsLifeCycMod;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Ip_FordEpsLifeCycMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Ip_FordSelDrvModEnad(void)
{
    extern __PST__UINT8 FordMsg41EBusHiSpd_Ip_FordSelDrvModEnad;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Ip_FordSelDrvModEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldMissFaildThd(void)
{
    extern __PST__g__32 FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldMissFaildThd;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldMissFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldSigFaildThd(void)
{
    extern __PST__g__32 FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldSigFaildThd;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldSigFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldSigPassdThd(void)
{
    extern __PST__g__32 FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldSigPassdThd;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldSigPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdInvldMsgFaildThd(void)
{
    extern __PST__g__32 FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdInvldMsgFaildThd;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdInvldMsgFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdInvldMsgPassdThd(void)
{
    extern __PST__g__32 FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdInvldMsgPassdThd;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdInvldMsgPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdMissMsgFaildThd(void)
{
    extern __PST__g__32 FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdMissMsgFaildThd;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdMissMsgFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdMissMsgPassdThd(void)
{
    extern __PST__g__32 FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdMissMsgPassdThd;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdMissMsgPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_ClrDiagcFlgProxyPrev(void)
{
    extern __PST__UINT8 FordMsg41EBusHiSpd_Pim_ClrDiagcFlgProxyPrev;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_ClrDiagcFlgProxyPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FirstTranVldFlg(void)
{
    extern __PST__UINT8 FordMsg41EBusHiSpd_Pim_FirstTranVldFlg;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_FirstTranVldFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehMsg41EMiss(void)
{
    extern __PST__UINT8 FordMsg41EBusHiSpd_Pim_FordVehMsg41EMiss;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_FordVehMsg41EMiss = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehPenSelDrvModPrev(void)
{
    extern __PST__UINT8 FordMsg41EBusHiSpd_Pim_FordVehPenSelDrvModPrev;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_FordVehPenSelDrvModPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldPrev(void)
{
    extern __PST__UINT8 FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldPrev;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_InvldMsgFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg41EBusHiSpd_Pim_InvldMsgFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_InvldMsgFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_InvldMsgPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg41EBusHiSpd_Pim_InvldMsgPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_InvldMsgPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_MissMsgFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg41EBusHiSpd_Pim_MissMsgFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_MissMsgFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_MissMsgPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg41EBusHiSpd_Pim_MissMsgPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Pim_MissMsgPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 FordMsg41EBusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 FordMsg41EBusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg41EBusHiSpd_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 FordMsg41EBusHiSpd_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        FordMsg41EBusHiSpd_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FordMsg41EBusHiSpd_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Ip_ClrDiagcFlgProxy();
    
    /* init for variable FordMsg41EBusHiSpd_Ip_FordCanDtcInhb */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Ip_FordCanDtcInhb();
    
    /* init for variable FordMsg41EBusHiSpd_Ip_FordEpsLifeCycMod */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Ip_FordEpsLifeCycMod();
    
    /* init for variable FordMsg41EBusHiSpd_Ip_FordSelDrvModEnad */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Ip_FordSelDrvModEnad();
    
    /* init for variable FordMsg41EBusHiSpd_Op_FordVehSelDrvModChassisVld : useless (never read) */

    /* init for variable FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldMissFaildThd */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldMissFaildThd();
    
    /* init for variable FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldSigFaildThd */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldSigFaildThd();
    
    /* init for variable FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldSigPassdThd */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdChassisVldSigPassdThd();
    
    /* init for variable FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdInvldMsgFaildThd */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdInvldMsgFaildThd();
    
    /* init for variable FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdInvldMsgPassdThd */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdInvldMsgPassdThd();
    
    /* init for variable FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdMissMsgFaildThd */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdMissMsgFaildThd();
    
    /* init for variable FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdMissMsgPassdThd */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Cal_FordMsg41EBusHiSpdMissMsgPassdThd();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_ClrDiagcFlgProxyPrev */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_ClrDiagcFlgProxyPrev();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_FirstTranVldFlg */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FirstTranVldFlg();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_FordVehMsg41EMiss */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehMsg41EMiss();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_FordVehPenSelDrvModPrev */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehPenSelDrvModPrev();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldFaildRefTi */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldFaildRefTi();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldMissRefTi */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldMissRefTi();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldPassdRefTi */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldPassdRefTi();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldPrev */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_FordVehSelDrvModChassisVldPrev();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_InvldMsgFaildRefTi */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_InvldMsgFaildRefTi();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_InvldMsgPassdRefTi */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_InvldMsgPassdRefTi();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_MissMsgFaildRefTi */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_MissMsgFaildRefTi();
    
    /* init for variable FordMsg41EBusHiSpd_Pim_MissMsgPassdRefTi */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Pim_MissMsgPassdRefTi();
    
    /* init for variable FordMsg41EBusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable FordMsg41EBusHiSpd_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable FordMsg41EBusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable FordMsg41EBusHiSpd_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable FordMsg41EBusHiSpd_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable FordMsg41EBusHiSpd_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable FordMsg41EBusHiSpd_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable FordMsg41EBusHiSpd_Srv_SetNtcSts_Return */
    _main_gen_init_sym_FordMsg41EBusHiSpd_Srv_SetNtcSts_Return();
    
}
