#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__g__25 _main_gen_init_g25(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_PwrDiscnct_Ip_BattVltg(void)
{
    extern __PST__FLOAT32 PwrDiscnct_Ip_BattVltg;
    
    /* initialization with random value */
    {
        PwrDiscnct_Ip_BattVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Ip_BattVltgAdcFaild(void)
{
    extern __PST__UINT8 PwrDiscnct_Ip_BattVltgAdcFaild;
    
    /* initialization with random value */
    {
        PwrDiscnct_Ip_BattVltgAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Ip_BattVltgSwd1(void)
{
    extern __PST__FLOAT32 PwrDiscnct_Ip_BattVltgSwd1;
    
    /* initialization with random value */
    {
        PwrDiscnct_Ip_BattVltgSwd1 = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Ip_ChrgPmpDiag(void)
{
    extern __PST__FLOAT32 PwrDiscnct_Ip_ChrgPmpDiag;
    
    /* initialization with random value */
    {
        PwrDiscnct_Ip_ChrgPmpDiag = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Ip_ChrgPmpDiagAdcFaild(void)
{
    extern __PST__UINT8 PwrDiscnct_Ip_ChrgPmpDiagAdcFaild;
    
    /* initialization with random value */
    {
        PwrDiscnct_Ip_ChrgPmpDiagAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Ip_MotVelMrf(void)
{
    extern __PST__FLOAT32 PwrDiscnct_Ip_MotVelMrf;
    
    /* initialization with random value */
    {
        PwrDiscnct_Ip_MotVelMrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Ip_PwrDiscnctSwtDiag(void)
{
    extern __PST__FLOAT32 PwrDiscnct_Ip_PwrDiscnctSwtDiag;
    
    /* initialization with random value */
    {
        PwrDiscnct_Ip_PwrDiscnctSwtDiag = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Ip_StrtUpSt(void)
{
    extern __PST__UINT8 PwrDiscnct_Ip_StrtUpSt;
    
    /* initialization with random value */
    {
        PwrDiscnct_Ip_StrtUpSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Ip_SysSt(void)
{
    extern __PST__UINT8 PwrDiscnct_Ip_SysSt;
    
    /* initialization with random value */
    {
        PwrDiscnct_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctBattVltgExtdNormThd(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctBattVltgExtdNormThd;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctBattVltgExtdNormThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctBattVltgNonExtdThd(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctBattVltgNonExtdThd;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctBattVltgNonExtdThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaExtOper(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaExtOper;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaExtOper = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaNonOper(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaNonOper;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaNonOper = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaNormOper(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaNormOper;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaNormOper = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctChrgPmpDiagOpenThd(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctChrgPmpDiagOpenThd;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctChrgPmpDiagOpenThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctDeltaSwtClsThd(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctDeltaSwtClsThd;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctDeltaSwtClsThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctDeltaVltgClsThd(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctDeltaVltgClsThd;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctDeltaVltgClsThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctDeltaVltgOpenThd(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctDeltaVltgOpenThd;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctDeltaVltgOpenThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctFltFailStep(void)
{
    extern __PST__g__26 PwrDiscnct_Cal_PwrDiscnctFltFailStep;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctFltFailStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctFltPassStep(void)
{
    extern __PST__g__26 PwrDiscnct_Cal_PwrDiscnctFltPassStep;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctFltPassStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctFltThd(void)
{
    extern __PST__g__26 PwrDiscnct_Cal_PwrDiscnctFltThd;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctFltThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctMtrMtnThd(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctMtrMtnThd;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctMtrMtnThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctPwrDiscnctRtFltFailStep(void)
{
    extern __PST__g__26 PwrDiscnct_Cal_PwrDiscnctPwrDiscnctRtFltFailStep;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctPwrDiscnctRtFltFailStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctPwrDiscnctRtFltPassStep(void)
{
    extern __PST__g__26 PwrDiscnct_Cal_PwrDiscnctPwrDiscnctRtFltPassStep;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctPwrDiscnctRtFltPassStep = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctSwtDiagOpenThd(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_PwrDiscnctSwtDiagOpenThd;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_PwrDiscnctSwtDiagOpenThd = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Cal_BattVltgSwdMax(void)
{
    extern __PST__g__25 PwrDiscnct_Cal_BattVltgSwdMax;
    
    /* initialization with random value */
    {
        PwrDiscnct_Cal_BattVltgSwdMax = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Pim_FirstRunCmpl(void)
{
    extern __PST__UINT8 PwrDiscnct_Pim_FirstRunCmpl;
    
    /* initialization with random value */
    {
        PwrDiscnct_Pim_FirstRunCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Pim_Ntc042PrmByte(void)
{
    extern __PST__UINT8 PwrDiscnct_Pim_Ntc042PrmByte;
    
    /* initialization with random value */
    {
        PwrDiscnct_Pim_Ntc042PrmByte = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Pim_PwrDiscnctClsdSts(void)
{
    extern __PST__UINT8 PwrDiscnct_Pim_PwrDiscnctClsdSts;
    
    /* initialization with random value */
    {
        PwrDiscnct_Pim_PwrDiscnctClsdSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Pim_PwrDiscnctFltAtInitErrAcc(void)
{
    extern __PST__UINT16 PwrDiscnct_Pim_PwrDiscnctFltAtInitErrAcc;
    
    /* initialization with random value */
    {
        PwrDiscnct_Pim_PwrDiscnctFltAtInitErrAcc = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Pim_PwrDiscnctSt(void)
{
    extern __PST__UINT8 PwrDiscnct_Pim_PwrDiscnctSt;
    
    /* initialization with random value */
    {
        PwrDiscnct_Pim_PwrDiscnctSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Pim_PwrDiscnctTestACmpl(void)
{
    extern __PST__UINT8 PwrDiscnct_Pim_PwrDiscnctTestACmpl;
    
    /* initialization with random value */
    {
        PwrDiscnct_Pim_PwrDiscnctTestACmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Pim_PwrDiscnctTestBCmpl(void)
{
    extern __PST__UINT8 PwrDiscnct_Pim_PwrDiscnctTestBCmpl;
    
    /* initialization with random value */
    {
        PwrDiscnct_Pim_PwrDiscnctTestBCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Srv_CnvSnpshtData_f32_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 PwrDiscnct_Srv_CnvSnpshtData_f32_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        PwrDiscnct_Srv_CnvSnpshtData_f32_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_PwrDiscnct_Srv_SetNtcStsAndSnpshtData_Return(void)
{
    extern __PST__UINT8 PwrDiscnct_Srv_SetNtcStsAndSnpshtData_Return;
    
    /* initialization with random value */
    {
        PwrDiscnct_Srv_SetNtcStsAndSnpshtData_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable PwrDiscnct_Ip_BattVltg */
    _main_gen_init_sym_PwrDiscnct_Ip_BattVltg();
    
    /* init for variable PwrDiscnct_Ip_BattVltgAdcFaild */
    _main_gen_init_sym_PwrDiscnct_Ip_BattVltgAdcFaild();
    
    /* init for variable PwrDiscnct_Ip_BattVltgSwd1 */
    _main_gen_init_sym_PwrDiscnct_Ip_BattVltgSwd1();
    
    /* init for variable PwrDiscnct_Ip_ChrgPmpDiag */
    _main_gen_init_sym_PwrDiscnct_Ip_ChrgPmpDiag();
    
    /* init for variable PwrDiscnct_Ip_ChrgPmpDiagAdcFaild */
    _main_gen_init_sym_PwrDiscnct_Ip_ChrgPmpDiagAdcFaild();
    
    /* init for variable PwrDiscnct_Ip_MotVelMrf */
    _main_gen_init_sym_PwrDiscnct_Ip_MotVelMrf();
    
    /* init for variable PwrDiscnct_Ip_PwrDiscnctSwtDiag */
    _main_gen_init_sym_PwrDiscnct_Ip_PwrDiscnctSwtDiag();
    
    /* init for variable PwrDiscnct_Ip_StrtUpSt */
    _main_gen_init_sym_PwrDiscnct_Ip_StrtUpSt();
    
    /* init for variable PwrDiscnct_Ip_SysSt */
    _main_gen_init_sym_PwrDiscnct_Ip_SysSt();
    
    /* init for variable PwrDiscnct_Op_PwrDiscnctATestCmpl : useless (never read) */

    /* init for variable PwrDiscnct_Op_PwrDiscnctBTestCmpl : useless (never read) */

    /* init for variable PwrDiscnct_Op_PwrDiscnctClsd : useless (never read) */

    /* init for variable PwrDiscnct_Cal_PwrDiscnctBattVltgExtdNormThd */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctBattVltgExtdNormThd();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctBattVltgNonExtdThd */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctBattVltgNonExtdThd();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaExtOper */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaExtOper();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaNonOper */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaNonOper();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaNormOper */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctChrgMinDeltaNormOper();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctChrgPmpDiagOpenThd */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctChrgPmpDiagOpenThd();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctDeltaSwtClsThd */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctDeltaSwtClsThd();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctDeltaVltgClsThd */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctDeltaVltgClsThd();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctDeltaVltgOpenThd */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctDeltaVltgOpenThd();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctFltFailStep */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctFltFailStep();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctFltPassStep */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctFltPassStep();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctFltThd */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctFltThd();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctMtrMtnThd */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctMtrMtnThd();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctPwrDiscnctRtFltFailStep */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctPwrDiscnctRtFltFailStep();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctPwrDiscnctRtFltPassStep */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctPwrDiscnctRtFltPassStep();
    
    /* init for variable PwrDiscnct_Cal_PwrDiscnctSwtDiagOpenThd */
    _main_gen_init_sym_PwrDiscnct_Cal_PwrDiscnctSwtDiagOpenThd();
    
    /* init for variable PwrDiscnct_Cal_BattVltgSwdMax */
    _main_gen_init_sym_PwrDiscnct_Cal_BattVltgSwdMax();
    
    /* init for variable PwrDiscnct_Pim_FirstRunCmpl */
    _main_gen_init_sym_PwrDiscnct_Pim_FirstRunCmpl();
    
    /* init for variable PwrDiscnct_Pim_Ntc042PrmByte */
    _main_gen_init_sym_PwrDiscnct_Pim_Ntc042PrmByte();
    
    /* init for variable PwrDiscnct_Pim_PwrDiscnctClsdSts */
    _main_gen_init_sym_PwrDiscnct_Pim_PwrDiscnctClsdSts();
    
    /* init for variable PwrDiscnct_Pim_PwrDiscnctFltAtInitErrAcc */
    _main_gen_init_sym_PwrDiscnct_Pim_PwrDiscnctFltAtInitErrAcc();
    
    /* init for variable PwrDiscnct_Pim_PwrDiscnctSt */
    _main_gen_init_sym_PwrDiscnct_Pim_PwrDiscnctSt();
    
    /* init for variable PwrDiscnct_Pim_PwrDiscnctTestACmpl */
    _main_gen_init_sym_PwrDiscnct_Pim_PwrDiscnctTestACmpl();
    
    /* init for variable PwrDiscnct_Pim_PwrDiscnctTestBCmpl */
    _main_gen_init_sym_PwrDiscnct_Pim_PwrDiscnctTestBCmpl();
    
    /* init for variable PwrDiscnct_Srv_CnvSnpshtData_f32_SnpshtDataCnvd */
    _main_gen_init_sym_PwrDiscnct_Srv_CnvSnpshtData_f32_SnpshtDataCnvd();
    
    /* init for variable PwrDiscnct_Srv_CnvSnpshtData_f32_SnpshtData : useless (never read) */

    /* init for variable PwrDiscnct_Srv_SetNtcStsAndSnpshtData_NtcNr : useless (never read) */

    /* init for variable PwrDiscnct_Srv_SetNtcStsAndSnpshtData_NtcStInfo : useless (never read) */

    /* init for variable PwrDiscnct_Srv_SetNtcStsAndSnpshtData_NtcSts : useless (never read) */

    /* init for variable PwrDiscnct_Srv_SetNtcStsAndSnpshtData_DebStep : useless (never read) */

    /* init for variable PwrDiscnct_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData0 : useless (never read) */

    /* init for variable PwrDiscnct_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData1 : useless (never read) */

    /* init for variable PwrDiscnct_Srv_SetNtcStsAndSnpshtData_SpclSnpshtData2 : useless (never read) */

    /* init for variable PwrDiscnct_Srv_SetNtcStsAndSnpshtData_Return */
    _main_gen_init_sym_PwrDiscnct_Srv_SetNtcStsAndSnpshtData_Return();
    
}
