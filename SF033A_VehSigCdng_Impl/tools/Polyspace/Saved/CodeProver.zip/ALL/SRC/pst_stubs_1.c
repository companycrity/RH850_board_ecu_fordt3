#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__27 _main_gen_init_g27(void);

extern __PST__g__26 _main_gen_init_g26(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__27 _main_gen_init_g27(void)
{
    static struct __PST__g__27 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_VehSigCdng_Ip_HwTq(void)
{
    extern __PST__FLOAT32 VehSigCdng_Ip_HwTq;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_VehSigCdng_Ip_VehLatASerlCom(void)
{
    extern __PST__FLOAT32 VehSigCdng_Ip_VehLatASerlCom;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_VehLatASerlCom = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_VehSigCdng_Ip_VehLatAVldSerlCom(void)
{
    extern __PST__UINT8 VehSigCdng_Ip_VehLatAVldSerlCom;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_VehLatAVldSerlCom = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_VehSigCdng_Ip_VehLgtASerlCom(void)
{
    extern __PST__FLOAT32 VehSigCdng_Ip_VehLgtASerlCom;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_VehLgtASerlCom = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_VehSigCdng_Ip_VehLgtAVldSerlCom(void)
{
    extern __PST__UINT8 VehSigCdng_Ip_VehLgtAVldSerlCom;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_VehLgtAVldSerlCom = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_VehSigCdng_Ip_VehSpdOvrd(void)
{
    extern __PST__FLOAT32 VehSigCdng_Ip_VehSpdOvrd;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_VehSpdOvrd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_VehSigCdng_Ip_VehSpdOvrdEna(void)
{
    extern __PST__UINT8 VehSigCdng_Ip_VehSpdOvrdEna;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_VehSpdOvrdEna = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_VehSigCdng_Ip_VehSpdSerlCom(void)
{
    extern __PST__FLOAT32 VehSigCdng_Ip_VehSpdSerlCom;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_VehSpdSerlCom = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_VehSigCdng_Ip_VehSpdVldSerlCom(void)
{
    extern __PST__UINT8 VehSigCdng_Ip_VehSpdVldSerlCom;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_VehSpdVldSerlCom = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_VehSigCdng_Ip_VehYawRateSerlCom(void)
{
    extern __PST__FLOAT32 VehSigCdng_Ip_VehYawRateSerlCom;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_VehYawRateSerlCom = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_VehSigCdng_Ip_VehYawRateVldSerlCom(void)
{
    extern __PST__UINT8 VehSigCdng_Ip_VehYawRateVldSerlCom;
    
    /* initialization with random value */
    {
        VehSigCdng_Ip_VehYawRateVldSerlCom = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngDftLatA(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngDftLatA;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngDftLatA = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngDftLgtA(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngDftLgtA;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngDftLgtA = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngDftVehSpd(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngDftVehSpd;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngDftVehSpd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngDftYawRate(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngDftYawRate;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngDftYawRate = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngLatADifThd(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngLatADifThd;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngLatADifThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngLatAFilFrq(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngLatAFilFrq;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngLatAFilFrq = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngLatASlewRate(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngLatASlewRate;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngLatASlewRate = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngLtgADifThd(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngLtgADifThd;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngLtgADifThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngLtgASlewRate(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngLtgASlewRate;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngLtgASlewRate = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngVehSpdDifThd(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngVehSpdDifThd;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngVehSpdDifThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngVehSpdSlewRate(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngVehSpdSlewRate;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngVehSpdSlewRate = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngVehYawSlewRate(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngVehYawSlewRate;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngVehYawSlewRate = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngYawRateDifThd(void)
{
    extern __PST__g__26 VehSigCdng_Cal_VehSigCdngYawRateDifThd;
    
    /* initialization with random value */
    {
        VehSigCdng_Cal_VehSigCdngYawRateDifThd = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_VehSigCdng_Pim_HwTqFilRec(void)
{
    extern struct __PST__g__27 VehSigCdng_Pim_HwTqFilRec;
    
    /* initialization with random value */
    {
        VehSigCdng_Pim_HwTqFilRec = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_VehSigCdng_Pim_LatAFilRec(void)
{
    extern struct __PST__g__27 VehSigCdng_Pim_LatAFilRec;
    
    /* initialization with random value */
    {
        VehSigCdng_Pim_LatAFilRec = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_VehSigCdng_Pim_PrevLatA(void)
{
    extern __PST__FLOAT32 VehSigCdng_Pim_PrevLatA;
    
    /* initialization with random value */
    {
        VehSigCdng_Pim_PrevLatA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_VehSigCdng_Pim_PrevLatAVld(void)
{
    extern __PST__UINT8 VehSigCdng_Pim_PrevLatAVld;
    
    /* initialization with random value */
    {
        VehSigCdng_Pim_PrevLatAVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_VehSigCdng_Pim_PrevLtgA(void)
{
    extern __PST__FLOAT32 VehSigCdng_Pim_PrevLtgA;
    
    /* initialization with random value */
    {
        VehSigCdng_Pim_PrevLtgA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_VehSigCdng_Pim_PrevLtgAVld(void)
{
    extern __PST__UINT8 VehSigCdng_Pim_PrevLtgAVld;
    
    /* initialization with random value */
    {
        VehSigCdng_Pim_PrevLtgAVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_VehSigCdng_Pim_PrevVehSpd(void)
{
    extern __PST__FLOAT32 VehSigCdng_Pim_PrevVehSpd;
    
    /* initialization with random value */
    {
        VehSigCdng_Pim_PrevVehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_VehSigCdng_Pim_PrevVehSpdVld(void)
{
    extern __PST__UINT8 VehSigCdng_Pim_PrevVehSpdVld;
    
    /* initialization with random value */
    {
        VehSigCdng_Pim_PrevVehSpdVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_VehSigCdng_Pim_PrevYawRate(void)
{
    extern __PST__FLOAT32 VehSigCdng_Pim_PrevYawRate;
    
    /* initialization with random value */
    {
        VehSigCdng_Pim_PrevYawRate = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_VehSigCdng_Pim_PrevYawRateVld(void)
{
    extern __PST__UINT8 VehSigCdng_Pim_PrevYawRateVld;
    
    /* initialization with random value */
    {
        VehSigCdng_Pim_PrevYawRateVld = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable VehSigCdng_Ip_HwTq */
    _main_gen_init_sym_VehSigCdng_Ip_HwTq();
    
    /* init for variable VehSigCdng_Ip_VehLatASerlCom */
    _main_gen_init_sym_VehSigCdng_Ip_VehLatASerlCom();
    
    /* init for variable VehSigCdng_Ip_VehLatAVldSerlCom */
    _main_gen_init_sym_VehSigCdng_Ip_VehLatAVldSerlCom();
    
    /* init for variable VehSigCdng_Ip_VehLgtASerlCom */
    _main_gen_init_sym_VehSigCdng_Ip_VehLgtASerlCom();
    
    /* init for variable VehSigCdng_Ip_VehLgtAVldSerlCom */
    _main_gen_init_sym_VehSigCdng_Ip_VehLgtAVldSerlCom();
    
    /* init for variable VehSigCdng_Ip_VehSpdOvrd */
    _main_gen_init_sym_VehSigCdng_Ip_VehSpdOvrd();
    
    /* init for variable VehSigCdng_Ip_VehSpdOvrdEna */
    _main_gen_init_sym_VehSigCdng_Ip_VehSpdOvrdEna();
    
    /* init for variable VehSigCdng_Ip_VehSpdSerlCom */
    _main_gen_init_sym_VehSigCdng_Ip_VehSpdSerlCom();
    
    /* init for variable VehSigCdng_Ip_VehSpdVldSerlCom */
    _main_gen_init_sym_VehSigCdng_Ip_VehSpdVldSerlCom();
    
    /* init for variable VehSigCdng_Ip_VehYawRateSerlCom */
    _main_gen_init_sym_VehSigCdng_Ip_VehYawRateSerlCom();
    
    /* init for variable VehSigCdng_Ip_VehYawRateVldSerlCom */
    _main_gen_init_sym_VehSigCdng_Ip_VehYawRateVldSerlCom();
    
    /* init for variable VehSigCdng_Op_VehLatA : useless (never read) */

    /* init for variable VehSigCdng_Op_VehLatAEstimd : useless (never read) */

    /* init for variable VehSigCdng_Op_VehLatAEstimdVld : useless (never read) */

    /* init for variable VehSigCdng_Op_VehLatAVld : useless (never read) */

    /* init for variable VehSigCdng_Op_VehLgtA : useless (never read) */

    /* init for variable VehSigCdng_Op_VehLgtAVld : useless (never read) */

    /* init for variable VehSigCdng_Op_VehSpd : useless (never read) */

    /* init for variable VehSigCdng_Op_VehSpdVld : useless (never read) */

    /* init for variable VehSigCdng_Op_VehYawRate : useless (never read) */

    /* init for variable VehSigCdng_Op_VehYawRateVld : useless (never read) */

    /* init for variable VehSigCdng_Cal_VehSigCdngDftLatA */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngDftLatA();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngDftLgtA */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngDftLgtA();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngDftVehSpd */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngDftVehSpd();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngDftYawRate */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngDftYawRate();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngLatADifThd */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngLatADifThd();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngLatAFilFrq */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngLatAFilFrq();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngLatASlewRate */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngLatASlewRate();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngLtgADifThd */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngLtgADifThd();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngLtgASlewRate */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngLtgASlewRate();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngVehSpdDifThd */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngVehSpdDifThd();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngVehSpdSlewRate */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngVehSpdSlewRate();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngVehYawSlewRate */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngVehYawSlewRate();
    
    /* init for variable VehSigCdng_Cal_VehSigCdngYawRateDifThd */
    _main_gen_init_sym_VehSigCdng_Cal_VehSigCdngYawRateDifThd();
    
    /* init for variable VehSigCdng_Pim_HwTqFilRec */
    _main_gen_init_sym_VehSigCdng_Pim_HwTqFilRec();
    
    /* init for variable VehSigCdng_Pim_LatAFilRec */
    _main_gen_init_sym_VehSigCdng_Pim_LatAFilRec();
    
    /* init for variable VehSigCdng_Pim_PrevLatA */
    _main_gen_init_sym_VehSigCdng_Pim_PrevLatA();
    
    /* init for variable VehSigCdng_Pim_PrevLatAVld */
    _main_gen_init_sym_VehSigCdng_Pim_PrevLatAVld();
    
    /* init for variable VehSigCdng_Pim_PrevLtgA */
    _main_gen_init_sym_VehSigCdng_Pim_PrevLtgA();
    
    /* init for variable VehSigCdng_Pim_PrevLtgAVld */
    _main_gen_init_sym_VehSigCdng_Pim_PrevLtgAVld();
    
    /* init for variable VehSigCdng_Pim_PrevVehSpd */
    _main_gen_init_sym_VehSigCdng_Pim_PrevVehSpd();
    
    /* init for variable VehSigCdng_Pim_PrevVehSpdVld */
    _main_gen_init_sym_VehSigCdng_Pim_PrevVehSpdVld();
    
    /* init for variable VehSigCdng_Pim_PrevYawRate */
    _main_gen_init_sym_VehSigCdng_Pim_PrevYawRate();
    
    /* init for variable VehSigCdng_Pim_PrevYawRateVld */
    _main_gen_init_sym_VehSigCdng_Pim_PrevYawRateVld();
    
}
