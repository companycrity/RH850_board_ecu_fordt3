#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_FordMsg082BusHiSpd_FordElecPwrAssidSteerFailr_Ford_EPAS_Failure
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordElecPwrAssidSteerFailr_Ford_EPAS_Failure(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg082BusHiSpd_FordSteerModlSts_Ford_SteMdule_D_Stat
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordSteerModlSts_Ford_SteMdule_D_Stat(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg082BusHiSpd_FordVehDrvrSteerActvnSts_Ford_DrvSteActv_B_Stat
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordVehDrvrSteerActvnSts_Ford_DrvSteActv_B_Stat(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg082BusHiSpd_FordVehReCamrLiSts_Ford_TrlrHitchLamp_D_Rqst
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordVehReCamrLiSts_Ford_TrlrHitchLamp_D_Rqst(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts1_Ford_SAPPAngleControlStat1
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts1_Ford_SAPPAngleControlStat1(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts2_Ford_SAPPAngleControlStat2
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts2_Ford_SAPPAngleControlStat2(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts3_Ford_SAPPAngleControlStat3
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts3_Ford_SAPPAngleControlStat3(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts4_Ford_SAPPAngleControlStat4
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts4_Ford_SAPPAngleControlStat4(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts5_Ford_SAPPAngleControlStat5
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts5_Ford_SAPPAngleControlStat5(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts6_Ford_SAPPAngleControlStat6
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordVehSAPPAgCtrlSts6_Ford_SAPPAngleControlStat6(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_FordMsg082BusHiSpd_FordVehVelTrlrAidReq_Ford_VehVTrlrAid_B_Rq
 */


__PST__UINT8 Rte_Read_FordMsg082BusHiSpd_FordVehVelTrlrAidReq_Ford_VehVTrlrAid_B_Rq(__PST__g__24 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_DrvSteActv_B_Stat1_Ford_DrvSteActv_B_Stat
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_DrvSteActv_B_Stat1_Ford_DrvSteActv_B_Stat"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_DrvSteActv_B_Stat1_Ford_DrvSteActv_B_Stat(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_DrvSte_Tq_Actl_Ford_DrvSte_Tq_Actl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_DrvSte_Tq_Actl_Ford_DrvSte_Tq_Actl"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_DrvSte_Tq_Actl_Ford_DrvSte_Tq_Actl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_EPAS_Failure1_Ford_EPAS_Failure
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_EPAS_Failure1_Ford_EPAS_Failure"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_EPAS_Failure1_Ford_EPAS_Failure(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat1_1_Ford_SAPPAngleControlStat1
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat1_1_Ford_SAPPAngleControlStat1"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat1_1_Ford_SAPPAngleControlStat1(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat2_1_Ford_SAPPAngleControlStat2
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat2_1_Ford_SAPPAngleControlStat2"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat2_1_Ford_SAPPAngleControlStat2(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat3_1_Ford_SAPPAngleControlStat3
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat3_1_Ford_SAPPAngleControlStat3"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat3_1_Ford_SAPPAngleControlStat3(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat4_1_Ford_SAPPAngleControlStat4
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat4_1_Ford_SAPPAngleControlStat4"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat4_1_Ford_SAPPAngleControlStat4(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat5_1_Ford_SAPPAngleControlStat5
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat5_1_Ford_SAPPAngleControlStat5"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat5_1_Ford_SAPPAngleControlStat5(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat6_1_Ford_SAPPAngleControlStat6
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat6_1_Ford_SAPPAngleControlStat6"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_SAPPAngleControlStat6_1_Ford_SAPPAngleControlStat6(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_SteMdule_D_Stat1_Ford_SteMdule_D_Stat
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_SteMdule_D_Stat1_Ford_SteMdule_D_Stat"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_SteMdule_D_Stat1_Ford_SteMdule_D_Stat(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_SteMdule_I_Est_Ford_SteMdule_I_Est
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_SteMdule_I_Est_Ford_SteMdule_I_Est"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_SteMdule_I_Est_Ford_SteMdule_I_Est(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_SteMdule_U_Meas_Ford_SteMdule_U_Meas
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_SteMdule_U_Meas_Ford_SteMdule_U_Meas"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_SteMdule_U_Meas_Ford_SteMdule_U_Meas(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_SteeringColumnTorque_Ford_SteeringColumnTorque
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_SteeringColumnTorque_Ford_SteeringColumnTorque"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_SteeringColumnTorque_Ford_SteeringColumnTorque(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_TrlrHitchLamp_D_Rqst1_Ford_TrlrHitchLamp_D_Rqst
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_TrlrHitchLamp_D_Rqst1_Ford_TrlrHitchLamp_D_Rqst"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_TrlrHitchLamp_D_Rqst1_Ford_TrlrHitchLamp_D_Rqst(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_VehVTrlrAid_B_Rq1_Ford_VehVTrlrAid_B_Rq
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_VehVTrlrAid_B_Rq1_Ford_VehVTrlrAid_B_Rq"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_VehVTrlrAid_B_Rq1_Ford_VehVTrlrAid_B_Rq(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_FordMsg082BusHiSpd_Ford_Veh_V_RqMxTrlrAid_Ford_Veh_V_RqMxTrlrAid
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_FordMsg082BusHiSpd_Ford_Veh_V_RqMxTrlrAid_Ford_Veh_V_RqMxTrlrAid"


__PST__UINT8 Rte_Write_FordMsg082BusHiSpd_Ford_Veh_V_RqMxTrlrAid_Ford_Veh_V_RqMxTrlrAid(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

