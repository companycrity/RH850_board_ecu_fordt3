#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FordMsg167BusHiSpd_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordBrkOscnRednEnad(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Ip_FordBrkOscnRednEnad;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Ip_FordBrkOscnRednEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordCanDtcInhb(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Ip_FordCanDtcInhb;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Ip_FordCanDtcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordEpsLifeCycMod(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Ip_FordEpsLifeCycMod;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Ip_FordEpsLifeCycMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordInvldMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Ip_FordInvldMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Ip_FordInvldMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordMfgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Ip_FordMfgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Ip_FordMfgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordMissMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Ip_FordMissMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Ip_FordMissMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordTqSteerCmpEnad(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Ip_FordTqSteerCmpEnad;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Ip_FordTqSteerCmpEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordTrlrBackUpAssiEnad(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Ip_FordTrlrBackUpAssiEnad;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Ip_FordTrlrBackUpAssiEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdMissMsgFaildTiThd(void)
{
    extern __PST__g__32 FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdMissMsgFaildTiThd;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdMissMsgFaildTiThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdMissMsgPassdTiThd(void)
{
    extern __PST__g__32 FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdMissMsgPassdTiThd;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdMissMsgPassdTiThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqFaildTiThd(void)
{
    extern __PST__g__32 FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqFaildTiThd;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqFaildTiThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqMissTiThd(void)
{
    extern __PST__g__32 FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqMissTiThd;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqMissTiThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqPassdTiThd(void)
{
    extern __PST__g__32 FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqPassdTiThd;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqPassdTiThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqSigInvldFaildTiThd(void)
{
    extern __PST__g__32 FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqSigInvldFaildTiThd;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqSigInvldFaildTiThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqSigInvldPassdTiThd(void)
{
    extern __PST__g__32 FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqSigInvldPassdTiThd;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqSigInvldPassdTiThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_ClrDiagcFlgProxyPrev(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Pim_ClrDiagcFlgProxyPrev;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_ClrDiagcFlgProxyPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FirstTranVldFlg(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Pim_FirstTranVldFlg;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FirstTranVldFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehElecPwrStrtStopStsPrev(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Pim_FordVehElecPwrStrtStopStsPrev;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FordVehElecPwrStrtStopStsPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehElecPwrStsPrev(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Pim_FordVehElecPwrStsPrev;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FordVehElecPwrStsPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehMsg167Miss(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Pim_FordVehMsg167Miss;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FordVehMsg167Miss = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehMsg167Rxd(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Pim_FordVehMsg167Rxd;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FordVehMsg167Rxd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqPrev(void)
{
    extern __PST__FLOAT32 FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqPrev;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqRawPrev(void)
{
    extern __PST__UINT16 FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqRawPrev;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqSigInvldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqSigInvldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqSigInvldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqSigInvldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqSigInvldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqSigInvldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqVldPrev(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqVldPrev;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPwrpkTqStsPrev(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Pim_FordVehPwrpkTqStsPrev;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_FordVehPwrpkTqStsPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_MissMsgFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg167BusHiSpd_Pim_MissMsgFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_MissMsgFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_MissMsgPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg167BusHiSpd_Pim_MissMsgPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_MissMsgPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_PrpnWhlTqVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg167BusHiSpd_Pim_PrpnWhlTqVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_PrpnWhlTqVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_PrpnWhlTqVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg167BusHiSpd_Pim_PrpnWhlTqVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_PrpnWhlTqVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Pim_PrpnWhlTqVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg167BusHiSpd_Pim_PrpnWhlTqVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Pim_PrpnWhlTqVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 FordMsg167BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 FordMsg167BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg167BusHiSpd_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 FordMsg167BusHiSpd_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        FordMsg167BusHiSpd_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FordMsg167BusHiSpd_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_FordMsg167BusHiSpd_Ip_ClrDiagcFlgProxy();
    
    /* init for variable FordMsg167BusHiSpd_Ip_FordBrkOscnRednEnad */
    _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordBrkOscnRednEnad();
    
    /* init for variable FordMsg167BusHiSpd_Ip_FordCanDtcInhb */
    _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordCanDtcInhb();
    
    /* init for variable FordMsg167BusHiSpd_Ip_FordEpsLifeCycMod */
    _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordEpsLifeCycMod();
    
    /* init for variable FordMsg167BusHiSpd_Ip_FordInvldMsgDiagcInhb */
    _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordInvldMsgDiagcInhb();
    
    /* init for variable FordMsg167BusHiSpd_Ip_FordMfgDiagcInhb */
    _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordMfgDiagcInhb();
    
    /* init for variable FordMsg167BusHiSpd_Ip_FordMissMsgDiagcInhb */
    _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordMissMsgDiagcInhb();
    
    /* init for variable FordMsg167BusHiSpd_Ip_FordTqSteerCmpEnad */
    _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordTqSteerCmpEnad();
    
    /* init for variable FordMsg167BusHiSpd_Ip_FordTrlrBackUpAssiEnad */
    _main_gen_init_sym_FordMsg167BusHiSpd_Ip_FordTrlrBackUpAssiEnad();
    
    /* init for variable FordMsg167BusHiSpd_Op_FordVehPrpnWhlTq : useless (never read) */

    /* init for variable FordMsg167BusHiSpd_Op_FordVehPrpnWhlTqRaw : useless (never read) */

    /* init for variable FordMsg167BusHiSpd_Op_FordVehPrpnWhlTqVld : useless (never read) */

    /* init for variable FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdMissMsgFaildTiThd */
    _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdMissMsgFaildTiThd();
    
    /* init for variable FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdMissMsgPassdTiThd */
    _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdMissMsgPassdTiThd();
    
    /* init for variable FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqFaildTiThd */
    _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqFaildTiThd();
    
    /* init for variable FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqMissTiThd */
    _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqMissTiThd();
    
    /* init for variable FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqPassdTiThd */
    _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqPassdTiThd();
    
    /* init for variable FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqSigInvldFaildTiThd */
    _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqSigInvldFaildTiThd();
    
    /* init for variable FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqSigInvldPassdTiThd */
    _main_gen_init_sym_FordMsg167BusHiSpd_Cal_FordMsg167BusHiSpdPrpnWhlTqSigInvldPassdTiThd();
    
    /* init for variable FordMsg167BusHiSpd_Pim_ClrDiagcFlgProxyPrev */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_ClrDiagcFlgProxyPrev();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FirstTranVldFlg */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FirstTranVldFlg();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FordVehElecPwrStrtStopStsPrev */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehElecPwrStrtStopStsPrev();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FordVehElecPwrStsPrev */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehElecPwrStsPrev();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FordVehMsg167Miss */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehMsg167Miss();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FordVehMsg167Rxd */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehMsg167Rxd();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqPrev */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqPrev();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqRawPrev */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqRawPrev();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqSigInvldFaildRefTi */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqSigInvldFaildRefTi();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqSigInvldPassdRefTi */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqSigInvldPassdRefTi();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqVldPrev */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPrpnWhlTqVldPrev();
    
    /* init for variable FordMsg167BusHiSpd_Pim_FordVehPwrpkTqStsPrev */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_FordVehPwrpkTqStsPrev();
    
    /* init for variable FordMsg167BusHiSpd_Pim_MissMsgFaildRefTi */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_MissMsgFaildRefTi();
    
    /* init for variable FordMsg167BusHiSpd_Pim_MissMsgPassdRefTi */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_MissMsgPassdRefTi();
    
    /* init for variable FordMsg167BusHiSpd_Pim_PrpnWhlTqVldFaildRefTi */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_PrpnWhlTqVldFaildRefTi();
    
    /* init for variable FordMsg167BusHiSpd_Pim_PrpnWhlTqVldMissRefTi */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_PrpnWhlTqVldMissRefTi();
    
    /* init for variable FordMsg167BusHiSpd_Pim_PrpnWhlTqVldPassdRefTi */
    _main_gen_init_sym_FordMsg167BusHiSpd_Pim_PrpnWhlTqVldPassdRefTi();
    
    /* init for variable FordMsg167BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_FordMsg167BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable FordMsg167BusHiSpd_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable FordMsg167BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_FordMsg167BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable FordMsg167BusHiSpd_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable FordMsg167BusHiSpd_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable FordMsg167BusHiSpd_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable FordMsg167BusHiSpd_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable FordMsg167BusHiSpd_Srv_SetNtcSts_Return */
    _main_gen_init_sym_FordMsg167BusHiSpd_Srv_SetNtcSts_Return();
    
}
