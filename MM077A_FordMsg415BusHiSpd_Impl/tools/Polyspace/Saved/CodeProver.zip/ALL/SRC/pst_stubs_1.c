#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FordMsg415BusHiSpd_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordAbsPrsnt(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Ip_FordAbsPrsnt;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Ip_FordAbsPrsnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordCanDtcInhb(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Ip_FordCanDtcInhb;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Ip_FordCanDtcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordEpsLifeCycMod(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Ip_FordEpsLifeCycMod;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Ip_FordEpsLifeCycMod = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordInvldMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Ip_FordInvldMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Ip_FordInvldMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordMfgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Ip_FordMfgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Ip_FordMfgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordMissMsgDiagcInhb(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Ip_FordMissMsgDiagcInhb;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Ip_FordMissMsgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordTrlrBackupAssiEnad(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Ip_FordTrlrBackupAssiEnad;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Ip_FordTrlrBackupAssiEnad = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldFaildThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldMissThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldPassdThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldFaildThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldMissThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldPassdThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkSprtVldMissThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkSprtVldMissThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkSprtVldMissThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkSprtVldPassdThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkSprtVldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkSprtVldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdChksBrkModlInvldFaildThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdChksBrkModlInvldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdChksBrkModlInvldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdChksBrkModlInvldPassdThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdChksBrkModlInvldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdChksBrkModlInvldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdCntrBrkModlInvldFaildThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdCntrBrkModlInvldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdCntrBrkModlInvldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdCntrBrkModlInvldPassdThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdCntrBrkModlInvldPassdThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdCntrBrkModlInvldPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdMissMsgFaildThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdMissMsgFaildThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdMissMsgFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdMissMsgPassdThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdMissMsgPassdThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdMissMsgPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdQlyFacBrkModlInvldFaildThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdQlyFacBrkModlInvldFaildThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdQlyFacBrkModlInvldFaildThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdQlyFacBrkModlInvldSigPassdThd(void)
{
    extern __PST__g__32 FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdQlyFacBrkModlInvldSigPassdThd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdQlyFacBrkModlInvldSigPassdThd = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlVldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_BrkModlVldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_BrkModlVldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_BrkModlVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_BrkModlVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_BrkModlVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_BrkModlVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkSprtVldMissRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_BrkSprtVldMissRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_BrkSprtVldMissRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkSprtVldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_BrkSprtVldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_BrkSprtVldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_ChksBrkModlInvldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_ChksBrkModlInvldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_ChksBrkModlInvldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_ChksBrkModlInvldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_ChksBrkModlInvldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_ChksBrkModlInvldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_ClrDiagcFlgProxyPrev(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_ClrDiagcFlgProxyPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_ClrDiagcFlgProxyPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_CntrBrkModlInvldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_CntrBrkModlInvldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_CntrBrkModlInvldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_CntrBrkModlInvldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_CntrBrkModlInvldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_CntrBrkModlInvldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FirstTranVldFlg(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FirstTranVldFlg;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FirstTranVldFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtStsPrev(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtStsPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtStsPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtStsRawPrev(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtStsRawPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtStsRawPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtVldPrev(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtVldPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehMsg415Miss(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FordVehMsg415Miss;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehMsg415Miss = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehMsg415Rxd(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FordVehMsg415Rxd;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehMsg415Rxd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlLoQlyVldPrev(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlLoQlyVldPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlLoQlyVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlPrev(void)
{
    extern __PST__FLOAT32 FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlRawPrev(void)
{
    extern __PST__UINT16 FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlRawPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlRawPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlVldPrev(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlVldPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlVldPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdChksBrkModlPrev(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FordVehSpdChksBrkModlPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehSpdChksBrkModlPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdCntrBrkModlPrev(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FordVehSpdCntrBrkModlPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehSpdCntrBrkModlPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdQlyFacBrkModlPrev(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Pim_FordVehSpdQlyFacBrkModlPrev;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_FordVehSpdQlyFacBrkModlPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_MissMsgFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_MissMsgFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_MissMsgFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_MissMsgPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_MissMsgPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_MissMsgPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_QlyFacBrkModlInvldFaildRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_QlyFacBrkModlInvldFaildRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_QlyFacBrkModlInvldFaildRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Pim_QlyFacBrkModlInvldPassdRefTi(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Pim_QlyFacBrkModlInvldPassdRefTi;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Pim_QlyFacBrkModlInvldPassdRefTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 FordMsg415BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FordMsg415BusHiSpd_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 FordMsg415BusHiSpd_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        FordMsg415BusHiSpd_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FordMsg415BusHiSpd_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_FordMsg415BusHiSpd_Ip_ClrDiagcFlgProxy();
    
    /* init for variable FordMsg415BusHiSpd_Ip_FordAbsPrsnt */
    _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordAbsPrsnt();
    
    /* init for variable FordMsg415BusHiSpd_Ip_FordCanDtcInhb */
    _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordCanDtcInhb();
    
    /* init for variable FordMsg415BusHiSpd_Ip_FordEpsLifeCycMod */
    _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordEpsLifeCycMod();
    
    /* init for variable FordMsg415BusHiSpd_Ip_FordInvldMsgDiagcInhb */
    _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordInvldMsgDiagcInhb();
    
    /* init for variable FordMsg415BusHiSpd_Ip_FordMfgDiagcInhb */
    _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordMfgDiagcInhb();
    
    /* init for variable FordMsg415BusHiSpd_Ip_FordMissMsgDiagcInhb */
    _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordMissMsgDiagcInhb();
    
    /* init for variable FordMsg415BusHiSpd_Ip_FordTrlrBackupAssiEnad */
    _main_gen_init_sym_FordMsg415BusHiSpd_Ip_FordTrlrBackupAssiEnad();
    
    /* init for variable FordMsg415BusHiSpd_Op_FordVehLoSpdMtnCtrlBrkSprtStsRaw : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Op_FordVehLoSpdMtnCtrlBrkSprtVld : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Op_FordVehSpdBrkModl : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Op_FordVehSpdBrkModlLoQlyVld : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Op_FordVehSpdBrkModlRaw : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Op_FordVehSpdBrkModlVld : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Op_FordVehSpdChksBrkModl : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Op_FordVehSpdCntrBrkModl : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldFaildThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldFaildThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldMissThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldMissThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldPassdThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlLoQlyVldPassdThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldFaildThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldFaildThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldMissThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldMissThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldPassdThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkModlVldPassdThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkSprtVldMissThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkSprtVldMissThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkSprtVldPassdThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdBrkSprtVldPassdThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdChksBrkModlInvldFaildThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdChksBrkModlInvldFaildThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdChksBrkModlInvldPassdThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdChksBrkModlInvldPassdThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdCntrBrkModlInvldFaildThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdCntrBrkModlInvldFaildThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdCntrBrkModlInvldPassdThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdCntrBrkModlInvldPassdThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdMissMsgFaildThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdMissMsgFaildThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdMissMsgPassdThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdMissMsgPassdThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdQlyFacBrkModlInvldFaildThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdQlyFacBrkModlInvldFaildThd();
    
    /* init for variable FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdQlyFacBrkModlInvldSigPassdThd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Cal_FordMsg415BusHiSpdQlyFacBrkModlInvldSigPassdThd();
    
    /* init for variable FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldFaildRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldFaildRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldMissRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldMissRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldPassdRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlLoQlyVldPassdRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_BrkModlVldFaildRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlVldFaildRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_BrkModlVldMissRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlVldMissRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_BrkModlVldPassdRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkModlVldPassdRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_BrkSprtVldMissRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkSprtVldMissRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_BrkSprtVldPassdRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_BrkSprtVldPassdRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_ChksBrkModlInvldFaildRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_ChksBrkModlInvldFaildRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_ChksBrkModlInvldPassdRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_ChksBrkModlInvldPassdRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_ClrDiagcFlgProxyPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_ClrDiagcFlgProxyPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_CntrBrkModlInvldFaildRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_CntrBrkModlInvldFaildRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_CntrBrkModlInvldPassdRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_CntrBrkModlInvldPassdRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FirstTranVldFlg */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FirstTranVldFlg();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtStsPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtStsPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtStsRawPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtStsRawPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtVldPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehLoSpdMtnCtrlBrkSprtVldPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehMsg415Miss */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehMsg415Miss();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehMsg415Rxd */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehMsg415Rxd();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlLoQlyVldPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlLoQlyVldPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlRawPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlRawPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlVldPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdBrkModlVldPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehSpdChksBrkModlPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdChksBrkModlPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehSpdCntrBrkModlPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdCntrBrkModlPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_FordVehSpdQlyFacBrkModlPrev */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_FordVehSpdQlyFacBrkModlPrev();
    
    /* init for variable FordMsg415BusHiSpd_Pim_MissMsgFaildRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_MissMsgFaildRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_MissMsgPassdRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_MissMsgPassdRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_QlyFacBrkModlInvldFaildRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_QlyFacBrkModlInvldFaildRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Pim_QlyFacBrkModlInvldPassdRefTi */
    _main_gen_init_sym_FordMsg415BusHiSpd_Pim_QlyFacBrkModlInvldPassdRefTi();
    
    /* init for variable FordMsg415BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr */
    _main_gen_init_sym_FordMsg415BusHiSpd_Srv_GetRefTmr100MicroSec32bit_RefTmr();
    
    /* init for variable FordMsg415BusHiSpd_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_FordMsg415BusHiSpd_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable FordMsg415BusHiSpd_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable FordMsg415BusHiSpd_Srv_SetNtcSts_Return */
    _main_gen_init_sym_FordMsg415BusHiSpd_Srv_SetNtcSts_Return();
    
}
