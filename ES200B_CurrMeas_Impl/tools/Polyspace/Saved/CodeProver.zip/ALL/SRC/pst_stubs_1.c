#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern struct __PST__g__38 _main_gen_init_g38(void);

extern struct __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__36 _main_gen_init_g36(void);

extern __PST__g__35 _main_gen_init_g35(void);

extern __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__33 _main_gen_init_g33(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__33 _main_gen_init_g33(void)
{
    __PST__g__33 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__g__34 _main_gen_init_g34(void)
{
    __PST__g__34 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__g__35 _main_gen_init_g35(void)
{
    __PST__g__35 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__36 _main_gen_init_g36(void)
{
    __PST__g__36 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__37 _main_gen_init_g37(void)
{
    static struct __PST__g__37 x;
    /* struct/union type */
    x.CurrMeasMotCurrEolGainA = _main_gen_init_g10();
    x.CurrMeasMotCurrEolGainB = _main_gen_init_g10();
    x.CurrMeasMotCurrEolGainC = _main_gen_init_g10();
    return x;
}

struct __PST__g__38 _main_gen_init_g38(void)
{
    static struct __PST__g__38 x;
    /* struct/union type */
    x.CurrMeasEolOffsHiBrdgVltg = _main_gen_init_g10();
    x.CurrMeasMotCurrEolOffsDifA = _main_gen_init_g10();
    x.CurrMeasMotCurrEolOffsDifB = _main_gen_init_g10();
    x.CurrMeasMotCurrEolOffsDifC = _main_gen_init_g10();
    x.CurrMeasMotCurrOffsLoAvrgA = _main_gen_init_g10();
    x.CurrMeasMotCurrOffsLoAvrgB = _main_gen_init_g10();
    x.CurrMeasMotCurrOffsLoAvrgC = _main_gen_init_g10();
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_CurrMeas_Ip_BrdgVltg(void)
{
    extern __PST__FLOAT32 CurrMeas_Ip_BrdgVltg;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_BrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Ip_DiagcStsIvtr1Inactv(void)
{
    extern __PST__UINT8 CurrMeas_Ip_DiagcStsIvtr1Inactv;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_DiagcStsIvtr1Inactv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Ip_MotCurrAdcVlyA(void)
{
    extern __PST__FLOAT32 CurrMeas_Ip_MotCurrAdcVlyA;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_MotCurrAdcVlyA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Ip_MotCurrAdcVlyB(void)
{
    extern __PST__FLOAT32 CurrMeas_Ip_MotCurrAdcVlyB;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_MotCurrAdcVlyB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Ip_MotCurrAdcVlyC(void)
{
    extern __PST__FLOAT32 CurrMeas_Ip_MotCurrAdcVlyC;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_MotCurrAdcVlyC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Ip_MotVelMrf(void)
{
    extern __PST__FLOAT32 CurrMeas_Ip_MotVelMrf;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_MotVelMrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Ip_Ntc5DErrCnt(void)
{
    extern __PST__UINT16 CurrMeas_Ip_Ntc5DErrCnt;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_Ntc5DErrCnt = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_CurrMeas_Ip_StrtUpSt(void)
{
    extern __PST__UINT8 CurrMeas_Ip_StrtUpSt;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_StrtUpSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Ip_SysSt(void)
{
    extern __PST__UINT8 CurrMeas_Ip_SysSt;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Ip_VehSpd(void)
{
    extern __PST__FLOAT32 CurrMeas_Ip_VehSpd;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_VehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Ip_VehSpdVld(void)
{
    extern __PST__UINT8 CurrMeas_Ip_VehSpdVld;
    
    /* initialization with random value */
    {
        CurrMeas_Ip_VehSpdVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolGainMax(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasEolGainMax;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolGainMax = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolGainMin(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasEolGainMin;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolGainMin = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolGainNom(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasEolGainNom;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolGainNom = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolGainNrOfSample(void)
{
    extern __PST__g__34 CurrMeas_Cal_CurrMeasEolGainNrOfSample;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolGainNrOfSample = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolGainNumer(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasEolGainNumer;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolGainNumer = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolMaxMotVel(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasEolMaxMotVel;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolMaxMotVel = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsHiBrdgVltgMin(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasEolOffsHiBrdgVltgMin;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolOffsHiBrdgVltgMin = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsHiCmuOffs(void)
{
    extern __PST__g__35 CurrMeas_Cal_CurrMeasEolOffsHiCmuOffs;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolOffsHiCmuOffs = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsLoCmuOffs(void)
{
    extern __PST__g__35 CurrMeas_Cal_CurrMeasEolOffsLoCmuOffs;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolOffsLoCmuOffs = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsMax(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasEolOffsMax;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolOffsMax = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsMin(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasEolOffsMin;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolOffsMin = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsNom(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasEolOffsNom;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolOffsNom = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsNrOfSample(void)
{
    extern __PST__g__34 CurrMeas_Cal_CurrMeasEolOffsNrOfSample;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolOffsNrOfSample = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolTranCntrThd(void)
{
    extern __PST__g__36 CurrMeas_Cal_CurrMeasEolTranCntrThd;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasEolTranCntrThd = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasMotCurrAdcVlyWrmIninMax(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasMotCurrAdcVlyWrmIninMax;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasMotCurrAdcVlyWrmIninMax = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasMotCurrAdcVlyWrmIninMin(void)
{
    extern __PST__g__33 CurrMeas_Cal_CurrMeasMotCurrAdcVlyWrmIninMin;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasMotCurrAdcVlyWrmIninMin = _main_gen_init_g33();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasNtc0x05DFailStep(void)
{
    extern __PST__g__34 CurrMeas_Cal_CurrMeasNtc0x05DFailStep;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasNtc0x05DFailStep = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasNtc0x05DPassStep(void)
{
    extern __PST__g__34 CurrMeas_Cal_CurrMeasNtc0x05DPassStep;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasNtc0x05DPassStep = _main_gen_init_g34();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_CurrMeasEolGainCalSetABC(void)
{
    extern struct __PST__g__37 CurrMeas_Pim_CurrMeasEolGainCalSetABC;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_CurrMeasEolGainCalSetABC = _main_gen_init_g37();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_CurrMeasEolOffsCalSetABC(void)
{
    extern struct __PST__g__38 CurrMeas_Pim_CurrMeasEolOffsCalSetABC;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_CurrMeasEolOffsCalSetABC = _main_gen_init_g38();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_BrdgVltgSumPrev(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_BrdgVltgSumPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_BrdgVltgSumPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_EolGainSts(void)
{
    extern __PST__UINT8 CurrMeas_Pim_EolGainSts;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_EolGainSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_EolGainTranCntrPrev(void)
{
    extern __PST__UINT8 CurrMeas_Pim_EolGainTranCntrPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_EolGainTranCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_EolOffsHiBrdgVltg(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_EolOffsHiBrdgVltg;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_EolOffsHiBrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_EolOffsSts(void)
{
    extern __PST__UINT8 CurrMeas_Pim_EolOffsSts;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_EolOffsSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_EolOffsTranCntrPrev(void)
{
    extern __PST__UINT8 CurrMeas_Pim_EolOffsTranCntrPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_EolOffsTranCntrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_GainEolAvrgCntrPrev(void)
{
    extern __PST__UINT16 CurrMeas_Pim_GainEolAvrgCntrPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_GainEolAvrgCntrPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrEolCalStPrev(void)
{
    extern __PST__UINT8 CurrMeas_Pim_MotCurrEolCalStPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrEolCalStPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrEolGainA(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrEolGainA;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrEolGainA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrEolGainB(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrEolGainB;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrEolGainB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrEolGainC(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrEolGainC;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrEolGainC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrEolOffsProcFlg(void)
{
    extern __PST__UINT8 CurrMeas_Pim_MotCurrEolOffsProcFlg;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrEolOffsProcFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsDeltaA(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsDeltaA;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsDeltaA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsDeltaB(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsDeltaB;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsDeltaB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsDeltaC(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsDeltaC;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsDeltaC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsHiAvrgA(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsHiAvrgA;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsHiAvrgA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsHiAvrgB(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsHiAvrgB;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsHiAvrgB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsHiAvrgC(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsHiAvrgC;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsHiAvrgC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsLoAvrgA(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsLoAvrgA;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsLoAvrgA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsLoAvrgB(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsLoAvrgB;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsLoAvrgB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsLoAvrgC(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsLoAvrgC;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsLoAvrgC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsZeroAvrgA(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsZeroAvrgA;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsZeroAvrgA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsZeroAvrgB(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsZeroAvrgB;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsZeroAvrgB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsZeroAvrgC(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrOffsZeroAvrgC;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrOffsZeroAvrgC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrSumAPrev(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrSumAPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrSumAPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrSumBPrev(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrSumBPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrSumBPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrSumCPrev(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_MotCurrSumCPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrSumCPrev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_Ntc5DErrCnt2MilliSecPrev(void)
{
    extern __PST__UINT16 CurrMeas_Pim_Ntc5DErrCnt2MilliSecPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_Ntc5DErrCnt2MilliSecPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_OffsEolAvrgCntrPrev(void)
{
    extern __PST__UINT16 CurrMeas_Pim_OffsEolAvrgCntrPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_OffsEolAvrgCntrPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_TmpMotCurrAdcVlySum1Prev(void)
{
    extern __PST__FLOAT32 CurrMeas_Pim_TmpMotCurrAdcVlySum1Prev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_TmpMotCurrAdcVlySum1Prev = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_WrmIninTestCmplPrev(void)
{
    extern __PST__UINT8 CurrMeas_Pim_WrmIninTestCmplPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_WrmIninTestCmplPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyA(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrAdcVlyA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyB(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrAdcVlyB;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyC(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrAdcVlyC;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasMinRqrdPhaOnTi(void)
{
    extern __PST__g__35 CurrMeas_Cal_CurrMeasMinRqrdPhaOnTi;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasMinRqrdPhaOnTi = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_CurrMeasMotAgCompuDly(void)
{
    extern __PST__g__35 CurrMeas_Cal_CurrMeasMotAgCompuDly;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_CurrMeasMotAgCompuDly = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_CurrMeas_Cal_SysGlbPrmMotPoleCnt(void)
{
    extern __PST__g__36 CurrMeas_Cal_SysGlbPrmMotPoleCnt;
    
    /* initialization with random value */
    {
        CurrMeas_Cal_SysGlbPrmMotPoleCnt = _main_gen_init_g36();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCtrlNtc5DErrCntPrev(void)
{
    extern __PST__UINT16 CurrMeas_Pim_MotCtrlNtc5DErrCntPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCtrlNtc5DErrCntPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_MotCurrRollgCnt1Prev(void)
{
    extern __PST__UINT8 CurrMeas_Pim_MotCurrRollgCnt1Prev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_MotCurrRollgCnt1Prev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Pim_PhaOnTiErrCntPrev(void)
{
    extern __PST__UINT16 CurrMeas_Pim_PhaOnTiErrCntPrev;
    
    /* initialization with random value */
    {
        CurrMeas_Pim_PhaOnTiErrCntPrev = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlBrdgVltg(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlBrdgVltg;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlBrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlCurrMeasWrmIninTestCmpl(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlCurrMeasWrmIninTestCmpl;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlCurrMeasWrmIninTestCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlDiagcStsIvtr1Inactv(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlDiagcStsIvtr1Inactv;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlDiagcStsIvtr1Inactv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElec(void)
{
    extern __PST__UINT16 MOTCTRLMGR_MotCtrlMotAgElec;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgElec = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyAAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrAdcVlyAAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyAAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyBAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrAdcVlyBAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyBAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyCAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrAdcVlyCAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyCAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotElecMeclPolarity(void)
{
    extern __PST__SINT8 MOTCTRLMGR_MotCtrlMotElecMeclPolarity;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotElecMeclPolarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVelMrf(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotVelMrf;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotVelMrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiA = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiB;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiB = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiC;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiC = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPwmPerd(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPwmPerd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPwmPerd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlSysSt(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlSysSt;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlSysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdA(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdB(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdB;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdC(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdC;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolGainCalSetABC_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 CurrMeas_Srv_CurrMeasEolGainCalSetABC_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        CurrMeas_Srv_CurrMeasEolGainCalSetABC_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolGainCalSetABC_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 CurrMeas_Srv_CurrMeasEolGainCalSetABC_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        CurrMeas_Srv_CurrMeasEolGainCalSetABC_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolGainCalSetABC_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 CurrMeas_Srv_CurrMeasEolGainCalSetABC_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        CurrMeas_Srv_CurrMeasEolGainCalSetABC_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolOffsCalSetABC_GetErrorStatus_RequestResultPtr(void)
{
    extern __PST__UINT8 CurrMeas_Srv_CurrMeasEolOffsCalSetABC_GetErrorStatus_RequestResultPtr;
    
    /* initialization with random value */
    {
        CurrMeas_Srv_CurrMeasEolOffsCalSetABC_GetErrorStatus_RequestResultPtr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolOffsCalSetABC_GetErrorStatus_Return(void)
{
    extern __PST__UINT8 CurrMeas_Srv_CurrMeasEolOffsCalSetABC_GetErrorStatus_Return;
    
    /* initialization with random value */
    {
        CurrMeas_Srv_CurrMeasEolOffsCalSetABC_GetErrorStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolOffsCalSetABC_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 CurrMeas_Srv_CurrMeasEolOffsCalSetABC_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        CurrMeas_Srv_CurrMeasEolOffsCalSetABC_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 CurrMeas_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        CurrMeas_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 CurrMeas_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        CurrMeas_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 CurrMeas_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        CurrMeas_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasEolGainStsReq_CurrMeasEolGainSt(void)
{
    extern __PST__UINT8 CurrMeas_Cli_CurrMeasEolGainStsReq_CurrMeasEolGainSt;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasEolGainStsReq_CurrMeasEolGainSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasEolOffsStsReq_CurrMeasEolOffsSt(void)
{
    extern __PST__UINT8 CurrMeas_Cli_CurrMeasEolOffsStsReq_CurrMeasEolOffsSt;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasEolOffsStsReq_CurrMeasEolOffsSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainA(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainA;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainB(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainB;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainC(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainC;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainA(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainA;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainB(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainB;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainC(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainC;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasGainWrReqSts(void)
{
    extern __PST__UINT8 CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasGainWrReqSts;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasGainWrReqSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasEolOffsHiBrdgVltg(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasEolOffsHiBrdgVltg;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasEolOffsHiBrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifA(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifA;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifB(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifB;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifC(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifC;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgA(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgA;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgB(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgB;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgC(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgC;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasEolOffsHiBrdgVltg(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasEolOffsHiBrdgVltg;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasEolOffsHiBrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifA(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifA;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifB(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifB;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifC(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifC;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgA(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgA;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgB(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgB;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgC(void)
{
    extern __PST__FLOAT32 CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgC;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasOffsWrReqSts(void)
{
    extern __PST__UINT8 CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasOffsWrReqSts;
    
    /* initialization with random value */
    {
        CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasOffsWrReqSts = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable CurrMeas_Ip_BrdgVltg */
    _main_gen_init_sym_CurrMeas_Ip_BrdgVltg();
    
    /* init for variable CurrMeas_Ip_DiagcStsIvtr1Inactv */
    _main_gen_init_sym_CurrMeas_Ip_DiagcStsIvtr1Inactv();
    
    /* init for variable CurrMeas_Ip_MotCurrAdcVlyA */
    _main_gen_init_sym_CurrMeas_Ip_MotCurrAdcVlyA();
    
    /* init for variable CurrMeas_Ip_MotCurrAdcVlyB */
    _main_gen_init_sym_CurrMeas_Ip_MotCurrAdcVlyB();
    
    /* init for variable CurrMeas_Ip_MotCurrAdcVlyC */
    _main_gen_init_sym_CurrMeas_Ip_MotCurrAdcVlyC();
    
    /* init for variable CurrMeas_Ip_MotVelMrf */
    _main_gen_init_sym_CurrMeas_Ip_MotVelMrf();
    
    /* init for variable CurrMeas_Ip_Ntc5DErrCnt */
    _main_gen_init_sym_CurrMeas_Ip_Ntc5DErrCnt();
    
    /* init for variable CurrMeas_Ip_StrtUpSt */
    _main_gen_init_sym_CurrMeas_Ip_StrtUpSt();
    
    /* init for variable CurrMeas_Ip_SysSt */
    _main_gen_init_sym_CurrMeas_Ip_SysSt();
    
    /* init for variable CurrMeas_Ip_VehSpd */
    _main_gen_init_sym_CurrMeas_Ip_VehSpd();
    
    /* init for variable CurrMeas_Ip_VehSpdVld */
    _main_gen_init_sym_CurrMeas_Ip_VehSpdVld();
    
    /* init for variable CurrMeas_Op_CurrMeasWrmIninTestCmpl : useless (never read) */

    /* init for variable CurrMeas_Op_MotCurrEolCalSt : useless (never read) */

    /* init for variable CurrMeas_Op_MotCurrQlfr1 : useless (never read) */

    /* init for variable CurrMeas_Cal_CurrMeasEolGainMax */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolGainMax();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolGainMin */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolGainMin();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolGainNom */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolGainNom();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolGainNrOfSample */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolGainNrOfSample();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolGainNumer */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolGainNumer();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolMaxMotVel */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolMaxMotVel();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolOffsHiBrdgVltgMin */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsHiBrdgVltgMin();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolOffsHiCmuOffs */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsHiCmuOffs();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolOffsLoCmuOffs */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsLoCmuOffs();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolOffsMax */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsMax();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolOffsMin */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsMin();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolOffsNom */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsNom();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolOffsNrOfSample */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolOffsNrOfSample();
    
    /* init for variable CurrMeas_Cal_CurrMeasEolTranCntrThd */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasEolTranCntrThd();
    
    /* init for variable CurrMeas_Cal_CurrMeasMotCurrAdcVlyWrmIninMax */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasMotCurrAdcVlyWrmIninMax();
    
    /* init for variable CurrMeas_Cal_CurrMeasMotCurrAdcVlyWrmIninMin */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasMotCurrAdcVlyWrmIninMin();
    
    /* init for variable CurrMeas_Cal_CurrMeasNtc0x05DFailStep */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasNtc0x05DFailStep();
    
    /* init for variable CurrMeas_Cal_CurrMeasNtc0x05DPassStep */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasNtc0x05DPassStep();
    
    /* init for variable CurrMeas_Pim_CurrMeasEolGainCalSetABC */
    _main_gen_init_sym_CurrMeas_Pim_CurrMeasEolGainCalSetABC();
    
    /* init for variable CurrMeas_Pim_CurrMeasEolOffsCalSetABC */
    _main_gen_init_sym_CurrMeas_Pim_CurrMeasEolOffsCalSetABC();
    
    /* init for variable CurrMeas_Pim_BrdgVltgSumPrev */
    _main_gen_init_sym_CurrMeas_Pim_BrdgVltgSumPrev();
    
    /* init for variable CurrMeas_Pim_EolGainSts */
    _main_gen_init_sym_CurrMeas_Pim_EolGainSts();
    
    /* init for variable CurrMeas_Pim_EolGainTranCntrPrev */
    _main_gen_init_sym_CurrMeas_Pim_EolGainTranCntrPrev();
    
    /* init for variable CurrMeas_Pim_EolOffsHiBrdgVltg */
    _main_gen_init_sym_CurrMeas_Pim_EolOffsHiBrdgVltg();
    
    /* init for variable CurrMeas_Pim_EolOffsSts */
    _main_gen_init_sym_CurrMeas_Pim_EolOffsSts();
    
    /* init for variable CurrMeas_Pim_EolOffsTranCntrPrev */
    _main_gen_init_sym_CurrMeas_Pim_EolOffsTranCntrPrev();
    
    /* init for variable CurrMeas_Pim_GainEolAvrgCntrPrev */
    _main_gen_init_sym_CurrMeas_Pim_GainEolAvrgCntrPrev();
    
    /* init for variable CurrMeas_Pim_MotCurrEolCalStPrev */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrEolCalStPrev();
    
    /* init for variable CurrMeas_Pim_MotCurrEolGainA */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrEolGainA();
    
    /* init for variable CurrMeas_Pim_MotCurrEolGainB */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrEolGainB();
    
    /* init for variable CurrMeas_Pim_MotCurrEolGainC */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrEolGainC();
    
    /* init for variable CurrMeas_Pim_MotCurrEolOffsProcFlg */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrEolOffsProcFlg();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsDeltaA */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsDeltaA();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsDeltaB */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsDeltaB();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsDeltaC */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsDeltaC();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsHiAvrgA */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsHiAvrgA();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsHiAvrgB */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsHiAvrgB();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsHiAvrgC */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsHiAvrgC();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsLoAvrgA */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsLoAvrgA();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsLoAvrgB */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsLoAvrgB();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsLoAvrgC */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsLoAvrgC();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsZeroAvrgA */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsZeroAvrgA();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsZeroAvrgB */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsZeroAvrgB();
    
    /* init for variable CurrMeas_Pim_MotCurrOffsZeroAvrgC */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrOffsZeroAvrgC();
    
    /* init for variable CurrMeas_Pim_MotCurrSumAPrev */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrSumAPrev();
    
    /* init for variable CurrMeas_Pim_MotCurrSumBPrev */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrSumBPrev();
    
    /* init for variable CurrMeas_Pim_MotCurrSumCPrev */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrSumCPrev();
    
    /* init for variable CurrMeas_Pim_Ntc5DErrCnt2MilliSecPrev */
    _main_gen_init_sym_CurrMeas_Pim_Ntc5DErrCnt2MilliSecPrev();
    
    /* init for variable CurrMeas_Pim_OffsEolAvrgCntrPrev */
    _main_gen_init_sym_CurrMeas_Pim_OffsEolAvrgCntrPrev();
    
    /* init for variable CurrMeas_Pim_TmpMotCurrAdcVlySum1Prev */
    _main_gen_init_sym_CurrMeas_Pim_TmpMotCurrAdcVlySum1Prev();
    
    /* init for variable CurrMeas_Pim_WrmIninTestCmplPrev */
    _main_gen_init_sym_CurrMeas_Pim_WrmIninTestCmplPrev();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyA();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyB */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyB();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyC */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyC();
    
    /* init for variable CurrMeas_Cal_CurrMeasMinRqrdPhaOnTi */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasMinRqrdPhaOnTi();
    
    /* init for variable CurrMeas_Cal_CurrMeasMotAgCompuDly */
    _main_gen_init_sym_CurrMeas_Cal_CurrMeasMotAgCompuDly();
    
    /* init for variable CurrMeas_Cal_SysGlbPrmMotPoleCnt */
    _main_gen_init_sym_CurrMeas_Cal_SysGlbPrmMotPoleCnt();
    
    /* init for variable CurrMeas_Pim_MotCtrlNtc5DErrCntPrev */
    _main_gen_init_sym_CurrMeas_Pim_MotCtrlNtc5DErrCntPrev();
    
    /* init for variable CurrMeas_Pim_MotCurrRollgCnt1Prev */
    _main_gen_init_sym_CurrMeas_Pim_MotCurrRollgCnt1Prev();
    
    /* init for variable CurrMeas_Pim_PhaOnTiErrCntPrev */
    _main_gen_init_sym_CurrMeas_Pim_PhaOnTiErrCntPrev();
    
    /* init for variable MOTCTRLMGR_MotCtrlBrdgVltg */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlBrdgVltg();
    
    /* init for variable MOTCTRLMGR_MotCtrlCurrMeasWrmIninTestCmpl */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlCurrMeasWrmIninTestCmpl();
    
    /* init for variable MOTCTRLMGR_MotCtrlDiagcStsIvtr1Inactv */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlDiagcStsIvtr1Inactv();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgElec */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElec();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyAAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyAAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyBAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyBAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyCAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyCAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotElecMeclPolarity */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotElecMeclPolarity();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotVelMrf */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVelMrf();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiB */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiC */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC();
    
    /* init for variable MOTCTRLMGR_MotCtrlPwmPerd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPwmPerd();
    
    /* init for variable MOTCTRLMGR_MotCtrlSysSt */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlSysSt();
    
    /* init for variable MOTCTRLMGR_MotCtrlCurrMeasMotAgCorrd : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdA();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdB */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdB();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdC */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdC();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrRollgCntr1 : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlNtc5DErrCnt : useless (never read) */

    /* init for variable CurrMeas_Srv_CurrMeasEolGainCalSetABC_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolGainCalSetABC_GetErrorStatus_RequestResultPtr();
    
    /* init for variable CurrMeas_Srv_CurrMeasEolGainCalSetABC_GetErrorStatus_Return */
    _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolGainCalSetABC_GetErrorStatus_Return();
    
    /* init for variable CurrMeas_Srv_CurrMeasEolGainCalSetABC_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable CurrMeas_Srv_CurrMeasEolGainCalSetABC_SetRamBlockStatus_Return */
    _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolGainCalSetABC_SetRamBlockStatus_Return();
    
    /* init for variable CurrMeas_Srv_CurrMeasEolOffsCalSetABC_GetErrorStatus_RequestResultPtr */
    _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolOffsCalSetABC_GetErrorStatus_RequestResultPtr();
    
    /* init for variable CurrMeas_Srv_CurrMeasEolOffsCalSetABC_GetErrorStatus_Return */
    _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolOffsCalSetABC_GetErrorStatus_Return();
    
    /* init for variable CurrMeas_Srv_CurrMeasEolOffsCalSetABC_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable CurrMeas_Srv_CurrMeasEolOffsCalSetABC_SetRamBlockStatus_Return */
    _main_gen_init_sym_CurrMeas_Srv_CurrMeasEolOffsCalSetABC_SetRamBlockStatus_Return();
    
    /* init for variable CurrMeas_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable CurrMeas_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_CurrMeas_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable CurrMeas_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_CurrMeas_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable CurrMeas_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable CurrMeas_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable CurrMeas_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable CurrMeas_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable CurrMeas_Srv_SetNtcSts_Return */
    _main_gen_init_sym_CurrMeas_Srv_SetNtcSts_Return();
    
    /* init for variable CurrMeas_Cli_CurrMeasEolGainStsReq_CurrMeasEolGainSt */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasEolGainStsReq_CurrMeasEolGainSt();
    
    /* init for variable CurrMeas_Cli_CurrMeasEolOffsStsReq_CurrMeasEolOffsSt */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasEolOffsStsReq_CurrMeasEolOffsSt();
    
    /* init for variable CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainA */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainA();
    
    /* init for variable CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainB */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainB();
    
    /* init for variable CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainC */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainReadReqSngIvtr_CurrMeasMotCurrGainC();
    
    /* init for variable CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainA */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainA();
    
    /* init for variable CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainB */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainB();
    
    /* init for variable CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainC */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasMotCurrGainC();
    
    /* init for variable CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasGainWrReqSts */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasGainWrReqSngIvtr_CurrMeasGainWrReqSts();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasEolOffsHiBrdgVltg */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasEolOffsHiBrdgVltg();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifA */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifA();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifB */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifB();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifC */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsDifC();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgA */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgA();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgB */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgB();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgC */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsReadReqSngIvtr_CurrMeasMotCurrOffsLoAvrgC();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasEolOffsHiBrdgVltg */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasEolOffsHiBrdgVltg();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifA */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifA();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifB */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifB();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifC */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsDifC();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgA */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgA();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgB */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgB();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgC */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasMotCurrOffsLoAvrgC();
    
    /* init for variable CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasOffsWrReqSts */
    _main_gen_init_sym_CurrMeas_Cli_CurrMeasOffsWrReqSngIvtr_CurrMeasOffsWrReqSts();
    
}
