#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_TmplMonr_Srv_GetRefTmr1MicroSec32bit_RefTmr(void)
{
    extern __PST__UINT32 TmplMonr_Srv_GetRefTmr1MicroSec32bit_RefTmr;
    
    /* initialization with random value */
    {
        TmplMonr_Srv_GetRefTmr1MicroSec32bit_RefTmr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_TmplMonr_Srv_GetTiSpan1MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 TmplMonr_Srv_GetTiSpan1MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        TmplMonr_Srv_GetTiSpan1MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_TmplMonr_Srv_IoHwAb_GetGpioPwrOutpEnaFb_PinSt(void)
{
    extern __PST__UINT8 TmplMonr_Srv_IoHwAb_GetGpioPwrOutpEnaFb_PinSt;
    
    /* initialization with random value */
    {
        TmplMonr_Srv_IoHwAb_GetGpioPwrOutpEnaFb_PinSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Srv_IoHwAb_GetGpioPwrOutpEnaFb_Return(void)
{
    extern __PST__UINT8 TmplMonr_Srv_IoHwAb_GetGpioPwrOutpEnaFb_Return;
    
    /* initialization with random value */
    {
        TmplMonr_Srv_IoHwAb_GetGpioPwrOutpEnaFb_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Srv_IoHwAb_SetGpioTmplMonrWdg_Return(void)
{
    extern __PST__UINT8 TmplMonr_Srv_IoHwAb_SetGpioTmplMonrWdg_Return;
    
    /* initialization with random value */
    {
        TmplMonr_Srv_IoHwAb_SetGpioTmplMonrWdg_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 TmplMonr_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        TmplMonr_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Ip_StrtUpSt(void)
{
    extern __PST__UINT8 TmplMonr_Ip_StrtUpSt;
    
    /* initialization with random value */
    {
        TmplMonr_Ip_StrtUpSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Ip_SysSt(void)
{
    extern __PST__UINT8 TmplMonr_Ip_SysSt;
    
    /* initialization with random value */
    {
        TmplMonr_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Pim_AvrgElpdTiMicroSec(void)
{
    extern __PST__UINT32 TmplMonr_Pim_AvrgElpdTiMicroSec;
    
    /* initialization with random value */
    {
        TmplMonr_Pim_AvrgElpdTiMicroSec = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_TmplMonr_Pim_TmplMonrIninCntr(void)
{
    extern __PST__UINT8 TmplMonr_Pim_TmplMonrIninCntr;
    
    /* initialization with random value */
    {
        TmplMonr_Pim_TmplMonrIninCntr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Pim_TmplMonrIninTestCmplFlg(void)
{
    extern __PST__UINT8 TmplMonr_Pim_TmplMonrIninTestCmplFlg;
    
    /* initialization with random value */
    {
        TmplMonr_Pim_TmplMonrIninTestCmplFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Pim_TmplMonrNtc40PrmByte(void)
{
    extern __PST__UINT8 TmplMonr_Pim_TmplMonrNtc40PrmByte;
    
    /* initialization with random value */
    {
        TmplMonr_Pim_TmplMonrNtc40PrmByte = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Pim_TmplMonrSpiReadWrOrderFlg1(void)
{
    extern __PST__UINT8 TmplMonr_Pim_TmplMonrSpiReadWrOrderFlg1;
    
    /* initialization with random value */
    {
        TmplMonr_Pim_TmplMonrSpiReadWrOrderFlg1 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Pim_TmplMonrSpiReadWrOrderFlg2(void)
{
    extern __PST__UINT8 TmplMonr_Pim_TmplMonrSpiReadWrOrderFlg2;
    
    /* initialization with random value */
    {
        TmplMonr_Pim_TmplMonrSpiReadWrOrderFlg2 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Pim_TmplMonrWdgRstrtCnt(void)
{
    extern __PST__UINT8 TmplMonr_Pim_TmplMonrWdgRstrtCnt;
    
    /* initialization with random value */
    {
        TmplMonr_Pim_TmplMonrWdgRstrtCnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Pim_TrsmErrCntr(void)
{
    extern __PST__UINT16 TmplMonr_Pim_TrsmErrCntr;
    
    /* initialization with random value */
    {
        TmplMonr_Pim_TrsmErrCntr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_TmplMonr_Pim_TrsmErrNtcThd(void)
{
    extern __PST__UINT8 TmplMonr_Pim_TrsmErrNtcThd;
    
    /* initialization with random value */
    {
        TmplMonr_Pim_TrsmErrNtcThd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_TmplMonr_Irv_ElpdTiMicroSec(void)
{
    extern __PST__UINT32 TmplMonr_Irv_ElpdTiMicroSec;
    
    /* initialization with random value */
    {
        TmplMonr_Irv_ElpdTiMicroSec = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable TmplMonr_Srv_CtrlErrOut_PinSt : useless (never read) */

    /* init for variable TmplMonr_Srv_CtrlErrOut_TrigReg : useless (never read) */

    /* init for variable TmplMonr_Srv_GetRefTmr1MicroSec32bit_RefTmr */
    _main_gen_init_sym_TmplMonr_Srv_GetRefTmr1MicroSec32bit_RefTmr();
    
    /* init for variable TmplMonr_Srv_GetTiSpan1MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable TmplMonr_Srv_GetTiSpan1MicroSec32bit_TiSpan */
    _main_gen_init_sym_TmplMonr_Srv_GetTiSpan1MicroSec32bit_TiSpan();
    
    /* init for variable TmplMonr_Srv_IoHwAb_GetGpioPwrOutpEnaFb_PinSt */
    _main_gen_init_sym_TmplMonr_Srv_IoHwAb_GetGpioPwrOutpEnaFb_PinSt();
    
    /* init for variable TmplMonr_Srv_IoHwAb_GetGpioPwrOutpEnaFb_Return */
    _main_gen_init_sym_TmplMonr_Srv_IoHwAb_GetGpioPwrOutpEnaFb_Return();
    
    /* init for variable TmplMonr_Srv_IoHwAb_SetGpioTmplMonrWdg_PinSt : useless (never read) */

    /* init for variable TmplMonr_Srv_IoHwAb_SetGpioTmplMonrWdg_Return */
    _main_gen_init_sym_TmplMonr_Srv_IoHwAb_SetGpioTmplMonrWdg_Return();
    
    /* init for variable TmplMonr_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable TmplMonr_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable TmplMonr_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable TmplMonr_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable TmplMonr_Srv_SetNtcSts_Return */
    _main_gen_init_sym_TmplMonr_Srv_SetNtcSts_Return();
    
    /* init for variable TmplMonr_Ip_StrtUpSt */
    _main_gen_init_sym_TmplMonr_Ip_StrtUpSt();
    
    /* init for variable TmplMonr_Ip_SysSt */
    _main_gen_init_sym_TmplMonr_Ip_SysSt();
    
    /* init for variable TmplMonr_Op_TmplMonrIninTestCmpl : useless (never read) */

    /* init for variable TmplMonr_Pim_AvrgElpdTiMicroSec */
    _main_gen_init_sym_TmplMonr_Pim_AvrgElpdTiMicroSec();
    
    /* init for variable TmplMonr_Pim_TmplMonrIninCntr */
    _main_gen_init_sym_TmplMonr_Pim_TmplMonrIninCntr();
    
    /* init for variable TmplMonr_Pim_TmplMonrIninTestCmplFlg */
    _main_gen_init_sym_TmplMonr_Pim_TmplMonrIninTestCmplFlg();
    
    /* init for variable TmplMonr_Pim_TmplMonrNtc40PrmByte */
    _main_gen_init_sym_TmplMonr_Pim_TmplMonrNtc40PrmByte();
    
    /* init for variable TmplMonr_Pim_TmplMonrSpiReadWrOrderFlg1 */
    _main_gen_init_sym_TmplMonr_Pim_TmplMonrSpiReadWrOrderFlg1();
    
    /* init for variable TmplMonr_Pim_TmplMonrSpiReadWrOrderFlg2 */
    _main_gen_init_sym_TmplMonr_Pim_TmplMonrSpiReadWrOrderFlg2();
    
    /* init for variable TmplMonr_Pim_TmplMonrWdgRstrtCnt */
    _main_gen_init_sym_TmplMonr_Pim_TmplMonrWdgRstrtCnt();
    
    /* init for variable TmplMonr_Pim_TrsmErrCntr */
    _main_gen_init_sym_TmplMonr_Pim_TrsmErrCntr();
    
    /* init for variable TmplMonr_Pim_TrsmErrNtcThd */
    _main_gen_init_sym_TmplMonr_Pim_TrsmErrNtcThd();
    
    /* init for variable TmplMonr_Irv_ElpdTiMicroSec */
    _main_gen_init_sym_TmplMonr_Irv_ElpdTiMicroSec();
    
}
