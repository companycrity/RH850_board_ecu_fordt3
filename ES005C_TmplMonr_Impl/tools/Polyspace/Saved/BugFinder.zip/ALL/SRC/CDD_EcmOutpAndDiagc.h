/* Header file for contract folder of ES005C */


#ifndef CDD_ECMOUTPANDDIAGC_H   /* Multiple include preventer */
#define CDD_ECMOUTPANDDIAGC_H


typedef uint8 TrigReg1;

#define   TRIGREG_MST             (85U)
#define   TRIGREG_CHKR            (170U)
#define   TRIGREG_MSTANDCHKR      (255U)


#endif
