#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__g__30 _main_gen_init_g30(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct Rte_CDS_FordSysSt _main_gen_init_g28(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct Rte_CDS_FordSysSt _main_gen_init_g28(void)
{
    static struct Rte_CDS_FordSysSt x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g10();
        }
        x.Pim_FordVltgOperRamp = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_4[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g10();
        }
        x.Pim_FordVltgOperScar = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g10();
        }
        x.Pim_OperRampRatePrev = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_8[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g10();
        }
        x.Pim_OperScaFctrPrev = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__g__30 _main_gen_init_g30(void)
{
    __PST__g__30 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_FordSysSt(void)
{
    extern __PST__g__25 Rte_Inst_FordSysSt;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_FordSysSt _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_FordSysSt)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_FordSysSt); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g28();
            }
            Rte_Inst_FordSysSt = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_FordSysSt) / 2];
        }
    }
}

static void _main_gen_init_sym_FordSysSt_Ip_SysStWrmIninCmpl(void)
{
    extern __PST__UINT8 FordSysSt_Ip_SysStWrmIninCmpl;
    
    /* initialization with random value */
    {
        FordSysSt_Ip_SysStWrmIninCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Ip_SysStReqEnaOvrd(void)
{
    extern __PST__UINT8 FordSysSt_Ip_SysStReqEnaOvrd;
    
    /* initialization with random value */
    {
        FordSysSt_Ip_SysStReqEnaOvrd = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Ip_LoaSt(void)
{
    extern __PST__UINT8 FordSysSt_Ip_LoaSt;
    
    /* initialization with random value */
    {
        FordSysSt_Ip_LoaSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Ip_SysSt(void)
{
    extern __PST__UINT8 FordSysSt_Ip_SysSt;
    
    /* initialization with random value */
    {
        FordSysSt_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Ip_FordVehSpd(void)
{
    extern __PST__FLOAT32 FordSysSt_Ip_FordVehSpd;
    
    /* initialization with random value */
    {
        FordSysSt_Ip_FordVehSpd = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordSysSt_Ip_FordVehSpdVld(void)
{
    extern __PST__UINT8 FordSysSt_Ip_FordVehSpdVld;
    
    /* initialization with random value */
    {
        FordSysSt_Ip_FordVehSpdVld = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Ip_FordVltgOperSt(void)
{
    extern __PST__UINT8 FordSysSt_Ip_FordVltgOperSt;
    
    /* initialization with random value */
    {
        FordSysSt_Ip_FordVltgOperSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Ip_FordVltgOperRamp(void)
{
    extern __PST__FLOAT32 FordSysSt_Ip_FordVltgOperRamp;
    
    /* initialization with random value */
    {
        FordSysSt_Ip_FordVltgOperRamp = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordSysSt_Ip_FordVltgOperScar(void)
{
    extern __PST__FLOAT32 FordSysSt_Ip_FordVltgOperScar;
    
    /* initialization with random value */
    {
        FordSysSt_Ip_FordVltgOperScar = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_FordSysSt_Cal_NormLimpHomeScar(void)
{
    extern __PST__g__30 FordSysSt_Cal_NormLimpHomeScar;
    
    /* initialization with random value */
    {
        FordSysSt_Cal_NormLimpHomeScar = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordSysSt_Cal_InitLimpHomeScar(void)
{
    extern __PST__g__30 FordSysSt_Cal_InitLimpHomeScar;
    
    /* initialization with random value */
    {
        FordSysSt_Cal_InitLimpHomeScar = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordSysSt_Cal_LimdAssiScar(void)
{
    extern __PST__g__30 FordSysSt_Cal_LimdAssiScar;
    
    /* initialization with random value */
    {
        FordSysSt_Cal_LimdAssiScar = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordSysSt_Cal_LimdAssiRamp(void)
{
    extern __PST__g__30 FordSysSt_Cal_LimdAssiRamp;
    
    /* initialization with random value */
    {
        FordSysSt_Cal_LimdAssiRamp = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordSysSt_Cal_NormLimpHomeRamp(void)
{
    extern __PST__g__30 FordSysSt_Cal_NormLimpHomeRamp;
    
    /* initialization with random value */
    {
        FordSysSt_Cal_NormLimpHomeRamp = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordSysSt_Cal_InitLimpHomeRamp(void)
{
    extern __PST__g__30 FordSysSt_Cal_InitLimpHomeRamp;
    
    /* initialization with random value */
    {
        FordSysSt_Cal_InitLimpHomeRamp = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordSysSt_Cal_LimdAssiRampUpRate(void)
{
    extern __PST__g__30 FordSysSt_Cal_LimdAssiRampUpRate;
    
    /* initialization with random value */
    {
        FordSysSt_Cal_LimdAssiRampUpRate = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordSysSt_Cal_LimdAssiRampUpRateFaild(void)
{
    extern __PST__g__30 FordSysSt_Cal_LimdAssiRampUpRateFaild;
    
    /* initialization with random value */
    {
        FordSysSt_Cal_LimdAssiRampUpRateFaild = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordSysSt_Cal_FullAssiRampUpRate(void)
{
    extern __PST__g__30 FordSysSt_Cal_FullAssiRampUpRate;
    
    /* initialization with random value */
    {
        FordSysSt_Cal_FullAssiRampUpRate = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordSysSt_Cal_ShtdwnRamp(void)
{
    extern __PST__g__30 FordSysSt_Cal_ShtdwnRamp;
    
    /* initialization with random value */
    {
        FordSysSt_Cal_ShtdwnRamp = _main_gen_init_g30();
    }
}

static void _main_gen_init_sym_FordSysSt_Pim_FordEpsFailrPrev(void)
{
    extern __PST__UINT8 FordSysSt_Pim_FordEpsFailrPrev;
    
    /* initialization with random value */
    {
        FordSysSt_Pim_FordEpsFailrPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Pim_FordEpsSysStPrev(void)
{
    extern __PST__UINT8 FordSysSt_Pim_FordEpsSysStPrev;
    
    /* initialization with random value */
    {
        FordSysSt_Pim_FordEpsSysStPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Pim_SysStReqEnaPrev(void)
{
    extern __PST__UINT8 FordSysSt_Pim_SysStReqEnaPrev;
    
    /* initialization with random value */
    {
        FordSysSt_Pim_SysStReqEnaPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Pim_FordSteerModlStsPrev(void)
{
    extern __PST__UINT8 FordSysSt_Pim_FordSteerModlStsPrev;
    
    /* initialization with random value */
    {
        FordSysSt_Pim_FordSteerModlStsPrev = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Srv_GetNtcQlfrSts_NtcQlfr(void)
{
    extern __PST__UINT8 FordSysSt_Srv_GetNtcQlfrSts_NtcQlfr;
    
    /* initialization with random value */
    {
        FordSysSt_Srv_GetNtcQlfrSts_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Srv_GetNtcQlfrSts_Return(void)
{
    extern __PST__UINT8 FordSysSt_Srv_GetNtcQlfrSts_Return;
    
    /* initialization with random value */
    {
        FordSysSt_Srv_GetNtcQlfrSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Srv_GetGpioMcuEna_PinSt(void)
{
    extern __PST__UINT8 FordSysSt_Srv_GetGpioMcuEna_PinSt;
    
    /* initialization with random value */
    {
        FordSysSt_Srv_GetGpioMcuEna_PinSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FordSysSt_Srv_GetGpioMcuEna_Return(void)
{
    extern __PST__UINT8 FordSysSt_Srv_GetGpioMcuEna_Return;
    
    /* initialization with random value */
    {
        FordSysSt_Srv_GetGpioMcuEna_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_FordSysSt */
    _main_gen_init_sym_Rte_Inst_FordSysSt();
    
    /* init for variable FordSysSt_Ip_SysStWrmIninCmpl */
    _main_gen_init_sym_FordSysSt_Ip_SysStWrmIninCmpl();
    
    /* init for variable FordSysSt_Ip_SysStReqEnaOvrd */
    _main_gen_init_sym_FordSysSt_Ip_SysStReqEnaOvrd();
    
    /* init for variable FordSysSt_Ip_LoaSt */
    _main_gen_init_sym_FordSysSt_Ip_LoaSt();
    
    /* init for variable FordSysSt_Ip_SysSt */
    _main_gen_init_sym_FordSysSt_Ip_SysSt();
    
    /* init for variable FordSysSt_Ip_FordVehSpd */
    _main_gen_init_sym_FordSysSt_Ip_FordVehSpd();
    
    /* init for variable FordSysSt_Ip_FordVehSpdVld */
    _main_gen_init_sym_FordSysSt_Ip_FordVehSpdVld();
    
    /* init for variable FordSysSt_Ip_FordVltgOperSt */
    _main_gen_init_sym_FordSysSt_Ip_FordVltgOperSt();
    
    /* init for variable FordSysSt_Ip_FordVltgOperRamp */
    _main_gen_init_sym_FordSysSt_Ip_FordVltgOperRamp();
    
    /* init for variable FordSysSt_Ip_FordVltgOperScar */
    _main_gen_init_sym_FordSysSt_Ip_FordVltgOperScar();
    
    /* init for variable FordSysSt_Op_FordEpsSysSt : useless (never read) */

    /* init for variable FordSysSt_Op_FordPwrSplyEnaReq : useless (never read) */

    /* init for variable FordSysSt_Op_OperScaFctr : useless (never read) */

    /* init for variable FordSysSt_Op_OperRampRate : useless (never read) */

    /* init for variable FordSysSt_Cal_NormLimpHomeScar */
    _main_gen_init_sym_FordSysSt_Cal_NormLimpHomeScar();
    
    /* init for variable FordSysSt_Cal_InitLimpHomeScar */
    _main_gen_init_sym_FordSysSt_Cal_InitLimpHomeScar();
    
    /* init for variable FordSysSt_Cal_LimdAssiScar */
    _main_gen_init_sym_FordSysSt_Cal_LimdAssiScar();
    
    /* init for variable FordSysSt_Cal_LimdAssiRamp */
    _main_gen_init_sym_FordSysSt_Cal_LimdAssiRamp();
    
    /* init for variable FordSysSt_Cal_NormLimpHomeRamp */
    _main_gen_init_sym_FordSysSt_Cal_NormLimpHomeRamp();
    
    /* init for variable FordSysSt_Cal_InitLimpHomeRamp */
    _main_gen_init_sym_FordSysSt_Cal_InitLimpHomeRamp();
    
    /* init for variable FordSysSt_Cal_LimdAssiRampUpRate */
    _main_gen_init_sym_FordSysSt_Cal_LimdAssiRampUpRate();
    
    /* init for variable FordSysSt_Cal_LimdAssiRampUpRateFaild */
    _main_gen_init_sym_FordSysSt_Cal_LimdAssiRampUpRateFaild();
    
    /* init for variable FordSysSt_Cal_FullAssiRampUpRate */
    _main_gen_init_sym_FordSysSt_Cal_FullAssiRampUpRate();
    
    /* init for variable FordSysSt_Cal_ShtdwnRamp */
    _main_gen_init_sym_FordSysSt_Cal_ShtdwnRamp();
    
    /* init for variable FordSysSt_Pim_FordEpsFailrPrev */
    _main_gen_init_sym_FordSysSt_Pim_FordEpsFailrPrev();
    
    /* init for variable FordSysSt_Pim_FordEpsSysStPrev */
    _main_gen_init_sym_FordSysSt_Pim_FordEpsSysStPrev();
    
    /* init for variable FordSysSt_Pim_SysStReqEnaPrev */
    _main_gen_init_sym_FordSysSt_Pim_SysStReqEnaPrev();
    
    /* init for variable FordSysSt_Pim_FordSteerModlStsPrev */
    _main_gen_init_sym_FordSysSt_Pim_FordSteerModlStsPrev();
    
    /* init for variable FordSysSt_Srv_GetNtcQlfrSts_NtcNr : useless (never read) */

    /* init for variable FordSysSt_Srv_GetNtcQlfrSts_NtcQlfr */
    _main_gen_init_sym_FordSysSt_Srv_GetNtcQlfrSts_NtcQlfr();
    
    /* init for variable FordSysSt_Srv_GetNtcQlfrSts_Return */
    _main_gen_init_sym_FordSysSt_Srv_GetNtcQlfrSts_Return();
    
    /* init for variable FordSysSt_Srv_GetGpioMcuEna_PinSt */
    _main_gen_init_sym_FordSysSt_Srv_GetGpioMcuEna_PinSt();
    
    /* init for variable FordSysSt_Srv_GetGpioMcuEna_Return */
    _main_gen_init_sym_FordSysSt_Srv_GetGpioMcuEna_Return();
    
}
